package com.myserver.survivalplus.gui;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.managers.ShopManager;
import com.myserver.survivalplus.models.PlayerShop;
import com.myserver.survivalplus.models.SaleRecord;
import com.myserver.survivalplus.models.ShopListing;
import com.myserver.survivalplus.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

public class ShopGuiManager {
    private final SurvivalPlus plugin;
    public final NamespacedKey keyShopOwner;
    public final NamespacedKey keyListingId;
    public final NamespacedKey keyPresetIcon;

    public ShopGuiManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.keyShopOwner = new NamespacedKey(plugin, "splus_shop_owner");
        this.keyListingId = new NamespacedKey(plugin, "splus_listing_id");
        this.keyPresetIcon = new NamespacedKey(plugin, "splus_preset_icon");
    }

    private List<Material> getPresetIcons() {
        List<Material> list = new ArrayList<>();
        for (String name : plugin.getConfig().getStringList("shop.preset-icons")) {
            Material m = Material.matchMaterial(name);
            if (m != null && m.isItem()) list.add(m);
        }
        if (list.isEmpty()) {
            list.addAll(Arrays.asList(Material.DIAMOND_SWORD, Material.GOLDEN_APPLE, Material.EMERALD, Material.NETHER_STAR));
        }
        return list;
    }

    private ItemStack makeItem(Material mat, String name, List<String> lore, boolean glow) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(TextUtil.color(name));
        if (lore != null && !lore.isEmpty()) {
            meta.lore(TextUtil.colorList(lore));
        }
        if (glow) meta.setEnchantmentGlintOverride(true);
        item.setItemMeta(meta);
        return item;
    }

    private void fillBottomBar(Inventory inv, int startSlot) {
        ItemStack glass = makeItem(Material.GRAY_STAINED_GLASS_PANE, " ", null, false);
        for (int i = startSlot; i < inv.getSize(); i++) {
            inv.setItem(i, glass);
        }
    }

    public void openDirectory(Player viewer, int page, ShopManager.SortMode sortMode) {
        List<PlayerShop> visible = plugin.getShopManager().getVisibleShops(sortMode);
        int perPage = 45;
        int totalPages = Math.max(1, (int) Math.ceil((double) visible.size() / perPage));
        int safePage = Math.max(0, Math.min(page, totalPages - 1));

        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.SHOP_DIRECTORY, safePage, sortMode, null, null, 0, null);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color("&8متاجر اللاعبين &7(" + (safePage + 1) + "/" + totalPages + ")"));

        int start = safePage * perPage;
        int end = Math.min(start + perPage, visible.size());
        String sym = plugin.getCurrencySymbol();

        for (int i = start; i < end; i++) {
            PlayerShop shop = visible.get(i);
            inv.setItem(i - start, buildShopDirectoryIcon(shop));
        }

        if (visible.isEmpty()) {
            inv.setItem(22, makeItem(Material.BARRIER, "&cلا توجد متاجر مفتوحة حالياً!", Arrays.asList(
                    "&7كن أول من يفتتح متجره في السيرفر!",
                    "&7امسك أي غرض واكتب &e/متجر بيع <السعر>",
                    "&7أو اضغط على &aلوحة تحكم متجرك &7بالأسفل."
            ), false));
        }

        fillBottomBar(inv, 45);

        if (safePage > 0) inv.setItem(45, makeItem(Material.ARROW, "&e⬅ الصفحة السابقة", null, false));

        inv.setItem(47, makeItem(Material.HOPPER, "&bترتيب المتاجر: &e" + sortMode.getDisplay(), Arrays.asList(
                "&7اضغط لتبديل طريقة الترتيب:",
                "&8• &fالأكثر مبيعاً",
                "&8• &fالأكثر إعجاباً",
                "&8• &fالأحدث إضافة",
                "&8• &fالأكثر سلعاً"
        ), false));

        inv.setItem(49, makeItem(Material.ENDER_CHEST, "&a&lمتجري ولوحة التحكم", Arrays.asList(
                "&7أدر سلعك، شاهد أرباحك وسجل مبيعاتك،",
                "&7وغيّر أيقونة واسم ووصف متجرك!",
                "",
                "&eاضغط لفتح لوحة التحكم"
        ), true));

        double bal = plugin.getEconomy().getBalance(viewer);
        inv.setItem(51, makeItem(Material.GOLD_INGOT, "&6رصيدك الحالي: &e" + TextUtil.formatMoney(bal, sym), Arrays.asList(
                "&7لإضافة سلعة لمتجرك:",
                "&fامسك الغرض في يدك واكتب:",
                "&a/shop sell <السعر> &7أو &a/متجر بيع <السعر>"
        ), false));

        if (safePage < totalPages - 1) inv.setItem(53, makeItem(Material.ARROW, "&eالصفحة التالية ➡", null, false));

        viewer.openInventory(inv);
    }

    private ItemStack buildShopDirectoryIcon(PlayerShop shop) {
        ItemStack item;
        if (shop.getIconMaterial() != null) {
            item = new ItemStack(shop.getIconMaterial());
        } else {
            item = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta skull = (SkullMeta) item.getItemMeta();
            OfflinePlayer offline = Bukkit.getOfflinePlayer(shop.getOwnerUuid());
            skull.setOwningPlayer(offline);
            item.setItemMeta(skull);
        }

        ItemMeta meta = item.getItemMeta();
        boolean featured = shop.isFeatured();
        String title = (featured ? "&6★ &l" : "") + shop.getCustomName() + (featured ? " &6★" : "");
        meta.displayName(TextUtil.color(title));

        boolean online = Bukkit.getPlayer(shop.getOwnerUuid()) != null;
        List<String> lore = new ArrayList<>();
        if (featured) lore.add("&6✦ متجر مميز ومروّج ✦");
        lore.add(shop.getDescription());
        lore.add("&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        lore.add("&7المالك: &f" + shop.getOwnerName() + (online ? " &a● متصل" : " &8● غير متصل"));
        lore.add("&7السلع المتوفرة: &a" + shop.getListings().size());
        lore.add("&7إجمالي المبيعات: &b" + shop.getTotalItemsSold() + " &8| &7الإعجابات: &c❤ " + shop.getLikes().size());
        lore.add("&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        lore.add("&eاضغط لفتح المتجر والتسوق");

        meta.lore(TextUtil.colorList(lore));
        if (featured) meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(keyShopOwner, PersistentDataType.STRING, shop.getOwnerUuid().toString());
        item.setItemMeta(meta);
        return item;
    }

    public void openPlayerShop(Player viewer, UUID ownerUuid, boolean countView) {
        PlayerShop shop = plugin.getShopManager().getShop(ownerUuid);
        if (shop == null) return;
        boolean isOwner = viewer.getUniqueId().equals(ownerUuid);
        if (!shop.isOpen() && !isOwner) return;
        if (countView && !isOwner) shop.incrementViews();

        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.PLAYER_SHOP, 0, ShopManager.SortMode.TOP_SALES, ownerUuid, null, 0, null);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(shop.getCustomName()));

        String sym = plugin.getCurrencySymbol();
        int slot = 0;
        for (ShopListing listing : shop.getListings().values()) {
            if (slot >= 45) break;
            ItemStack display = listing.getItem();
            ItemMeta meta = display.getItemMeta();
            List<Component> lore = meta.hasLore() && meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
            lore.add(TextUtil.color("&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            lore.add(TextUtil.color("&7السعر: &6&l" + TextUtil.formatMoney(listing.getPrice(), sym)));
            if (isOwner) {
                lore.add(TextUtil.color("&eكليك يسار: &fتعديل السعر"));
                lore.add(TextUtil.color("&cكليك يمين: &fسحب السلعة لحقيبتك"));
            } else {
                lore.add(TextUtil.color("&aاضغط للشراء والمراجعة"));
            }
            meta.lore(lore);
            meta.getPersistentDataContainer().set(keyListingId, PersistentDataType.STRING, listing.getId());
            display.setItemMeta(meta);
            inv.setItem(slot++, display);
        }

        fillBottomBar(inv, 45);
        inv.setItem(45, makeItem(Material.ARROW, "&c⬅ العودة لسوق اللاعبين", null, false));

        if (!isOwner) {
            boolean liked = shop.getLikes().contains(viewer.getUniqueId());
            inv.setItem(48, makeItem(liked ? Material.RED_DYE : Material.PINK_DYE,
                    liked ? "&c❤ أعجبك هذا المتجر" : "&d♡ أعجبني هذا المتجر",
                    Arrays.asList("&7إجمالي الإعجابات: &c" + shop.getLikes().size(), "&eاضغط " + (liked ? "لإلغاء الإعجاب" : "لدعم المتجر")),
                    liked));
        }

        inv.setItem(49, makeItem(Material.BOOK, shop.getCustomName(), Arrays.asList(
                shop.getDescription(),
                "&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "&7المالك: &f" + shop.getOwnerName(),
                "&7عدد الزيارات: &e" + shop.getViews(),
                "&7إجمالي المبيعات: &b" + shop.getTotalItemsSold(),
                "&7الإعجابات: &c❤ " + shop.getLikes().size()
        ), false));

        if (isOwner) {
            inv.setItem(50, makeItem(Material.COMPARATOR, "&aلوحة تحكم متجرك", Arrays.asList("&7اضغط لإدارة متجرك وإحصائياته"), true));
        }

        viewer.openInventory(inv);
    }

    public void openConfirmPurchase(Player buyer, PlayerShop shop, ShopListing listing) {
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.SHOP_CONFIRM, 0, ShopManager.SortMode.TOP_SALES,
                shop.getOwnerUuid(), listing.getId(), listing.getPrice(), null);
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color("&8تأكيد عملية الشراء"));

        ItemStack bg = makeItem(Material.BLACK_STAINED_GLASS_PANE, " ", null, false);
        for (int i = 0; i < 27; i++) inv.setItem(i, bg);

        String sym = plugin.getCurrencySymbol();
        double bal = plugin.getEconomy().getBalance(buyer);
        boolean enough = bal >= listing.getPrice();

        inv.setItem(11, makeItem(Material.LIME_STAINED_GLASS_PANE, "&a&l✔ تأكيد الشراء", Arrays.asList(
                "&7البائع: &f" + shop.getOwnerName(),
                "&7المبلغ المطلوب: &6" + TextUtil.formatMoney(listing.getPrice(), sym),
                "&7رصيدك الحالي: " + (enough ? "&a" : "&c") + TextUtil.formatMoney(bal, sym),
                "",
                enough ? "&aاضغط هنا لإتمام الصفقة!" : "&cرصيدك غير كافٍ!"
        ), enough));

        inv.setItem(13, listing.getItem());
        inv.setItem(15, makeItem(Material.RED_STAINED_GLASS_PANE, "&c&l✘ إلغاء والعودة", Arrays.asList(
                "&7اضغط للعودة إلى متجر &e" + shop.getOwnerName()
        ), false));

        buyer.openInventory(inv);
    }

    public void openOwnerDashboard(Player owner) {
        PlayerShop shop = plugin.getShopManager().getOrCreateShop(owner);
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.OWNER_DASHBOARD);
        Inventory inv = Bukkit.createInventory(holder, 45, TextUtil.color("&8لوحة تحكم متجرك"));

        ItemStack bg = makeItem(Material.GRAY_STAINED_GLASS_PANE, " ", null, false);
        for (int i = 0; i < 45; i++) inv.setItem(i, bg);

        String sym = plugin.getCurrencySymbol();
        int maxSlots = plugin.getShopManager().getMaxSlots(owner);

        inv.setItem(10, makeItem(Material.CHEST, "&e&lإدارة سلع متجرك &7(" + shop.getListings().size() + "/" + maxSlots + ")", Arrays.asList(
                "&7شاهد جميع سلعك المعروضة حالياً،",
                "&7عدّل أسعارها مباشرة أو اسحبها لحقيبتك.",
                "",
                "&aاضغط لإدارة السلع"
        ), false));

        inv.setItem(12, makeItem(Material.WRITABLE_BOOK, "&b&lسجل المبيعات والإحصائيات", Arrays.asList(
                "&7إجمالي الأرباح: &6" + TextUtil.formatMoney(shop.getTotalRevenue(), sym),
                "&7إجمالي المبيعات: &a" + shop.getTotalItemsSold() + " عملية",
                "&7زيارات المتجر: &e" + shop.getViews() + " زيارة",
                "&7الإعجابات: &c❤ " + shop.getLikes().size(),
                "",
                "&eاضغط لعرض سجل المبيعات التفصيلي"
        ), true));

        Material currentIcon = shop.getIconMaterial() != null ? shop.getIconMaterial() : Material.PLAYER_HEAD;
        inv.setItem(14, makeItem(currentIcon, "&d&lتخصيص أيقونة المتجر", Arrays.asList(
                "&7غيّر الشكل الذي يظهر لمتجرك في قائمة &e/shop",
                "&7يمكنك اختيار أيقونة جاهزة أو الغرض الممسوك بيدك",
                "&7أو العودة لرأس اللاعب الافتراضي!",
                "",
                "&eاضغط لتغيير الأيقونة"
        ), false));

        double boostCost = plugin.getConfig().getDouble("shop.boost-cost", 500.0);
        int boostHours = plugin.getConfig().getInt("shop.boost-hours", 24);
        List<String> boostLore = new ArrayList<>();
        if (shop.isFeatured()) {
            long rem = (shop.getFeaturedUntil() - System.currentTimeMillis()) / 1000L;
            boostLore.add("&aمتجرك مروّج حالياً!");
            boostLore.add("&7الوقت المتبقي: &e" + TextUtil.formatDuration(rem));
        } else {
            boostLore.add("&7اجعل متجرك يظهر في &6أول قائمة المتاجر");
            boostLore.add("&7مع توهج مميز لمدة &e" + boostHours + " ساعة!");
            boostLore.add("&7التكلفة: &6" + TextUtil.formatMoney(boostCost, sym));
            boostLore.add("");
            boostLore.add("&eاضغط لترويج متجرك الآن");
        }
        inv.setItem(16, makeItem(Material.NETHER_STAR, "&6&l★ ترويج المتجر (Boost)", boostLore, shop.isFeatured()));

        inv.setItem(20, makeItem(Material.NAME_TAG, "&eتعديل اسم المتجر", Arrays.asList(
                "&7الاسم الحالي: " + shop.getCustomName(),
                "&7اضغط واكتب الاسم الجديد في الشات."
        ), false));

        inv.setItem(22, makeItem(Material.OAK_SIGN, "&eتعديل وصف المتجر", Arrays.asList(
                "&7الوصف الحالي: " + shop.getDescription(),
                "&7اضغط واكتب الوصف الجديد في الشات."
        ), false));

        inv.setItem(24, makeItem(shop.isOpen() ? Material.LIME_DYE : Material.RED_DYE,
                shop.isOpen() ? "&aحالة المتجر: مفتوح للزوار" : "&cحالة المتجر: مغلق مؤقتاً",
                Arrays.asList("&7اضغط لتبديل حالة المتجر."), false));

        inv.setItem(31, makeItem(Material.ENDER_EYE, "&bمعاينة متجري", Arrays.asList(
                "&7شاهد كيف يظهر متجرك للآخرين."
        ), false));

        inv.setItem(36, makeItem(Material.ARROW, "&c⬅ العودة لسوق اللاعبين", null, false));
        owner.openInventory(inv);
    }

    public void openOwnerListings(Player owner) {
        PlayerShop shop = plugin.getShopManager().getOrCreateShop(owner);
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.OWNER_LISTINGS);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color("&8إدارة سلع متجرك"));

        String sym = plugin.getCurrencySymbol();
        int slot = 0;
        for (ShopListing listing : shop.getListings().values()) {
            if (slot >= 45) break;
            ItemStack item = listing.getItem();
            ItemMeta meta = item.getItemMeta();
            List<Component> lore = meta.hasLore() && meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
            lore.add(TextUtil.color("&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            lore.add(TextUtil.color("&7السعر الحالي: &6" + TextUtil.formatMoney(listing.getPrice(), sym)));
            lore.add(TextUtil.color("&aكليك يسار: &fتعديل السعر"));
            lore.add(TextUtil.color("&cكليك يمين: &fسحب السلعة وإرجاعها لحقيبتك"));
            meta.lore(lore);
            meta.getPersistentDataContainer().set(keyListingId, PersistentDataType.STRING, listing.getId());
            item.setItemMeta(meta);
            inv.setItem(slot++, item);
        }

        if (shop.getListings().isEmpty()) {
            inv.setItem(22, makeItem(Material.BARRIER, "&cمتجرك فارغ حالياً!", Arrays.asList(
                    "&7لإضافة سلعة جديدة:",
                    "&eامسك الغرض في يدك واكتب &a/متجر بيع <السعر>"
            ), false));
        }

        fillBottomBar(inv, 45);
        inv.setItem(49, makeItem(Material.ARROW, "&c⬅ العودة للوحة التحكم", null, false));
        owner.openInventory(inv);
    }

    public void openSalesLog(Player owner) {
        PlayerShop shop = plugin.getShopManager().getOrCreateShop(owner);
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.OWNER_SALES_LOG);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color("&8سجل مبيعات متجرك"));

        String sym = plugin.getCurrencySymbol();
        int slot = 0;
        for (SaleRecord rec : shop.getSalesHistory()) {
            if (slot >= 45) break;
            inv.setItem(slot++, makeItem(rec.getItemMaterial(), "&e" + rec.getItemName() + " &7(x" + rec.getAmount() + ")", Arrays.asList(
                    "&7المشتري: &f" + rec.getBuyerName(),
                    "&7صافي الربح: &6" + TextUtil.formatMoney(rec.getPrice(), sym),
                    "&7التاريخ: &7" + TextUtil.formatDate(rec.getTimestamp())
            ), false));
        }

        if (shop.getSalesHistory().isEmpty()) {
            inv.setItem(22, makeItem(Material.PAPER, "&7لا توجد مبيعات مسجلة بعد", Arrays.asList(
                    "&7ستظهر هنا كل عملية بيع بتفاصيل المشتري والوقت والمبلغ."
            ), false));
        }

        fillBottomBar(inv, 45);
        inv.setItem(49, makeItem(Material.ARROW, "&c⬅ العودة للوحة التحكم", null, false));
        owner.openInventory(inv);
    }

    public void openIconPicker(Player owner) {
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.OWNER_ICON_PICKER);
        Inventory inv = Bukkit.createInventory(holder, 45, TextUtil.color("&8اختر أيقونة متجرك"));

        ItemStack bg = makeItem(Material.GRAY_STAINED_GLASS_PANE, " ", null, false);
        for (int i = 0; i < 45; i++) inv.setItem(i, bg);

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        sm.setOwningPlayer(owner);
        sm.displayName(TextUtil.color("&eالعودة لرأس اللاعب الافتراضي"));
        sm.lore(TextUtil.colorList(Arrays.asList("&7يعرض رأس شخصيتك في قائمة المتاجر.")));
        head.setItemMeta(sm);
        inv.setItem(11, head);

        ItemStack hand = owner.getInventory().getItemInMainHand();
        Material handMat = hand.getType() != Material.AIR ? hand.getType() : Material.BARRIER;
        inv.setItem(15, makeItem(handMat, "&aاستخدام الغرض الممسوك في يدك", Arrays.asList(
                hand.getType() != Material.AIR
                        ? "&7الغرض الحالي: &e" + TextUtil.getItemFriendlyName(hand)
                        : "&cيدك فارغة حالياً! امسك أي غرض أولاً.",
                "&7(لن يتم سحب الغرض من يدك، الشكل فقط!)"
        ), hand.getType() != Material.AIR));

        List<Material> presets = getPresetIcons();
        int[] presetSlots = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        for (int i = 0; i < Math.min(presets.size(), presetSlots.length); i++) {
            Material mat = presets.get(i);
            ItemStack preset = makeItem(mat, "&bأيقونة جاهزة: &f" + mat.name().toLowerCase().replace('_', ' '),
                    Arrays.asList("&eاضغط لاختيار هذه الأيقونة لمتجرك"), false);
            ItemMeta meta = preset.getItemMeta();
            meta.getPersistentDataContainer().set(keyPresetIcon, PersistentDataType.STRING, mat.name());
            preset.setItemMeta(meta);
            inv.setItem(presetSlots[i], preset);
        }

        inv.setItem(36, makeItem(Material.ARROW, "&c⬅ العودة للوحة التحكم", null, false));
        owner.openInventory(inv);
    }
}
