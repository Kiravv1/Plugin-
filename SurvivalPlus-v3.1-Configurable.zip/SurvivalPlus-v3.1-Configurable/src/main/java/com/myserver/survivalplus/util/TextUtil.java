package com.myserver.survivalplus.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public final class TextUtil {
    private static final LegacyComponentSerializer AMPERSAND = LegacyComponentSerializer.legacyAmpersand();
    private static final LegacyComponentSerializer SECTION = LegacyComponentSerializer.legacySection();
    private static final DecimalFormat MONEY_FORMAT = new DecimalFormat("#,##0.##");
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy/MM/dd HH:mm");

    private TextUtil() {}

    public static Component color(String text) {
        if (text == null) return Component.empty();
        return AMPERSAND.deserialize(text.replace('§', '&'))
                .decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    public static List<Component> colorList(List<String> lines) {
        return lines.stream().map(TextUtil::color).collect(Collectors.toList());
    }

    public static String stripColor(String text) {
        if (text == null) return "";
        return PlainTextComponentSerializer.plainText().serialize(color(text));
    }

    public static String toPlain(Component component) {
        if (component == null) return "";
        return PlainTextComponentSerializer.plainText().serialize(component);
    }

    public static String formatMoney(double amount, String symbol) {
        return MONEY_FORMAT.format(amount) + symbol;
    }

    public static String formatDate(long epochMillis) {
        return DATE_FORMAT.format(new Date(epochMillis));
    }

    public static String formatDuration(long seconds) {
        if (seconds <= 0) return "0 ثانية";
        long hours = seconds / 3600;
        long mins = (seconds % 3600) / 60;
        long secs = seconds % 60;
        StringBuilder sb = new StringBuilder();
        if (hours > 0) sb.append(hours).append(" ساعة ");
        if (mins > 0) sb.append(mins).append(" دقيقة ");
        if (secs > 0 || sb.isEmpty()) sb.append(secs).append(" ثانية");
        return sb.toString().trim();
    }

    public static String getItemFriendlyName(ItemStack item) {
        if (item == null) return "غرض";
        ItemMeta meta = item.getItemMeta();
        if (meta != null && meta.hasDisplayName() && meta.displayName() != null) {
            return SECTION.serialize(meta.displayName());
        }
        String raw = item.getType().name().toLowerCase().replace('_', ' ');
        String[] parts = raw.split(" ");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (!p.isEmpty()) {
                sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }
}
