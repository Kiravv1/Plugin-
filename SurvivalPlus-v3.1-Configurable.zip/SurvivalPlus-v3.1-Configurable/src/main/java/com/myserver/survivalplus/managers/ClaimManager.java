package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.models.ClaimFlag;
import com.myserver.survivalplus.models.RegionClaim;
import com.myserver.survivalplus.models.TrustLevel;
import com.myserver.survivalplus.util.PermissionUtil;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class ClaimManager {
    private final SurvivalPlus plugin;
    private final File file;
    private FileConfiguration config;

    private final Map<String, RegionClaim> topClaims = new LinkedHashMap<>();
    private final Map<UUID, Integer> accruedBlocks = new HashMap<>();
    private final Map<UUID, Integer> bonusBlocks = new HashMap<>();

    public enum WandMode { BASIC, SUBDIVIDE, ADMIN }

    public static class WandSession {
        public Location corner1;
        public RegionClaim resizingClaim;
        public int fixedCornerX;
        public int fixedCornerZ;
    }

    private final Map<UUID, WandMode> wandModes = new HashMap<>();
    private final Map<UUID, WandSession> wandSessions = new HashMap<>();
    private final Set<UUID> adminIgnore = new HashSet<>();
    private final Map<UUID, List<Location>> activeVisualBlocks = new HashMap<>();

    public ClaimManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "claims.yml");
        load();
        startAccrualTask();
    }

    private Material matchMat(String path, Material fallback) {
        Material m = Material.matchMaterial(plugin.getConfig().getString(path, fallback.name()));
        return m != null ? m : fallback;
    }

    public Material getWandMaterial() { return matchMat("claims.wand-material", Material.GOLDEN_SHOVEL); }
    public Material getInspectMaterial() { return matchMat("claims.inspect-material", Material.STICK); }

    public boolean isWorldDisabled(World world) {
        for (String w : plugin.getConfig().getStringList("claims.disabled-worlds")) {
            if (w.equalsIgnoreCase(world.getName())) return true;
        }
        return false;
    }

    public void load() {
        topClaims.clear();
        accruedBlocks.clear();
        bonusBlocks.clear();
        if (!file.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        config = YamlConfiguration.loadConfiguration(file);

        int initBlocks = plugin.getConfig().getInt("claims.initial-blocks", 400);
        ConfigurationSection playersSec = config.getConfigurationSection("players");
        if (playersSec != null) {
            for (String uuidStr : playersSec.getKeys(false)) {
                try {
                    UUID u = UUID.fromString(uuidStr);
                    accruedBlocks.put(u, playersSec.getInt(uuidStr + ".accrued", initBlocks));
                    bonusBlocks.put(u, playersSec.getInt(uuidStr + ".bonus", 0));
                } catch (IllegalArgumentException ignored) {}
            }
        }

        ConfigurationSection claimsSec = config.getConfigurationSection("claims");
        if (claimsSec != null) {
            for (String id : claimsSec.getKeys(false)) {
                RegionClaim claim = readClaimFromSection(id, claimsSec.getConfigurationSection(id), null);
                if (claim != null) {
                    ConfigurationSection subsSec = claimsSec.getConfigurationSection(id + ".subclaims");
                    if (subsSec != null) {
                        for (String subId : subsSec.getKeys(false)) {
                            RegionClaim sub = readClaimFromSection(subId, subsSec.getConfigurationSection(subId), id);
                            if (sub != null) claim.getSubclaims().add(sub);
                        }
                    }
                    topClaims.put(id, claim);
                }
            }
        }
    }

    private RegionClaim readClaimFromSection(String id, ConfigurationSection sec, String parentId) {
        if (sec == null) return null;
        String world = sec.getString("world");
        if (world == null) return null;
        int minX = sec.getInt("minX");
        int minZ = sec.getInt("minZ");
        int maxX = sec.getInt("maxX");
        int maxZ = sec.getInt("maxZ");
        String ownerStr = sec.getString("owner");
        UUID owner = (ownerStr == null || ownerStr.isEmpty()) ? null : UUID.fromString(ownerStr);
        String ownerName = sec.getString("ownerName", "لاعب");

        RegionClaim claim = new RegionClaim(id, world, minX, minZ, maxX, maxZ, owner, ownerName, parentId);
        for (ClaimFlag flag : ClaimFlag.values()) {
            boolean def = plugin.getConfig().getBoolean("claims.default-flags." + flag.getConfigKey(), false);
            claim.setFlag(flag, sec.getBoolean("flags." + flag.getConfigKey(), def));
        }
        ConfigurationSection trustSec = sec.getConfigurationSection("trust");
        if (trustSec != null) {
            for (String tUuid : trustSec.getKeys(false)) {
                try {
                    UUID tu = UUID.fromString(tUuid);
                    TrustLevel lvl = TrustLevel.valueOf(trustSec.getString(tUuid, "BUILD"));
                    claim.getTrustedPlayers().put(tu, lvl);
                } catch (Exception ignored) {}
            }
        }
        return claim;
    }

    public void save() {
        config = new YamlConfiguration();
        Set<UUID> allPlayers = new HashSet<>(accruedBlocks.keySet());
        allPlayers.addAll(bonusBlocks.keySet());
        for (UUID u : allPlayers) {
            config.set("players." + u + ".accrued", getAccruedBlocks(u));
            config.set("players." + u + ".bonus", getBonusBlocks(u));
        }

        for (RegionClaim claim : topClaims.values()) {
            writeClaimToSection("claims." + claim.getId(), claim);
            for (RegionClaim sub : claim.getSubclaims()) {
                writeClaimToSection("claims." + claim.getId() + ".subclaims." + sub.getId(), sub);
            }
        }
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void writeClaimToSection(String path, RegionClaim claim) {
        config.set(path + ".world", claim.getWorldName());
        config.set(path + ".minX", claim.getMinX());
        config.set(path + ".minZ", claim.getMinZ());
        config.set(path + ".maxX", claim.getMaxX());
        config.set(path + ".maxZ", claim.getMaxZ());
        config.set(path + ".owner", claim.getOwnerUuid() != null ? claim.getOwnerUuid().toString() : null);
        config.set(path + ".ownerName", claim.getOwnerName());
        for (ClaimFlag flag : ClaimFlag.values()) {
            config.set(path + ".flags." + flag.getConfigKey(), claim.getFlag(flag));
        }
        for (Map.Entry<UUID, TrustLevel> entry : claim.getTrustedPlayers().entrySet()) {
            config.set(path + ".trust." + entry.getKey(), entry.getValue().name());
        }
    }

    public int getAccruedBlocks(UUID uuid) {
        int init = plugin.getConfig().getInt("claims.initial-blocks", 400);
        return accruedBlocks.computeIfAbsent(uuid, k -> init);
    }

    public int getBonusBlocks(UUID uuid) {
        return bonusBlocks.getOrDefault(uuid, 0);
    }

    public void addBonusBlocks(UUID uuid, int amount) {
        bonusBlocks.put(uuid, Math.max(0, getBonusBlocks(uuid) + amount));
        save();
    }

    public void setBonusBlocks(UUID uuid, int amount) {
        bonusBlocks.put(uuid, Math.max(0, amount));
        save();
    }

    public int getTotalClaimBlocks(UUID uuid) {
        return getAccruedBlocks(uuid) + getBonusBlocks(uuid);
    }

    public int getUsedClaimBlocks(UUID uuid) {
        int used = 0;
        for (RegionClaim c : topClaims.values()) {
            if (uuid.equals(c.getOwnerUuid())) used += c.getArea();
        }
        return used;
    }

    public int getRemainingClaimBlocks(UUID uuid) {
        return getTotalClaimBlocks(uuid) - getUsedClaimBlocks(uuid);
    }

    public List<RegionClaim> getPlayerClaims(UUID uuid) {
        List<RegionClaim> list = new ArrayList<>();
        for (RegionClaim c : topClaims.values()) {
            if (uuid.equals(c.getOwnerUuid())) list.add(c);
        }
        return list;
    }

    public int getMaxClaimsCount(Player player) {
        int def = plugin.getConfig().getInt("claims.max-claims-per-player", 10);
        return PermissionUtil.getMaxNumericPermission(player, "survivalplus.claims.", def, 200);
    }

    private void startAccrualTask() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            int perHour = plugin.getConfig().getInt("claims.blocks-per-hour", 120);
            int maxAccrued = plugin.getConfig().getInt("claims.max-accrued-blocks", 50000);
            int perMinute = Math.max(1, perHour / 60);

            for (Player p : Bukkit.getOnlinePlayers()) {
                int current = getAccruedBlocks(p.getUniqueId());
                if (current < maxAccrued) {
                    accruedBlocks.put(p.getUniqueId(), Math.min(maxAccrued, current + perMinute));
                }
            }
        }, 1200L, 1200L);
    }

    public RegionClaim getTopClaimAt(Location loc) {
        if (loc == null || loc.getWorld() == null) return null;
        return getTopClaimAt(loc.getWorld().getName(), loc.getBlockX(), loc.getBlockZ());
    }

    public RegionClaim getTopClaimAt(String world, int x, int z) {
        for (RegionClaim claim : topClaims.values()) {
            if (claim.containsXZ(world, x, z)) return claim;
        }
        return null;
    }

    public RegionClaim getClaimAt(Location loc) {
        RegionClaim top = getTopClaimAt(loc);
        if (top == null) return null;
        for (RegionClaim sub : top.getSubclaims()) {
            if (sub.contains(loc)) return sub;
        }
        return top;
    }

    public RegionClaim getClaimById(String id) {
        if (topClaims.containsKey(id)) return topClaims.get(id);
        for (RegionClaim top : topClaims.values()) {
            for (RegionClaim sub : top.getSubclaims()) {
                if (sub.getId().equals(id)) return sub;
            }
        }
        return null;
    }

    public boolean isAdminIgnore(Player player) {
        return player.hasPermission("survivalplus.claim.admin") && adminIgnore.contains(player.getUniqueId());
    }

    public boolean toggleAdminIgnore(Player player) {
        if (adminIgnore.contains(player.getUniqueId())) {
            adminIgnore.remove(player.getUniqueId());
            return false;
        }
        adminIgnore.add(player.getUniqueId());
        return true;
    }

    public WandMode getWandMode(UUID uuid) {
        return wandModes.getOrDefault(uuid, WandMode.BASIC);
    }

    public void setWandMode(UUID uuid, WandMode mode) {
        wandModes.put(uuid, mode);
        wandSessions.remove(uuid);
    }

    public boolean hasTrust(Player player, Location loc, TrustLevel required) {
        if (isAdminIgnore(player)) return true;
        RegionClaim top = getTopClaimAt(loc);
        if (top == null) return true;

        UUID uuid = player.getUniqueId();
        if (!top.isAdminClaim() && top.getOwnerUuid().equals(uuid)) return true;

        for (RegionClaim sub : top.getSubclaims()) {
            if (sub.contains(loc)) {
                TrustLevel subLvl = sub.getTrustedPlayers().get(uuid);
                if (subLvl != null && subLvl.isAtLeast(required)) return true;
                TrustLevel topLvl = top.getTrustedPlayers().get(uuid);
                return topLvl != null && topLvl.isAtLeast(required);
            }
        }

        TrustLevel lvl = top.getTrustedPlayers().get(uuid);
        return lvl != null && lvl.isAtLeast(required);
    }

    public boolean canManageClaim(Player player, RegionClaim claim) {
        if (claim == null) return false;
        if (isAdminIgnore(player)) return true;
        if (claim.isAdminClaim()) return player.hasPermission("survivalplus.claim.admin");
        if (claim.getOwnerUuid().equals(player.getUniqueId())) return true;
        TrustLevel lvl = claim.getTrustedPlayers().get(player.getUniqueId());
        return lvl != null && lvl.isAtLeast(TrustLevel.MANAGER);
    }

    public boolean sameOwnerOrTrusted(RegionClaim sourceClaim, RegionClaim targetClaim) {
        if (targetClaim == null) return true;
        if (sourceClaim == null) return false;
        if (Objects.equals(sourceClaim.getOwnerUuid(), targetClaim.getOwnerUuid())) return true;
        if (sourceClaim.getOwnerUuid() != null) {
            TrustLevel lvl = targetClaim.getTrustedPlayers().get(sourceClaim.getOwnerUuid());
            return lvl != null && lvl.isAtLeast(TrustLevel.BUILD);
        }
        return false;
    }

    public void handleWandClick(Player player, Block clickedBlock) {
        if (clickedBlock == null) return;
        World world = clickedBlock.getWorld();
        if (isWorldDisabled(world)) {
            player.sendMessage(plugin.msg("claim.world-disabled"));
            return;
        }

        UUID uuid = player.getUniqueId();
        WandMode mode = getWandMode(uuid);
        WandSession session = wandSessions.computeIfAbsent(uuid, k -> new WandSession());
        int x = clickedBlock.getX();
        int z = clickedBlock.getZ();

        if (session.resizingClaim != null) {
            RegionClaim target = session.resizingClaim;
            session.resizingClaim = null;
            resizeClaim(player, target, session.fixedCornerX, session.fixedCornerZ, x, z);
            return;
        }

        if (session.corner1 == null) {
            RegionClaim existing = getClaimAt(clickedBlock.getLocation());

            if (existing != null && canManageClaim(player, existing) && existing.isCorner(x, z)) {
                session.resizingClaim = existing;
                session.fixedCornerX = existing.getOppositeCornerX(x);
                session.fixedCornerZ = existing.getOppositeCornerZ(z);
                player.sendMessage(plugin.msg("claim.resize-started"));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.4f);
                return;
            }

            if (mode == WandMode.SUBDIVIDE) {
                RegionClaim top = getTopClaimAt(clickedBlock.getLocation());
                if (top == null || !canManageClaim(player, top)) {
                    player.sendMessage(plugin.msg("claim.not-owner"));
                    return;
                }
            } else if (existing != null && !existing.isSubclaim()) {
                player.sendMessage(plugin.msg("claim.already-claimed", "{owner}", existing.getOwnerName()));
                visualizeClaim(player, existing, false);
                return;
            }

            session.corner1 = clickedBlock.getLocation();
            showSingleMarker(player, clickedBlock.getLocation(), matchMat("claims.visual-first-corner", Material.DIAMOND_BLOCK));
            player.sendMessage(plugin.msg("claim.corner1-set", "{x}", String.valueOf(x), "{z}", String.valueOf(z)));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1.3f);
            return;
        }

        Location c1 = session.corner1;
        session.corner1 = null;

        if (!c1.getWorld().equals(world)) {
            player.sendMessage(plugin.msg("claim.world-disabled"));
            return;
        }

        int x1 = c1.getBlockX();
        int z1 = c1.getBlockZ();

        if (mode == WandMode.SUBDIVIDE) {
            createSubclaim(player, world, x1, z1, x, z);
        } else {
            createTopClaim(player, world, x1, z1, x, z, mode == WandMode.ADMIN);
        }
    }

    public boolean createTopClaim(Player player, World world, int x1, int z1, int x2, int z2, boolean adminClaim) {
        if (adminClaim && !player.hasPermission("survivalplus.claim.admin")) {
            player.sendMessage(plugin.msg("general.no-permission"));
            return false;
        }

        int width = Math.abs(x2 - x1) + 1;
        int length = Math.abs(z2 - z1) + 1;
        int area = width * length;

        int minWidth = plugin.getConfig().getInt("claims.min-claim-width", 5);
        int minArea = plugin.getConfig().getInt("claims.min-claim-area", 25);

        if (!adminClaim && (width < minWidth || length < minWidth || area < minArea)) {
            player.sendMessage(plugin.msg("claim.too-small",
                    "{min_width}", String.valueOf(minWidth),
                    "{min_area}", String.valueOf(minArea)));
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return false;
        }

        for (RegionClaim other : topClaims.values()) {
            if (other.overlaps(world.getName(), x1, z1, x2, z2)) {
                player.sendMessage(plugin.msg("claim.overlap", "{owner}", other.getOwnerName()));
                visualizeClaim(player, other, false);
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return false;
            }
        }

        if (!adminClaim) {
            int maxClaims = getMaxClaimsCount(player);
            if (getPlayerClaims(player.getUniqueId()).size() >= maxClaims) {
                player.sendMessage(plugin.msg("claim.max-claims-reached", "{max}", String.valueOf(maxClaims)));
                return false;
            }
            int remaining = getRemainingClaimBlocks(player.getUniqueId());
            if (area > remaining) {
                player.sendMessage(plugin.msg("claim.not-enough-blocks",
                        "{needed}", String.valueOf(area),
                        "{remaining}", String.valueOf(remaining)));
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return false;
            }
        }

        String id = UUID.randomUUID().toString().substring(0, 8);
        RegionClaim claim = new RegionClaim(id, world.getName(), x1, z1, x2, z2,
                adminClaim ? null : player.getUniqueId(),
                adminClaim ? "الإدارة" : player.getName(),
                null);

        for (ClaimFlag flag : ClaimFlag.values()) {
            claim.setFlag(flag, plugin.getConfig().getBoolean("claims.default-flags." + flag.getConfigKey(), false));
        }

        topClaims.put(id, claim);
        save();

        int leftAfter = adminClaim ? 0 : getRemainingClaimBlocks(player.getUniqueId());
        player.sendMessage(plugin.msg("claim.claim-created",
                "{width}", String.valueOf(width),
                "{length}", String.valueOf(length),
                "{area}", String.valueOf(area),
                "{remaining}", String.valueOf(leftAfter)));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.4f);
        visualizeClaim(player, claim, true);
        return true;
    }

    private void createSubclaim(Player player, World world, int x1, int z1, int x2, int z2) {
        RegionClaim parent = getTopClaimAt(world.getName(), x1, z1);
        if (parent == null || !canManageClaim(player, parent)) {
            player.sendMessage(plugin.msg("claim.not-owner"));
            return;
        }
        RegionClaim candidate = new RegionClaim(UUID.randomUUID().toString().substring(0, 8),
                world.getName(), x1, z1, x2, z2, parent.getOwnerUuid(), parent.getOwnerName(), parent.getId());

        if (!candidate.isInside(parent)) {
            player.sendMessage(plugin.msg("claim.overlap", "{owner}", parent.getOwnerName()));
            return;
        }
        for (RegionClaim existingSub : parent.getSubclaims()) {
            if (existingSub.overlaps(world.getName(), x1, z1, x2, z2)) {
                player.sendMessage(plugin.msg("claim.overlap", "{owner}", parent.getOwnerName()));
                return;
            }
        }

        parent.getSubclaims().add(candidate);
        save();
        player.sendMessage(plugin.msg("claim.claim-created",
                "{width}", String.valueOf(candidate.getWidth()),
                "{length}", String.valueOf(candidate.getLength()),
                "{area}", String.valueOf(candidate.getArea()),
                "{remaining}", String.valueOf(getRemainingClaimBlocks(player.getUniqueId()))));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
        visualizeClaim(player, candidate, true);
    }

    public boolean resizeClaim(Player player, RegionClaim claim, int fixedX, int fixedZ, int newX, int newZ) {
        World world = Bukkit.getWorld(claim.getWorldName());
        if (world == null) return false;

        int newWidth = Math.abs(newX - fixedX) + 1;
        int newLength = Math.abs(newZ - fixedZ) + 1;
        int newArea = newWidth * newLength;

        int minWidth = plugin.getConfig().getInt("claims.min-claim-width", 5);
        int minArea = plugin.getConfig().getInt("claims.min-claim-area", 25);

        if (!claim.isAdminClaim() && !claim.isSubclaim() && (newWidth < minWidth || newLength < minWidth || newArea < minArea)) {
            player.sendMessage(plugin.msg("claim.too-small",
                    "{min_width}", String.valueOf(minWidth),
                    "{min_area}", String.valueOf(minArea)));
            return false;
        }

        if (claim.isSubclaim()) {
            RegionClaim parent = topClaims.get(claim.getParentId());
            if (parent == null) return false;
            RegionClaim test = new RegionClaim("test", claim.getWorldName(), fixedX, fixedZ, newX, newZ, null, "", parent.getId());
            if (!test.isInside(parent)) {
                player.sendMessage(plugin.msg("claim.overlap", "{owner}", parent.getOwnerName()));
                return false;
            }
            for (RegionClaim sub : parent.getSubclaims()) {
                if (!sub.getId().equals(claim.getId()) && sub.overlaps(claim.getWorldName(), fixedX, fixedZ, newX, newZ)) {
                    player.sendMessage(plugin.msg("claim.overlap", "{owner}", parent.getOwnerName()));
                    return false;
                }
            }
            claim.setBounds(fixedX, fixedZ, newX, newZ);
            save();
            player.sendMessage(plugin.msg("claim.claim-resized",
                    "{width}", String.valueOf(newWidth),
                    "{length}", String.valueOf(newLength),
                    "{area}", String.valueOf(newArea)));
            visualizeClaim(player, claim, true);
            return true;
        }

        for (RegionClaim other : topClaims.values()) {
            if (!other.getId().equals(claim.getId()) && other.overlaps(claim.getWorldName(), fixedX, fixedZ, newX, newZ)) {
                player.sendMessage(plugin.msg("claim.overlap", "{owner}", other.getOwnerName()));
                visualizeClaim(player, other, false);
                return false;
            }
        }

        RegionClaim test = new RegionClaim("test", claim.getWorldName(), fixedX, fixedZ, newX, newZ, null, "", null);
        for (RegionClaim sub : claim.getSubclaims()) {
            if (!sub.isInside(test)) {
                player.sendMessage(plugin.msg("claim.overlap", "{owner}", claim.getOwnerName()));
                return false;
            }
        }

        int diff = newArea - claim.getArea();
        if (!claim.isAdminClaim() && diff > 0) {
            int rem = getRemainingClaimBlocks(claim.getOwnerUuid());
            if (diff > rem) {
                player.sendMessage(plugin.msg("claim.not-enough-blocks",
                        "{needed}", String.valueOf(diff),
                        "{remaining}", String.valueOf(rem)));
                return false;
            }
        }

        claim.setBounds(fixedX, fixedZ, newX, newZ);
        save();
        player.sendMessage(plugin.msg("claim.claim-resized",
                "{width}", String.valueOf(newWidth),
                "{length}", String.valueOf(newLength),
                "{area}", String.valueOf(newArea)));
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
        visualizeClaim(player, claim, true);
        return true;
    }

    public boolean deleteClaim(Player player, RegionClaim claim) {
        if (claim.isSubclaim()) {
            RegionClaim parent = topClaims.get(claim.getParentId());
            if (parent != null) {
                parent.getSubclaims().removeIf(s -> s.getId().equals(claim.getId()));
                save();
                player.sendMessage(plugin.msg("claim.claim-deleted",
                        "{area}", String.valueOf(claim.getArea()),
                        "{remaining}", String.valueOf(getRemainingClaimBlocks(player.getUniqueId()))));
                return true;
            }
            return false;
        }
        topClaims.remove(claim.getId());
        save();
        int rem = getRemainingClaimBlocks(player.getUniqueId());
        player.sendMessage(plugin.msg("claim.claim-deleted",
                "{area}", String.valueOf(claim.getArea()),
                "{remaining}", String.valueOf(rem)));
        player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5f, 1.3f);
        return true;
    }

    public int deleteAllPlayerClaims(Player player) {
        int before = topClaims.size();
        topClaims.values().removeIf(c -> player.getUniqueId().equals(c.getOwnerUuid()));
        int removed = before - topClaims.size();
        if (removed > 0) save();
        return removed;
    }

    public void giveClaimTools(Player player) {
        ItemStack wand = new ItemStack(getWandMaterial());
        ItemMeta wm = wand.getItemMeta();
        wm.displayName(TextUtil.color("&6&lأداة الحماية (Claiming Wand)"));
        wm.lore(TextUtil.colorList(Arrays.asList(
                "&7اضغط &eكليك يمين &7على الزاوية الأولى للأرض",
                "&7ثم اضغط &eكليك يمين &7على الزاوية المقابلة!",
                "&8• &7كليك يمين على زاوية أرضك لتوسيعها أو تصغيرها."
        )));
        wand.setItemMeta(wm);

        ItemStack stick = new ItemStack(getInspectMaterial());
        ItemMeta sm = stick.getItemMeta();
        sm.displayName(TextUtil.color("&b&lعصا فحص الأراضي (Inspector)"));
        sm.lore(TextUtil.colorList(Arrays.asList(
                "&7اضغط &eكليك يمين &7على أي بلوكة لمعرفة صاحب الأرض",
                "&7وإظهار حدود الحماية ببلوكات الذهب والـ Glowstone."
        )));
        stick.setItemMeta(sm);

        Map<Integer, ItemStack> left = player.getInventory().addItem(wand, stick);
        for (ItemStack item : left.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), item);
        }
    }

    public void showSingleMarker(Player player, Location loc, Material mat) {
        clearVisualBlocks(player);
        BlockData fake = mat.createBlockData();
        player.sendBlockChange(loc, fake);
        activeVisualBlocks.put(player.getUniqueId(), Collections.singletonList(loc));
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                player.sendBlockChange(loc, loc.getBlock().getBlockData());
            }
        }, 200L);
    }

    public void visualizeClaim(Player player, RegionClaim claim, boolean friendly) {
        clearVisualBlocks(player);
        World world = Bukkit.getWorld(claim.getWorldName());
        if (world == null) return;

        Material cornerMat = friendly
                ? matchMat("claims.visual-corner-friendly", Material.GLOWSTONE)
                : matchMat("claims.visual-corner-enemy", Material.NETHERRACK);
        Material edgeMat = friendly
                ? matchMat("claims.visual-edge-friendly", Material.GOLD_BLOCK)
                : matchMat("claims.visual-edge-enemy", Material.REDSTONE_BLOCK);

        BlockData cornerData = cornerMat.createBlockData();
        BlockData edgeData = edgeMat.createBlockData();

        List<Location> shown = new ArrayList<>();
        int minX = claim.getMinX();
        int maxX = claim.getMaxX();
        int minZ = claim.getMinZ();
        int maxZ = claim.getMaxZ();
        int playerY = player.getLocation().getBlockY();

        Set<Long> visitedXZ = new HashSet<>();
        for (int x = minX; x <= maxX; x++) {
            if (x == minX || x == maxX || (x - minX) % 4 == 0) {
                addBorderPoint(player, world, x, minZ, playerY, (x == minX || x == maxX) ? cornerData : edgeData, shown, visitedXZ);
                addBorderPoint(player, world, x, maxZ, playerY, (x == minX || x == maxX) ? cornerData : edgeData, shown, visitedXZ);
            }
        }
        for (int z = minZ; z <= maxZ; z++) {
            if (z == minZ || z == maxZ || (z - minZ) % 4 == 0) {
                addBorderPoint(player, world, minX, z, playerY, (z == minZ || z == maxZ) ? cornerData : edgeData, shown, visitedXZ);
                addBorderPoint(player, world, maxX, z, playerY, (z == minZ || z == maxZ) ? cornerData : edgeData, shown, visitedXZ);
            }
        }

        activeVisualBlocks.put(player.getUniqueId(), shown);
        int seconds = plugin.getConfig().getInt("claims.visual-seconds", 15);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                for (Location l : shown) {
                    player.sendBlockChange(l, l.getBlock().getBlockData());
                }
            }
            activeVisualBlocks.remove(player.getUniqueId(), shown);
        }, seconds * 20L);
    }

    private void addBorderPoint(Player player, World world, int x, int z, int refY, BlockData fakeData, List<Location> shown, Set<Long> visited) {
        long key = (((long) x) << 32) ^ (z & 0xffffffffL);
        if (!visited.add(key)) return;

        int y = findVisibleSurfaceY(world, x, refY, z);
        Location loc = new Location(world, x, y, z);
        player.sendBlockChange(loc, fakeData);
        shown.add(loc);
    }

    private int findVisibleSurfaceY(World world, int x, int refY, int z) {
        int minH = world.getMinHeight();
        int maxH = world.getMaxHeight() - 1;
        int start = Math.max(minH, Math.min(maxH, refY + 3));
        for (int y = start; y >= Math.max(minH, refY - 12); y--) {
            Block b = world.getBlockAt(x, y, z);
            if (b.getType().isSolid()) return y;
        }
        return world.getHighestBlockYAt(x, z);
    }

    public void clearVisualBlocks(Player player) {
        List<Location> old = activeVisualBlocks.remove(player.getUniqueId());
        if (old != null && player.isOnline()) {
            for (Location l : old) {
                player.sendBlockChange(l, l.getBlock().getBlockData());
            }
        }
    }

    public List<RegionClaim> getNearbyClaims(Location center, int radius) {
        List<RegionClaim> result = new ArrayList<>();
        String world = center.getWorld().getName();
        int cx = center.getBlockX();
        int cz = center.getBlockZ();
        for (RegionClaim c : topClaims.values()) {
            if (c.overlaps(world, cx - radius, cz - radius, cx + radius, cz + radius)) {
                result.add(c);
            }
        }
        return result;
    }

    public void cleanupPlayer(UUID uuid) {
        wandSessions.remove(uuid);
        wandModes.remove(uuid);
        adminIgnore.remove(uuid);
        activeVisualBlocks.remove(uuid);
    }
}
