package com.myserver.survivalplus.commands;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.managers.ClaimManager;
import com.myserver.survivalplus.models.RegionClaim;
import com.myserver.survivalplus.models.TrustLevel;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class ClaimCommand implements CommandExecutor, TabCompleter {
    private final SurvivalPlus plugin;

    public ClaimCommand(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("general.players-only"));
            return true;
        }

        String cmd = command.getName().toLowerCase();
        ClaimManager cm = plugin.getClaimManager();
        RegionClaim currentClaim = cm.getClaimAt(player.getLocation());
        RegionClaim topClaim = cm.getTopClaimAt(player.getLocation());

        switch (cmd) {
            case "claimwand" -> {
                cm.giveClaimTools(player);
                int rem = cm.getRemainingClaimBlocks(player.getUniqueId());
                player.sendMessage(plugin.msg("claim.wand-given", "{blocks}", String.valueOf(rem)));
            }

            case "claim" -> {
                if (args.length > 0 && (args[0].equalsIgnoreCase("wand") || args[0].equals("واند") || args[0].equals("اداة"))) {
                    cm.giveClaimTools(player);
                    int rem = cm.getRemainingClaimBlocks(player.getUniqueId());
                    player.sendMessage(plugin.msg("claim.wand-given", "{blocks}", String.valueOf(rem)));
                    return true;
                }
                if (args.length > 0 && (args[0].equalsIgnoreCase("menu") || args[0].equals("ادارة"))) {
                    plugin.getClaimGuiManager().openClaimMenu(player, topClaim);
                    return true;
                }
                int radius = 5;
                if (args.length > 0) {
                    try {
                        radius = Math.max(2, Math.min(50, Integer.parseInt(args[0])));
                    } catch (NumberFormatException e) {
                        return true;
                    }
                }
                Location loc = player.getLocation();
                cm.createTopClaim(player, loc.getWorld(),
                        loc.getBlockX() - radius, loc.getBlockZ() - radius,
                        loc.getBlockX() + radius, loc.getBlockZ() + radius,
                        cm.getWandMode(player.getUniqueId()) == ClaimManager.WandMode.ADMIN);
            }

            case "abandonclaim" -> {
                if (currentClaim == null) {
                    player.sendMessage(plugin.msg("claim.not-in-claim"));
                    return true;
                }
                if (!cm.canManageClaim(player, currentClaim)) {
                    player.sendMessage(plugin.msg("claim.not-owner"));
                    return true;
                }
                cm.deleteClaim(player, currentClaim);
            }

            case "abandonallclaims" -> {
                if (args.length == 0 || (!args[0].equalsIgnoreCase("confirm") && !args[0].equals("تاكيد") && !args[0].equals("تأكيد"))) {
                    player.sendMessage(TextUtil.color("&cتحذير: للتأكيد اكتب &e/abandonallclaims confirm &cأو &e/حذف_كل_الحمايات تاكيد"));
                    return true;
                }
                int count = cm.deleteAllPlayerClaims(player);
                player.sendMessage(TextUtil.color("&eتم حذف &c" + count + " &eأرض محمية واسترجاع جميع بلوكاتك."));
            }

            case "claimslist" -> {
                UUID targetUuid = player.getUniqueId();
                String targetName = player.getName();
                if (args.length > 0 && player.hasPermission("survivalplus.claim.admin")) {
                    OfflinePlayer op = Bukkit.getOfflinePlayer(args[0]);
                    targetUuid = op.getUniqueId();
                    targetName = args[0];
                }
                List<RegionClaim> list = cm.getPlayerClaims(targetUuid);
                int total = cm.getTotalClaimBlocks(targetUuid);
                int used = cm.getUsedClaimBlocks(targetUuid);
                int rem = total - used;

                player.sendMessage(TextUtil.color("&8&m----------&r &6أراضي " + targetName + " &8&m----------"));
                player.sendMessage(TextUtil.color("&7إجمالي الرصيد: &e" + total + " &8| &7المستخدم: &c" + used + " &8| &7المتاح: &a" + rem + " بلوكة"));
                int idx = 1;
                for (RegionClaim c : list) {
                    player.sendMessage(TextUtil.color("&e" + (idx++) + ". &fالعالم: &b" + c.getWorldName()
                            + " &8| &fالإحداثيات: &a" + c.getCenterCoords()
                            + " &8| &fالمساحة: &6" + c.getWidth() + "x" + c.getLength() + " (" + c.getArea() + ")"));
                }
            }

            case "extendclaim" -> {
                if (topClaim == null) {
                    player.sendMessage(plugin.msg("claim.not-in-claim"));
                    return true;
                }
                if (!cm.canManageClaim(player, topClaim)) {
                    player.sendMessage(plugin.msg("claim.not-owner"));
                    return true;
                }
                if (args.length < 1) return true;
                int amount;
                try {
                    amount = Integer.parseInt(args[0]);
                    if (amount == 0) throw new NumberFormatException();
                } catch (NumberFormatException e) {
                    return true;
                }

                BlockFace facing = player.getFacing();
                int minX = topClaim.getMinX();
                int maxX = topClaim.getMaxX();
                int minZ = topClaim.getMinZ();
                int maxZ = topClaim.getMaxZ();

                switch (facing) {
                    case NORTH -> minZ -= amount;
                    case SOUTH -> maxZ += amount;
                    case WEST -> minX -= amount;
                    case EAST -> maxX += amount;
                    default -> { return true; }
                }
                cm.resizeClaim(player, topClaim, minX, minZ, maxX, maxZ);
            }

            case "subdivideclaims" -> {
                cm.setWandMode(player.getUniqueId(), ClaimManager.WandMode.SUBDIVIDE);
                player.sendMessage(TextUtil.color("&b✔ وضع المناطق الفرعية (Subclaims) مفعل الآن. للعودة: &e/حماية_عادية"));
            }

            case "basicclaims" -> {
                cm.setWandMode(player.getUniqueId(), ClaimManager.WandMode.BASIC);
                player.sendMessage(TextUtil.color("&a✔ تمت إعادة أداة الحماية لوضع الحماية العادية."));
            }

            case "adminclaims" -> {
                if (!player.hasPermission("survivalplus.claim.admin")) {
                    player.sendMessage(plugin.msg("general.no-permission"));
                    return true;
                }
                cm.setWandMode(player.getUniqueId(), ClaimManager.WandMode.ADMIN);
                player.sendMessage(TextUtil.color("&c✔ وضع الحمايات الإدارية (Admin Claims) مفعل الآن."));
            }

            case "ignoreclaims" -> {
                if (!player.hasPermission("survivalplus.claim.admin")) {
                    player.sendMessage(plugin.msg("general.no-permission"));
                    return true;
                }
                boolean active = cm.toggleAdminIgnore(player);
                player.sendMessage(TextUtil.color(active ? "&aتم تفعيل تخطي الحماية للإدارة." : "&eتم إيقاف تخطي الحماية."));
            }

            case "trust" -> applyTrust(player, currentClaim, args, TrustLevel.BUILD);
            case "containertrust" -> applyTrust(player, currentClaim, args, TrustLevel.CONTAINER);
            case "accesstrust" -> applyTrust(player, currentClaim, args, TrustLevel.ACCESS);
            case "permissiontrust" -> applyTrust(player, currentClaim, args, TrustLevel.MANAGER);

            case "untrust" -> {
                if (currentClaim == null || !cm.canManageClaim(player, currentClaim)) {
                    player.sendMessage(plugin.msg("claim.not-owner"));
                    return true;
                }
                if (args.length < 1) return true;
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
                if (currentClaim.getTrustedPlayers().remove(target.getUniqueId()) != null) {
                    cm.save();
                    player.sendMessage(plugin.msg("claim.trust-removed", "{player}", args[0]));
                }
            }

            case "trustlist" -> {
                if (currentClaim == null || !cm.canManageClaim(player, currentClaim)) {
                    player.sendMessage(plugin.msg("claim.not-owner"));
                    return true;
                }
                player.sendMessage(TextUtil.color("&8&m----------&r &6قائمة الموثوقين &8&m----------"));
                for (Map.Entry<UUID, TrustLevel> entry : currentClaim.getTrustedPlayers().entrySet()) {
                    OfflinePlayer op = Bukkit.getOfflinePlayer(entry.getKey());
                    String name = op.getName() != null ? op.getName() : entry.getKey().toString().substring(0, 8);
                    player.sendMessage(TextUtil.color(" &8• &a" + name + " &8-> &e" + entry.getValue().getArabicLabel()));
                }
            }

            case "trapped" -> {
                if (topClaim == null || cm.hasTrust(player, player.getLocation(), TrustLevel.ACCESS)) {
                    player.sendMessage(plugin.msg("claim.trapped-not-stuck"));
                    return true;
                }
                World w = player.getWorld();
                int x = topClaim.getMaxX() + 3;
                int z = topClaim.getMaxZ() + 3;
                Block highest = w.getHighestBlockAt(x, z);
                Location safe = highest.getLocation().add(0.5, 1.0, 0.5);
                player.teleport(safe);
                player.playSound(safe, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
                player.sendMessage(plugin.msg("claim.trapped-success"));
            }

            case "buyclaimblocks" -> {
                if (!plugin.getEconomy().isReady()) return true;
                double pricePerBlock = plugin.getConfig().getDouble("claims.claim-block-price", 2.0);
                String sym = plugin.getCurrencySymbol();
                if (args.length < 1) {
                    player.sendMessage(TextUtil.color("&7سعر البلوكة الواحدة: &6" + TextUtil.formatMoney(pricePerBlock, sym) + " &7| للشراء: &e/شراء_بلوكات <العدد>"));
                    return true;
                }
                int count;
                try {
                    count = Integer.parseInt(args[0]);
                    if (count <= 0 || count > 100000) throw new NumberFormatException();
                } catch (NumberFormatException e) {
                    return true;
                }
                double totalCost = count * pricePerBlock;
                if (!plugin.getEconomy().has(player, totalCost)) {
                    player.sendMessage(plugin.msg("shop.not-enough-money", "{price}", TextUtil.formatMoney(totalCost, sym)));
                    return true;
                }
                if (plugin.getEconomy().withdraw(player, totalCost)) {
                    cm.addBonusBlocks(player.getUniqueId(), count);
                    int newRem = cm.getRemainingClaimBlocks(player.getUniqueId());
                    player.sendMessage(plugin.msg("claim.blocks-bought",
                            "{amount}", String.valueOf(count),
                            "{cost}", TextUtil.formatMoney(totalCost, sym),
                            "{remaining}", String.valueOf(newRem)));
                    player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
                }
            }

            case "claimmenu" -> plugin.getClaimGuiManager().openClaimMenu(player, topClaim);
        }
        return true;
    }

    private void applyTrust(Player player, RegionClaim claim, String[] args, TrustLevel level) {
        if (claim == null || !plugin.getClaimManager().canManageClaim(player, claim)) {
            player.sendMessage(plugin.msg("claim.not-owner"));
            return;
        }
        if (args.length < 1) return;
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (target.getUniqueId().equals(player.getUniqueId())) return;
        claim.getTrustedPlayers().put(target.getUniqueId(), level);
        plugin.getClaimManager().save();
        player.sendMessage(plugin.msg("claim.trust-added",
                "{player}", args[0],
                "{level}", level.getArabicLabel()));
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String cmd = command.getName().toLowerCase();
        if (cmd.equals("claim") && args.length == 1) {
            return Arrays.asList("wand", "واند", "menu", "ادارة", "10", "15", "20");
        }
        if (cmd.equals("abandonallclaims") && args.length == 1) {
            return Arrays.asList("confirm", "تاكيد");
        }
        if ((cmd.equals("trust") || cmd.equals("containertrust") || cmd.equals("accesstrust")
                || cmd.equals("permissiontrust") || cmd.equals("untrust")) && args.length == 1) {
            return null;
        }
        return Collections.emptyList();
    }
}
