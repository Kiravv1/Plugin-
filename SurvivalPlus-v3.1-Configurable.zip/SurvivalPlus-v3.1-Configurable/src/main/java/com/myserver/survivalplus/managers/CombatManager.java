package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class CombatManager {
    private final SurvivalPlus plugin;
    private final Map<UUID, Long> combatEndTime = new HashMap<>();

    public CombatManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        startActionBarTask();
    }

    public void tag(Player player) {
        if (!plugin.getConfig().getBoolean("combat.enabled", true)) return;
        if (player.hasPermission("survivalplus.combat.bypass")) return;

        int duration = plugin.getConfig().getInt("combat.duration-seconds", 15);
        boolean wasInCombat = isInCombat(player);
        combatEndTime.put(player.getUniqueId(), System.currentTimeMillis() + (duration * 1000L));

        if (!wasInCombat) {
            player.sendMessage(plugin.msg("combat.tagged", "{seconds}", String.valueOf(duration)));
        }
    }

    public boolean isInCombat(Player player) {
        Long end = combatEndTime.get(player.getUniqueId());
        if (end == null) return false;
        if (System.currentTimeMillis() >= end) {
            combatEndTime.remove(player.getUniqueId());
            return false;
        }
        return true;
    }

    public long getRemainingSeconds(Player player) {
        Long end = combatEndTime.get(player.getUniqueId());
        if (end == null) return 0;
        long diff = (end - System.currentTimeMillis() + 999L) / 1000L;
        return Math.max(0, diff);
    }

    public void untag(UUID uuid) {
        combatEndTime.remove(uuid);
    }

    public boolean isCommandBlocked(String rawCommand) {
        String cmd = rawCommand.toLowerCase().trim();
        if (cmd.startsWith("/")) cmd = cmd.substring(1);
        int space = cmd.indexOf(' ');
        if (space != -1) cmd = cmd.substring(0, space);
        int colon = cmd.indexOf(':');
        if (colon != -1) cmd = cmd.substring(colon + 1);

        for (String blocked : plugin.getConfig().getStringList("combat.blocked-commands")) {
            if (cmd.equalsIgnoreCase(blocked)) return true;
        }
        return false;
    }

    private void startActionBarTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (combatEndTime.isEmpty()) return;
                Iterator<Map.Entry<UUID, Long>> it = combatEndTime.entrySet().iterator();
                long now = System.currentTimeMillis();
                while (it.hasNext()) {
                    Map.Entry<UUID, Long> entry = it.next();
                    Player p = Bukkit.getPlayer(entry.getKey());
                    if (p == null || !p.isOnline()) continue;

                    if (now >= entry.getValue()) {
                        it.remove();
                        p.sendActionBar(plugin.getMessages().getNoPrefix("combat.actionbar-safe"));
                    } else {
                        long sec = (entry.getValue() - now + 999L) / 1000L;
                        p.sendActionBar(plugin.getMessages().getNoPrefix("combat.actionbar-active", "{seconds}", String.valueOf(sec)));
                    }
                }
            }
        }.runTaskTimer(plugin, 10L, 10L);
    }
}
