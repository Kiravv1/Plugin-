package com.myserver.survivalplus.models;

import org.bukkit.Material;

public enum ClaimFlag {
    PVP("pvp", "القتال داخل الأرض (PvP)", Material.IRON_SWORD, "السماح أو منع قتال اللاعبين داخل هذه الأرض"),
    EXPLOSIONS("explosions", "تأثير التفجيرات", Material.TNT, "السماح أو منع تدمير الكريبر والـ TNT للبلوكات"),
    VISITOR_INTERACT("visitor-interact", "تفاعل الزوار العام", Material.OAK_DOOR, "السماح لجميع الزوار بفتح الأبواب والأزرار والتجارة مع القرويين"),
    FIRE_SPREAD("fire-spread", "انتشار النار", Material.FLINT_AND_STEEL, "السماح أو منع انتشار الحرائق داخل الأرض"),
    MOB_GRIEF("mob-grief", "تخريب الوحوش", Material.CREEPER_HEAD, "السماح أو منع الإندرمان والموبات من تكسير البلوكات والمزارع");

    private final String configKey;
    private final String arabicName;
    private final Material icon;
    private final String description;

    ClaimFlag(String configKey, String arabicName, Material icon, String description) {
        this.configKey = configKey;
        this.arabicName = arabicName;
        this.icon = icon;
        this.description = description;
    }

    public String getConfigKey() { return configKey; }
    public String getArabicName() { return arabicName; }
    public Material getIcon() { return icon; }
    public String getDescription() { return description; }
}
