package com.myserver.survivalplus.models;

import org.bukkit.Material;
import java.util.*;

public class PlayerShop {
    private final UUID ownerUuid;
    private String ownerName;
    private String customName;
    private String description;
    private Material iconMaterial;
    private boolean open;
    private int views;
    private int totalItemsSold;
    private double totalRevenue;
    private long featuredUntil;
    private double pendingOfflineEarnings;
    private int pendingOfflineSalesCount;
    private final Set<UUID> likes = new HashSet<>();
    private final Map<String, ShopListing> listings = new LinkedHashMap<>();
    private final LinkedList<SaleRecord> salesHistory = new LinkedList<>();

    public PlayerShop(UUID ownerUuid, String ownerName) {
        this.ownerUuid = ownerUuid;
        this.ownerName = ownerName;
        this.customName = "&eمتجر " + ownerName;
        this.description = "&7أهلاً بك في متجري! أفضل الأسعار في السيرفر.";
        this.iconMaterial = null;
        this.open = true;
    }

    public UUID getOwnerUuid() { return ownerUuid; }
    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }

    public String getCustomName() { return customName; }
    public void setCustomName(String customName) { this.customName = customName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Material getIconMaterial() { return iconMaterial; }
    public void setIconMaterial(Material iconMaterial) { this.iconMaterial = iconMaterial; }

    public boolean isOpen() { return open; }
    public void setOpen(boolean open) { this.open = open; }

    public int getViews() { return views; }
    public void setViews(int views) { this.views = views; }
    public void incrementViews() { this.views++; }

    public int getTotalItemsSold() { return totalItemsSold; }
    public void setTotalItemsSold(int totalItemsSold) { this.totalItemsSold = totalItemsSold; }

    public double getTotalRevenue() { return totalRevenue; }
    public void setTotalRevenue(double totalRevenue) { this.totalRevenue = totalRevenue; }

    public long getFeaturedUntil() { return featuredUntil; }
    public void setFeaturedUntil(long featuredUntil) { this.featuredUntil = featuredUntil; }
    public boolean isFeatured() { return System.currentTimeMillis() < featuredUntil; }

    public double getPendingOfflineEarnings() { return pendingOfflineEarnings; }
    public void setPendingOfflineEarnings(double pendingOfflineEarnings) { this.pendingOfflineEarnings = pendingOfflineEarnings; }

    public int getPendingOfflineSalesCount() { return pendingOfflineSalesCount; }
    public void setPendingOfflineSalesCount(int pendingOfflineSalesCount) { this.pendingOfflineSalesCount = pendingOfflineSalesCount; }

    public Set<UUID> getLikes() { return likes; }
    public boolean toggleLike(UUID voter) {
        if (likes.contains(voter)) {
            likes.remove(voter);
            return false;
        }
        likes.add(voter);
        return true;
    }

    public Map<String, ShopListing> getListings() { return listings; }
    public LinkedList<SaleRecord> getSalesHistory() { return salesHistory; }

    public void addSaleRecord(SaleRecord record, int maxHistory) {
        salesHistory.addFirst(record);
        while (salesHistory.size() > maxHistory) {
            salesHistory.removeLast();
        }
        totalItemsSold++;
        totalRevenue += record.getPrice();
    }

    public long getLatestListingTime() {
        long latest = 0;
        for (ShopListing l : listings.values()) {
            if (l.getCreatedAt() > latest) latest = l.getCreatedAt();
        }
        return latest;
    }
}
