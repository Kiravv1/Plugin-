package com.myserver.survivalplus.models;

import org.bukkit.Location;

import java.util.*;

public class RegionClaim {
    private final String id;
    private final String worldName;
    private int minX;
    private int minZ;
    private int maxX;
    private int maxZ;
    private UUID ownerUuid;
    private String ownerName;
    private final String parentId;
    private final Map<UUID, TrustLevel> trustedPlayers = new HashMap<>();
    private final Map<ClaimFlag, Boolean> flags = new EnumMap<>(ClaimFlag.class);
    private final List<RegionClaim> subclaims = new ArrayList<>();

    public RegionClaim(String id, String worldName, int x1, int z1, int x2, int z2, UUID ownerUuid, String ownerName, String parentId) {
        this.id = id;
        this.worldName = worldName;
        this.minX = Math.min(x1, x2);
        this.maxX = Math.max(x1, x2);
        this.minZ = Math.min(z1, z2);
        this.maxZ = Math.max(z1, z2);
        this.ownerUuid = ownerUuid;
        this.ownerName = ownerName;
        this.parentId = parentId;
        for (ClaimFlag flag : ClaimFlag.values()) {
            flags.put(flag, false);
        }
    }

    public String getId() { return id; }
    public String getWorldName() { return worldName; }
    public int getMinX() { return minX; }
    public int getMinZ() { return minZ; }
    public int getMaxX() { return maxX; }
    public int getMaxZ() { return maxZ; }

    public void setBounds(int x1, int z1, int x2, int z2) {
        this.minX = Math.min(x1, x2);
        this.maxX = Math.max(x1, x2);
        this.minZ = Math.min(z1, z2);
        this.maxZ = Math.max(z1, z2);
    }

    public int getWidth() { return (maxX - minX) + 1; }
    public int getLength() { return (maxZ - minZ) + 1; }
    public int getArea() { return getWidth() * getLength(); }

    public boolean isAdminClaim() { return ownerUuid == null; }
    public UUID getOwnerUuid() { return ownerUuid; }
    public void setOwnerUuid(UUID ownerUuid) { this.ownerUuid = ownerUuid; }
    public String getOwnerName() { return isAdminClaim() ? "الإدارة (Admin)" : ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }

    public String getParentId() { return parentId; }
    public boolean isSubclaim() { return parentId != null; }

    public Map<UUID, TrustLevel> getTrustedPlayers() { return trustedPlayers; }
    public Map<ClaimFlag, Boolean> getFlags() { return flags; }
    public List<RegionClaim> getSubclaims() { return subclaims; }

    public boolean getFlag(ClaimFlag flag) {
        return flags.getOrDefault(flag, false);
    }

    public void setFlag(ClaimFlag flag, boolean val) {
        flags.put(flag, val);
    }

    public boolean toggleFlag(ClaimFlag flag) {
        boolean next = !getFlag(flag);
        flags.put(flag, next);
        return next;
    }

    public boolean contains(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;
        if (!loc.getWorld().getName().equals(worldName)) return false;
        int x = loc.getBlockX();
        int z = loc.getBlockZ();
        return x >= minX && x <= maxX && z >= minZ && z <= maxZ;
    }

    public boolean containsXZ(String world, int x, int z) {
        return worldName.equals(world) && x >= minX && x <= maxX && z >= minZ && z <= maxZ;
    }

    public boolean overlaps(String world, int oMinX, int oMinZ, int oMaxX, int oMaxZ) {
        if (!worldName.equals(world)) return false;
        int aMinX = Math.min(oMinX, oMaxX);
        int aMaxX = Math.max(oMinX, oMaxX);
        int aMinZ = Math.min(oMinZ, oMaxZ);
        int aMaxZ = Math.max(oMinZ, oMaxZ);
        return this.minX <= aMaxX && this.maxX >= aMinX && this.minZ <= aMaxZ && this.maxZ >= aMinZ;
    }

    public boolean isInside(RegionClaim parent) {
        return worldName.equals(parent.worldName)
                && this.minX >= parent.minX && this.maxX <= parent.maxX
                && this.minZ >= parent.minZ && this.maxZ <= parent.maxZ;
    }

    public boolean isCorner(int x, int z) {
        return (x == minX || x == maxX) && (z == minZ || z == maxZ);
    }

    public int getOppositeCornerX(int cornerX) {
        return (cornerX == minX) ? maxX : minX;
    }

    public int getOppositeCornerZ(int cornerZ) {
        return (cornerZ == minZ) ? maxZ : minZ;
    }

    public String getCenterCoords() {
        int cx = (minX + maxX) / 2;
        int cz = (minZ + maxZ) / 2;
        return "X:" + cx + ", Z:" + cz;
    }
}
