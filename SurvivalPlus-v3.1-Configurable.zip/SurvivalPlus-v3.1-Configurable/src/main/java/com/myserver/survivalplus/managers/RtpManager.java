package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.util.PermissionUtil;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class RtpManager {
    private final SurvivalPlus plugin;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> searching = new HashSet<>();
    private final Random random = new Random();

    public RtpManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    public void startRtp(Player player) {
        World world = player.getWorld();
        List<String> allowed = plugin.getConfig().getStringList("rtp.allowed-worlds");
        if (!allowed.isEmpty() && allowed.stream().noneMatch(w -> w.equalsIgnoreCase(world.getName()))) {
            player.sendMessage(plugin.msg("claim.world-disabled"));
            return;
        }

        if (searching.contains(player.getUniqueId())) return;

        if (!player.hasPermission("survivalplus.rtp.bypass")) {
            int defaultCd = plugin.getConfig().getInt("rtp.default-cooldown-seconds", 300);
            int cd = PermissionUtil.getMinNumericPermission(player, "survivalplus.rtp.cooldown.", defaultCd, 0);
            long last = cooldowns.getOrDefault(player.getUniqueId(), 0L);
            long elapsedSec = (System.currentTimeMillis() - last) / 1000L;
            if (elapsedSec < cd) {
                long left = cd - elapsedSec;
                player.sendMessage(plugin.msg("rtp.cooldown", "{time}", TextUtil.formatDuration(left)));
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }
        }

        searching.add(player.getUniqueId());
        player.sendMessage(plugin.msg("rtp.searching"));

        int maxAttempts = plugin.getConfig().getInt("rtp.max-attempts", 15);
        findSafeLocationAsync(player, world, maxAttempts);
    }

    private void findSafeLocationAsync(Player player, World world, int attemptsLeft) {
        if (!player.isOnline()) {
            searching.remove(player.getUniqueId());
            return;
        }
        if (attemptsLeft <= 0) {
            searching.remove(player.getUniqueId());
            return;
        }

        int minR = plugin.getConfig().getInt("rtp.min-radius", 250);
        int maxR = plugin.getConfig().getInt("rtp.max-radius", 3500);
        double angle = random.nextDouble() * Math.PI * 2;
        double dist = minR + random.nextDouble() * Math.max(100, maxR - minR);
        int x = (int) Math.round(Math.cos(angle) * dist);
        int z = (int) Math.round(Math.sin(angle) * dist);

        world.getChunkAtAsync(x >> 4, z >> 4).thenAccept(chunk -> {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) {
                    searching.remove(player.getUniqueId());
                    return;
                }
                if (plugin.getClaimManager().getTopClaimAt(world.getName(), x, z) != null) {
                    findSafeLocationAsync(player, world, attemptsLeft - 1);
                    return;
                }

                Block highest = world.getHighestBlockAt(x, z);
                Material mat = highest.getType();
                Block above1 = highest.getRelative(0, 1, 0);
                Block above2 = highest.getRelative(0, 2, 0);

                if (isSafeGround(mat) && above1.isPassable() && !above1.isLiquid() && above2.isPassable() && !above2.isLiquid()) {
                    Location target = highest.getLocation().add(0.5, 1.0, 0.5);
                    beginWarmup(player, target);
                } else {
                    findSafeLocationAsync(player, world, attemptsLeft - 1);
                }
            });
        });
    }

    private boolean isSafeGround(Material mat) {
        if (!mat.isSolid()) return false;
        return switch (mat) {
            case LAVA, WATER, MAGMA_BLOCK, CACTUS, CAMPFIRE, SOUL_CAMPFIRE,
                 FIRE, SOUL_FIRE, POWDER_SNOW, SWEET_BERRY_BUSH, POINTED_DRIPSTONE -> false;
            default -> true;
        };
    }

    private void beginWarmup(Player player, Location target) {
        int warmup = player.hasPermission("survivalplus.rtp.bypass") ? 0 : plugin.getConfig().getInt("rtp.warmup-seconds", 3);
        if (warmup <= 0) {
            completeTeleport(player, target);
            return;
        }

        Location startLoc = player.getLocation().clone();
        player.sendMessage(plugin.msg("rtp.warmup", "{seconds}", String.valueOf(warmup)));

        new BukkitRunnable() {
            int remaining = warmup;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    searching.remove(player.getUniqueId());
                    cancel();
                    return;
                }
                if (plugin.getCombatManager().isInCombat(player)) {
                    searching.remove(player.getUniqueId());
                    player.sendMessage(plugin.msg("rtp.cancelled-combat"));
                    cancel();
                    return;
                }
                if (player.getLocation().getWorld() != startLoc.getWorld()
                        || player.getLocation().distanceSquared(startLoc) > 1.2) {
                    searching.remove(player.getUniqueId());
                    player.sendMessage(plugin.msg("rtp.cancelled-move"));
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                    cancel();
                    return;
                }
                if (remaining <= 0) {
                    completeTeleport(player, target);
                    cancel();
                    return;
                }
                player.sendActionBar(plugin.getMessages().getNoPrefix("rtp.warmup-actionbar", "{seconds}", String.valueOf(remaining)));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.6f, 1.2f);
                remaining--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void completeTeleport(Player player, Location target) {
        searching.remove(player.getUniqueId());
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis());
        player.teleport(target);
        player.playSound(target, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
        player.spawnParticle(Particle.PORTAL, target.clone().add(0, 1, 0), 40, 0.5, 1, 0.5, 0.1);
        player.sendMessage(plugin.msg("rtp.success",
                "{x}", String.valueOf(target.getBlockX()),
                "{y}", String.valueOf(target.getBlockY()),
                "{z}", String.valueOf(target.getBlockZ())));
    }

    public void cleanupPlayer(UUID uuid) {
        searching.remove(uuid);
    }
}
