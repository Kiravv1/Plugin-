package com.myserver.survivalplus.listeners;

import com.myserver.survivalplus.SurvivalPlus;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class CombatListener implements Listener {
    private final SurvivalPlus plugin;

    public CombatListener(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPvP(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        Player attacker = null;
        if (event.getDamager() instanceof Player p) {
            attacker = p;
        } else if (event.getDamager() instanceof Projectile proj && proj.getShooter() instanceof Player shooter) {
            attacker = shooter;
        }
        if (attacker == null || attacker.equals(victim)) return;

        plugin.getCombatManager().tag(victim);
        plugin.getCombatManager().tag(attacker);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getCombatManager().isInCombat(player)) return;
        if (plugin.getCombatManager().isCommandBlocked(event.getMessage())) {
            event.setCancelled(true);
            long rem = plugin.getCombatManager().getRemainingSeconds(player);
            player.sendMessage(plugin.msg("combat.blocked-command", "{seconds}", String.valueOf(rem)));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (plugin.getCombatManager().isInCombat(player)) {
            plugin.getCombatManager().untag(player.getUniqueId());
            if (plugin.getConfig().getBoolean("combat.kill-on-logout", true)) {
                player.setHealth(0.0);
                Bukkit.broadcast(plugin.msg("combat.logout-broadcast", "{player}", player.getName()));
            }
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        plugin.getCombatManager().untag(event.getEntity().getUniqueId());
    }
}
