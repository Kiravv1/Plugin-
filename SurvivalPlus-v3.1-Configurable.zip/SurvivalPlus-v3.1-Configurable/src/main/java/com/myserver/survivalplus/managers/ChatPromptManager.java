package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.models.PlayerShop;
import com.myserver.survivalplus.models.ShopListing;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ChatPromptManager {
    private final SurvivalPlus plugin;
    private final Map<UUID, PromptSession> sessions = new HashMap<>();

    public enum PromptType { SHOP_NAME, SHOP_DESC, EDIT_PRICE }

    public record PromptSession(PromptType type, String targetId, long expiresAt) {}

    public ChatPromptManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    public void startPrompt(Player player, PromptType type, String targetId, String instruction) {
        sessions.put(player.getUniqueId(), new PromptSession(type, targetId, System.currentTimeMillis() + 30_000L));
        player.closeInventory();
        player.sendMessage(TextUtil.color(plugin.getConfig().getString("prefix", "") + "&e" + instruction));
        player.sendMessage(TextUtil.color("&7(اكتب &cالغاء &7أو &ccancel &7للتراجع - تنتهي المهلة خلال 30 ثانية)"));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 1.3f);
    }

    public boolean hasActivePrompt(UUID uuid) {
        PromptSession session = sessions.get(uuid);
        if (session == null) return false;
        if (System.currentTimeMillis() > session.expiresAt()) {
            sessions.remove(uuid);
            return false;
        }
        return true;
    }

    public void handleInput(Player player, String rawText) {
        PromptSession session = sessions.remove(player.getUniqueId());
        if (session == null) return;

        String input = rawText.trim();
        if (input.equalsIgnoreCase("cancel") || input.equals("الغاء") || input.equals("إلغاء")) {
            player.sendMessage(TextUtil.color("&eتم إلغاء التعديل."));
            return;
        }

        Bukkit.getScheduler().runTask(plugin, () -> {
            PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
            boolean allowColor = player.hasPermission("survivalplus.shop.color");

            switch (session.type()) {
                case SHOP_NAME -> {
                    String clean = allowColor ? input : TextUtil.stripColor(input);
                    if (TextUtil.stripColor(clean).length() > 32) return;
                    shop.setCustomName(allowColor ? clean : "&e" + clean);
                    plugin.getShopManager().save();
                    plugin.getShopGuiManager().openOwnerDashboard(player);
                }
                case SHOP_DESC -> {
                    String clean = allowColor ? input : TextUtil.stripColor(input);
                    if (TextUtil.stripColor(clean).length() > 80) return;
                    shop.setDescription(allowColor ? clean : "&7" + clean);
                    plugin.getShopManager().save();
                    plugin.getShopGuiManager().openOwnerDashboard(player);
                }
                case EDIT_PRICE -> {
                    ShopListing listing = shop.getListings().get(session.targetId());
                    if (listing == null || listing.isSold()) return;
                    double newPrice;
                    try {
                        newPrice = plugin.getShopManager().roundPrice(Double.parseDouble(input));
                    } catch (NumberFormatException e) {
                        return;
                    }
                    if (!plugin.getShopManager().validatePrice(player, newPrice)) return;
                    listing.setPrice(newPrice);
                    plugin.getShopManager().save();
                    plugin.getShopGuiManager().openOwnerListings(player);
                }
            }
        });
    }

    public void cleanupPlayer(UUID uuid) {
        sessions.remove(uuid);
    }
}
