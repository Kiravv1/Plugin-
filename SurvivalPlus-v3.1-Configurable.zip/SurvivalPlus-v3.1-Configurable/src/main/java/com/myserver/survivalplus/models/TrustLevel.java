package com.myserver.survivalplus.models;

public enum TrustLevel {
    ACCESS(1, "دخول وأزرار (Access)"),
    CONTAINER(2, "صناديق وحيوانات (Container)"),
    BUILD(3, "بناء كامل (Build)"),
    MANAGER(4, "مدير أرض (Permission)");

    private final int rank;
    private final String arabicLabel;

    TrustLevel(int rank, String arabicLabel) {
        this.rank = rank;
        this.arabicLabel = arabicLabel;
    }

    public int getRank() { return rank; }
    public String getArabicLabel() { return arabicLabel; }

    public boolean isAtLeast(TrustLevel required) {
        return this.rank >= required.rank;
    }
}
