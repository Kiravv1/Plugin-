package com.myserver.survivalplus.listeners;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.managers.ChatPromptManager;
import com.myserver.survivalplus.managers.ShopManager;
import com.myserver.survivalplus.models.ClaimFlag;
import com.myserver.survivalplus.models.PlayerShop;
import com.myserver.survivalplus.models.RegionClaim;
import com.myserver.survivalplus.models.ShopListing;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.UUID;

public class GuiListener implements Listener {
    private final SurvivalPlus plugin;

    public GuiListener(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof GuiHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof GuiHolder holder)) return;

        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
            return;
        }

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        int slot = event.getSlot();

        switch (holder.getType()) {
            case SHOP_DIRECTORY -> handleDirectoryClick(player, holder, slot, clicked);
            case PLAYER_SHOP -> handlePlayerShopClick(player, holder, slot, clicked, event.getClick());
            case SHOP_CONFIRM -> handleConfirmClick(player, holder, slot);
            case OWNER_DASHBOARD -> handleOwnerDashboardClick(player, slot);
            case OWNER_LISTINGS -> handleOwnerListingsClick(player, slot, clicked, event.getClick());
            case OWNER_SALES_LOG -> {
                if (slot == 49) {
                    clickSound(player);
                    plugin.getShopGuiManager().openOwnerDashboard(player);
                }
            }
            case OWNER_ICON_PICKER -> handleIconPickerClick(player, slot, clicked);
            case CLAIM_MENU -> handleClaimMenuClick(player, holder, slot, clicked, event.isShiftClick());
        }
    }

    private void handleDirectoryClick(Player player, GuiHolder holder, int slot, ItemStack clicked) {
        if (slot == 45 && clicked.getType() == Material.ARROW) {
            clickSound(player);
            plugin.getShopGuiManager().openDirectory(player, holder.getPage() - 1, holder.getSortMode());
            return;
        }
        if (slot == 53 && clicked.getType() == Material.ARROW) {
            clickSound(player);
            plugin.getShopGuiManager().openDirectory(player, holder.getPage() + 1, holder.getSortMode());
            return;
        }
        if (slot == 47) {
            clickSound(player);
            plugin.getShopGuiManager().openDirectory(player, 0, holder.getSortMode().next());
            return;
        }
        if (slot == 49) {
            clickSound(player);
            plugin.getShopGuiManager().openOwnerDashboard(player);
            return;
        }
        if (slot < 45 && clicked.hasItemMeta()) {
            String ownerStr = clicked.getItemMeta().getPersistentDataContainer()
                    .get(plugin.getShopGuiManager().keyShopOwner, PersistentDataType.STRING);
            if (ownerStr != null) {
                player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 0.7f, 1.2f);
                plugin.getShopGuiManager().openPlayerShop(player, UUID.fromString(ownerStr), true);
            }
        }
    }

    private void handlePlayerShopClick(Player player, GuiHolder holder, int slot, ItemStack clicked, ClickType clickType) {
        UUID ownerUuid = holder.getTargetUuid();
        PlayerShop shop = plugin.getShopManager().getShop(ownerUuid);
        if (shop == null) {
            player.closeInventory();
            return;
        }

        if (slot == 45) {
            clickSound(player);
            plugin.getShopGuiManager().openDirectory(player, 0, holder.getSortMode());
            return;
        }

        if (slot == 48 && !player.getUniqueId().equals(ownerUuid)) {
            boolean liked = shop.toggleLike(player.getUniqueId());
            plugin.getShopManager().save();
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, liked ? 1.5f : 0.8f);
            plugin.getShopGuiManager().openPlayerShop(player, ownerUuid, false);
            return;
        }

        if (slot == 50 && player.getUniqueId().equals(ownerUuid)) {
            clickSound(player);
            plugin.getShopGuiManager().openOwnerDashboard(player);
            return;
        }

        if (slot < 45 && clicked.hasItemMeta()) {
            String listingId = clicked.getItemMeta().getPersistentDataContainer()
                    .get(plugin.getShopGuiManager().keyListingId, PersistentDataType.STRING);
            if (listingId == null) return;

            ShopListing listing = shop.getListings().get(listingId);
            if (listing == null || listing.isSold()) {
                plugin.getShopGuiManager().openPlayerShop(player, ownerUuid, false);
                return;
            }

            if (player.getUniqueId().equals(ownerUuid)) {
                if (clickType.isRightClick()) {
                    plugin.getShopManager().withdrawListing(player, listingId);
                    plugin.getShopGuiManager().openPlayerShop(player, ownerUuid, false);
                } else {
                    plugin.getChatPromptManager().startPrompt(player, ChatPromptManager.PromptType.EDIT_PRICE,
                            listingId, "اكتب السعر الجديد للسلعة في الشات:");
                }
            } else {
                clickSound(player);
                plugin.getShopGuiManager().openConfirmPurchase(player, shop, listing);
            }
        }
    }

    private void handleConfirmClick(Player player, GuiHolder holder, int slot) {
        if (slot == 15) {
            clickSound(player);
            plugin.getShopGuiManager().openPlayerShop(player, holder.getTargetUuid(), false);
            return;
        }
        if (slot == 11) {
            plugin.getShopManager().purchaseListing(player, holder.getTargetUuid(), holder.getListingId(), holder.getExpectedPrice());
            player.closeInventory();
        }
    }

    private void handleOwnerDashboardClick(Player player, int slot) {
        PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
        switch (slot) {
            case 10 -> {
                clickSound(player);
                plugin.getShopGuiManager().openOwnerListings(player);
            }
            case 12 -> {
                clickSound(player);
                plugin.getShopGuiManager().openSalesLog(player);
            }
            case 14 -> {
                if (!player.hasPermission("survivalplus.shop.icon")) {
                    player.sendMessage(plugin.msg("general.no-permission"));
                    return;
                }
                clickSound(player);
                plugin.getShopGuiManager().openIconPicker(player);
            }
            case 16 -> {
                plugin.getShopManager().boostShop(player);
                plugin.getShopGuiManager().openOwnerDashboard(player);
            }
            case 20 -> plugin.getChatPromptManager().startPrompt(player, ChatPromptManager.PromptType.SHOP_NAME,
                    null, "اكتب الاسم الجديد لمتجرك في الشات:");
            case 22 -> plugin.getChatPromptManager().startPrompt(player, ChatPromptManager.PromptType.SHOP_DESC,
                    null, "اكتب الوصف الجديد لمتجرك في الشات:");
            case 24 -> {
                shop.setOpen(!shop.isOpen());
                plugin.getShopManager().save();
                clickSound(player);
                plugin.getShopGuiManager().openOwnerDashboard(player);
            }
            case 31 -> {
                clickSound(player);
                plugin.getShopGuiManager().openPlayerShop(player, player.getUniqueId(), false);
            }
            case 36 -> {
                clickSound(player);
                plugin.getShopGuiManager().openDirectory(player, 0, ShopManager.SortMode.TOP_SALES);
            }
        }
    }

    private void handleOwnerListingsClick(Player player, int slot, ItemStack clicked, ClickType clickType) {
        if (slot == 49) {
            clickSound(player);
            plugin.getShopGuiManager().openOwnerDashboard(player);
            return;
        }
        if (slot < 45 && clicked.hasItemMeta()) {
            String listingId = clicked.getItemMeta().getPersistentDataContainer()
                    .get(plugin.getShopGuiManager().keyListingId, PersistentDataType.STRING);
            if (listingId == null) return;

            if (clickType.isRightClick()) {
                plugin.getShopManager().withdrawListing(player, listingId);
                plugin.getShopGuiManager().openOwnerListings(player);
            } else {
                plugin.getChatPromptManager().startPrompt(player, ChatPromptManager.PromptType.EDIT_PRICE,
                        listingId, "اكتب السعر الجديد للسلعة في الشات:");
            }
        }
    }

    private void handleIconPickerClick(Player player, int slot, ItemStack clicked) {
        PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
        if (slot == 36) {
            clickSound(player);
            plugin.getShopGuiManager().openOwnerDashboard(player);
            return;
        }
        if (slot == 11) {
            shop.setIconMaterial(null);
            plugin.getShopManager().save();
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
            plugin.getShopGuiManager().openOwnerDashboard(player);
            return;
        }
        if (slot == 15) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand.getType() == Material.AIR) {
                player.sendMessage(plugin.msg("shop.hold-item"));
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }
            shop.setIconMaterial(hand.getType());
            plugin.getShopManager().save();
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
            plugin.getShopGuiManager().openOwnerDashboard(player);
            return;
        }
        if (clicked.hasItemMeta()) {
            String matName = clicked.getItemMeta().getPersistentDataContainer()
                    .get(plugin.getShopGuiManager().keyPresetIcon, PersistentDataType.STRING);
            if (matName != null) {
                Material mat = Material.matchMaterial(matName);
                if (mat != null) {
                    shop.setIconMaterial(mat);
                    plugin.getShopManager().save();
                    player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
                    plugin.getShopGuiManager().openOwnerDashboard(player);
                }
            }
        }
    }

    private void handleClaimMenuClick(Player player, GuiHolder holder, int slot, ItemStack clicked, boolean shift) {
        RegionClaim claim = plugin.getClaimManager().getClaimById(holder.getExtraData());
        if (claim == null || !plugin.getClaimManager().canManageClaim(player, claim)) {
            player.closeInventory();
            return;
        }

        if (slot == 29) {
            player.closeInventory();
            plugin.getClaimManager().visualizeClaim(player, claim, true);
            return;
        }

        if (slot == 33) {
            if (!shift) return;
            player.closeInventory();
            plugin.getClaimManager().deleteClaim(player, claim);
            return;
        }

        if (clicked.hasItemMeta()) {
            String flagName = clicked.getItemMeta().getPersistentDataContainer()
                    .get(plugin.getClaimGuiManager().keyFlag, PersistentDataType.STRING);
            if (flagName != null) {
                ClaimFlag flag = ClaimFlag.valueOf(flagName);
                claim.toggleFlag(flag);
                plugin.getClaimManager().save();
                clickSound(player);
                plugin.getClaimGuiManager().openClaimMenu(player, claim);
            }
        }
    }

    private void clickSound(Player player) {
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1.2f);
    }
}
