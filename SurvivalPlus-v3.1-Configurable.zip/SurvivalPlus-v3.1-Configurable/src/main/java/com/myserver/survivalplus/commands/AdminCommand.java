package com.myserver.survivalplus.commands;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class AdminCommand implements CommandExecutor, TabCompleter {
    private final SurvivalPlus plugin;

    public AdminCommand(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("survivalplus.admin")) {
            sender.sendMessage(plugin.msg("general.no-permission"));
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            plugin.reloadConfig();
            plugin.getMessages().reload();
            sender.sendMessage(plugin.msg("general.reloaded"));
            return true;
        }
        if (args.length >= 4 && (args[0].equalsIgnoreCase("blocks") || args[0].equals("بلوكات"))) {
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[2]);
            int amount;
            try {
                amount = Integer.parseInt(args[3]);
            } catch (NumberFormatException e) {
                return true;
            }
            if (args[1].equalsIgnoreCase("give") || args[1].equals("اعطاء")) {
                plugin.getClaimManager().addBonusBlocks(target.getUniqueId(), amount);
                sender.sendMessage(TextUtil.color("&a✔ تمت إضافة &e" + amount + " &aبلوكة حماية للاعب &f" + args[2]));
            } else if (args[1].equalsIgnoreCase("set") || args[1].equals("تحديد")) {
                plugin.getClaimManager().setBonusBlocks(target.getUniqueId(), amount);
                sender.sendMessage(TextUtil.color("&a✔ تم ضبط بلوكات الحماية الإضافية للاعب &f" + args[2] + " &aعلى &e" + amount));
            }
            return true;
        }
        sender.sendMessage(TextUtil.color("&eSurvivalPlus v3.1.0 &7| الأوامر الإدارية:"));
        sender.sendMessage(TextUtil.color("&f/splus reload &7- إعادة تحميل config.yml و messages.yml فوراً"));
        sender.sendMessage(TextUtil.color("&f/splus blocks <give|set> <اللاعب> <العدد> &7- تعديل بلوكات الحماية للاعب"));
        sender.sendMessage(TextUtil.color("&7حالة اقتصاد Vault: " + (plugin.getEconomy().isReady() ? "&aمتصل ✔" : "&cغير متصل ✘")));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return Arrays.asList("reload", "blocks", "بلوكات");
        if (args.length == 2 && (args[0].equalsIgnoreCase("blocks") || args[0].equals("بلوكات"))) {
            return Arrays.asList("give", "set");
        }
        if (args.length == 3) return null;
        return Collections.emptyList();
    }
}
