package com.myserver.survivalplus.listeners;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.models.PlayerShop;
import com.myserver.survivalplus.util.TextUtil;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerSessionListener implements Listener {
    private final SurvivalPlus plugin;

    public PlayerSessionListener(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getClaimManager().getAccruedBlocks(player.getUniqueId());

        PlayerShop shop = plugin.getShopManager().getShop(player.getUniqueId());
        if (shop != null) {
            shop.setOwnerName(player.getName());
            if (shop.getPendingOfflineSalesCount() > 0) {
                int count = shop.getPendingOfflineSalesCount();
                double earnings = shop.getPendingOfflineEarnings();
                shop.setPendingOfflineSalesCount(0);
                shop.setPendingOfflineEarnings(0.0);
                plugin.getShopManager().save();

                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (!player.isOnline()) return;
                    player.sendMessage(plugin.msg("shop.offline-earnings",
                            "{count}", String.valueOf(count),
                            "{earnings}", TextUtil.formatMoney(earnings, plugin.getCurrencySymbol())));
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.3f);
                }, 40L);
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getChatPromptManager().hasActivePrompt(player.getUniqueId())) return;

        event.setCancelled(true);
        String plain = TextUtil.toPlain(event.message());
        plugin.getChatPromptManager().handleInput(player, plain);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getChatPromptManager().cleanupPlayer(event.getPlayer().getUniqueId());
        plugin.getRtpManager().cleanupPlayer(event.getPlayer().getUniqueId());
        plugin.getClaimManager().cleanupPlayer(event.getPlayer().getUniqueId());
    }
}
