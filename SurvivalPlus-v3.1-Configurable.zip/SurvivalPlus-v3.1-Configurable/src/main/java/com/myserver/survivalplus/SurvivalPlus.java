package com.myserver.survivalplus;

import com.myserver.survivalplus.commands.AdminCommand;
import com.myserver.survivalplus.commands.ClaimCommand;
import com.myserver.survivalplus.commands.RtpCommand;
import com.myserver.survivalplus.commands.ShopCommand;
import com.myserver.survivalplus.gui.ClaimGuiManager;
import com.myserver.survivalplus.gui.ShopGuiManager;
import com.myserver.survivalplus.listeners.CombatListener;
import com.myserver.survivalplus.listeners.GuiListener;
import com.myserver.survivalplus.listeners.PlayerSessionListener;
import com.myserver.survivalplus.listeners.ProtectionListener;
import com.myserver.survivalplus.managers.*;
import com.myserver.survivalplus.util.DynamicCommand;
import com.myserver.survivalplus.util.EconomyProvider;
import com.myserver.survivalplus.util.VaultEconomyProvider;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;
import java.util.List;

public class SurvivalPlus extends JavaPlugin {
    private EconomyProvider economy = EconomyProvider.NONE;
    private MessageManager messageManager;
    private ShopManager shopManager;
    private ClaimManager claimManager;
    private RtpManager rtpManager;
    private CombatManager combatManager;
    private ChatPromptManager chatPromptManager;
    private ShopGuiManager shopGuiManager;
    private ClaimGuiManager claimGuiManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.messageManager = new MessageManager(this);

        if (getServer().getPluginManager().getPlugin("Vault") != null) {
            VaultEconomyProvider vault = new VaultEconomyProvider();
            if (vault.setup()) {
                this.economy = vault;
                getLogger().info("تم ربط SurvivalPlus بنظام اقتصاد Vault (EssentialsX) بنجاح!");
            } else {
                getLogger().warning("تم العثور على Vault لكن لم يتوفر مزود اقتصاد (تأكد من تشغيل EssentialsX).");
            }
        } else {
            getLogger().warning("تحذير: بلقن Vault غير مثبت! حمّل Vault وضعه في plugins لربط فلوس EssentialsX بالمتجر.");
        }

        this.shopManager = new ShopManager(this);
        this.claimManager = new ClaimManager(this);
        this.rtpManager = new RtpManager(this);
        this.combatManager = new CombatManager(this);
        this.chatPromptManager = new ChatPromptManager(this);
        this.shopGuiManager = new ShopGuiManager(this);
        this.claimGuiManager = new ClaimGuiManager(this);

        getServer().getPluginManager().registerEvents(new GuiListener(this), this);
        getServer().getPluginManager().registerEvents(new ProtectionListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerSessionListener(this), this);

        // تسجيل ديناميكي للأوامر ومرادفاتها من config.yml مباشرة!
        ShopCommand shopCmd = new ShopCommand(this);
        registerDynamicCmd("shop", "سوق متاجر اللاعبين", shopCmd, shopCmd);

        ClaimCommand claimCmd = new ClaimCommand(this);
        List<String> claimCommands = Arrays.asList(
                "claim", "claimwand", "abandonclaim", "abandonallclaims",
                "claimslist", "extendclaim", "subdivideclaims", "basicclaims",
                "adminclaims", "ignoreclaims", "trust", "containertrust",
                "accesstrust", "permissiontrust", "untrust", "trustlist",
                "trapped", "buyclaimblocks", "claimmenu"
        );
        for (String c : claimCommands) {
            registerDynamicCmd(c, "أوامر حماية الأراضي", claimCmd, claimCmd);
        }

        registerDynamicCmd("rtp", "انتقال عشوائي آمن", new RtpCommand(this), null);

        AdminCommand adminCmd = new AdminCommand(this);
        registerDynamicCmd("splus", "إدارة SurvivalPlus", adminCmd, adminCmd);

        getLogger().info("تم تشغيل بلقن SurvivalPlus v3.1.0 بنجاح!");
    }

    private void registerDynamicCmd(String name, String desc, CommandExecutor executor, TabCompleter completer) {
        List<String> aliases = getConfig().getStringList("commands." + name + ".aliases");
        DynamicCommand dyn = new DynamicCommand(name, desc, aliases, executor, completer);
        Bukkit.getCommandMap().register("survivalplus", dyn);
    }

    @Override
    public void onDisable() {
        if (shopManager != null) shopManager.save();
        if (claimManager != null) claimManager.save();
    }

    public Component msg(String path, String... placeholders) {
        return messageManager.get(path, placeholders);
    }

    public String getCurrencySymbol() {
        return getConfig().getString("shop.currency-symbol", "$");
    }

    public EconomyProvider getEconomy() { return economy; }
    public MessageManager getMessages() { return messageManager; }
    public ShopManager getShopManager() { return shopManager; }
    public ClaimManager getClaimManager() { return claimManager; }
    public RtpManager getRtpManager() { return rtpManager; }
    public CombatManager getCombatManager() { return combatManager; }
    public ChatPromptManager getChatPromptManager() { return chatPromptManager; }
    public ShopGuiManager getShopGuiManager() { return shopGuiManager; }
    public ClaimGuiManager getClaimGuiManager() { return claimGuiManager; }
}
