package com.myserver.survivalplus.gui;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.models.ClaimFlag;
import com.myserver.survivalplus.models.RegionClaim;
import com.myserver.survivalplus.models.TrustLevel;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

public class ClaimGuiManager {
    private final SurvivalPlus plugin;
    public final NamespacedKey keyFlag;

    public ClaimGuiManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.keyFlag = new NamespacedKey(plugin, "splus_claim_flag");
    }

    public void openClaimMenu(Player player, RegionClaim claim) {
        if (claim == null) {
            player.sendMessage(plugin.msg("claim.not-in-claim"));
            return;
        }
        if (!plugin.getClaimManager().canManageClaim(player, claim)) {
            player.sendMessage(plugin.msg("claim.not-owner"));
            return;
        }

        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.CLAIM_MENU, 0, null, claim.getOwnerUuid(), null, 0, claim.getId());
        Inventory inv = Bukkit.createInventory(holder, 36, TextUtil.color("&8إدارة الأرض المحمية"));

        ItemStack bg = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta bgMeta = bg.getItemMeta();
        bgMeta.displayName(TextUtil.color(" "));
        bg.setItemMeta(bgMeta);
        for (int i = 0; i < 36; i++) inv.setItem(i, bg);

        int[] flagSlots = {11, 12, 13, 14, 15};
        ClaimFlag[] flags = ClaimFlag.values();
        for (int i = 0; i < flags.length; i++) {
            ClaimFlag flag = flags[i];
            boolean enabled = claim.getFlag(flag);
            ItemStack item = new ItemStack(flag.getIcon());
            ItemMeta meta = item.getItemMeta();
            meta.displayName(TextUtil.color("&e" + flag.getArabicName() + ": " + (enabled ? "&aمفعل ✔" : "&cمعطل ✘")));
            meta.lore(TextUtil.colorList(Arrays.asList(
                    "&7" + flag.getDescription(),
                    "",
                    "&eاضغط للتبديل"
            )));
            if (enabled) meta.setEnchantmentGlintOverride(true);
            meta.getPersistentDataContainer().set(keyFlag, PersistentDataType.STRING, flag.name());
            item.setItemMeta(meta);
            inv.setItem(flagSlots[i], item);
        }

        ItemStack borders = new ItemStack(Material.GOLD_BLOCK);
        ItemMeta bMeta = borders.getItemMeta();
        bMeta.displayName(TextUtil.color("&6إظهار حدود الأرض بالذهب والـ Glowstone"));
        bMeta.lore(TextUtil.colorList(Arrays.asList(
                "&7المساحة: &e" + claim.getWidth() + "x" + claim.getLength() + " &7(" + claim.getArea() + " بلوكة)",
                "&7المركز: &f" + claim.getCenterCoords()
        )));
        borders.setItemMeta(bMeta);
        inv.setItem(29, borders);

        List<String> tLore = new ArrayList<>();
        if (claim.getTrustedPlayers().isEmpty()) {
            tLore.add("&7لا يوجد لاعبون موثوقون في هذه الأرض.");
        } else {
            for (Map.Entry<UUID, TrustLevel> entry : claim.getTrustedPlayers().entrySet()) {
                OfflinePlayer op = Bukkit.getOfflinePlayer(entry.getKey());
                String name = op.getName() != null ? op.getName() : entry.getKey().toString().substring(0, 8);
                tLore.add("&8• &a" + name + " &7- &e" + entry.getValue().getArabicLabel());
            }
        }
        tLore.add("");
        tLore.add("&e/ثقة <اللاعب> &7(بناء كامل)");
        tLore.add("&e/ثقة_صناديق <اللاعب> &7(صناديق فقط)");
        tLore.add("&e/ثقة_دخول <اللاعب> &7(أبواب وأزرار فقط)");
        ItemStack friends = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta fMeta = friends.getItemMeta();
        fMeta.displayName(TextUtil.color("&bالموثوقون في هذه الأرض (" + claim.getTrustedPlayers().size() + ")"));
        fMeta.lore(TextUtil.colorList(tLore));
        friends.setItemMeta(fMeta);
        inv.setItem(31, friends);

        ItemStack unclaim = new ItemStack(Material.BARRIER);
        ItemMeta uMeta = unclaim.getItemMeta();
        uMeta.displayName(TextUtil.color("&c&lحذف حماية هذه الأرض"));
        uMeta.lore(TextUtil.colorList(Arrays.asList(
                "&7سيتم استرجاع &a" + claim.getArea() + " &7بلوكة لرصيدك.",
                "&eاضغط Shift + Click للتأكيد."
        )));
        unclaim.setItemMeta(uMeta);
        inv.setItem(33, unclaim);

        player.openInventory(inv);
    }
}
