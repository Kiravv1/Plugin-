package com.myserver.survivalplus.gui;

import com.myserver.survivalplus.managers.ShopManager;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.UUID;

public class GuiHolder implements InventoryHolder {
    public enum MenuType {
        SHOP_DIRECTORY,
        PLAYER_SHOP,
        SHOP_CONFIRM,
        OWNER_DASHBOARD,
        OWNER_LISTINGS,
        OWNER_SALES_LOG,
        OWNER_ICON_PICKER,
        CLAIM_MENU
    }

    private final MenuType type;
    private final int page;
    private final ShopManager.SortMode sortMode;
    private final UUID targetUuid;
    private final String listingId;
    private final double expectedPrice;
    private final String extraData;

    public GuiHolder(MenuType type) {
        this(type, 0, ShopManager.SortMode.TOP_SALES, null, null, 0.0, null);
    }

    public GuiHolder(MenuType type, int page, ShopManager.SortMode sortMode, UUID targetUuid, String listingId, double expectedPrice, String extraData) {
        this.type = type;
        this.page = page;
        this.sortMode = sortMode;
        this.targetUuid = targetUuid;
        this.listingId = listingId;
        this.expectedPrice = expectedPrice;
        this.extraData = extraData;
    }

    public MenuType getType() { return type; }
    public int getPage() { return page; }
    public ShopManager.SortMode getSortMode() { return sortMode; }
    public UUID getTargetUuid() { return targetUuid; }
    public String getListingId() { return listingId; }
    public double getExpectedPrice() { return expectedPrice; }
    public String getExtraData() { return extraData; }

    @Override
    public Inventory getInventory() { return null; }
}
