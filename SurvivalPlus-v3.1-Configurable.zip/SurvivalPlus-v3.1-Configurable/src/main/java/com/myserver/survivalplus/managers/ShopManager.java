package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.models.PlayerShop;
import com.myserver.survivalplus.models.SaleRecord;
import com.myserver.survivalplus.models.ShopListing;
import com.myserver.survivalplus.util.PermissionUtil;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class ShopManager {
    private final SurvivalPlus plugin;
    private final File file;
    private FileConfiguration config;
    private final Map<UUID, PlayerShop> shops = new LinkedHashMap<>();

    public enum SortMode {
        TOP_SALES("الأكثر مبيعاً"),
        MOST_LIKED("الأكثر إعجاباً"),
        NEWEST("الأحدث إضافة"),
        MOST_ITEMS("الأكثر سلعاً");

        private final String display;
        SortMode(String display) { this.display = display; }
        public String getDisplay() { return display; }
        public SortMode next() {
            SortMode[] vals = values();
            return vals[(this.ordinal() + 1) % vals.length];
        }
    }

    public ShopManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shops.yml");
        load();
    }

    public void load() {
        shops.clear();
        if (!file.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = config.getConfigurationSection("shops");
        if (root == null) return;

        for (String uuidStr : root.getKeys(false)) {
            try {
                UUID ownerUuid = UUID.fromString(uuidStr);
                ConfigurationSection sec = root.getConfigurationSection(uuidStr);
                if (sec == null) continue;

                String ownerName = sec.getString("ownerName", "لاعب");
                PlayerShop shop = new PlayerShop(ownerUuid, ownerName);
                shop.setCustomName(sec.getString("customName", "&eمتجر " + ownerName));
                shop.setDescription(sec.getString("description", "&7أهلاً بك في متجري!"));

                String iconStr = sec.getString("iconMaterial");
                if (iconStr != null && !iconStr.isEmpty()) {
                    Material mat = Material.matchMaterial(iconStr);
                    if (mat != null && mat.isItem()) {
                        shop.setIconMaterial(mat);
                    }
                }

                shop.setOpen(sec.getBoolean("open", true));
                shop.setViews(sec.getInt("views", 0));
                shop.setTotalItemsSold(sec.getInt("totalItemsSold", 0));
                shop.setTotalRevenue(sec.getDouble("totalRevenue", 0.0));
                shop.setFeaturedUntil(sec.getLong("featuredUntil", 0L));
                shop.setPendingOfflineEarnings(sec.getDouble("pendingOfflineEarnings", 0.0));
                shop.setPendingOfflineSalesCount(sec.getInt("pendingOfflineSalesCount", 0));

                for (String likeUuid : sec.getStringList("likes")) {
                    try { shop.getLikes().add(UUID.fromString(likeUuid)); } catch (IllegalArgumentException ignored) {}
                }

                ConfigurationSection listingsSec = sec.getConfigurationSection("listings");
                if (listingsSec != null) {
                    for (String id : listingsSec.getKeys(false)) {
                        ItemStack item = listingsSec.getItemStack(id + ".item");
                        double price = listingsSec.getDouble(id + ".price");
                        long createdAt = listingsSec.getLong(id + ".createdAt", System.currentTimeMillis());
                        if (item != null && item.getType() != Material.AIR && price > 0) {
                            shop.getListings().put(id, new ShopListing(id, ownerUuid, item, price, createdAt));
                        }
                    }
                }

                ConfigurationSection histSec = sec.getConfigurationSection("history");
                if (histSec != null) {
                    List<String> keys = new ArrayList<>(histSec.getKeys(false));
                    keys.sort(Comparator.comparingInt(k -> {
                        try { return Integer.parseInt(k); } catch (NumberFormatException e) { return 0; }
                    }));
                    for (String k : keys) {
                        String buyer = histSec.getString(k + ".buyer", "مشتري");
                        String itemName = histSec.getString(k + ".itemName", "غرض");
                        Material mat = Material.matchMaterial(histSec.getString(k + ".material", "PAPER"));
                        int amt = histSec.getInt(k + ".amount", 1);
                        double pr = histSec.getDouble(k + ".price", 0.0);
                        long ts = histSec.getLong(k + ".timestamp", System.currentTimeMillis());
                        shop.getSalesHistory().addLast(new SaleRecord(buyer, itemName, mat, amt, pr, ts));
                    }
                }

                shops.put(ownerUuid, shop);
            } catch (Exception e) {
                plugin.getLogger().warning("تعذر تحميل بيانات متجر: " + uuidStr);
            }
        }
    }

    public void save() {
        config = new YamlConfiguration();
        for (PlayerShop shop : shops.values()) {
            String base = "shops." + shop.getOwnerUuid();
            config.set(base + ".ownerName", shop.getOwnerName());
            config.set(base + ".customName", shop.getCustomName());
            config.set(base + ".description", shop.getDescription());
            config.set(base + ".iconMaterial", shop.getIconMaterial() != null ? shop.getIconMaterial().name() : null);
            config.set(base + ".open", shop.isOpen());
            config.set(base + ".views", shop.getViews());
            config.set(base + ".totalItemsSold", shop.getTotalItemsSold());
            config.set(base + ".totalRevenue", shop.getTotalRevenue());
            config.set(base + ".featuredUntil", shop.getFeaturedUntil());
            config.set(base + ".pendingOfflineEarnings", shop.getPendingOfflineEarnings());
            config.set(base + ".pendingOfflineSalesCount", shop.getPendingOfflineSalesCount());
            config.set(base + ".likes", shop.getLikes().stream().map(UUID::toString).collect(Collectors.toList()));

            for (ShopListing listing : shop.getListings().values()) {
                String lp = base + ".listings." + listing.getId();
                config.set(lp + ".item", listing.getItem());
                config.set(lp + ".price", listing.getPrice());
                config.set(lp + ".createdAt", listing.getCreatedAt());
            }

            int idx = 0;
            for (SaleRecord rec : shop.getSalesHistory()) {
                String hp = base + ".history." + (idx++);
                config.set(hp + ".buyer", rec.getBuyerName());
                config.set(hp + ".itemName", rec.getItemName());
                config.set(hp + ".material", rec.getItemMaterial().name());
                config.set(hp + ".amount", rec.getAmount());
                config.set(hp + ".price", rec.getPrice());
                config.set(hp + ".timestamp", rec.getTimestamp());
            }
        }
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public PlayerShop getOrCreateShop(Player player) {
        PlayerShop shop = shops.computeIfAbsent(player.getUniqueId(), uuid -> new PlayerShop(uuid, player.getName()));
        shop.setOwnerName(player.getName());
        return shop;
    }

    public PlayerShop getShop(UUID ownerUuid) {
        return shops.get(ownerUuid);
    }

    public int getMaxSlots(Player player) {
        int def = plugin.getConfig().getInt("shop.default-max-slots", 5);
        return PermissionUtil.getMaxNumericPermission(player, "survivalplus.shop.slots.", def, 45);
    }

    public boolean isItemBlacklisted(Material material) {
        for (String s : plugin.getConfig().getStringList("shop.blacklisted-items")) {
            if (s.equalsIgnoreCase(material.name())) return true;
        }
        return false;
    }

    public List<PlayerShop> getVisibleShops(SortMode sortMode) {
        List<PlayerShop> visible = shops.values().stream()
                .filter(s -> s.isOpen() && !s.getListings().isEmpty())
                .collect(Collectors.toList());

        Comparator<PlayerShop> secondary = switch (sortMode) {
            case TOP_SALES -> Comparator.comparingInt(PlayerShop::getTotalItemsSold).reversed();
            case MOST_LIKED -> Comparator.comparingInt((PlayerShop s) -> s.getLikes().size()).reversed();
            case NEWEST -> Comparator.comparingLong(PlayerShop::getLatestListingTime).reversed();
            case MOST_ITEMS -> Comparator.comparingInt((PlayerShop s) -> s.getListings().size()).reversed();
        };

        visible.sort(Comparator.comparing(PlayerShop::isFeatured).reversed().thenComparing(secondary));
        return visible;
    }

    public boolean validatePrice(Player player, double price) {
        double min = plugin.getConfig().getDouble("shop.min-price", 1.0);
        double max = plugin.getConfig().getDouble("shop.max-price", 100000000.0);
        if (Double.isNaN(price) || Double.isInfinite(price) || price < min || price > max) {
            String sym = plugin.getCurrencySymbol();
            player.sendMessage(plugin.msg("shop.invalid-price",
                    "{min}", TextUtil.formatMoney(min, sym),
                    "{max}", TextUtil.formatMoney(max, sym)));
            return false;
        }
        return true;
    }

    public double roundPrice(double price) {
        return Math.round(price * 100.0) / 100.0;
    }

    public void addListing(Player player, ItemStack handItem, double rawPrice) {
        if (handItem == null || handItem.getType() == Material.AIR || handItem.getAmount() <= 0) {
            player.sendMessage(plugin.msg("shop.hold-item"));
            return;
        }
        if (isItemBlacklisted(handItem.getType())) {
            player.sendMessage(plugin.msg("shop.blacklisted"));
            return;
        }
        double price = roundPrice(rawPrice);
        if (!validatePrice(player, price)) return;

        PlayerShop shop = getOrCreateShop(player);
        int maxSlots = getMaxSlots(player);
        if (shop.getListings().size() >= maxSlots) {
            player.sendMessage(plugin.msg("shop.max-slots", "{max}", String.valueOf(maxSlots)));
            return;
        }

        ItemStack cloned = handItem.clone();
        player.getInventory().setItemInMainHand(null);

        String id = UUID.randomUUID().toString().substring(0, 8);
        ShopListing listing = new ShopListing(id, player.getUniqueId(), cloned, price, System.currentTimeMillis());
        shop.getListings().put(id, listing);
        save();

        String sym = plugin.getCurrencySymbol();
        player.sendMessage(plugin.msg("shop.listed",
                "{item}", TextUtil.getItemFriendlyName(cloned),
                "{amount}", String.valueOf(cloned.getAmount()),
                "{price}", TextUtil.formatMoney(price, sym)));
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
    }

    public void withdrawListing(Player owner, String listingId) {
        PlayerShop shop = getShop(owner.getUniqueId());
        if (shop == null) return;
        ShopListing listing = shop.getListings().remove(listingId);
        if (listing == null || listing.isSold()) return;
        listing.setSold(true);
        save();
        giveItemSafely(owner, listing.getItem());
        owner.sendMessage(plugin.msg("shop.withdrawn"));
        owner.playSound(owner.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 1f);
    }

    public boolean purchaseListing(Player buyer, UUID sellerUuid, String listingId, double expectedPrice) {
        if (!plugin.getEconomy().isReady()) {
            buyer.sendMessage(TextUtil.color("&cنظام الاقتصاد (Vault) غير متصل حالياً!"));
            return false;
        }

        PlayerShop shop = getShop(sellerUuid);
        if (shop == null || !shop.isOpen()) return false;
        if (buyer.getUniqueId().equals(sellerUuid)) return false;

        ShopListing listing = shop.getListings().get(listingId);
        if (listing == null || listing.isSold()) return false;

        if (Double.compare(listing.getPrice(), expectedPrice) != 0) {
            buyer.sendMessage(plugin.msg("shop.price-changed-scam"));
            buyer.playSound(buyer.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return false;
        }

        double price = listing.getPrice();
        String sym = plugin.getCurrencySymbol();
        if (!plugin.getEconomy().has(buyer, price)) {
            buyer.sendMessage(plugin.msg("shop.not-enough-money", "{price}", TextUtil.formatMoney(price, sym)));
            buyer.playSound(buyer.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return false;
        }

        if (!plugin.getEconomy().withdraw(buyer, price)) return false;

        listing.setSold(true);
        shop.getListings().remove(listingId);

        double taxPercent = Math.max(0.0, Math.min(50.0, plugin.getConfig().getDouble("shop.tax-percent", 0.0)));
        double sellerPayout = roundPrice(price * (1.0 - (taxPercent / 100.0)));

        OfflinePlayer sellerOffline = Bukkit.getOfflinePlayer(sellerUuid);
        plugin.getEconomy().deposit(sellerOffline, sellerPayout);

        ItemStack boughtItem = listing.getItem();
        giveItemSafely(buyer, boughtItem);

        int maxHist = plugin.getConfig().getInt("shop.max-sales-history", 45);
        SaleRecord record = new SaleRecord(
                buyer.getName(),
                TextUtil.getItemFriendlyName(boughtItem),
                boughtItem.getType(),
                boughtItem.getAmount(),
                sellerPayout,
                System.currentTimeMillis()
        );
        shop.addSaleRecord(record, maxHist);

        buyer.sendMessage(plugin.msg("shop.bought-buyer",
                "{item}", record.getItemName(),
                "{amount}", String.valueOf(boughtItem.getAmount()),
                "{price}", TextUtil.formatMoney(price, sym)));
        buyer.playSound(buyer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.4f);

        Player sellerOnline = Bukkit.getPlayer(sellerUuid);
        if (sellerOnline != null && sellerOnline.isOnline()) {
            sellerOnline.sendMessage(plugin.msg("shop.bought-seller",
                    "{buyer}", buyer.getName(),
                    "{item}", record.getItemName(),
                    "{amount}", String.valueOf(boughtItem.getAmount()),
                    "{payout}", TextUtil.formatMoney(sellerPayout, sym)));
            sellerOnline.playSound(sellerOnline.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
        } else {
            shop.setPendingOfflineEarnings(shop.getPendingOfflineEarnings() + sellerPayout);
            shop.setPendingOfflineSalesCount(shop.getPendingOfflineSalesCount() + 1);
        }

        save();
        return true;
    }

    public boolean boostShop(Player owner) {
        if (!plugin.getEconomy().isReady()) return false;
        PlayerShop shop = getOrCreateShop(owner);
        if (shop.isFeatured()) {
            long remSec = (shop.getFeaturedUntil() - System.currentTimeMillis()) / 1000L;
            owner.sendMessage(plugin.msg("shop.boost-already", "{remaining}", TextUtil.formatDuration(remSec)));
            return false;
        }
        double cost = plugin.getConfig().getDouble("shop.boost-cost", 500.0);
        int hours = plugin.getConfig().getInt("shop.boost-hours", 24);
        String sym = plugin.getCurrencySymbol();

        if (!plugin.getEconomy().has(owner, cost)) {
            owner.sendMessage(plugin.msg("shop.not-enough-money", "{price}", TextUtil.formatMoney(cost, sym)));
            owner.playSound(owner.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return false;
        }

        if (!plugin.getEconomy().withdraw(owner, cost)) return false;

        shop.setFeaturedUntil(System.currentTimeMillis() + (hours * 3600L * 1000L));
        save();
        owner.sendMessage(plugin.msg("shop.boost-success", "{hours}", String.valueOf(hours)));
        owner.playSound(owner.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
        return true;
    }

    public void giveItemSafely(Player player, ItemStack item) {
        Map<Integer, ItemStack> overflow = player.getInventory().addItem(item);
        if (!overflow.isEmpty()) {
            for (ItemStack left : overflow.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), left);
            }
            player.sendMessage(plugin.msg("shop.inventory-full"));
        }
    }
}
