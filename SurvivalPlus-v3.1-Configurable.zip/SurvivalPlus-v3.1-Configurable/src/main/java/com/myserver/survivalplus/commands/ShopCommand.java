package com.myserver.survivalplus.commands;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.managers.ShopManager;
import com.myserver.survivalplus.models.PlayerShop;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class ShopCommand implements CommandExecutor, TabCompleter {
    private final SurvivalPlus plugin;

    public ShopCommand(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("general.players-only"));
            return true;
        }

        if (args.length == 0) {
            plugin.getShopGuiManager().openDirectory(player, 0, ShopManager.SortMode.TOP_SALES);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "sell", "بيع" -> {
                if (args.length < 2) return true;
                double price;
                try {
                    price = Double.parseDouble(args[1]);
                } catch (NumberFormatException e) {
                    return true;
                }
                plugin.getShopManager().addListing(player, player.getInventory().getItemInMainHand(), price);
            }

            case "manage", "ادارة", "إدارة", "my", "متجري" -> plugin.getShopGuiManager().openOwnerDashboard(player);

            case "icon", "ايقونة", "أيقونة" -> {
                if (!player.hasPermission("survivalplus.shop.icon")) {
                    player.sendMessage(plugin.msg("general.no-permission"));
                    return true;
                }
                if (args.length >= 2 && (args[1].equalsIgnoreCase("reset") || args[1].equals("راس") || args[1].equals("افتراضي"))) {
                    PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
                    shop.setIconMaterial(null);
                    plugin.getShopManager().save();
                    return true;
                }
                ItemStack hand = player.getInventory().getItemInMainHand();
                if (hand.getType() == Material.AIR) {
                    plugin.getShopGuiManager().openIconPicker(player);
                } else {
                    PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
                    shop.setIconMaterial(hand.getType());
                    plugin.getShopManager().save();
                }
            }

            case "name", "اسم" -> {
                if (args.length < 2) return true;
                String raw = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
                boolean allowColor = player.hasPermission("survivalplus.shop.color");
                String clean = allowColor ? raw : TextUtil.stripColor(raw);
                if (TextUtil.stripColor(clean).length() > 32) return true;
                PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
                shop.setCustomName(allowColor ? clean : "&e" + clean);
                plugin.getShopManager().save();
            }

            case "desc", "وصف" -> {
                if (args.length < 2) return true;
                String raw = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
                boolean allowColor = player.hasPermission("survivalplus.shop.color");
                String clean = allowColor ? raw : TextUtil.stripColor(raw);
                if (TextUtil.stripColor(clean).length() > 80) return true;
                PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
                shop.setDescription(allowColor ? clean : "&7" + clean);
                plugin.getShopManager().save();
            }

            case "boost", "ترويج" -> plugin.getShopManager().boostShop(player);

            case "toggle", "اغلاق", "فتح" -> {
                PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
                shop.setOpen(!shop.isOpen());
                plugin.getShopManager().save();
            }

            default -> {
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
                PlayerShop shop = plugin.getShopManager().getShop(target.getUniqueId());
                if (shop != null) {
                    plugin.getShopGuiManager().openPlayerShop(player, target.getUniqueId(), true);
                }
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("sell", "بيع", "manage", "ادارة", "icon", "ايقونة", "name", "اسم", "desc", "وصف", "boost", "ترويج", "toggle");
        }
        return Collections.emptyList();
    }
}
