package com.myserver.survivalplus.listeners;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.models.ClaimFlag;
import com.myserver.survivalplus.models.RegionClaim;
import com.myserver.survivalplus.models.TrustLevel;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.vehicle.VehicleDamageEvent;
import org.bukkit.event.vehicle.VehicleMoveEvent;
import org.bukkit.event.world.StructureGrowEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.Objects;

public class ProtectionListener implements Listener {
    private final SurvivalPlus plugin;

    public ProtectionListener(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    private void deny(Player player, String messageKey) {
        player.sendActionBar(TextUtil.color("&c✖ " + plugin.getMessages().raw(messageKey)));
    }

    private Player extractPlayerAttacker(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Player shooter) return shooter;
        if (damager instanceof AreaEffectCloud cloud && cloud.getSource() instanceof Player shooter) return shooter;
        if (damager instanceof TNTPrimed tnt && tnt.getSource() instanceof Player igniter) return igniter;
        return null;
    }

    private boolean isAccessBlock(Material mat) {
        String name = mat.name();
        return name.endsWith("_DOOR") || name.endsWith("_TRAPDOOR") || name.endsWith("_FENCE_GATE")
                || name.endsWith("_BUTTON") || name.endsWith("_PRESSURE_PLATE")
                || name.endsWith("_BED") || mat == Material.LEVER || mat == Material.CRAFTING_TABLE
                || mat == Material.ENDER_CHEST || mat == Material.ENCHANTING_TABLE || mat == Material.ANVIL
                || mat == Material.CHIPPED_ANVIL || mat == Material.DAMAGED_ANVIL;
    }

    @EventHandler
    public void onItemHeld(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        ItemStack next = player.getInventory().getItem(event.getNewSlot());
        if (next != null && next.getType() == plugin.getClaimManager().getWandMaterial()) {
            int rem = plugin.getClaimManager().getRemainingClaimBlocks(player.getUniqueId());
            player.sendActionBar(plugin.getMessages().getNoPrefix("claim.wand-actionbar", "{blocks}", String.valueOf(rem)));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (event.getTo() == null) return;
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()
                && event.getFrom().getWorld().equals(event.getTo().getWorld())) return;

        RegionClaim fromClaim = plugin.getClaimManager().getTopClaimAt(event.getFrom());
        RegionClaim toClaim = plugin.getClaimManager().getTopClaimAt(event.getTo());

        if (Objects.equals(fromClaim == null ? null : fromClaim.getId(),
                toClaim == null ? null : toClaim.getId())) return;

        Player player = event.getPlayer();
        if (toClaim != null) {
            player.sendActionBar(plugin.getMessages().getNoPrefix("claim.enter-claim-actionbar", "{owner}", toClaim.getOwnerName()));
        } else if (fromClaim != null) {
            player.sendActionBar(plugin.getMessages().getNoPrefix("claim.leave-claim-actionbar"));
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack hand = event.getItem();

        if (event.getHand() == EquipmentSlot.HAND && hand != null && event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null) {
            if (hand.getType() == plugin.getClaimManager().getWandMaterial()) {
                event.setCancelled(true);
                plugin.getClaimManager().handleWandClick(player, event.getClickedBlock());
                return;
            }
            if (hand.getType() == plugin.getClaimManager().getInspectMaterial()) {
                event.setCancelled(true);
                handleInspectClick(player, event.getClickedBlock());
                return;
            }
        }

        if (event.isCancelled()) return;
        Block block = event.getClickedBlock();
        if (block == null) return;

        Location loc = block.getLocation();
        RegionClaim topClaim = plugin.getClaimManager().getTopClaimAt(loc);

        if (event.getAction() == Action.PHYSICAL) {
            if (topClaim != null && !plugin.getClaimManager().hasTrust(player, loc, TrustLevel.ACCESS)) {
                if (block.getType() == Material.FARMLAND || !topClaim.getFlag(ClaimFlag.VISITOR_INTERACT)) {
                    event.setCancelled(true);
                }
            }
            return;
        }

        if (topClaim != null) {
            Material type = block.getType();
            if (type.isInteractable()) {
                if (isAccessBlock(type)) {
                    if (plugin.getClaimManager().hasTrust(player, loc, TrustLevel.ACCESS)
                            || topClaim.getFlag(ClaimFlag.VISITOR_INTERACT)) {
                        return;
                    }
                    event.setCancelled(true);
                    deny(player, "claim.deny-access");
                    return;
                } else {
                    if (!plugin.getClaimManager().hasTrust(player, loc, TrustLevel.CONTAINER)) {
                        event.setCancelled(true);
                        deny(player, "claim.deny-container");
                        return;
                    }
                }
            }
        }

        if (hand != null && event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            Location targetLoc = block.getRelative(event.getBlockFace()).getLocation();
            if (!plugin.getClaimManager().hasTrust(player, targetLoc, TrustLevel.BUILD)
                    || !plugin.getClaimManager().hasTrust(player, loc, TrustLevel.BUILD)) {
                String matName = hand.getType().name();
                if (matName.contains("BOAT") || matName.contains("MINECART") || matName.contains("SPAWN_EGG")
                        || hand.getType() == Material.ARMOR_STAND || hand.getType() == Material.END_CRYSTAL
                        || hand.getType() == Material.FLINT_AND_STEEL || hand.getType() == Material.FIRE_CHARGE
                        || hand.getType() == Material.BONE_MEAL || hand.getType() == Material.ITEM_FRAME
                        || hand.getType() == Material.GLOW_ITEM_FRAME || hand.getType() == Material.PAINTING) {
                    event.setCancelled(true);
                    deny(player, "claim.deny-build");
                }
            }
        }
    }

    private void handleInspectClick(Player player, Block block) {
        if (player.isSneaking()) {
            List<RegionClaim> nearby = plugin.getClaimManager().getNearbyClaims(block.getLocation(), 50);
            if (nearby.isEmpty()) {
                player.sendMessage(plugin.msg("claim.inspect-wild"));
            } else {
                for (RegionClaim c : nearby) {
                    player.sendMessage(TextUtil.color(" &8• &fالمالك: &e" + c.getOwnerName() + " &7| المساحة: &a" + c.getWidth() + "x" + c.getLength() + " &7| " + c.getCenterCoords()));
                }
                plugin.getClaimManager().visualizeClaim(player, nearby.get(0),
                        !nearby.get(0).isAdminClaim() && nearby.get(0).getOwnerUuid().equals(player.getUniqueId()));
            }
            return;
        }

        RegionClaim top = plugin.getClaimManager().getTopClaimAt(block.getLocation());
        if (top == null) {
            player.sendMessage(plugin.msg("claim.inspect-wild"));
            return;
        }

        boolean mine = !top.isAdminClaim() && top.getOwnerUuid().equals(player.getUniqueId());
        player.sendMessage(plugin.msg("claim.inspect-claimed",
                "{owner}", top.getOwnerName(),
                "{width}", String.valueOf(top.getWidth()),
                "{length}", String.valueOf(top.getLength()),
                "{area}", String.valueOf(top.getArea())));
        plugin.getClaimManager().visualizeClaim(player, top, mine);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (!plugin.getClaimManager().hasTrust(event.getPlayer(), event.getBlock().getLocation(), TrustLevel.BUILD)) {
            event.setCancelled(true);
            deny(event.getPlayer(), "claim.deny-build");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!plugin.getClaimManager().hasTrust(event.getPlayer(), event.getBlock().getLocation(), TrustLevel.BUILD)) {
            event.setCancelled(true);
            deny(event.getPlayer(), "claim.deny-build");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        Location target = event.getBlockClicked().getRelative(event.getBlockFace()).getLocation();
        if (!plugin.getClaimManager().hasTrust(event.getPlayer(), target, TrustLevel.BUILD)) {
            event.setCancelled(true);
            deny(event.getPlayer(), "claim.deny-build");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent event) {
        if (!plugin.getClaimManager().hasTrust(event.getPlayer(), event.getBlockClicked().getLocation(), TrustLevel.BUILD)) {
            event.setCancelled(true);
            deny(event.getPlayer(), "claim.deny-build");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFluidFlow(BlockFromToEvent event) {
        RegionClaim from = plugin.getClaimManager().getTopClaimAt(event.getBlock().getLocation());
        RegionClaim to = plugin.getClaimManager().getTopClaimAt(event.getToBlock().getLocation());
        if (!plugin.getClaimManager().sameOwnerOrTrusted(from, to)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent event) {
        RegionClaim pistonClaim = plugin.getClaimManager().getTopClaimAt(event.getBlock().getLocation());
        BlockFace dir = event.getDirection();

        RegionClaim headClaim = plugin.getClaimManager().getTopClaimAt(event.getBlock().getRelative(dir).getLocation());
        if (!plugin.getClaimManager().sameOwnerOrTrusted(pistonClaim, headClaim)) {
            event.setCancelled(true);
            return;
        }
        for (Block moved : event.getBlocks()) {
            RegionClaim src = plugin.getClaimManager().getTopClaimAt(moved.getLocation());
            RegionClaim dst = plugin.getClaimManager().getTopClaimAt(moved.getRelative(dir).getLocation());
            if (!plugin.getClaimManager().sameOwnerOrTrusted(pistonClaim, src)
                    || !plugin.getClaimManager().sameOwnerOrTrusted(pistonClaim, dst)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent event) {
        RegionClaim pistonClaim = plugin.getClaimManager().getTopClaimAt(event.getBlock().getLocation());
        BlockFace dir = event.getDirection();
        for (Block moved : event.getBlocks()) {
            RegionClaim src = plugin.getClaimManager().getTopClaimAt(moved.getLocation());
            RegionClaim dst = plugin.getClaimManager().getTopClaimAt(moved.getRelative(dir).getLocation());
            if (!plugin.getClaimManager().sameOwnerOrTrusted(pistonClaim, src)
                    || !plugin.getClaimManager().sameOwnerOrTrusted(pistonClaim, dst)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHopperTransfer(InventoryMoveItemEvent event) {
        Location srcLoc = event.getSource().getLocation();
        Location dstLoc = event.getDestination().getLocation();
        if (srcLoc == null || dstLoc == null) return;

        RegionClaim srcClaim = plugin.getClaimManager().getTopClaimAt(srcLoc);
        if (srcClaim == null) return;

        RegionClaim dstClaim = plugin.getClaimManager().getTopClaimAt(dstLoc);
        if (!plugin.getClaimManager().sameOwnerOrTrusted(dstClaim, srcClaim)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onMinecartCrossBorder(VehicleMoveEvent event) {
        if (!(event.getVehicle() instanceof Minecart minecart)) return;
        RegionClaim from = plugin.getClaimManager().getTopClaimAt(event.getFrom());
        RegionClaim to = plugin.getClaimManager().getTopClaimAt(event.getTo());
        if (!plugin.getClaimManager().sameOwnerOrTrusted(from, to)) {
            if (minecart instanceof org.bukkit.entity.minecart.HopperMinecart
                    || minecart instanceof org.bukkit.entity.minecart.ExplosiveMinecart) {
                minecart.setVelocity(new Vector(0, 0, 0));
                minecart.teleport(event.getFrom());
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDispense(BlockDispenseEvent event) {
        if (!(event.getBlock().getBlockData() instanceof Directional dir)) return;
        Block target = event.getBlock().getRelative(dir.getFacing());
        RegionClaim src = plugin.getClaimManager().getTopClaimAt(event.getBlock().getLocation());
        RegionClaim dst = plugin.getClaimManager().getTopClaimAt(target.getLocation());
        if (!plugin.getClaimManager().sameOwnerOrTrusted(src, dst)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        event.blockList().removeIf(block -> {
            RegionClaim claim = plugin.getClaimManager().getTopClaimAt(block.getLocation());
            return claim != null && !claim.getFlag(ClaimFlag.EXPLOSIONS);
        });
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        event.blockList().removeIf(block -> {
            RegionClaim claim = plugin.getClaimManager().getTopClaimAt(block.getLocation());
            return claim != null && !claim.getFlag(ClaimFlag.EXPLOSIONS);
        });
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFireSpread(BlockSpreadEvent event) {
        if (event.getSource().getType() == Material.FIRE || event.getSource().getType() == Material.SOUL_FIRE) {
            RegionClaim claim = plugin.getClaimManager().getTopClaimAt(event.getBlock().getLocation());
            if (claim != null && !claim.getFlag(ClaimFlag.FIRE_SPREAD)) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBurn(BlockBurnEvent event) {
        RegionClaim claim = plugin.getClaimManager().getTopClaimAt(event.getBlock().getLocation());
        if (claim != null && !claim.getFlag(ClaimFlag.FIRE_SPREAD)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent event) {
        RegionClaim claim = plugin.getClaimManager().getTopClaimAt(event.getBlock().getLocation());
        if (claim == null) return;
        if (event.getPlayer() != null) {
            if (!plugin.getClaimManager().hasTrust(event.getPlayer(), event.getBlock().getLocation(), TrustLevel.BUILD)) {
                event.setCancelled(true);
            }
        } else if (!claim.getFlag(ClaimFlag.FIRE_SPREAD)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        Entity victim = event.getEntity();
        RegionClaim claim = plugin.getClaimManager().getTopClaimAt(victim.getLocation());
        if (claim == null) return;

        Player attacker = extractPlayerAttacker(event.getDamager());

        if (victim instanceof Player) {
            if (attacker != null && !claim.getFlag(ClaimFlag.PVP)) {
                event.setCancelled(true);
                deny(attacker, "claim.deny-pvp");
            }
            return;
        }

        if (!(victim instanceof Monster) && !(victim instanceof Slime) && !(victim instanceof Phantom)) {
            if (attacker != null) {
                if (!plugin.getClaimManager().hasTrust(attacker, victim.getLocation(), TrustLevel.CONTAINER)) {
                    event.setCancelled(true);
                    deny(attacker, "claim.deny-container");
                }
            } else if (!claim.getFlag(ClaimFlag.EXPLOSIONS)) {
                if (event.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION
                        || event.getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPotionSplash(PotionSplashEvent event) {
        if (!(event.getPotion().getShooter() instanceof Player thrower)) return;
        for (LivingEntity affected : event.getAffectedEntities()) {
            RegionClaim claim = plugin.getClaimManager().getTopClaimAt(affected.getLocation());
            if (claim == null) continue;
            if (affected instanceof Player target && !target.equals(thrower)) {
                if (!claim.getFlag(ClaimFlag.PVP)) {
                    event.setIntensity(affected, 0.0);
                }
            } else if (!(affected instanceof Monster) && !plugin.getClaimManager().hasTrust(thrower, affected.getLocation(), TrustLevel.CONTAINER)) {
                event.setIntensity(affected, 0.0);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFishSteal(PlayerFishEvent event) {
        Entity caught = event.getCaught();
        if (caught == null || caught instanceof Item || caught instanceof Player) return;
        if (!plugin.getClaimManager().hasTrust(event.getPlayer(), caught.getLocation(), TrustLevel.CONTAINER)) {
            event.setCancelled(true);
            deny(event.getPlayer(), "claim.deny-container");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onProjectileHitBlock(ProjectileHitEvent event) {
        Block hit = event.getHitBlock();
        if (hit == null) return;
        RegionClaim claim = plugin.getClaimManager().getTopClaimAt(hit.getLocation());
        if (claim == null) return;
        if (event.getEntity().getShooter() instanceof Player shooter) {
            if (!plugin.getClaimManager().hasTrust(shooter, hit.getLocation(), TrustLevel.ACCESS)) {
                if (hit.getType().isInteractable() || event.getEntity() instanceof WindCharge) {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onArmorStand(PlayerArmorStandManipulateEvent event) {
        if (!plugin.getClaimManager().hasTrust(event.getPlayer(), event.getRightClicked().getLocation(), TrustLevel.CONTAINER)) {
            event.setCancelled(true);
            deny(event.getPlayer(), "claim.deny-container");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityInteract(PlayerInteractEntityEvent event) {
        Entity target = event.getRightClicked();
        if (target instanceof Player) return;
        if (!plugin.getClaimManager().hasTrust(event.getPlayer(), target.getLocation(), TrustLevel.CONTAINER)) {
            RegionClaim claim = plugin.getClaimManager().getTopClaimAt(target.getLocation());
            if (target instanceof Villager && claim != null && claim.getFlag(ClaimFlag.VISITOR_INTERACT)) {
                return;
            }
            event.setCancelled(true);
            deny(event.getPlayer(), "claim.deny-container");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent event) {
        RegionClaim claim = plugin.getClaimManager().getTopClaimAt(event.getEntity().getLocation());
        if (claim == null) return;
        Player remover = extractPlayerAttacker(event.getRemover());
        if (remover != null) {
            if (!plugin.getClaimManager().hasTrust(remover, event.getEntity().getLocation(), TrustLevel.BUILD)) {
                event.setCancelled(true);
                deny(remover, "claim.deny-build");
            }
        } else if (!claim.getFlag(ClaimFlag.EXPLOSIONS)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingPlace(HangingPlaceEvent event) {
        if (event.getPlayer() != null && !plugin.getClaimManager().hasTrust(event.getPlayer(), event.getEntity().getLocation(), TrustLevel.BUILD)) {
            event.setCancelled(true);
            deny(event.getPlayer(), "claim.deny-build");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onVehicleDamage(VehicleDamageEvent event) {
        RegionClaim claim = plugin.getClaimManager().getTopClaimAt(event.getVehicle().getLocation());
        if (claim == null) return;
        Player attacker = extractPlayerAttacker(event.getAttacker());
        if (attacker != null && !plugin.getClaimManager().hasTrust(attacker, event.getVehicle().getLocation(), TrustLevel.BUILD)) {
            event.setCancelled(true);
            deny(attacker, "claim.deny-build");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMobGrief(EntityChangeBlockEvent event) {
        RegionClaim claim = plugin.getClaimManager().getTopClaimAt(event.getBlock().getLocation());
        if (claim == null) return;
        if (event.getEntity() instanceof Player p) {
            if (!plugin.getClaimManager().hasTrust(p, event.getBlock().getLocation(), TrustLevel.BUILD)) {
                event.setCancelled(true);
            }
        } else if (!claim.getFlag(ClaimFlag.MOB_GRIEF)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTreeGrow(StructureGrowEvent event) {
        RegionClaim origin = plugin.getClaimManager().getTopClaimAt(event.getLocation());
        event.getBlocks().removeIf(state -> {
            RegionClaim target = plugin.getClaimManager().getTopClaimAt(state.getLocation());
            return !plugin.getClaimManager().sameOwnerOrTrusted(origin, target);
        });
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFrostWalker(EntityBlockFormEvent event) {
        if (event.getEntity() instanceof Player p) {
            if (!plugin.getClaimManager().hasTrust(p, event.getBlock().getLocation(), TrustLevel.BUILD)) {
                event.setCancelled(true);
            }
        }
    }
}
