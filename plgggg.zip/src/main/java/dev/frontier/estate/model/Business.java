package dev.frontier.estate.model;

import java.util.UUID;

/** A shop operating on a plot. Has its own balance, separate from the owner's personal money. */
public final class Business {
    public final String id;
    public String name;
    public final UUID owner;
    public final String plotId;
    public double balance;
    public final long createdAt;

    public Business(String id, String name, UUID owner, String plotId, double balance, long createdAt) {
        this.id = id;
        this.name = name;
        this.owner = owner;
        this.plotId = plotId;
        this.balance = balance;
        this.createdAt = createdAt;
    }
}
