package dev.frontier.estate.model;

import java.util.UUID;

/** A rental listing for a plot, and the contract with the current tenant if there is one. */
public final class Rental {

    public enum Status { LISTED, ACTIVE, GRACE }

    public final String plotId;
    public Status status = Status.LISTED;
    public double price;
    public long periodSec;
    /** Deposit held by the plugin while the tenant occupies the plot. */
    public double deposit;
    public boolean allowBuild;
    /** Number of billing periods in the contract. 0 = open-ended. */
    public int periodsTotal;
    public int periodsPaid;
    public UUID tenant;
    public long startMs;
    public long nextDueMs;
    public long graceUntilMs;
    /** In-memory only: a reminder was already sent for the next due date. */
    public boolean reminded;

    public Rental(String plotId) {
        this.plotId = plotId;
    }

    public boolean isOccupied() {
        return status != Status.LISTED && tenant != null;
    }
}
