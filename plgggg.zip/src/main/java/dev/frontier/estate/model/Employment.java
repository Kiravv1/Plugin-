package dev.frontier.estate.model;

import java.util.UUID;

/** A player working for a business. */
public final class Employment {
    public final String id;
    public final String businessId;
    public final String jobId;
    public final UUID employee;
    public final String employeeName;
    public double wage;
    public int maxHours;
    public final long hiredAt;
    public long dayStamp;
    public long workedTodayMs;
    public long totalWorkedMs;
    public double totalPaid;

    public Employment(String id, String businessId, String jobId, UUID employee, String employeeName,
                      double wage, int maxHours, long hiredAt) {
        this.id = id;
        this.businessId = businessId;
        this.jobId = jobId;
        this.employee = employee;
        this.employeeName = employeeName;
        this.wage = wage;
        this.maxHours = maxHours;
        this.hiredAt = hiredAt;
    }
}
