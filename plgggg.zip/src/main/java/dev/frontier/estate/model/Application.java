package dev.frontier.estate.model;

import java.util.UUID;

/** A player's application for a job. */
public final class Application {
    public final String id;
    public final String jobId;
    public final UUID applicant;
    public final String applicantName;
    public final long createdAt;

    public Application(String id, String jobId, UUID applicant, String applicantName, long createdAt) {
        this.id = id;
        this.jobId = jobId;
        this.applicant = applicant;
        this.applicantName = applicantName;
        this.createdAt = createdAt;
    }
}
