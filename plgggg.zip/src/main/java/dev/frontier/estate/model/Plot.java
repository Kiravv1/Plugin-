package dev.frontier.estate.model;

import org.bukkit.Location;
import org.bukkit.World;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** A protected region of the world that can be owned, rented and built on. */
public final class Plot {

    public enum Type { HOUSE, SHOP, FARM, LAND }

    public final String id;
    public final String world;
    public final int minX, minY, minZ, maxX, maxY, maxZ;
    public Type type = Type.HOUSE;
    /** Price when sold by the state. Negative = not for sale. */
    public double price;
    /** null = owned by the state (for sale if price >= 0). */
    public UUID owner;
    public String displayName;
    /** Anyone may use doors, buttons and levers inside. */
    public boolean publicAccess;
    public final Set<UUID> trusted = new HashSet<>();
    public long createdAt = System.currentTimeMillis();
    public Rental rental;
    /** True while a snapshot is being captured or restored: nobody may build. */
    public boolean busy;

    public Plot(String id, String world, int x1, int y1, int z1, int x2, int y2, int z2) {
        this.id = id;
        this.world = world;
        this.minX = Math.min(x1, x2);
        this.maxX = Math.max(x1, x2);
        this.minY = Math.min(y1, y2);
        this.maxY = Math.max(y1, y2);
        this.minZ = Math.min(z1, z2);
        this.maxZ = Math.max(z1, z2);
    }

    public boolean contains(String w, int x, int y, int z) {
        return w.equals(world) && x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    public boolean contains(Location l) {
        World w = l.getWorld();
        return w != null && contains(w.getName(), l.getBlockX(), l.getBlockY(), l.getBlockZ());
    }

    public boolean overlaps(String w, int x1, int y1, int z1, int x2, int y2, int z2) {
        if (!w.equals(world)) return false;
        return Math.min(x1, x2) <= maxX && Math.max(x1, x2) >= minX
                && Math.min(y1, y2) <= maxY && Math.max(y1, y2) >= minY
                && Math.min(z1, z2) <= maxZ && Math.max(z1, z2) >= minZ;
    }

    public int sizeX() { return maxX - minX + 1; }
    public int sizeY() { return maxY - minY + 1; }
    public int sizeZ() { return maxZ - minZ + 1; }

    /** The person who currently controls the plot: the tenant while rented, otherwise the owner. */
    public UUID controller() {
        return rental != null && rental.isOccupied() ? rental.tenant : owner;
    }

    public boolean isOwner(UUID id) { return owner != null && owner.equals(id); }

    public boolean isTenant(UUID id) { return rental != null && rental.isOccupied() && rental.tenant.equals(id); }

    public boolean isControlledBy(UUID id) {
        UUID c = controller();
        return c != null && c.equals(id);
    }

    public String label() {
        return displayName != null && !displayName.isBlank() ? displayName : id;
    }
}
