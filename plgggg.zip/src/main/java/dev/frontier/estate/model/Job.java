package dev.frontier.estate.model;

/** A vacancy posted by a business. */
public final class Job {
    public final String id;
    public final String businessId;
    public String title;
    public double wage;
    public int maxHours;
    public int slots;
    public boolean open;
    public final long createdAt;

    public Job(String id, String businessId, String title, double wage, int maxHours, int slots, boolean open, long createdAt) {
        this.id = id;
        this.businessId = businessId;
        this.title = title;
        this.wage = wage;
        this.maxHours = maxHours;
        this.slots = slots;
        this.open = open;
        this.createdAt = createdAt;
    }
}
