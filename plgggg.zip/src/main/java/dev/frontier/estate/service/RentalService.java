package dev.frontier.estate.service;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.model.Plot;
import dev.frontier.estate.model.Rental;
import dev.frontier.estate.util.TimeUtil;
import dev.frontier.estate.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.block.Container;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Listing, renting, automatic billing, grace periods and eviction. */
public final class RentalService {

    public enum EndReason { COMPLETED, LEFT, EVICTED, ADMIN }

    private final FrontierEstatePlugin plugin;
    private BukkitTask task;

    public RentalService(FrontierEstatePlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        long seconds = Math.max(5L, plugin.getConfig().getLong("rental.billing-check-seconds", 30L));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::billingTick, 100L, seconds * 20L);
    }

    public void shutdown() {
        if (task != null) task.cancel();
    }

    private void msg(Player p, String key, Object... pairs) {
        plugin.messages().send(p, key, pairs);
    }

    private String money(double v) {
        return plugin.economy().format(v);
    }

    // ------------------------------------------------------------------ owner: list / unlist

    public boolean list(Player p, Plot plot, double price, long periodSec, double deposit,
                        int periodsTotal, boolean allowBuild) {
        if (!plot.isOwner(p.getUniqueId())) {
            msg(p, "rent.not-owner");
            return false;
        }
        if (plot.rental != null) {
            msg(p, "rent.already-listed");
            return false;
        }
        var cfg = plugin.getConfig();
        double minPrice = cfg.getDouble("rental.min-price", 1);
        double maxPrice = cfg.getDouble("rental.max-price", 1_000_000);
        long minPeriod = cfg.getLong("rental.min-period-seconds", 3600L);
        long maxPeriod = cfg.getLong("rental.max-period-seconds", 2_592_000L);
        double depositMult = cfg.getDouble("rental.max-deposit-multiplier", 10);
        int maxPeriods = cfg.getInt("rental.max-periods", 365);
        if (price < minPrice || price > maxPrice) {
            msg(p, "rent.bad-price", "min", money(minPrice), "max", money(maxPrice));
            return false;
        }
        if (periodSec < minPeriod || periodSec > maxPeriod) {
            msg(p, "rent.bad-period", "min", TimeUtil.format(minPeriod), "max", TimeUtil.format(maxPeriod));
            return false;
        }
        if (deposit < 0 || deposit > price * depositMult) {
            msg(p, "rent.bad-deposit", "max", money(price * depositMult));
            return false;
        }
        if (periodsTotal < 0 || periodsTotal > maxPeriods) {
            msg(p, "rent.bad-periods", "max", maxPeriods);
            return false;
        }
        Rental r = new Rental(plot.id);
        r.price = EconomyService.round(price);
        r.periodSec = periodSec;
        r.deposit = EconomyService.round(deposit);
        r.periodsTotal = periodsTotal;
        r.allowBuild = allowBuild;
        plot.rental = r;
        plugin.plots().saveRental(r);
        msg(p, "rent.listed", "plot", (plot.label()), "price", money(r.price),
                "period", TimeUtil.format(periodSec));
        return true;
    }

    public boolean unlist(Player p, Plot plot) {
        if (!plot.isOwner(p.getUniqueId())) {
            msg(p, "rent.not-owner");
            return false;
        }
        Rental r = plot.rental;
        if (r == null) {
            msg(p, "rent.not-listed");
            return false;
        }
        if (r.isOccupied()) {
            msg(p, "rent.has-tenant");
            return false;
        }
        plot.rental = null;
        plugin.plots().deleteRental(plot.id);
        plugin.snapshots().delete(plot.id);
        msg(p, "rent.unlisted");
        return true;
    }

    // ------------------------------------------------------------------ tenant: rent / leave / pay

    public boolean rent(Player t, Plot plot) {
        Rental r = plot.rental;
        if (r == null || r.status != Rental.Status.LISTED || plot.owner == null) {
            msg(t, "rent.not-available");
            return false;
        }
        if (plot.busy) {
            msg(t, "protect.busy");
            return false;
        }
        UUID tid = t.getUniqueId();
        if (plot.owner.equals(tid)) {
            msg(t, "rent.own-plot");
            return false;
        }
        int max = plugin.getConfig().getInt("rental.max-rentals-per-player", 3);
        if (plugin.plots().rentedBy(tid).size() >= max) {
            msg(t, "rent.limit", "max", max);
            return false;
        }
        double total = EconomyService.round(r.price + r.deposit);
        if (!plugin.economy().has(tid, total)) {
            msg(t, "common.no-money", "price", money(total));
            return false;
        }
        if (!plugin.economy().withdraw(tid, total)) {
            msg(t, "common.payment-failed");
            return false;
        }
        double tax = taxOf(r.price);
        double net = EconomyService.round(r.price - tax);
        plugin.economy().deposit(plot.owner, net);
        plugin.ledger().log("RENT_FIRST", tid, plot.owner, r.price, plot.id);
        if (r.deposit > 0) plugin.ledger().log("RENT_DEPOSIT_HELD", tid, null, r.deposit, plot.id);

        // the owner's own shop (if any) closes: the tenant controls the plot now
        plugin.business().closeForPlot(plot, "business.closed-rented");

        long now = System.currentTimeMillis();
        r.status = Rental.Status.ACTIVE;
        r.tenant = tid;
        r.startMs = now;
        r.nextDueMs = now + r.periodSec * 1000L;
        r.graceUntilMs = 0;
        r.periodsPaid = 1;
        r.reminded = false;
        plot.trusted.clear();
        plugin.plots().saveRental(r);
        plugin.plots().save(plot);

        msg(t, "rent.rented", "plot", (plot.label()), "price", money(r.price),
                "period", TimeUtil.format(r.periodSec), "deposit", money(r.deposit));
        plugin.notices().notify(plot.owner, "rent.owner-rented", "player", t.getName(),
                "plot", (plot.label()), "amount", money(net));

        if (r.allowBuild && plugin.getConfig().getBoolean("snapshot.enabled", true)) {
            plot.busy = true;
            plugin.snapshots().capture(plot, ok -> {
                plot.busy = false;
                Player online = Bukkit.getPlayer(tid);
                if (online != null) msg(online, ok ? "rent.snapshot-ready" : "rent.snapshot-failed");
            });
        }
        return true;
    }

    public boolean leave(Player t, Plot plot) {
        if (!plot.isTenant(t.getUniqueId())) {
            msg(t, "rent.not-tenant");
            return false;
        }
        endRental(plot, EndReason.LEFT);
        return true;
    }

    /** Pays an overdue amount by hand while in the grace period. */
    public boolean payNow(Player t, Plot plot) {
        Rental r = plot.rental;
        if (r == null || !plot.isTenant(t.getUniqueId())) {
            msg(t, "rent.not-tenant");
            return false;
        }
        if (r.status != Rental.Status.GRACE) {
            msg(t, "rent.nothing-due");
            return false;
        }
        if (!charge(plot, r)) {
            msg(t, "common.no-money", "price", money(r.price));
            return false;
        }
        recover(plot, r, System.currentTimeMillis());
        msg(t, "rent.paid-late");
        return true;
    }

    // ------------------------------------------------------------------ billing

    private double taxOf(double amount) {
        double pct = plugin.getConfig().getDouble("rental.tax-percent", 5);
        return EconomyService.round(amount * pct / 100.0);
    }

    /** Takes one period of rent from the tenant and pays the owner (minus tax). */
    private boolean charge(Plot plot, Rental r) {
        if (r.tenant == null || plot.owner == null) return false;
        if (!plugin.economy().has(r.tenant, r.price)) return false;
        if (!plugin.economy().withdraw(r.tenant, r.price)) return false;
        double net = EconomyService.round(r.price - taxOf(r.price));
        plugin.economy().deposit(plot.owner, net);
        plugin.ledger().log("RENT", r.tenant, plot.owner, r.price, plot.id);
        return true;
    }

    private void recover(Plot plot, Rental r, long now) {
        r.status = Rental.Status.ACTIVE;
        r.graceUntilMs = 0;
        r.periodsPaid++;
        r.nextDueMs = now + r.periodSec * 1000L;
        r.reminded = false;
        plugin.plots().saveRental(r);
        plugin.notices().notify(plot.owner, "rent.owner-paid", "player", Text.name(r.tenant),
                "plot", (plot.label()));
    }

    private void billingTick() {
        long now = System.currentTimeMillis();
        int cap = Math.max(20, plugin.getConfig().getInt("rental.max-billing-per-tick", 200));
        int processed = 0;
        long reminderMs = plugin.getConfig().getLong("rental.reminder-hours", 24L) * 3_600_000L;
        for (Plot plot : plugin.plots().occupied()) {
            Rental r = plot.rental;
            if (r == null || !r.isOccupied() || plot.busy) continue;
            if (processed >= cap) break;
            if (r.status == Rental.Status.ACTIVE) {
                if (now >= r.nextDueMs) {
                    processed++;
                    billActive(plot, r, now);
                } else if (!r.reminded && r.nextDueMs - now <= reminderMs) {
                    r.reminded = true;
                    Player online = Bukkit.getPlayer(r.tenant);
                    if (online != null) {
                        msg(online, "rent.reminder", "plot", (plot.label()), "price", money(r.price),
                                "left", TimeUtil.formatMillis(r.nextDueMs - now));
                    }
                }
            } else {
                processed++;
                billGrace(plot, r, now);
            }
        }
    }

    private void billActive(Plot plot, Rental r, long now) {
        if (r.periodsTotal > 0 && r.periodsPaid >= r.periodsTotal) {
            endRental(plot, EndReason.COMPLETED);
            return;
        }
        if (charge(plot, r)) {
            r.periodsPaid++;
            r.nextDueMs += r.periodSec * 1000L;
            if (r.nextDueMs <= now) r.nextDueMs = now + r.periodSec * 1000L; // after downtime, never double-charge
            r.reminded = false;
            plugin.plots().saveRental(r);
            Player online = Bukkit.getPlayer(r.tenant);
            if (online != null) {
                msg(online, "rent.paid-auto", "plot", (plot.label()), "price", money(r.price));
            }
            plugin.notices().notify(plot.owner, "rent.owner-paid", "player", Text.name(r.tenant),
                    "plot", (plot.label()));
        } else {
            long graceMs = plugin.getConfig().getLong("rental.grace-hours", 48L) * 3_600_000L;
            r.status = Rental.Status.GRACE;
            r.graceUntilMs = now + graceMs;
            plugin.plots().saveRental(r);
            plugin.notices().notify(r.tenant, "rent.payment-failed", "plot", (plot.label()),
                    "price", money(r.price), "grace", TimeUtil.formatMillis(graceMs));
            plugin.notices().notify(plot.owner, "rent.owner-late", "player", Text.name(r.tenant),
                    "plot", (plot.label()));
        }
    }

    private void billGrace(Plot plot, Rental r, long now) {
        if (charge(plot, r)) {
            recover(plot, r, now);
            plugin.notices().notify(r.tenant, "rent.recovered", "plot", (plot.label()));
        } else if (now >= r.graceUntilMs) {
            endRental(plot, EndReason.EVICTED);
        }
    }

    // ------------------------------------------------------------------ ending a rental

    public void endRental(Plot plot, EndReason reason) {
        Rental r = plot.rental;
        if (r == null || r.tenant == null) return;
        UUID tenant = r.tenant;
        UUID owner = plot.owner;
        double deposit = r.deposit;
        boolean hadBuild = r.allowBuild;

        // 1. deposit
        switch (reason) {
            case COMPLETED, ADMIN -> plugin.economy().deposit(tenant, deposit);
            case LEFT -> {
                double pct = plugin.getConfig().getDouble("rental.early-leave-refund-percent", 50);
                double back = EconomyService.round(deposit * pct / 100.0);
                plugin.economy().deposit(tenant, back);
                if (owner != null) plugin.economy().deposit(owner, EconomyService.round(deposit - back));
            }
            case EVICTED -> {
                if (owner != null) plugin.economy().deposit(owner, deposit);
                else plugin.economy().deposit(tenant, deposit);
            }
        }
        plugin.ledger().log("RENT_END_" + reason.name(), null, tenant, deposit, plot.id);

        // 2. the tenant's shop closes, their things go to the stash
        plugin.business().closeForPlot(plot, "business.closed-rental-ended");
        List<ItemStack> items = collectItems(plot);
        plugin.stash().add(tenant, items);

        // 3. get the tenant out
        Player online = Bukkit.getPlayer(tenant);
        World w = Bukkit.getWorld(plot.world);
        if (online != null && w != null && plot.contains(online.getLocation())) {
            online.teleport(w.getSpawnLocation());
        }

        // 4. reset the contract
        plot.trusted.clear();
        plot.publicAccess = plot.type == Plot.Type.SHOP;
        r.tenant = null;
        r.status = Rental.Status.LISTED;
        r.periodsPaid = 0;
        r.startMs = 0;
        r.nextDueMs = 0;
        r.graceUntilMs = 0;
        r.reminded = false;
        if (plugin.getConfig().getBoolean("rental.relist-after-end", true) && owner != null) {
            plugin.plots().saveRental(r);
        } else {
            plot.rental = null;
            plugin.plots().deleteRental(plot.id);
        }
        plugin.plots().save(plot);

        // 5. put the building back the way it was
        if (hadBuild && plugin.getConfig().getBoolean("snapshot.enabled", true)
                && plugin.snapshots().exists(plot.id)) {
            plot.busy = true;
            plugin.snapshots().restore(plot, ok -> plot.busy = false);
        }

        // 6. tell everyone
        String key = switch (reason) {
            case COMPLETED -> "rent.end-completed";
            case LEFT -> "rent.end-left";
            case EVICTED -> "rent.end-evicted";
            case ADMIN -> "rent.end-admin";
        };
        plugin.notices().notify(tenant, key, "plot", (plot.label()), "items", items.size());
        if (owner != null) {
            plugin.notices().notify(owner, "rent.owner-ended", "player", Text.name(tenant),
                    "plot", (plot.label()));
        }
    }

    /** Admin deleting a plot or clearing its listing: end any contract first. */
    public void clear(Plot plot) {
        if (plot.rental != null && plot.rental.isOccupied()) endRental(plot, EndReason.ADMIN);
        plot.rental = null;
        plugin.plots().deleteRental(plot.id);
    }

    // ------------------------------------------------------------------ recovering a tenant's belongings

    private List<ItemStack> collectItems(Plot plot) {
        List<ItemStack> out = new ArrayList<>();
        World w = Bukkit.getWorld(plot.world);
        if (w == null) return out;
        for (int cx = plot.minX >> 4; cx <= plot.maxX >> 4; cx++) {
            for (int cz = plot.minZ >> 4; cz <= plot.maxZ >> 4; cz++) {
                Chunk chunk = w.getChunkAt(cx, cz);
                for (BlockState st : chunk.getTileEntities()) {
                    if (!plot.contains(plot.world, st.getX(), st.getY(), st.getZ())) continue;
                    BlockState live = st.getBlock().getState();
                    if (!(live instanceof Container container)) continue;
                    Inventory inv = live instanceof Chest chest ? chest.getBlockInventory() : container.getInventory();
                    for (ItemStack it : inv.getContents()) {
                        if (it != null && !it.getType().isAir()) out.add(it.clone());
                    }
                    inv.clear();
                }
                for (Entity e : chunk.getEntities()) {
                    Location l = e.getLocation();
                    if (!plot.contains(l)) continue;
                    if (e instanceof ItemFrame frame) {
                        ItemStack it = frame.getItem();
                        if (it != null && !it.getType().isAir()) {
                            out.add(it.clone());
                            frame.setItem(null);
                        }
                    } else if (e instanceof ArmorStand stand) {
                        EntityEquipment eq = stand.getEquipment();
                        if (eq != null) {
                            for (ItemStack it : eq.getArmorContents()) {
                                if (it != null && !it.getType().isAir()) out.add(it.clone());
                            }
                            ItemStack main = eq.getItemInMainHand();
                            if (main != null && !main.getType().isAir()) out.add(main.clone());
                            ItemStack off = eq.getItemInOffHand();
                            if (off != null && !off.getType().isAir()) out.add(off.clone());
                            eq.clear();
                        }
                    }
                }
            }
        }
        return out;
    }
}
