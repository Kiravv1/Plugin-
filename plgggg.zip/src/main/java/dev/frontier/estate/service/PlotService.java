package dev.frontier.estate.service;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.db.Database;
import dev.frontier.estate.model.Plot;
import dev.frontier.estate.model.Rental;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachmentInfo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Holds every plot in memory with a per-chunk spatial index, so "which plot is this block in?" is O(1)
 * no matter how many thousands of plots exist. Everything here runs on the main thread.
 */
public final class PlotService {

    /** Lets the employment system say "this player is on shift in this plot". */
    public interface DutyChecker {
        boolean onDuty(UUID player, Plot plot);
    }

    private final FrontierEstatePlugin plugin;
    private final Database db;
    private final Map<String, Plot> byId = new HashMap<>();
    private final Map<String, Map<Long, List<Plot>>> index = new HashMap<>();
    private DutyChecker dutyChecker;

    public PlotService(FrontierEstatePlugin plugin, Database db) {
        this.plugin = plugin;
        this.db = db;
    }

    public void setDutyChecker(DutyChecker checker) {
        this.dutyChecker = checker;
    }

    // ------------------------------------------------------------------ loading / saving

    public void load() {
        List<Plot> plots = db.querySync(
                "SELECT id, world, min_x, min_y, min_z, max_x, max_y, max_z, plot_type, price, owner_uuid,"
                        + " display_name, public_access, trusted, created_at FROM plots",
                rs -> {
                    Plot p = new Plot(rs.getString("id"), rs.getString("world"),
                            rs.getInt("min_x"), rs.getInt("min_y"), rs.getInt("min_z"),
                            rs.getInt("max_x"), rs.getInt("max_y"), rs.getInt("max_z"));
                    try {
                        p.type = Plot.Type.valueOf(rs.getString("plot_type"));
                    } catch (Exception e) {
                        p.type = Plot.Type.HOUSE;
                    }
                    p.price = rs.getDouble("price");
                    String owner = rs.getString("owner_uuid");
                    p.owner = owner == null || owner.isEmpty() ? null : UUID.fromString(owner);
                    p.displayName = rs.getString("display_name");
                    p.publicAccess = rs.getInt("public_access") != 0;
                    String trusted = rs.getString("trusted");
                    if (trusted != null && !trusted.isEmpty()) {
                        for (String s : trusted.split(",")) {
                            try {
                                p.trusted.add(UUID.fromString(s.trim()));
                            } catch (IllegalArgumentException ignored) {
                                // skip bad entry
                            }
                        }
                    }
                    p.createdAt = rs.getLong("created_at");
                    return p;
                });
        for (Plot p : plots) register(p);

        List<Rental> rentals = db.querySync(
                "SELECT plot_id, status, price, period_sec, deposit, allow_build, periods_total, periods_paid,"
                        + " tenant_uuid, start_ms, next_due_ms, grace_until_ms FROM rentals",
                rs -> {
                    Rental r = new Rental(rs.getString("plot_id"));
                    try {
                        r.status = Rental.Status.valueOf(rs.getString("status"));
                    } catch (Exception e) {
                        r.status = Rental.Status.LISTED;
                    }
                    r.price = rs.getDouble("price");
                    r.periodSec = rs.getLong("period_sec");
                    r.deposit = rs.getDouble("deposit");
                    r.allowBuild = rs.getInt("allow_build") != 0;
                    r.periodsTotal = rs.getInt("periods_total");
                    r.periodsPaid = rs.getInt("periods_paid");
                    String tenant = rs.getString("tenant_uuid");
                    r.tenant = tenant == null || tenant.isEmpty() ? null : UUID.fromString(tenant);
                    r.startMs = rs.getLong("start_ms");
                    r.nextDueMs = rs.getLong("next_due_ms");
                    r.graceUntilMs = rs.getLong("grace_until_ms");
                    return r;
                });
        for (Rental r : rentals) {
            Plot p = byId.get(r.plotId);
            if (p != null) {
                if (r.status != Rental.Status.LISTED && r.tenant == null) r.status = Rental.Status.LISTED;
                p.rental = r;
            }
        }
        plugin.getLogger().info("Loaded " + byId.size() + " plots.");
    }

    public void save(Plot p) {
        StringBuilder sb = new StringBuilder();
        for (UUID u : p.trusted) {
            if (sb.length() > 0) sb.append(',');
            sb.append(u);
        }
        db.execute("REPLACE INTO plots (id, world, min_x, min_y, min_z, max_x, max_y, max_z, plot_type, price,"
                        + " owner_uuid, display_name, public_access, trusted, created_at)"
                        + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                p.id, p.world, p.minX, p.minY, p.minZ, p.maxX, p.maxY, p.maxZ, p.type.name(), p.price,
                p.owner == null ? null : p.owner.toString(), p.displayName, p.publicAccess ? 1 : 0,
                sb.toString(), p.createdAt);
    }

    public void saveRental(Rental r) {
        db.execute("REPLACE INTO rentals (plot_id, status, price, period_sec, deposit, allow_build, periods_total,"
                        + " periods_paid, tenant_uuid, start_ms, next_due_ms, grace_until_ms)"
                        + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                r.plotId, r.status.name(), r.price, r.periodSec, r.deposit, r.allowBuild ? 1 : 0,
                r.periodsTotal, r.periodsPaid, r.tenant == null ? null : r.tenant.toString(),
                r.startMs, r.nextDueMs, r.graceUntilMs);
    }

    public void deleteRental(String plotId) {
        db.execute("DELETE FROM rentals WHERE plot_id = ?", plotId);
    }

    // ------------------------------------------------------------------ registry / index

    public static long key(int chunkX, int chunkZ) {
        return ((long) chunkX << 32) | (chunkZ & 0xFFFFFFFFL);
    }

    private void register(Plot p) {
        byId.put(p.id, p);
        Map<Long, List<Plot>> m = index.computeIfAbsent(p.world, k -> new HashMap<>());
        for (int cx = p.minX >> 4; cx <= p.maxX >> 4; cx++) {
            for (int cz = p.minZ >> 4; cz <= p.maxZ >> 4; cz++) {
                m.computeIfAbsent(key(cx, cz), k -> new ArrayList<>(2)).add(p);
            }
        }
    }

    private void unregister(Plot p) {
        byId.remove(p.id);
        Map<Long, List<Plot>> m = index.get(p.world);
        if (m == null) return;
        for (int cx = p.minX >> 4; cx <= p.maxX >> 4; cx++) {
            for (int cz = p.minZ >> 4; cz <= p.maxZ >> 4; cz++) {
                long k = key(cx, cz);
                List<Plot> list = m.get(k);
                if (list != null) {
                    list.remove(p);
                    if (list.isEmpty()) m.remove(k);
                }
            }
        }
    }

    public void add(Plot p) {
        register(p);
        save(p);
    }

    public void remove(Plot p) {
        unregister(p);
        db.execute("DELETE FROM plots WHERE id = ?", p.id);
        db.execute("DELETE FROM rentals WHERE plot_id = ?", p.id);
    }

    public Plot get(String id) {
        return byId.get(id);
    }

    public Collection<Plot> all() {
        return byId.values();
    }

    public int count() {
        return byId.size();
    }

    public Plot getAt(String world, int x, int y, int z) {
        Map<Long, List<Plot>> m = index.get(world);
        if (m == null) return null;
        List<Plot> list = m.get(key(x >> 4, z >> 4));
        if (list == null) return null;
        for (int i = 0; i < list.size(); i++) {
            Plot p = list.get(i);
            if (p.contains(world, x, y, z)) return p;
        }
        return null;
    }

    public Plot getAt(Location l) {
        World w = l.getWorld();
        if (w == null) return null;
        return getAt(w.getName(), l.getBlockX(), l.getBlockY(), l.getBlockZ());
    }

    public Plot getAt(Block b) {
        return getAt(b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
    }

    public Plot findOverlap(String world, int x1, int y1, int z1, int x2, int y2, int z2) {
        Map<Long, List<Plot>> m = index.get(world);
        if (m == null) return null;
        for (int cx = Math.min(x1, x2) >> 4; cx <= Math.max(x1, x2) >> 4; cx++) {
            for (int cz = Math.min(z1, z2) >> 4; cz <= Math.max(z1, z2) >> 4; cz++) {
                List<Plot> list = m.get(key(cx, cz));
                if (list == null) continue;
                for (Plot p : list) {
                    if (p.overlaps(world, x1, y1, z1, x2, y2, z2)) return p;
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ queries

    public List<Plot> ownedBy(UUID id) {
        List<Plot> out = new ArrayList<>();
        for (Plot p : byId.values()) if (p.isOwner(id)) out.add(p);
        return out;
    }

    public List<Plot> rentedBy(UUID id) {
        List<Plot> out = new ArrayList<>();
        for (Plot p : byId.values()) if (p.isTenant(id)) out.add(p);
        return out;
    }

    public List<Plot> listedForRent() {
        List<Plot> out = new ArrayList<>();
        for (Plot p : byId.values()) {
            if (p.rental != null && p.rental.status == Rental.Status.LISTED && p.owner != null) out.add(p);
        }
        out.sort((a, b) -> Double.compare(a.rental.price, b.rental.price));
        return out;
    }

    public List<Plot> occupied() {
        List<Plot> out = new ArrayList<>();
        for (Plot p : byId.values()) if (p.rental != null && p.rental.isOccupied()) out.add(p);
        return out;
    }

    public int maxPlots(Player player) {
        int max = plugin.getConfig().getInt("limits.max-owned-plots", 3);
        for (PermissionAttachmentInfo info : player.getEffectivePermissions()) {
            if (!info.getValue()) continue;
            String perm = info.getPermission();
            if (perm.startsWith("frontierestate.limit.")) {
                try {
                    max = Math.max(max, Integer.parseInt(perm.substring("frontierestate.limit.".length())));
                } catch (NumberFormatException ignored) {
                    // not a number, ignore
                }
            }
        }
        return max;
    }

    // ------------------------------------------------------------------ permissions

    /** May this player place or break blocks in the plot? */
    public boolean canBuild(UUID id, Plot plot) {
        if (plot == null || plot.busy || plot.owner == null) return false;
        Rental r = plot.rental;
        if (r != null && r.isOccupied()) {
            if (!r.allowBuild) return false;
            return r.tenant.equals(id) || plot.trusted.contains(id);
        }
        return plot.owner.equals(id) || plot.trusted.contains(id);
    }

    /** May this player open containers and use the inside of the plot? */
    public boolean canUse(UUID id, Plot plot) {
        if (plot == null || plot.busy) return false;
        UUID controller = plot.controller();
        if (controller == null) return false;
        if (controller.equals(id) || plot.trusted.contains(id)) return true;
        return dutyChecker != null && dutyChecker.onDuty(id, plot);
    }

    /** Doors, buttons and levers: open to everybody if the plot is public. */
    public boolean canUsePublic(UUID id, Plot plot) {
        return plot.publicAccess || canUse(id, plot);
    }

    /** Controller or trusted friend: may place signs and manage the plot, even without full build rights. */
    public boolean canManage(UUID id, Plot plot) {
        if (plot == null || plot.busy) return false;
        UUID controller = plot.controller();
        return controller != null && (controller.equals(id) || plot.trusted.contains(id));
    }
}
