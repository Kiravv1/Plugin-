package dev.frontier.estate.service;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.model.Plot;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Saves the shape of a plot when a rental starts and puts it back when the rental ends, so a tenant can
 * never wreck the owner's building. Work is spread over many ticks and one plot is processed at a time,
 * so it never lags the server, even if hundreds of rentals end together.
 */
public final class SnapshotService {

    private static final int MAGIC = 0x46455350;
    private static final String AIR = "minecraft:air";

    private record Loaded(int sx, int sy, int sz, String[] palette, int[] data) { }

    private final FrontierEstatePlugin plugin;
    private final File dir;
    private final ArrayDeque<Runnable> queue = new ArrayDeque<>();
    private boolean running;

    public SnapshotService(FrontierEstatePlugin plugin) {
        this.plugin = plugin;
        this.dir = new File(plugin.getDataFolder(), "snapshots");
        if (!dir.exists() && !dir.mkdirs()) {
            plugin.getLogger().warning("Could not create the snapshots folder.");
        }
    }

    private File file(String plotId) {
        return new File(dir, plotId.replaceAll("[^A-Za-z0-9_.-]", "_") + ".snap");
    }

    public boolean exists(String plotId) {
        return file(plotId).isFile();
    }

    public void delete(String plotId) {
        File f = file(plotId);
        if (f.isFile() && !f.delete()) {
            plugin.getLogger().warning("Could not delete snapshot " + f.getName());
        }
    }

    // ------------------------------------------------------------------ job queue (main thread)

    private void enqueue(Runnable job) {
        queue.add(job);
        if (!running) next();
    }

    private void next() {
        Runnable job = queue.poll();
        if (job == null) {
            running = false;
            return;
        }
        running = true;
        try {
            job.run();
        } catch (RuntimeException e) {
            plugin.getLogger().log(Level.SEVERE, "Snapshot job failed", e);
            next();
        }
    }

    private void complete(Consumer<Boolean> done, boolean ok) {
        try {
            if (done != null) done.accept(ok);
        } finally {
            next();
        }
    }

    // ------------------------------------------------------------------ capture

    public void capture(Plot plot, Consumer<Boolean> done) {
        enqueue(() -> doCapture(plot, done));
    }

    private void doCapture(Plot plot, Consumer<Boolean> done) {
        World w = Bukkit.getWorld(plot.world);
        long total = (long) plot.sizeX() * plot.sizeY() * plot.sizeZ();
        long max = Math.min(plugin.getConfig().getLong("snapshot.max-blocks", 2_000_000L), 8_000_000L);
        if (w == null || total <= 0 || total > max) {
            plugin.getLogger().warning("Snapshot skipped for plot " + plot.id + " (world missing or "
                    + total + " blocks is over the limit of " + max + ").");
            complete(done, false);
            return;
        }
        final int sx = plot.sizeX();
        final int sy = plot.sizeY();
        final int sz = plot.sizeZ();
        final int[] data = new int[(int) total];
        final Map<String, Integer> palette = new LinkedHashMap<>();
        final int perTick = Math.max(1000, plugin.getConfig().getInt("snapshot.blocks-per-tick", 10000));
        final int total32 = (int) total;

        new BukkitRunnable() {
            int idx = 0;

            @Override
            public void run() {
                int end = Math.min(idx + perTick, total32);
                for (; idx < end; idx++) {
                    int x = plot.minX + idx / (sy * sz);
                    int rem = idx % (sy * sz);
                    int z = plot.minZ + rem / sy;
                    int y = plot.minY + rem % sy;
                    Block b = w.getBlockAt(x, y, z);
                    String s = b.getType().isAir() ? AIR : b.getBlockData().getAsString();
                    Integer pi = palette.get(s);
                    if (pi == null) {
                        pi = palette.size();
                        palette.put(s, pi);
                    }
                    data[idx] = pi;
                }
                if (idx >= total32) {
                    cancel();
                    writeAsync(plot, sx, sy, sz, new ArrayList<>(palette.keySet()), data, done);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void writeAsync(Plot plot, int sx, int sy, int sz, List<String> palette, int[] data,
                            Consumer<Boolean> done) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            boolean ok = true;
            File target = file(plot.id);
            File tmp = new File(dir, target.getName() + ".tmp");
            try (DataOutputStream out = new DataOutputStream(
                    new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(tmp))))) {
                out.writeInt(MAGIC);
                out.writeInt(1);
                out.writeInt(sx);
                out.writeInt(sy);
                out.writeInt(sz);
                out.writeInt(palette.size());
                for (String s : palette) out.writeUTF(s);
                int i = 0;
                while (i < data.length) {
                    int v = data[i];
                    int j = i + 1;
                    while (j < data.length && data[j] == v) j++;
                    out.writeInt(v);
                    out.writeInt(j - i);
                    i = j;
                }
            } catch (IOException e) {
                ok = false;
                plugin.getLogger().log(Level.SEVERE, "Could not write snapshot for " + plot.id, e);
            }
            if (ok) {
                try {
                    Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
                } catch (IOException e) {
                    ok = false;
                    plugin.getLogger().log(Level.SEVERE, "Could not finalize snapshot for " + plot.id, e);
                }
            }
            final boolean result = ok;
            Bukkit.getScheduler().runTask(plugin, () -> complete(done, result));
        });
    }

    // ------------------------------------------------------------------ restore

    public void restore(Plot plot, Consumer<Boolean> done) {
        enqueue(() -> doRestore(plot, done));
    }

    private void doRestore(Plot plot, Consumer<Boolean> done) {
        File f = file(plot.id);
        if (!f.isFile()) {
            complete(done, false);
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Loaded loaded = null;
            try (DataInputStream in = new DataInputStream(
                    new GZIPInputStream(new BufferedInputStream(new FileInputStream(f))))) {
                if (in.readInt() != MAGIC) throw new IOException("bad magic");
                in.readInt(); // version
                int sx = in.readInt();
                int sy = in.readInt();
                int sz = in.readInt();
                int pn = in.readInt();
                String[] palette = new String[pn];
                for (int i = 0; i < pn; i++) palette[i] = in.readUTF();
                long total = (long) sx * sy * sz;
                if (total <= 0 || total > 8_000_000L) throw new IOException("bad size");
                int[] data = new int[(int) total];
                int i = 0;
                while (i < data.length) {
                    int v = in.readInt();
                    int n = in.readInt();
                    if (n <= 0 || i + n > data.length || v < 0 || v >= pn) throw new IOException("corrupt");
                    Arrays.fill(data, i, i + n, v);
                    i += n;
                }
                loaded = new Loaded(sx, sy, sz, palette, data);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Could not read snapshot for " + plot.id, e);
            }
            final Loaded result = loaded;
            Bukkit.getScheduler().runTask(plugin, () -> applyRestore(plot, result, done));
        });
    }

    private void applyRestore(Plot plot, Loaded l, Consumer<Boolean> done) {
        World w = Bukkit.getWorld(plot.world);
        if (w == null || l == null || l.sx() != plot.sizeX() || l.sy() != plot.sizeY() || l.sz() != plot.sizeZ()) {
            complete(done, false);
            return;
        }
        BlockData[] palette = new BlockData[l.palette().length];
        for (int i = 0; i < palette.length; i++) {
            try {
                palette[i] = Bukkit.createBlockData(l.palette()[i]);
            } catch (IllegalArgumentException e) {
                palette[i] = Bukkit.createBlockData(Material.AIR);
            }
        }
        if (plugin.getConfig().getBoolean("snapshot.remove-entities", true)) {
            removeEntities(plot, w);
        }
        final int sy = l.sy();
        final int sz = l.sz();
        final int[] data = l.data();
        final int perTick = Math.max(1000, plugin.getConfig().getInt("snapshot.blocks-per-tick", 10000));

        new BukkitRunnable() {
            int idx = 0;

            @Override
            public void run() {
                int end = Math.min(idx + perTick, data.length);
                for (; idx < end; idx++) {
                    int x = plot.minX + idx / (sy * sz);
                    int rem = idx % (sy * sz);
                    int z = plot.minZ + rem / sy;
                    int y = plot.minY + rem % sy;
                    Block b = w.getBlockAt(x, y, z);
                    BlockData target = palette[data[idx]];
                    if (b.getType().isAir() && target.getMaterial().isAir()) continue;
                    if (!b.getBlockData().equals(target)) b.setBlockData(target, false);
                }
                if (idx >= data.length) {
                    cancel();
                    complete(done, true);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void removeEntities(Plot plot, World w) {
        BoundingBox box = new BoundingBox(plot.minX, plot.minY, plot.minZ,
                plot.maxX + 1.0, plot.maxY + 1.0, plot.maxZ + 1.0);
        for (Entity e : w.getNearbyEntities(box)) {
            if (e instanceof Player) continue;
            e.remove();
        }
    }
}
