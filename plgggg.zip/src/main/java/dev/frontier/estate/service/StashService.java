package dev.frontier.estate.service;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.db.Database;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/** Items recovered from a plot after a rental ends. The ex-tenant claims them from the stash menu. */
public final class StashService {

    public record Entry(String id, String data) { }

    private final FrontierEstatePlugin plugin;
    private final Database db;
    private final Set<UUID> hasStash = ConcurrentHashMap.newKeySet();

    public StashService(FrontierEstatePlugin plugin, Database db) {
        this.plugin = plugin;
        this.db = db;
    }

    public void load() {
        List<String> ids = db.querySync("SELECT DISTINCT owner_uuid FROM stash", rs -> rs.getString(1));
        for (String s : ids) {
            try {
                hasStash.add(UUID.fromString(s));
            } catch (IllegalArgumentException ignored) {
                // skip bad row
            }
        }
    }

    public boolean has(UUID id) {
        return hasStash.contains(id);
    }

    public void add(UUID owner, List<ItemStack> items) {
        if (items.isEmpty()) return;
        long now = System.currentTimeMillis();
        for (ItemStack it : items) {
            db.execute("INSERT INTO stash (id, owner_uuid, item_data, created_at) VALUES (?,?,?,?)",
                    UUID.randomUUID().toString(), owner.toString(), serialize(it), now);
        }
        hasStash.add(owner);
    }

    public CompletableFuture<List<Entry>> loadFor(UUID owner) {
        return db.queryAsync("SELECT id, item_data FROM stash WHERE owner_uuid = ? ORDER BY created_at",
                rs -> new Entry(rs.getString(1), rs.getString(2)), owner.toString());
    }

    public void remove(UUID owner, String entryId, int remainingInMenu) {
        db.execute("DELETE FROM stash WHERE id = ?", entryId);
        if (remainingInMenu <= 0) {
            // the menu only shows everything the player has, so an empty menu means an empty stash
            hasStash.remove(owner);
        }
    }

    public static String serialize(ItemStack item) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("i", item);
        return y.saveToString();
    }

    public static ItemStack deserialize(String data) {
        YamlConfiguration y = new YamlConfiguration();
        try {
            y.loadFromString(data);
        } catch (InvalidConfigurationException e) {
            return null;
        }
        return y.getItemStack("i");
    }
}
