package dev.frontier.estate.service;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.db.Database;
import dev.frontier.estate.model.Application;
import dev.frontier.estate.model.Business;
import dev.frontier.estate.model.Employment;
import dev.frontier.estate.model.Job;
import dev.frontier.estate.model.Plot;
import dev.frontier.estate.util.Text;
import dev.frontier.estate.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Shops, job postings, applications, employment contracts and automatic payroll.
 * Wages are paid from the business's own balance. Time is only paid while the employee is on shift,
 * inside the shop and not AFK.
 */
public final class BusinessService implements PlotService.DutyChecker {

    private static final class Shift {
        final UUID player;
        final String employmentId;
        final String plotId;
        long lastTickAt;
        long lastActiveAt;
        long pendingMs;
        long outsideSince;
        double paidTotal;
        boolean underfunded;
        Location lastLoc;

        Shift(UUID player, String employmentId, String plotId, long now) {
            this.player = player;
            this.employmentId = employmentId;
            this.plotId = plotId;
            this.lastTickAt = now;
            this.lastActiveAt = now;
        }
    }

    private final FrontierEstatePlugin plugin;
    private final Database db;
    private final Map<String, Business> businesses = new LinkedHashMap<>();
    private final Map<String, Business> byPlot = new HashMap<>();
    private final Map<String, Job> jobs = new LinkedHashMap<>();
    private final Map<String, Application> applications = new LinkedHashMap<>();
    private final Map<String, Employment> employments = new LinkedHashMap<>();
    private final Map<UUID, Shift> shifts = new HashMap<>();
    private BukkitTask task;

    public BusinessService(FrontierEstatePlugin plugin, Database db) {
        this.plugin = plugin;
        this.db = db;
    }

    // ------------------------------------------------------------------ small helpers

    private void msg(Player p, String key, Object... pairs) {
        plugin.messages().send(p, key, pairs);
    }

    private String money(double v) {
        return plugin.economy().format(v);
    }

    private static boolean validName(String s, int max) {
        return s != null && s.length() >= 3 && s.length() <= max && s.matches("[\\p{L}\\p{N} _.'-]+");
    }

    // ------------------------------------------------------------------ load / persist

    public void load() {
        for (Business b : db.querySync(
                "SELECT id, business_name, owner_uuid, plot_id, balance, created_at FROM businesses",
                rs -> new Business(rs.getString("id"), rs.getString("business_name"),
                        UUID.fromString(rs.getString("owner_uuid")), rs.getString("plot_id"),
                        rs.getDouble("balance"), rs.getLong("created_at")))) {
            businesses.put(b.id, b);
            byPlot.put(b.plotId, b);
        }
        for (Job j : db.querySync(
                "SELECT id, business_id, title, wage, max_hours, slots, is_open, created_at FROM jobs",
                rs -> new Job(rs.getString("id"), rs.getString("business_id"), rs.getString("title"),
                        rs.getDouble("wage"), rs.getInt("max_hours"), rs.getInt("slots"),
                        rs.getInt("is_open") != 0, rs.getLong("created_at")))) {
            if (businesses.containsKey(j.businessId)) jobs.put(j.id, j);
            else db.execute("DELETE FROM jobs WHERE id = ?", j.id);
        }
        for (Application a : db.querySync(
                "SELECT id, job_id, applicant_uuid, applicant_name, created_at FROM applications",
                rs -> new Application(rs.getString("id"), rs.getString("job_id"),
                        UUID.fromString(rs.getString("applicant_uuid")), rs.getString("applicant_name"),
                        rs.getLong("created_at")))) {
            if (jobs.containsKey(a.jobId)) applications.put(a.id, a);
            else db.execute("DELETE FROM applications WHERE id = ?", a.id);
        }
        for (Employment e : db.querySync(
                "SELECT id, business_id, job_id, employee_uuid, employee_name, wage, max_hours, hired_at,"
                        + " day_stamp, worked_today_ms, total_worked_ms, total_paid FROM employments",
                rs -> {
                    Employment e = new Employment(rs.getString("id"), rs.getString("business_id"),
                            rs.getString("job_id"), UUID.fromString(rs.getString("employee_uuid")),
                            rs.getString("employee_name"), rs.getDouble("wage"), rs.getInt("max_hours"),
                            rs.getLong("hired_at"));
                    e.dayStamp = rs.getLong("day_stamp");
                    e.workedTodayMs = rs.getLong("worked_today_ms");
                    e.totalWorkedMs = rs.getLong("total_worked_ms");
                    e.totalPaid = rs.getDouble("total_paid");
                    return e;
                })) {
            if (businesses.containsKey(e.businessId)) employments.put(e.id, e);
            else db.execute("DELETE FROM employments WHERE id = ?", e.id);
        }
        plugin.getLogger().info("Loaded " + businesses.size() + " businesses, " + jobs.size() + " jobs, "
                + employments.size() + " employees.");
    }

    private void saveBusiness(Business b) {
        db.execute("REPLACE INTO businesses (id, business_name, owner_uuid, plot_id, balance, created_at)"
                + " VALUES (?,?,?,?,?,?)", b.id, b.name, b.owner.toString(), b.plotId, b.balance, b.createdAt);
    }

    private void saveJob(Job j) {
        db.execute("REPLACE INTO jobs (id, business_id, title, wage, max_hours, slots, is_open, created_at)"
                + " VALUES (?,?,?,?,?,?,?,?)", j.id, j.businessId, j.title, j.wage, j.maxHours, j.slots,
                j.open ? 1 : 0, j.createdAt);
    }

    private void saveApplication(Application a) {
        db.execute("REPLACE INTO applications (id, job_id, applicant_uuid, applicant_name, created_at)"
                + " VALUES (?,?,?,?,?)", a.id, a.jobId, a.applicant.toString(), a.applicantName, a.createdAt);
    }

    private void saveEmployment(Employment e) {
        db.execute("REPLACE INTO employments (id, business_id, job_id, employee_uuid, employee_name, wage,"
                        + " max_hours, hired_at, day_stamp, worked_today_ms, total_worked_ms, total_paid)"
                        + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                e.id, e.businessId, e.jobId, e.employee.toString(), e.employeeName, e.wage, e.maxHours,
                e.hiredAt, e.dayStamp, e.workedTodayMs, e.totalWorkedMs, e.totalPaid);
    }

    // ------------------------------------------------------------------ lifecycle

    public void start() {
        long seconds = Math.max(5L, plugin.getConfig().getLong("employment.payroll-tick-seconds", 30L));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::payrollTick, 200L, seconds * 20L);
    }

    public void shutdown() {
        if (task != null) task.cancel();
        for (Shift s : new ArrayList<>(shifts.values())) endShift(s, null);
    }

    public void onQuit(Player p) {
        Shift s = shifts.get(p.getUniqueId());
        if (s != null) endShift(s, null);
    }

    // ------------------------------------------------------------------ queries

    public Business forPlot(String plotId) {
        return byPlot.get(plotId);
    }

    public List<Business> ownedBy(UUID owner) {
        List<Business> out = new ArrayList<>();
        for (Business b : businesses.values()) if (b.owner.equals(owner)) out.add(b);
        return out;
    }

    /** Picks the business the player means: by name, by the shop they stand in, or their only one. */
    public Business resolveOwned(Player p, String name) {
        List<Business> mine = ownedBy(p.getUniqueId());
        if (name != null && !name.isBlank()) {
            for (Business b : mine) if (b.name.equalsIgnoreCase(name.trim())) return b;
            return null;
        }
        Plot here = plugin.plots().getAt(p.getLocation());
        if (here != null) {
            Business b = byPlot.get(here.id);
            if (b != null && b.owner.equals(p.getUniqueId())) return b;
        }
        return mine.size() == 1 ? mine.get(0) : null;
    }

    public List<Job> jobsOf(Business b) {
        List<Job> out = new ArrayList<>();
        for (Job j : jobs.values()) if (j.businessId.equals(b.id)) out.add(j);
        return out;
    }

    public Job job(String id) {
        return jobs.get(id);
    }

    public Business business(String id) {
        return businesses.get(id);
    }

    public List<Employment> employeesOf(Business b) {
        List<Employment> out = new ArrayList<>();
        for (Employment e : employments.values()) if (e.businessId.equals(b.id)) out.add(e);
        return out;
    }

    public List<Employment> employmentsOf(UUID player) {
        List<Employment> out = new ArrayList<>();
        for (Employment e : employments.values()) if (e.employee.equals(player)) out.add(e);
        return out;
    }

    public int freeSlots(Job j) {
        int used = 0;
        for (Employment e : employments.values()) if (e.jobId.equals(j.id)) used++;
        return Math.max(0, j.slots - used);
    }

    public List<Job> openJobs() {
        List<Job> out = new ArrayList<>();
        for (Job j : jobs.values()) {
            if (j.open && freeSlots(j) > 0 && businesses.containsKey(j.businessId)) out.add(j);
        }
        out.sort((a, b) -> Double.compare(b.wage, a.wage));
        return out;
    }

    public List<Application> applicationsFor(Business b) {
        List<Application> out = new ArrayList<>();
        for (Application a : applications.values()) {
            Job j = jobs.get(a.jobId);
            if (j != null && j.businessId.equals(b.id)) out.add(a);
        }
        return out;
    }

    public double reserveRequired(Business b) {
        double hours = plugin.getConfig().getDouble("employment.reserve-hours", 8);
        double sum = 0;
        for (Employment e : employments.values()) if (e.businessId.equals(b.id)) sum += e.wage * hours;
        return EconomyService.round(sum);
    }

    public boolean isOnShift(UUID id) {
        return shifts.containsKey(id);
    }

    public Employment currentEmployment(UUID id) {
        Shift s = shifts.get(id);
        return s == null ? null : employments.get(s.employmentId);
    }

    public double shiftEarnings(UUID id) {
        Shift s = shifts.get(id);
        return s == null ? 0 : s.paidTotal;
    }

    public long shiftPendingMs(UUID id) {
        Shift s = shifts.get(id);
        return s == null ? 0 : s.pendingMs;
    }

    @Override
    public boolean onDuty(UUID player, Plot plot) {
        Shift s = shifts.get(player);
        return s != null && s.plotId.equals(plot.id);
    }

    // ------------------------------------------------------------------ businesses

    public Business create(Player p, Plot plot, String name) {
        var cfg = plugin.getConfig();
        UUID id = p.getUniqueId();
        if (!plot.isControlledBy(id)) {
            msg(p, "business.not-controller");
            return null;
        }
        if (!cfg.getStringList("business.allowed-plot-types").contains(plot.type.name())) {
            msg(p, "business.bad-plot-type", "type", plot.type.name());
            return null;
        }
        if (byPlot.containsKey(plot.id)) {
            msg(p, "business.plot-has-business");
            return null;
        }
        if (ownedBy(id).size() >= cfg.getInt("business.max-per-player", 3)) {
            msg(p, "business.limit", "max", cfg.getInt("business.max-per-player", 3));
            return null;
        }
        int maxLen = cfg.getInt("business.name-max-length", 24);
        if (!validName(name, maxLen)) {
            msg(p, "business.bad-name", "max", maxLen);
            return null;
        }
        for (Business other : ownedBy(id)) {
            if (other.name.equalsIgnoreCase(name)) {
                msg(p, "business.name-taken");
                return null;
            }
        }
        Business b = new Business(UUID.randomUUID().toString(), name, id, plot.id, 0, System.currentTimeMillis());
        businesses.put(b.id, b);
        byPlot.put(plot.id, b);
        saveBusiness(b);
        msg(p, "business.created", "name", (b.name));
        return b;
    }

    public boolean deposit(Player p, Business b, double amount) {
        if (!b.owner.equals(p.getUniqueId())) {
            msg(p, "business.not-owner");
            return false;
        }
        amount = EconomyService.round(amount);
        if (amount <= 0) {
            msg(p, "common.bad-amount");
            return false;
        }
        if (!plugin.economy().has(p.getUniqueId(), amount)) {
            msg(p, "common.no-money", "price", money(amount));
            return false;
        }
        if (!plugin.economy().withdraw(p.getUniqueId(), amount)) {
            msg(p, "common.payment-failed");
            return false;
        }
        b.balance = EconomyService.round(b.balance + amount);
        saveBusiness(b);
        plugin.ledger().log("BIZ_DEPOSIT", p.getUniqueId(), null, amount, b.id);
        msg(p, "business.deposited", "amount", money(amount), "balance", money(b.balance));
        return true;
    }

    public boolean withdraw(Player p, Business b, double amount) {
        if (!b.owner.equals(p.getUniqueId())) {
            msg(p, "business.not-owner");
            return false;
        }
        amount = EconomyService.round(amount);
        if (amount <= 0) {
            msg(p, "common.bad-amount");
            return false;
        }
        double reserve = reserveRequired(b);
        if (b.balance - amount < reserve - 0.0001) {
            msg(p, "business.reserve", "reserve", money(reserve),
                    "free", money(Math.max(0, EconomyService.round(b.balance - reserve))));
            return false;
        }
        b.balance = EconomyService.round(b.balance - amount);
        plugin.economy().deposit(p.getUniqueId(), amount);
        saveBusiness(b);
        plugin.ledger().log("BIZ_WITHDRAW", null, p.getUniqueId(), amount, b.id);
        msg(p, "business.withdrawn", "amount", money(amount), "balance", money(b.balance));
        return true;
    }

    /** Closes a business: employees are released, postings removed and the balance returned to the owner. */
    public void close(Business b, String reasonKey) {
        for (Employment e : employeesOf(b)) {
            Shift s = shifts.get(e.employee);
            if (s != null) endShift(s, null);
            employments.remove(e.id);
            db.execute("DELETE FROM employments WHERE id = ?", e.id);
            plugin.notices().notify(e.employee, "job.business-closed", "business", (b.name));
        }
        for (Job j : jobsOf(b)) {
            removeApplicationsOf(j);
            jobs.remove(j.id);
            db.execute("DELETE FROM jobs WHERE id = ?", j.id);
        }
        double refund = EconomyService.round(b.balance);
        if (refund > 0) {
            plugin.economy().deposit(b.owner, refund);
            plugin.ledger().log("BIZ_CLOSE_REFUND", null, b.owner, refund, b.id);
        }
        businesses.remove(b.id);
        byPlot.remove(b.plotId);
        db.execute("DELETE FROM businesses WHERE id = ?", b.id);
        plugin.notices().notify(b.owner, reasonKey, "business", (b.name), "refund", money(refund));
    }

    public void closeForPlot(Plot plot, String reasonKey) {
        Business b = byPlot.get(plot.id);
        if (b != null) close(b, reasonKey);
    }

    // ------------------------------------------------------------------ jobs

    public Job post(Player p, Business b, String title, double wage, int maxHours, int slots) {
        var cfg = plugin.getConfig();
        if (!b.owner.equals(p.getUniqueId())) {
            msg(p, "business.not-owner");
            return null;
        }
        int maxJobs = cfg.getInt("employment.max-jobs-per-business", 5);
        if (jobsOf(b).size() >= maxJobs) {
            msg(p, "job.limit", "max", maxJobs);
            return null;
        }
        if (!validName(title, 32)) {
            msg(p, "job.bad-title");
            return null;
        }
        double minWage = cfg.getDouble("employment.min-wage", 1);
        double maxWage = cfg.getDouble("employment.max-wage", 1000);
        if (wage < minWage || wage > maxWage) {
            msg(p, "job.bad-wage", "min", money(minWage), "max", money(maxWage));
            return null;
        }
        int hoursCap = cfg.getInt("employment.max-hours-per-day", 8);
        if (maxHours < 1 || maxHours > hoursCap) {
            msg(p, "job.bad-hours", "max", hoursCap);
            return null;
        }
        int slotCap = cfg.getInt("employment.max-slots-per-job", 10);
        if (slots < 1 || slots > slotCap) {
            msg(p, "job.bad-slots", "max", slotCap);
            return null;
        }
        double hours = cfg.getDouble("employment.reserve-hours", 8);
        double needed = EconomyService.round(reserveRequired(b) + wage * hours);
        if (b.balance + 0.0001 < needed) {
            msg(p, "job.fund-first", "needed", money(needed), "balance", money(b.balance));
            return null;
        }
        Job j = new Job(UUID.randomUUID().toString(), b.id, title, EconomyService.round(wage), maxHours, slots,
                true, System.currentTimeMillis());
        jobs.put(j.id, j);
        saveJob(j);
        msg(p, "job.posted", "title", (title), "wage", money(j.wage), "id", j.id.substring(0, 6));
        return j;
    }

    public Job findJob(Business b, String idPrefix) {
        if (idPrefix == null) return null;
        String q = idPrefix.toLowerCase(Locale.ROOT);
        for (Job j : jobsOf(b)) if (j.id.toLowerCase(Locale.ROOT).startsWith(q)) return j;
        return null;
    }

    public boolean closeJob(Player p, Business b, String idPrefix) {
        if (!b.owner.equals(p.getUniqueId())) {
            msg(p, "business.not-owner");
            return false;
        }
        Job j = findJob(b, idPrefix);
        if (j == null) {
            msg(p, "job.not-found");
            return false;
        }
        removeApplicationsOf(j);
        jobs.remove(j.id);
        db.execute("DELETE FROM jobs WHERE id = ?", j.id);
        msg(p, "job.closed", "title", (j.title));
        return true;
    }

    private void removeApplicationsOf(Job j) {
        for (Application a : new ArrayList<>(applications.values())) {
            if (a.jobId.equals(j.id)) {
                applications.remove(a.id);
                db.execute("DELETE FROM applications WHERE id = ?", a.id);
            }
        }
    }

    // ------------------------------------------------------------------ applications / hiring

    public boolean apply(Player p, Job job) {
        var cfg = plugin.getConfig();
        Business b = businesses.get(job.businessId);
        if (b == null || !job.open || freeSlots(job) <= 0) {
            msg(p, "job.not-available");
            return false;
        }
        UUID id = p.getUniqueId();
        if (b.owner.equals(id)) {
            msg(p, "job.own-business");
            return false;
        }
        for (Employment e : employmentsOf(id)) {
            if (e.businessId.equals(b.id)) {
                msg(p, "job.already-employed");
                return false;
            }
        }
        if (employmentsOf(id).size() >= cfg.getInt("employment.max-jobs-per-player", 2)) {
            msg(p, "job.too-many-jobs", "max", cfg.getInt("employment.max-jobs-per-player", 2));
            return false;
        }
        int mine = 0;
        for (Application a : applications.values()) {
            if (a.applicant.equals(id)) {
                mine++;
                if (a.jobId.equals(job.id)) {
                    msg(p, "job.already-applied");
                    return false;
                }
            }
        }
        if (mine >= cfg.getInt("employment.max-applications-per-player", 5)) {
            msg(p, "job.too-many-applications", "max", cfg.getInt("employment.max-applications-per-player", 5));
            return false;
        }
        Application a = new Application(UUID.randomUUID().toString(), job.id, id, p.getName(),
                System.currentTimeMillis());
        applications.put(a.id, a);
        saveApplication(a);
        msg(p, "job.applied", "title", (job.title), "business", (b.name));
        plugin.notices().notify(b.owner, "job.owner-new-application", "player", p.getName(),
                "title", (job.title));
        return true;
    }

    public boolean hire(Player owner, Application app) {
        Job job = jobs.get(app.jobId);
        Business b = job == null ? null : businesses.get(job.businessId);
        if (job == null || b == null || !applications.containsKey(app.id)) {
            msg(owner, "job.not-available");
            return false;
        }
        if (!b.owner.equals(owner.getUniqueId())) {
            msg(owner, "business.not-owner");
            return false;
        }
        if (freeSlots(job) <= 0) {
            msg(owner, "job.no-slots");
            return false;
        }
        for (Employment e : employmentsOf(app.applicant)) {
            if (e.businessId.equals(b.id)) {
                msg(owner, "job.already-employed");
                return false;
            }
        }
        if (employmentsOf(app.applicant).size() >= plugin.getConfig().getInt("employment.max-jobs-per-player", 2)) {
            msg(owner, "job.applicant-busy");
            return false;
        }
        double hours = plugin.getConfig().getDouble("employment.reserve-hours", 8);
        double needed = EconomyService.round(reserveRequired(b) + job.wage * hours);
        if (b.balance + 0.0001 < needed) {
            msg(owner, "job.fund-first", "needed", money(needed), "balance", money(b.balance));
            return false;
        }
        Employment e = new Employment(UUID.randomUUID().toString(), b.id, job.id, app.applicant,
                app.applicantName, job.wage, job.maxHours, System.currentTimeMillis());
        employments.put(e.id, e);
        saveEmployment(e);
        applications.remove(app.id);
        db.execute("DELETE FROM applications WHERE id = ?", app.id);
        msg(owner, "job.hired-owner", "player", app.applicantName, "title", (job.title));
        plugin.notices().notify(app.applicant, "job.hired", "business", (b.name),
                "title", (job.title), "wage", money(job.wage));
        return true;
    }

    public boolean decline(Player owner, Application app) {
        Job job = jobs.get(app.jobId);
        Business b = job == null ? null : businesses.get(job.businessId);
        if (b == null || !b.owner.equals(owner.getUniqueId())) {
            msg(owner, "business.not-owner");
            return false;
        }
        applications.remove(app.id);
        db.execute("DELETE FROM applications WHERE id = ?", app.id);
        msg(owner, "job.declined-owner", "player", app.applicantName);
        plugin.notices().notify(app.applicant, "job.declined", "business", (b.name),
                "title", (job.title));
        return true;
    }

    public boolean fire(Player owner, Business b, String playerName) {
        if (!b.owner.equals(owner.getUniqueId())) {
            msg(owner, "business.not-owner");
            return false;
        }
        for (Employment e : employeesOf(b)) {
            if (e.employeeName.equalsIgnoreCase(playerName)) {
                Shift s = shifts.get(e.employee);
                if (s != null) endShift(s, null);
                employments.remove(e.id);
                db.execute("DELETE FROM employments WHERE id = ?", e.id);
                msg(owner, "job.fired-owner", "player", e.employeeName);
                plugin.notices().notify(e.employee, "job.fired", "business", (b.name));
                return true;
            }
        }
        msg(owner, "job.employee-not-found");
        return false;
    }

    public boolean quit(Player p, String businessName) {
        List<Employment> mine = employmentsOf(p.getUniqueId());
        Employment target = null;
        if (businessName != null && !businessName.isBlank()) {
            for (Employment e : mine) {
                Business b = businesses.get(e.businessId);
                if (b != null && b.name.equalsIgnoreCase(businessName.trim())) target = e;
            }
        } else if (mine.size() == 1) {
            target = mine.get(0);
        }
        if (target == null) {
            msg(p, mine.isEmpty() ? "job.not-employed" : "job.specify-business");
            return false;
        }
        Shift s = shifts.get(p.getUniqueId());
        if (s != null && s.employmentId.equals(target.id)) endShift(s, null);
        employments.remove(target.id);
        db.execute("DELETE FROM employments WHERE id = ?", target.id);
        Business b = businesses.get(target.businessId);
        msg(p, "job.quit", "business", (b == null ? "-" : b.name));
        if (b != null) {
            plugin.notices().notify(b.owner, "job.owner-employee-quit", "player", p.getName());
        }
        return true;
    }

    // ------------------------------------------------------------------ shifts and payroll

    private static void rollDay(Employment e) {
        long today = LocalDate.now().toEpochDay();
        if (e.dayStamp != today) {
            e.dayStamp = today;
            e.workedTodayMs = 0;
        }
    }

    public boolean clockIn(Player p, String businessName) {
        UUID id = p.getUniqueId();
        if (shifts.containsKey(id)) {
            msg(p, "work.already");
            return false;
        }
        List<Employment> mine = employmentsOf(id);
        if (mine.isEmpty()) {
            msg(p, "job.not-employed");
            return false;
        }
        Employment target = null;
        if (businessName != null && !businessName.isBlank()) {
            for (Employment e : mine) {
                Business b = businesses.get(e.businessId);
                if (b != null && b.name.equalsIgnoreCase(businessName.trim())) target = e;
            }
        } else if (mine.size() == 1) {
            target = mine.get(0);
        } else {
            Plot here = plugin.plots().getAt(p.getLocation());
            if (here != null) {
                Business hb = byPlot.get(here.id);
                for (Employment e : mine) if (hb != null && e.businessId.equals(hb.id)) target = e;
            }
        }
        if (target == null) {
            msg(p, "job.specify-business");
            return false;
        }
        Business b = businesses.get(target.businessId);
        Plot plot = b == null ? null : plugin.plots().get(b.plotId);
        if (b == null || plot == null) {
            msg(p, "job.not-available");
            return false;
        }
        if (!plot.contains(p.getLocation())) {
            msg(p, "work.not-in-shop");
            return false;
        }
        double minHours = plugin.getConfig().getDouble("employment.min-balance-to-clock-in-hours", 1);
        if (b.balance + 0.0001 < target.wage * minHours) {
            msg(p, "work.business-broke");
            return false;
        }
        rollDay(target);
        if (target.workedTodayMs >= target.maxHours * 3_600_000L) {
            msg(p, "work.cap-reached", "hours", target.maxHours);
            return false;
        }
        long now = System.currentTimeMillis();
        Shift s = new Shift(id, target.id, plot.id, now);
        s.lastLoc = p.getLocation();
        shifts.put(id, s);
        msg(p, "work.started", "business", (b.name), "wage", money(target.wage));
        return true;
    }

    public boolean clockOutCommand(Player p) {
        Shift s = shifts.get(p.getUniqueId());
        if (s == null) {
            msg(p, "work.not-on-shift");
            return false;
        }
        endShift(s, "work.ended-manual");
        return true;
    }

    /** Finishes a shift, paying whatever has been earned and is affordable. */
    private void endShift(Shift s, String reasonKey) {
        Employment e = employments.get(s.employmentId);
        Business b = e == null ? null : businesses.get(e.businessId);
        if (e != null && b != null) {
            rollDay(e);
            payPending(s, e, b);
            if (s.underfunded) {
                plugin.notices().notify(b.owner, "work.owner-underfunded", "business", (b.name),
                        "player", e.employeeName);
            }
        }
        shifts.remove(s.player);
        Player p = Bukkit.getPlayer(s.player);
        String key = s.underfunded ? "work.ended-underfunded" : reasonKey;
        if (p != null && key != null) {
            msg(p, key, "paid", money(s.paidTotal));
        }
    }

    private double payPending(Shift s, Employment e, Business b) {
        long remaining = Math.max(0L, e.maxHours * 3_600_000L - e.workedTodayMs);
        long payMs = Math.min(s.pendingMs, remaining);
        s.pendingMs = 0;
        if (payMs <= 0) return 0;
        double gross = EconomyService.round(e.wage * payMs / 3_600_000.0);
        if (gross > 0 && b.balance + 0.0001 < gross) {
            gross = Math.max(0, EconomyService.round(b.balance));
            s.underfunded = true;
        }
        e.workedTodayMs += payMs;
        e.totalWorkedMs += payMs;
        if (gross <= 0) {
            saveEmployment(e);
            return 0;
        }
        double taxPct = plugin.getConfig().getDouble("employment.wage-tax-percent", 0);
        double net = EconomyService.round(gross - EconomyService.round(gross * taxPct / 100.0));
        b.balance = EconomyService.round(b.balance - gross);
        plugin.economy().deposit(e.employee, net);
        e.totalPaid = EconomyService.round(e.totalPaid + net);
        s.paidTotal = EconomyService.round(s.paidTotal + net);
        saveBusiness(b);
        saveEmployment(e);
        plugin.ledger().log("WAGE", null, e.employee, net, b.id);
        Player p = Bukkit.getPlayer(e.employee);
        if (p != null) {
            p.sendActionBar(plugin.messages().component("work.paid-bar", "amount", money(net)));
        }
        return net;
    }

    private void payrollTick() {
        if (shifts.isEmpty()) return;
        long now = System.currentTimeMillis();
        var cfg = plugin.getConfig();
        long afkMs = cfg.getLong("employment.afk-seconds", 120L) * 1000L;
        long kickMs = cfg.getLong("employment.afk-kick-seconds", 600L) * 1000L;
        long leaveMs = cfg.getLong("employment.leave-grace-seconds", 30L) * 1000L;
        long payChunkMs = cfg.getLong("employment.pay-interval-seconds", 300L) * 1000L;

        for (Shift s : new ArrayList<>(shifts.values())) {
            Player p = Bukkit.getPlayer(s.player);
            Employment e = employments.get(s.employmentId);
            Business b = e == null ? null : businesses.get(e.businessId);
            Plot plot = b == null ? null : plugin.plots().get(b.plotId);
            if (p == null || e == null || b == null || plot == null) {
                endShift(s, null);
                continue;
            }
            rollDay(e);
            Location l = p.getLocation();
            boolean inside = plot.contains(l);
            if (!inside) {
                if (s.outsideSince == 0) {
                    s.outsideSince = now;
                } else if (now - s.outsideSince > leaveMs) {
                    endShift(s, "work.ended-left");
                    continue;
                }
            } else {
                s.outsideSince = 0;
            }
            boolean moved = s.lastLoc == null || s.lastLoc.getWorld() != l.getWorld()
                    || s.lastLoc.distanceSquared(l) > 0.0004
                    || Math.abs(s.lastLoc.getYaw() - l.getYaw()) > 0.5f
                    || Math.abs(s.lastLoc.getPitch() - l.getPitch()) > 0.5f;
            s.lastLoc = l;
            if (moved) s.lastActiveAt = now;
            long elapsed = Math.min(Math.max(0L, now - s.lastTickAt), 120_000L);
            s.lastTickAt = now;
            if (now - s.lastActiveAt > kickMs) {
                endShift(s, "work.ended-afk");
                continue;
            }
            if (inside && now - s.lastActiveAt <= afkMs) s.pendingMs += elapsed;

            long dayLeft = e.maxHours * 3_600_000L - e.workedTodayMs - s.pendingMs;
            if (s.pendingMs >= payChunkMs || dayLeft <= 0) {
                payPending(s, e, b);
                if (s.underfunded) {
                    endShift(s, "work.ended-underfunded");
                } else if (e.workedTodayMs >= e.maxHours * 3_600_000L) {
                    endShift(s, "work.ended-cap");
                }
            }
        }
    }

    public String describeTime(UUID id) {
        return TimeUtil.formatMillis(shiftPendingMs(id));
    }

    public int businessCount() {
        return businesses.size();
    }

    public int jobCount() {
        return jobs.size();
    }

    public int employmentCount() {
        return employments.size();
    }

    public int onShiftCount() {
        return shifts.size();
    }
}
