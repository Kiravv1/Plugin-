package dev.frontier.estate.service;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.db.Database;
import dev.frontier.estate.util.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Messages for people who are offline (rent paid, evicted, hired...). Delivered when they join. */
public final class NoticeService {

    private final FrontierEstatePlugin plugin;
    private final Database db;
    private final Set<UUID> pending = ConcurrentHashMap.newKeySet();

    public NoticeService(FrontierEstatePlugin plugin, Database db) {
        this.plugin = plugin;
        this.db = db;
    }

    public void load() {
        List<String> ids = db.querySync("SELECT DISTINCT owner_uuid FROM notices", rs -> rs.getString(1));
        for (String s : ids) {
            try {
                pending.add(UUID.fromString(s));
            } catch (IllegalArgumentException ignored) {
                // skip bad row
            }
        }
    }

    /** Sends now if the player is online, otherwise stores it for their next login. */
    public void notify(UUID target, String key, Object... pairs) {
        Component c = plugin.messages().component(key, pairs);
        Player p = Bukkit.getPlayer(target);
        if (p != null) {
            p.sendMessage(c);
            return;
        }
        db.execute("INSERT INTO notices (id, owner_uuid, msg_text, created_at) VALUES (?,?,?,?)",
                UUID.randomUUID().toString(), target.toString(), Text.MM.serialize(c), System.currentTimeMillis());
        pending.add(target);
    }

    public void deliver(Player player) {
        UUID id = player.getUniqueId();
        if (!pending.remove(id)) return;
        db.queryAsync("SELECT msg_text FROM notices WHERE owner_uuid = ? ORDER BY created_at DESC",
                rs -> rs.getString(1), id.toString()).thenAccept(rows -> {
            db.execute("DELETE FROM notices WHERE owner_uuid = ?", id.toString());
            List<Component> shown = new ArrayList<>();
            int limit = Math.min(rows.size(), 15);
            for (int i = limit - 1; i >= 0; i--) shown.add(Text.MM.deserialize(rows.get(i)));
            Bukkit.getScheduler().runTask(plugin, () -> {
                Player p = Bukkit.getPlayer(id);
                if (p == null) return;
                for (Component c : shown) p.sendMessage(c);
            });
        });
    }
}
