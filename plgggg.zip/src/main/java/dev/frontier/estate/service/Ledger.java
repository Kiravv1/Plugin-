package dev.frontier.estate.service;

import dev.frontier.estate.db.Database;

import java.util.UUID;

/** Append-only audit trail of every money movement made by this plugin. */
public final class Ledger {

    private final Database db;

    public Ledger(Database db) {
        this.db = db;
    }

    public void purgeOlderThanDays(int days) {
        if (days <= 0) return;
        long cutoff = System.currentTimeMillis() - days * 86_400_000L;
        db.execute("DELETE FROM transactions WHERE ts < ?", cutoff);
    }

    public void log(String type, UUID from, UUID to, double amount, String note) {
        db.execute("INSERT INTO transactions (id, ts, tx_type, from_id, to_id, amount, note) VALUES (?,?,?,?,?,?,?)",
                UUID.randomUUID().toString(), System.currentTimeMillis(), type,
                from == null ? null : from.toString(), to == null ? null : to.toString(), amount,
                note == null ? "" : (note.length() > 250 ? note.substring(0, 250) : note));
    }
}
