package dev.frontier.estate.service;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.util.UUID;

/** Thin wrapper over Vault. Always call on the main thread. */
public final class EconomyService {

    private final Economy economy;

    public EconomyService(Economy economy) {
        this.economy = economy;
    }

    public static double round(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    private static OfflinePlayer off(UUID id) {
        return Bukkit.getOfflinePlayer(id);
    }

    public boolean has(UUID id, double amount) {
        return economy.has(off(id), amount);
    }

    public boolean withdraw(UUID id, double amount) {
        if (amount <= 0) return true;
        EconomyResponse r = economy.withdrawPlayer(off(id), amount);
        return r != null && r.transactionSuccess();
    }

    public boolean deposit(UUID id, double amount) {
        if (amount <= 0) return true;
        EconomyResponse r = economy.depositPlayer(off(id), amount);
        return r != null && r.transactionSuccess();
    }

    public String format(double amount) {
        return economy.format(amount);
    }
}
