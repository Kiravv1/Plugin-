package dev.frontier.estate.service;

import org.bukkit.block.Block;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Remembers each admin's two selection corners. */
public final class SelectionService {

    public record Pos(String world, int x, int y, int z) { }

    private final Map<UUID, Pos> first = new HashMap<>();
    private final Map<UUID, Pos> second = new HashMap<>();

    private static Pos of(Block b) {
        return new Pos(b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
    }

    public void setFirst(UUID id, Block b) {
        first.put(id, of(b));
    }

    public void setSecond(UUID id, Block b) {
        second.put(id, of(b));
    }

    public Pos first(UUID id) {
        return first.get(id);
    }

    public Pos second(UUID id) {
        return second.get(id);
    }

    public void clear(UUID id) {
        first.remove(id);
        second.remove(id);
    }
}
