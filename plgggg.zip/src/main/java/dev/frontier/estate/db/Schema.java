package dev.frontier.estate.db;

import java.util.List;

public final class Schema {

    private Schema() { }

    /** Portable between SQLite and MySQL/MariaDB (no auto-increment, ids are generated in code). */
    public static List<String> tables() {
        return List.of(
                "CREATE TABLE IF NOT EXISTS plots ("
                        + "id VARCHAR(64) PRIMARY KEY, world VARCHAR(64) NOT NULL,"
                        + "min_x INT, min_y INT, min_z INT, max_x INT, max_y INT, max_z INT,"
                        + "plot_type VARCHAR(16), price DOUBLE, owner_uuid VARCHAR(36), display_name VARCHAR(64),"
                        + "public_access INT, trusted TEXT, created_at BIGINT)",

                "CREATE TABLE IF NOT EXISTS rentals ("
                        + "plot_id VARCHAR(64) PRIMARY KEY, status VARCHAR(16), price DOUBLE, period_sec BIGINT,"
                        + "deposit DOUBLE, allow_build INT, periods_total INT, periods_paid INT,"
                        + "tenant_uuid VARCHAR(36), start_ms BIGINT, next_due_ms BIGINT, grace_until_ms BIGINT)",

                "CREATE TABLE IF NOT EXISTS businesses ("
                        + "id VARCHAR(36) PRIMARY KEY, business_name VARCHAR(64), owner_uuid VARCHAR(36),"
                        + "plot_id VARCHAR(64), balance DOUBLE, created_at BIGINT)",

                "CREATE TABLE IF NOT EXISTS jobs ("
                        + "id VARCHAR(36) PRIMARY KEY, business_id VARCHAR(36), title VARCHAR(64), wage DOUBLE,"
                        + "max_hours INT, slots INT, is_open INT, created_at BIGINT)",

                "CREATE TABLE IF NOT EXISTS applications ("
                        + "id VARCHAR(36) PRIMARY KEY, job_id VARCHAR(36), applicant_uuid VARCHAR(36),"
                        + "applicant_name VARCHAR(32), created_at BIGINT)",

                "CREATE TABLE IF NOT EXISTS employments ("
                        + "id VARCHAR(36) PRIMARY KEY, business_id VARCHAR(36), job_id VARCHAR(36),"
                        + "employee_uuid VARCHAR(36), employee_name VARCHAR(32), wage DOUBLE, max_hours INT,"
                        + "hired_at BIGINT, day_stamp BIGINT, worked_today_ms BIGINT, total_worked_ms BIGINT,"
                        + "total_paid DOUBLE)",

                "CREATE TABLE IF NOT EXISTS stash ("
                        + "id VARCHAR(36) PRIMARY KEY, owner_uuid VARCHAR(36), item_data LONGTEXT, created_at BIGINT)",

                "CREATE TABLE IF NOT EXISTS notices ("
                        + "id VARCHAR(36) PRIMARY KEY, owner_uuid VARCHAR(36), msg_text TEXT, created_at BIGINT)",

                "CREATE TABLE IF NOT EXISTS transactions ("
                        + "id VARCHAR(36) PRIMARY KEY, ts BIGINT, tx_type VARCHAR(24), from_id VARCHAR(36),"
                        + "to_id VARCHAR(36), amount DOUBLE, note VARCHAR(255))"
        );
    }
}
