package dev.frontier.estate.db;

import org.bukkit.configuration.ConfigurationSection;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * One database thread, one connection. All reads/writes happen off the main thread, so the game never waits
 * for the disk. State lives in memory; this class only persists it.
 */
public final class Database {

    public interface RowMapper<T> {
        T map(ResultSet rs) throws SQLException;
    }

    private final Logger log;
    private final ExecutorService executor;
    private final String url;
    private final String user;
    private final String pass;
    private final boolean sqlite;
    private Connection conn;

    public Database(Logger log, ConfigurationSection cfg, File dataFolder) {
        this.log = log;
        String type = cfg == null ? "sqlite" : cfg.getString("type", "sqlite");
        this.sqlite = !"mysql".equalsIgnoreCase(type);
        if (sqlite) {
            String file = cfg == null ? "estate.db" : cfg.getString("sqlite-file", "estate.db");
            this.url = "jdbc:sqlite:" + new File(dataFolder, file).getAbsolutePath();
            this.user = null;
            this.pass = null;
        } else {
            ConfigurationSection my = cfg.getConfigurationSection("mysql");
            String host = my == null ? "localhost" : my.getString("host", "localhost");
            int port = my == null ? 3306 : my.getInt("port", 3306);
            String db = my == null ? "estate" : my.getString("database", "estate");
            boolean ssl = my != null && my.getBoolean("use-ssl", false);
            this.url = "jdbc:mysql://" + host + ":" + port + "/" + db
                    + "?useSSL=" + ssl + "&autoReconnect=true&characterEncoding=utf8";
            this.user = my == null ? "root" : my.getString("user", "root");
            this.pass = my == null ? "" : my.getString("password", "");
        }
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "FrontierEstate-DB");
            t.setDaemon(false);
            return t;
        });
    }

    /** Opens the connection and creates tables. Throws if the database is unusable. */
    public void init(List<String> ddl) throws Exception {
        try {
            Class.forName(sqlite ? "org.sqlite.JDBC" : "com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("JDBC driver not found for " + (sqlite ? "SQLite" : "MySQL"), e);
        }
        Future<?> f = executor.submit(() -> {
            try {
                Connection c = connection();
                try (Statement st = c.createStatement()) {
                    for (String sql : ddl) st.execute(sql);
                }
            } catch (SQLException e) {
                throw new IllegalStateException(e);
            }
        });
        f.get(60, TimeUnit.SECONDS);
    }

    private Connection connection() throws SQLException {
        if (conn == null || conn.isClosed() || !conn.isValid(2)) {
            conn = sqlite ? DriverManager.getConnection(url) : DriverManager.getConnection(url, user, pass);
            if (sqlite) {
                try (Statement st = conn.createStatement()) {
                    st.execute("PRAGMA journal_mode=WAL");
                    st.execute("PRAGMA synchronous=NORMAL");
                }
            }
        }
        return conn;
    }

    private static void bind(PreparedStatement ps, Object[] params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            Object p = params[i];
            if (p instanceof UUID) {
                p = p.toString();
            } else if (p instanceof Boolean b) {
                p = b ? 1 : 0;
            }
            ps.setObject(i + 1, p);
        }
    }

    /** Fire-and-forget write. */
    public void execute(String sql, Object... params) {
        executor.execute(() -> {
            try (PreparedStatement ps = connection().prepareStatement(sql)) {
                bind(ps, params);
                ps.executeUpdate();
            } catch (Exception e) {
                log.log(Level.SEVERE, "Database write failed: " + sql, e);
            }
        });
    }

    private <T> List<T> queryNow(String sql, RowMapper<T> mapper, Object[] params) throws SQLException {
        List<T> out = new ArrayList<>();
        try (PreparedStatement ps = connection().prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(mapper.map(rs));
            }
        }
        return out;
    }

    /** Blocking read, used only while loading at startup. */
    public <T> List<T> querySync(String sql, RowMapper<T> mapper, Object... params) {
        Future<List<T>> f = executor.submit(() -> queryNow(sql, mapper, params));
        try {
            return f.get(60, TimeUnit.SECONDS);
        } catch (Exception e) {
            throw new IllegalStateException("Database read failed: " + sql, e);
        }
    }

    public <T> CompletableFuture<List<T>> queryAsync(String sql, RowMapper<T> mapper, Object... params) {
        CompletableFuture<List<T>> cf = new CompletableFuture<>();
        executor.execute(() -> {
            try {
                cf.complete(queryNow(sql, mapper, params));
            } catch (Exception e) {
                cf.completeExceptionally(e);
            }
        });
        return cf;
    }

    /** Waits for queued writes, then closes the connection. */
    public void close() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(30, TimeUnit.SECONDS)) {
                log.warning("Database queue did not finish in time.");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        try {
            if (conn != null) conn.close();
        } catch (SQLException ignored) {
            // closing anyway
        }
    }
}
