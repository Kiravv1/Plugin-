package dev.frontier.estate.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class Text {

    public static final MiniMessage MM = MiniMessage.miniMessage();

    private Text() { }

    /** Component from MiniMessage markup written by the plugin itself (never raw player input). */
    public static Component mm(String markup) {
        return MM.deserialize("<!italic>" + markup);
    }

    /** Escape player-provided text so it is shown literally inside MiniMessage markup. */
    public static String esc(String s) {
        return MM.escapeTags(s == null ? "" : s);
    }

    public static ItemStack item(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(mm(name));
            if (lore.length > 0) {
                List<Component> lines = new ArrayList<>();
                for (String line : lore) lines.add(mm(line));
                meta.lore(lines);
            }
            stack.setItemMeta(meta);
        }
        return stack;
    }

    /** Best-effort player name from a UUID without any network lookups. */
    public static String name(UUID id) {
        if (id == null) return "-";
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n != null ? n : id.toString().substring(0, 8);
    }
}
