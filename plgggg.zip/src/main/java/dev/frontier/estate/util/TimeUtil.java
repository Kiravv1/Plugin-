package dev.frontier.estate.util;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TimeUtil {

    private static final Pattern TOKEN = Pattern.compile("(\\d{1,6})([dhm])");

    private TimeUtil() { }

    /** Parses values like 30m, 12h, 7d, 1d12h. Returns -1 if invalid. */
    public static long parseSeconds(String input) {
        if (input == null) return -1;
        String s = input.toLowerCase(Locale.ROOT).trim();
        if (s.isEmpty()) return -1;
        Matcher m = TOKEN.matcher(s);
        long total = 0;
        int consumed = 0;
        while (m.find()) {
            if (m.start() != consumed) return -1;
            long n = Long.parseLong(m.group(1));
            switch (m.group(2)) {
                case "d" -> total += n * 86400L;
                case "h" -> total += n * 3600L;
                default -> total += n * 60L;
            }
            consumed = m.end();
        }
        if (consumed != s.length()) return -1;
        return total;
    }

    /** Human readable Arabic duration, e.g. "2 يوم 3 ساعة". */
    public static String format(long seconds) {
        if (seconds <= 0) return "0 دقيقة";
        long d = seconds / 86400L;
        long h = (seconds % 86400L) / 3600L;
        long m = (seconds % 3600L) / 60L;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append(" يوم ");
        if (h > 0) sb.append(h).append(" ساعة ");
        if (m > 0 || sb.length() == 0) sb.append(m).append(" دقيقة");
        return sb.toString().trim();
    }

    public static String formatMillis(long millis) {
        return format(Math.max(0L, millis) / 1000L);
    }
}
