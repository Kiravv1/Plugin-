package dev.frontier.estate.util;

import dev.frontier.estate.model.Plot;

public final class Names {

    private Names() { }

    public static String plotType(Plot.Type type) {
        return switch (type) {
            case HOUSE -> "بيت";
            case SHOP -> "محل";
            case FARM -> "مزرعة";
            case LAND -> "أرض";
        };
    }
}
