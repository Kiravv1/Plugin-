package dev.frontier.estate.util;

import dev.frontier.estate.model.Plot;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class Locations {

    private Locations() { }

    /** A reasonable place to teleport to for a plot: its centre, on the highest block inside it. */
    public static Location plotSpawn(Plot plot) {
        World w = Bukkit.getWorld(plot.world);
        if (w == null) return null;
        int x = (plot.minX + plot.maxX) / 2;
        int z = (plot.minZ + plot.maxZ) / 2;
        int y = w.getHighestBlockYAt(x, z) + 1;
        if (y < plot.minY) y = plot.minY;
        if (y > plot.maxY) y = plot.maxY;
        return new Location(w, x + 0.5, y, z + 0.5);
    }
}
