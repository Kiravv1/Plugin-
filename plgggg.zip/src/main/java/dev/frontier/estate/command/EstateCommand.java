package dev.frontier.estate.command;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.gui.ApplicantsMenu;
import dev.frontier.estate.gui.JobBoardMenu;
import dev.frontier.estate.gui.RentBoardMenu;
import dev.frontier.estate.gui.StashMenu;
import dev.frontier.estate.model.Business;
import dev.frontier.estate.model.Employment;
import dev.frontier.estate.model.Job;
import dev.frontier.estate.model.Plot;
import dev.frontier.estate.model.Rental;
import dev.frontier.estate.service.EconomyService;
import dev.frontier.estate.service.RentalService;
import dev.frontier.estate.service.SelectionService;
import dev.frontier.estate.service.StashService;
import dev.frontier.estate.util.Locations;
import dev.frontier.estate.util.Names;
import dev.frontier.estate.util.Text;
import dev.frontier.estate.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/** Every /estate subcommand. */
public final class EstateCommand implements CommandExecutor, TabCompleter {

    private record Offer(String plotId, UUID seller, double price, long expiresAt) { }

    private static final List<String> PLAYER_SUBS = List.of("help", "info", "buy", "sell", "accept", "trust",
            "untrust", "public", "rename", "list", "home", "rent", "board", "stash", "business", "jobs", "job",
            "applicants", "fire", "quit", "clockin", "clockout", "work");
    private static final List<String> ADMIN_SUBS = List.of("wand", "pos1", "pos2", "create", "grid", "delete",
            "setowner", "setprice", "settype", "tp", "info", "evict", "snapshot", "restore", "reload", "stats");

    private final FrontierEstatePlugin plugin;
    private final Map<UUID, Offer> offers = new HashMap<>();
    private final Map<UUID, Long> homeCooldown = new HashMap<>();

    public EstateCommand(FrontierEstatePlugin plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ plumbing

    private void msg(CommandSender s, String key, Object... pairs) {
        plugin.messages().send(s, key, pairs);
    }

    private String money(double v) {
        return plugin.economy().format(v);
    }

    private Player player(CommandSender s) {
        if (s instanceof Player p) return p;
        msg(s, "cmd.players-only");
        return null;
    }

    private Plot here(Player p) {
        Plot plot = plugin.plots().getAt(p.getLocation());
        if (plot == null) msg(p, "plot.not-here");
        return plot;
    }

    /** Parses an amount; returns NaN (after telling the player) if it is not valid. */
    private double amount(CommandSender s, String text, boolean allowZero) {
        try {
            double v = Double.parseDouble(text);
            boolean ok = !Double.isNaN(v) && !Double.isInfinite(v) && v <= 1_000_000_000d
                    && (allowZero ? v >= 0 : v > 0);
            if (ok) return EconomyService.round(v);
        } catch (NumberFormatException ignored) {
            // falls through to the error message
        }
        msg(s, "common.bad-amount");
        return Double.NaN;
    }

    private int whole(CommandSender s, String text, int min, int max) {
        try {
            int v = Integer.parseInt(text);
            if (v >= min && v <= max) return v;
        } catch (NumberFormatException ignored) {
            // falls through to the error message
        }
        msg(s, "common.bad-number", "min", min, "max", max);
        return Integer.MIN_VALUE;
    }

    private boolean isAdmin(CommandSender s) {
        if (s.hasPermission("frontierestate.admin")) return true;
        msg(s, "cmd.no-permission");
        return false;
    }

    private static boolean validName(String s, int max) {
        return s != null && s.length() >= 2 && s.length() <= max && s.matches("[\\p{L}\\p{N} _.'-]+");
    }

    // ------------------------------------------------------------------ dispatch

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("frontierestate.use")) {
            msg(sender, "cmd.no-permission");
            return true;
        }
        if (args.length == 0) {
            help(sender);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        String[] a = Arrays.copyOfRange(args, 1, args.length);
        try {
            switch (sub) {
                case "help" -> help(sender);
                case "info" -> info(sender);
                case "buy" -> buy(sender);
                case "sell" -> sell(sender, a);
                case "accept" -> accept(sender);
                case "trust" -> trust(sender, a, true);
                case "untrust" -> trust(sender, a, false);
                case "public" -> togglePublic(sender, a);
                case "rename" -> rename(sender, a);
                case "list" -> listMine(sender);
                case "home" -> home(sender, a);
                case "rent" -> rent(sender, a);
                case "board" -> board(sender);
                case "stash" -> stash(sender);
                case "business", "shop" -> business(sender, a);
                case "jobs" -> jobsBoard(sender);
                case "job" -> job(sender, a);
                case "applicants" -> applicants(sender, a);
                case "fire" -> fire(sender, a);
                case "quit" -> quit(sender, a);
                case "clockin" -> clockIn(sender, a);
                case "clockout" -> clockOut(sender);
                case "work" -> work(sender);
                case "admin" -> admin(sender, a);
                default -> msg(sender, "cmd.unknown");
            }
        } catch (RuntimeException ex) {
            plugin.getLogger().log(Level.WARNING, "Error while running /estate " + sub, ex);
            msg(sender, "cmd.error");
        }
        return true;
    }

    private void help(CommandSender s) {
        plugin.messages().sendList(s, "help.player");
        if (s.hasPermission("frontierestate.admin")) plugin.messages().sendList(s, "help.admin");
    }

    // ------------------------------------------------------------------ plots

    private void info(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        Plot plot = here(p);
        if (plot == null) return;
        sendPlotInfo(p, plot);
    }

    private void sendPlotInfo(CommandSender s, Plot plot) {
        String owner = plot.owner == null ? "الدولة" : Text.name(plot.owner);
        String price = plot.owner != null || plot.price < 0 ? "غير معروض للبيع" : money(plot.price);
        plugin.messages().sendList(s, "plot.info", "id", plot.id, "name", plot.label(),
                "type", Names.plotType(plot.type),
                "size", plot.sizeX() + "×" + plot.sizeY() + "×" + plot.sizeZ(),
                "owner", owner, "price", price);
        Rental r = plot.rental;
        if (r != null) {
            if (r.isOccupied()) {
                msg(s, "plot.info-rented", "tenant", Text.name(r.tenant),
                        "next", TimeUtil.formatMillis(r.nextDueMs - System.currentTimeMillis()),
                        "status", r.status == Rental.Status.GRACE ? "متأخر" : "فعّال");
            } else {
                msg(s, "plot.info-listed", "price", money(r.price), "period", TimeUtil.format(r.periodSec));
            }
        }
        Business b = plugin.business().forPlot(plot.id);
        if (b != null) msg(s, "plot.info-business", "name", b.name);
    }

    private void buy(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        Plot plot = here(p);
        if (plot == null) return;
        UUID id = p.getUniqueId();
        if (plot.owner != null) {
            msg(p, plot.isOwner(id) ? "buy.already-yours" : "buy.not-for-sale");
            return;
        }
        if (plot.price < 0) {
            msg(p, "buy.not-for-sale");
            return;
        }
        int max = plugin.plots().maxPlots(p);
        if (plugin.plots().ownedBy(id).size() >= max) {
            msg(p, "buy.limit", "max", max);
            return;
        }
        double price = plot.price;
        if (!plugin.economy().has(id, price)) {
            msg(p, "common.no-money", "price", money(price));
            return;
        }
        if (!plugin.economy().withdraw(id, price)) {
            msg(p, "common.payment-failed");
            return;
        }
        plot.owner = id;
        plot.trusted.clear();
        plot.publicAccess = plot.type == Plot.Type.SHOP;
        plugin.plots().save(plot);
        plugin.ledger().log("PLOT_BUY", id, null, price, plot.id);
        msg(p, "buy.success", "plot", plot.label(), "price", money(price));
    }

    private void sell(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Plot plot = here(p);
        if (plot == null) return;
        UUID id = p.getUniqueId();
        if (!plot.isOwner(id)) {
            msg(p, "sell.not-owner");
            return;
        }
        if (plot.rental != null) {
            msg(p, "sell.has-rental");
            return;
        }
        if (plugin.business().forPlot(plot.id) != null) {
            msg(p, "sell.has-business");
            return;
        }
        if (a.length == 0) {
            if (plot.price < 0) {
                msg(p, "sell.cannot-state");
                return;
            }
            double pct = plugin.getConfig().getDouble("plots.sell-refund-percent", 70);
            double refund = EconomyService.round(plot.price * pct / 100.0);
            plot.owner = null;
            plot.trusted.clear();
            plot.publicAccess = plot.type == Plot.Type.SHOP;
            plugin.plots().save(plot);
            plugin.economy().deposit(id, refund);
            plugin.ledger().log("PLOT_SELL_STATE", null, id, refund, plot.id);
            msg(p, "sell.to-state", "plot", plot.label(), "refund", money(refund));
            return;
        }
        if (a.length < 2) {
            msg(p, "sell.usage");
            return;
        }
        Player buyer = Bukkit.getPlayerExact(a[0]);
        if (buyer == null || buyer.equals(p)) {
            msg(p, "common.player-offline");
            return;
        }
        double price = amount(p, a[1], false);
        if (Double.isNaN(price)) return;
        offers.put(buyer.getUniqueId(), new Offer(plot.id, id, price, System.currentTimeMillis() + 60_000L));
        msg(p, "sell.offer-sent", "player", buyer.getName(), "price", money(price));
        msg(buyer, "sell.offer-received", "player", p.getName(), "plot", plot.label(), "price", money(price));
    }

    private void accept(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        Offer o = offers.remove(p.getUniqueId());
        if (o == null || o.expiresAt() < System.currentTimeMillis()) {
            msg(p, "sell.no-offer");
            return;
        }
        Plot plot = plugin.plots().get(o.plotId());
        if (plot == null || !plot.isOwner(o.seller()) || plot.rental != null
                || plugin.business().forPlot(plot.id) != null) {
            msg(p, "sell.offer-invalid");
            return;
        }
        UUID id = p.getUniqueId();
        if (plugin.plots().ownedBy(id).size() >= plugin.plots().maxPlots(p)) {
            msg(p, "buy.limit", "max", plugin.plots().maxPlots(p));
            return;
        }
        double price = o.price();
        if (!plugin.economy().has(id, price)) {
            msg(p, "common.no-money", "price", money(price));
            return;
        }
        if (!plugin.economy().withdraw(id, price)) {
            msg(p, "common.payment-failed");
            return;
        }
        double tax = EconomyService.round(price * plugin.getConfig().getDouble("plots.sale-tax-percent", 5) / 100.0);
        double net = EconomyService.round(price - tax);
        plugin.economy().deposit(o.seller(), net);
        plot.owner = id;
        plot.trusted.clear();
        plugin.plots().save(plot);
        plugin.ledger().log("PLOT_SALE", id, o.seller(), price, plot.id);
        msg(p, "sell.bought", "plot", plot.label(), "price", money(price));
        plugin.notices().notify(o.seller(), "sell.sold", "player", p.getName(), "plot", plot.label(),
                "amount", money(net));
    }

    private void trust(CommandSender s, String[] a, boolean add) {
        Player p = player(s);
        if (p == null) return;
        Plot plot = here(p);
        if (plot == null) return;
        if (!plot.isControlledBy(p.getUniqueId())) {
            msg(p, "trust.not-controller");
            return;
        }
        if (a.length < 1) {
            msg(p, add ? "trust.usage" : "untrust.usage");
            return;
        }
        OfflinePlayer target = Bukkit.getPlayerExact(a[0]);
        if (target == null) target = Bukkit.getOfflinePlayerIfCached(a[0]);
        if (target == null) {
            msg(p, "common.player-unknown");
            return;
        }
        UUID tid = target.getUniqueId();
        String tname = target.getName() == null ? a[0] : target.getName();
        if (add) {
            int max = plugin.getConfig().getInt("limits.max-trusted-per-plot", 10);
            if (tid.equals(p.getUniqueId())) {
                msg(p, "trust.self");
                return;
            }
            if (plot.trusted.size() >= max && !plot.trusted.contains(tid)) {
                msg(p, "trust.limit", "max", max);
                return;
            }
            plot.trusted.add(tid);
            msg(p, "trust.added", "player", tname, "plot", plot.label());
        } else {
            if (!plot.trusted.remove(tid)) {
                msg(p, "untrust.not-trusted", "player", tname);
                return;
            }
            msg(p, "untrust.removed", "player", tname, "plot", plot.label());
        }
        plugin.plots().save(plot);
    }

    private void togglePublic(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Plot plot = here(p);
        if (plot == null) return;
        if (!plot.isControlledBy(p.getUniqueId())) {
            msg(p, "trust.not-controller");
            return;
        }
        if (a.length > 0) {
            plot.publicAccess = a[0].equalsIgnoreCase("on");
        } else {
            plot.publicAccess = !plot.publicAccess;
        }
        plugin.plots().save(plot);
        msg(p, plot.publicAccess ? "public.opened" : "public.closed", "plot", plot.label());
    }

    private void rename(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Plot plot = here(p);
        if (plot == null) return;
        if (!plot.isOwner(p.getUniqueId())) {
            msg(p, "sell.not-owner");
            return;
        }
        String name = String.join(" ", a).trim();
        if (!validName(name, 32)) {
            msg(p, "rename.bad-name");
            return;
        }
        plot.displayName = name;
        plugin.plots().save(plot);
        msg(p, "rename.done", "name", name);
    }

    private void listMine(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        UUID id = p.getUniqueId();
        List<Plot> owned = plugin.plots().ownedBy(id);
        List<Plot> rented = plugin.plots().rentedBy(id);
        if (owned.isEmpty() && rented.isEmpty()) {
            msg(p, "list.none");
            return;
        }
        msg(p, "list.header");
        for (Plot plot : owned) {
            String state = plot.rental == null ? "-"
                    : plot.rental.isOccupied() ? "مؤجّر لـ " + Text.name(plot.rental.tenant) : "معروض للإيجار";
            msg(p, "list.owned", "id", plot.id, "name", plot.label(), "type", Names.plotType(plot.type),
                    "state", state);
        }
        for (Plot plot : rented) {
            msg(p, "list.rented", "id", plot.id, "name", plot.label(), "owner", Text.name(plot.owner),
                    "next", TimeUtil.formatMillis(plot.rental.nextDueMs - System.currentTimeMillis()));
        }
    }

    private void home(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        if (!plugin.getConfig().getBoolean("teleport.home-enabled", true)) {
            msg(p, "home.disabled");
            return;
        }
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        long cooldown = plugin.getConfig().getLong("teleport.home-cooldown-seconds", 10L) * 1000L;
        Long last = homeCooldown.get(id);
        if (last != null && now - last < cooldown) {
            msg(p, "home.cooldown", "seconds", (cooldown - (now - last)) / 1000L + 1);
            return;
        }
        List<Plot> mine = new ArrayList<>();
        for (Plot plot : plugin.plots().ownedBy(id)) if (plot.isControlledBy(id)) mine.add(plot);
        mine.addAll(plugin.plots().rentedBy(id));
        if (mine.isEmpty()) {
            msg(p, "list.none");
            return;
        }
        Plot target = null;
        if (a.length > 0) {
            for (Plot plot : mine) if (plot.id.equalsIgnoreCase(a[0])) target = plot;
        } else if (mine.size() == 1) {
            target = mine.get(0);
        }
        if (target == null) {
            msg(p, "home.choose");
            for (Plot plot : mine) msg(p, "home.entry", "id", plot.id, "name", plot.label());
            return;
        }
        Location loc = Locations.plotSpawn(target);
        if (loc == null) {
            msg(p, "common.error-world");
            return;
        }
        homeCooldown.put(id, now);
        p.teleport(loc);
        msg(p, "home.done", "plot", target.label());
    }

    // ------------------------------------------------------------------ rentals

    private void rent(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        if (a.length == 0) {
            msg(p, "rent.usage");
            return;
        }
        Plot plot = here(p);
        if (plot == null) return;
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "list" -> rentList(p, plot, a);
            case "unlist" -> plugin.rentals().unlist(p, plot);
            case "leave" -> plugin.rentals().leave(p, plot);
            case "pay" -> plugin.rentals().payNow(p, plot);
            case "info" -> sendPlotInfo(p, plot);
            default -> msg(p, "rent.usage");
        }
    }

    private void rentList(Player p, Plot plot, String[] a) {
        if (a.length < 3) {
            msg(p, "rent.usage-list");
            return;
        }
        double price = amount(p, a[1], false);
        if (Double.isNaN(price)) return;
        long period = TimeUtil.parseSeconds(a[2]);
        if (period <= 0) {
            msg(p, "rent.bad-period-format");
            return;
        }
        double deposit = 0;
        int periods = 0;
        boolean build = false;
        int numbers = 0;
        for (int i = 3; i < a.length; i++) {
            String t = a[i].toLowerCase(Locale.ROOT);
            if (t.equals("build")) {
                build = true;
            } else if (t.equals("nobuild")) {
                build = false;
            } else if (numbers == 0) {
                deposit = amount(p, a[i], true);
                if (Double.isNaN(deposit)) return;
                numbers++;
            } else if (numbers == 1) {
                periods = whole(p, a[i], 0, 100000);
                if (periods == Integer.MIN_VALUE) return;
                numbers++;
            }
        }
        plugin.rentals().list(p, plot, price, period, deposit, periods, build);
    }

    private void board(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        List<Plot> listed = plugin.plots().listedForRent();
        if (listed.isEmpty()) {
            msg(p, "board.empty");
            return;
        }
        new RentBoardMenu(plugin, listed).open(p);
    }

    private void stash(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        UUID id = p.getUniqueId();
        if (!plugin.stash().has(id)) {
            msg(p, "stash.empty");
            return;
        }
        plugin.stash().loadFor(id).thenAccept(rows -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            List<StashMenu.StashItem> items = new ArrayList<>();
            for (StashService.Entry e : rows) {
                ItemStack it = StashService.deserialize(e.data());
                if (it != null) items.add(new StashMenu.StashItem(e.id(), it));
            }
            if (items.isEmpty()) {
                msg(p, "stash.empty");
                return;
            }
            new StashMenu(plugin, items).open(p);
        })).exceptionally(ex -> {
            plugin.getLogger().log(Level.WARNING, "Could not load stash", ex);
            return null;
        });
    }

    // ------------------------------------------------------------------ businesses and jobs

    private Business ownedBusiness(Player p, String name) {
        Business b = plugin.business().resolveOwned(p, name);
        if (b == null) msg(p, "business.specify");
        return b;
    }

    private void business(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        if (a.length == 0) {
            msg(p, "business.usage");
            return;
        }
        String[] rest = Arrays.copyOfRange(a, 1, a.length);
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                Plot plot = here(p);
                if (plot != null) plugin.business().create(p, plot, String.join(" ", rest).trim());
            }
            case "info" -> {
                Business b = ownedBusiness(p, String.join(" ", rest));
                if (b != null) businessInfo(p, b);
            }
            case "deposit", "withdraw" -> {
                if (rest.length < 1) {
                    msg(p, "business.usage");
                    return;
                }
                double amt = amount(p, rest[0], false);
                if (Double.isNaN(amt)) return;
                Business b = ownedBusiness(p, String.join(" ", Arrays.copyOfRange(rest, 1, rest.length)));
                if (b == null) return;
                if (a[0].equalsIgnoreCase("deposit")) plugin.business().deposit(p, b, amt);
                else plugin.business().withdraw(p, b, amt);
            }
            case "close" -> {
                Business b = ownedBusiness(p, String.join(" ", rest));
                if (b != null) {
                    plugin.business().close(b, "business.closed-by-owner");
                }
            }
            default -> msg(p, "business.usage");
        }
    }

    private void businessInfo(Player p, Business b) {
        Plot plot = plugin.plots().get(b.plotId);
        msg(p, "business.info", "name", b.name, "plot", plot == null ? "-" : plot.label(),
                "balance", money(b.balance), "reserve", money(plugin.business().reserveRequired(b)));
        for (Employment e : plugin.business().employeesOf(b)) {
            msg(p, "business.info-employee", "player", e.employeeName, "wage", money(e.wage),
                    "worked", TimeUtil.formatMillis(e.totalWorkedMs), "paid", money(e.totalPaid));
        }
        for (Job j : plugin.business().jobsOf(b)) {
            msg(p, "business.info-job", "id", j.id.substring(0, 6), "title", j.title, "wage", money(j.wage),
                    "free", plugin.business().freeSlots(j));
        }
    }

    private void jobsBoard(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        List<Job> open = plugin.business().openJobs();
        if (open.isEmpty()) {
            msg(p, "jobs.empty");
            return;
        }
        new JobBoardMenu(plugin, open).open(p);
    }

    private void job(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        if (a.length == 0) {
            msg(p, "job.usage");
            return;
        }
        String[] rest = Arrays.copyOfRange(a, 1, a.length);
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "post" -> {
                if (rest.length < 4) {
                    msg(p, "job.usage-post");
                    return;
                }
                double wage = amount(p, rest[0], false);
                if (Double.isNaN(wage)) return;
                int slots = whole(p, rest[1], 1, 1000);
                if (slots == Integer.MIN_VALUE) return;
                int hours = whole(p, rest[2], 1, 24);
                if (hours == Integer.MIN_VALUE) return;
                String title = String.join(" ", Arrays.copyOfRange(rest, 3, rest.length)).trim();
                Business b = ownedBusiness(p, null);
                if (b != null) plugin.business().post(p, b, title, wage, hours, slots);
            }
            case "close" -> {
                if (rest.length < 1) {
                    msg(p, "job.usage");
                    return;
                }
                Business b = ownedBusiness(p, null);
                if (b != null) plugin.business().closeJob(p, b, rest[0]);
            }
            case "list" -> {
                Business b = ownedBusiness(p, null);
                if (b != null) businessInfo(p, b);
            }
            default -> msg(p, "job.usage");
        }
    }

    private void applicants(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Business b = ownedBusiness(p, String.join(" ", a));
        if (b == null) return;
        if (plugin.business().applicationsFor(b).isEmpty()) {
            msg(p, "applicants.empty");
            return;
        }
        new ApplicantsMenu(plugin, b).open(p);
    }

    private void fire(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        if (a.length < 1) {
            msg(p, "fire.usage");
            return;
        }
        Business b = ownedBusiness(p, null);
        if (b != null) plugin.business().fire(p, b, a[0]);
    }

    private void quit(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        plugin.business().quit(p, String.join(" ", a));
    }

    private void clockIn(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        plugin.business().clockIn(p, String.join(" ", a));
    }

    private void clockOut(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        plugin.business().clockOutCommand(p);
    }

    private void work(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        UUID id = p.getUniqueId();
        List<Employment> mine = plugin.business().employmentsOf(id);
        if (mine.isEmpty()) {
            msg(p, "job.not-employed");
            return;
        }
        Employment current = plugin.business().currentEmployment(id);
        if (current != null) {
            Business b = plugin.business().business(current.businessId);
            msg(p, "work.status-on", "business", b == null ? "-" : b.name,
                    "pending", plugin.business().describeTime(id),
                    "earned", money(plugin.business().shiftEarnings(id)));
        } else {
            msg(p, "work.status-off");
        }
        for (Employment e : mine) {
            Business b = plugin.business().business(e.businessId);
            msg(p, "work.entry", "business", b == null ? "-" : b.name, "wage", money(e.wage),
                    "hours", e.maxHours, "paid", money(e.totalPaid));
        }
    }

    // ------------------------------------------------------------------ admin

    private void admin(CommandSender s, String[] a) {
        if (!isAdmin(s)) return;
        if (a.length == 0) {
            plugin.messages().sendList(s, "help.admin");
            return;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "wand" -> {
                Player p = player(s);
                if (p == null) return;
                p.getInventory().addItem(plugin.createWand());
                msg(p, "admin.wand");
            }
            case "pos1", "pos2" -> {
                Player p = player(s);
                if (p == null) return;
                if (sub.equals("pos1")) plugin.selections().setFirst(p.getUniqueId(), p.getLocation().getBlock());
                else plugin.selections().setSecond(p.getUniqueId(), p.getLocation().getBlock());
                Location l = p.getLocation();
                msg(p, sub.equals("pos1") ? "admin.pos1" : "admin.pos2", "x", l.getBlockX(), "y", l.getBlockY(),
                        "z", l.getBlockZ());
            }
            case "create" -> adminCreate(s, a);
            case "grid" -> adminGrid(s, a);
            case "delete" -> adminDelete(s, a);
            case "setowner" -> adminSetOwner(s, a);
            case "setprice" -> adminSetPrice(s, a);
            case "settype" -> adminSetType(s, a);
            case "tp" -> adminTp(s, a);
            case "info" -> {
                Plot plot = adminPlot(s, a);
                if (plot != null) sendPlotInfo(s, plot);
            }
            case "evict" -> {
                Plot plot = adminPlot(s, a);
                if (plot == null) return;
                if (plot.rental == null || !plot.rental.isOccupied()) {
                    msg(s, "admin.no-tenant");
                    return;
                }
                plugin.rentals().endRental(plot, RentalService.EndReason.ADMIN);
                msg(s, "admin.evicted", "plot", plot.id);
            }
            case "snapshot" -> {
                Plot plot = adminPlot(s, a);
                if (plot == null) return;
                plot.busy = true;
                plugin.snapshots().capture(plot, ok -> {
                    plot.busy = false;
                    msg(s, ok ? "admin.snapshot-ok" : "admin.snapshot-fail", "plot", plot.id);
                });
                msg(s, "admin.snapshot-started", "plot", plot.id);
            }
            case "restore" -> {
                Plot plot = adminPlot(s, a);
                if (plot == null) return;
                if (!plugin.snapshots().exists(plot.id)) {
                    msg(s, "admin.no-snapshot");
                    return;
                }
                plot.busy = true;
                plugin.snapshots().restore(plot, ok -> {
                    plot.busy = false;
                    msg(s, ok ? "admin.restore-ok" : "admin.restore-fail", "plot", plot.id);
                });
                msg(s, "admin.restore-started", "plot", plot.id);
            }
            case "reload" -> {
                plugin.reloadAll();
                msg(s, "admin.reloaded");
            }
            case "stats" -> msg(s, "admin.stats", "plots", plugin.plots().count(),
                    "rented", plugin.plots().occupied().size(), "listed", plugin.plots().listedForRent().size(),
                    "businesses", plugin.business().businessCount(), "jobs", plugin.business().jobCount(),
                    "employees", plugin.business().employmentCount(), "onshift", plugin.business().onShiftCount());
            default -> plugin.messages().sendList(s, "help.admin");
        }
    }

    private Plot adminPlot(CommandSender s, String[] a) {
        if (a.length < 2) {
            msg(s, "admin.usage");
            return null;
        }
        Plot plot = plugin.plots().get(a[1]);
        if (plot == null) msg(s, "admin.unknown-plot", "plot", a[1]);
        return plot;
    }

    private Plot.Type parseType(CommandSender s, String text) {
        try {
            return Plot.Type.valueOf(text.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            msg(s, "admin.bad-type");
            return null;
        }
    }

    private double parsePrice(CommandSender s, String text) {
        try {
            double v = Double.parseDouble(text);
            if (!Double.isNaN(v) && !Double.isInfinite(v) && v <= 1_000_000_000d) return EconomyService.round(v);
        } catch (NumberFormatException ignored) {
            // falls through
        }
        msg(s, "common.bad-amount");
        return Double.NaN;
    }

    private int[] selection(Player p, boolean fullHeight) {
        SelectionService.Pos a = plugin.selections().first(p.getUniqueId());
        SelectionService.Pos b = plugin.selections().second(p.getUniqueId());
        if (a == null || b == null) {
            msg(p, "admin.no-selection");
            return null;
        }
        if (!a.world().equals(b.world())) {
            msg(p, "admin.different-worlds");
            return null;
        }
        World w = Bukkit.getWorld(a.world());
        if (w == null) {
            msg(p, "common.error-world");
            return null;
        }
        int minY = fullHeight ? w.getMinHeight() : Math.min(a.y(), b.y());
        int maxY = fullHeight ? w.getMaxHeight() - 1 : Math.max(a.y(), b.y());
        return new int[]{Math.min(a.x(), b.x()), minY, Math.min(a.z(), b.z()),
                Math.max(a.x(), b.x()), maxY, Math.max(a.z(), b.z())};
    }

    private void adminCreate(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        if (a.length < 4) {
            msg(p, "admin.usage-create");
            return;
        }
        String id = a[1];
        if (!id.matches("[A-Za-z0-9_-]{2,40}")) {
            msg(p, "admin.bad-id");
            return;
        }
        if (plugin.plots().get(id) != null) {
            msg(p, "admin.id-taken");
            return;
        }
        Plot.Type type = parseType(p, a[2]);
        if (type == null) return;
        double price = parsePrice(p, a[3]);
        if (Double.isNaN(price)) return;
        boolean full = a.length >= 5 && a[4].equalsIgnoreCase("fullheight");
        int[] box = selection(p, full);
        if (box == null) return;
        String world = plugin.selections().first(p.getUniqueId()).world();
        Plot clash = plugin.plots().findOverlap(world, box[0], box[1], box[2], box[3], box[4], box[5]);
        if (clash != null) {
            msg(p, "admin.overlap", "plot", clash.id);
            return;
        }
        Plot plot = new Plot(id, world, box[0], box[1], box[2], box[3], box[4], box[5]);
        plot.type = type;
        plot.price = price;
        plot.publicAccess = type == Plot.Type.SHOP;
        plugin.plots().add(plot);
        msg(p, "admin.created", "plot", id, "size", plot.sizeX() + "×" + plot.sizeY() + "×" + plot.sizeZ());
    }

    private void adminGrid(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        if (a.length < 7) {
            msg(p, "admin.usage-grid");
            return;
        }
        String prefix = a[1];
        if (!prefix.matches("[A-Za-z0-9_-]{1,30}")) {
            msg(p, "admin.bad-id");
            return;
        }
        Plot.Type type = parseType(p, a[2]);
        if (type == null) return;
        double price = parsePrice(p, a[3]);
        if (Double.isNaN(price)) return;
        int countX = whole(p, a[4], 1, 100);
        if (countX == Integer.MIN_VALUE) return;
        int countZ = whole(p, a[5], 1, 100);
        if (countZ == Integer.MIN_VALUE) return;
        int gap = whole(p, a[6], 0, 64);
        if (gap == Integer.MIN_VALUE) return;
        if ((long) countX * countZ > 500) {
            msg(p, "admin.grid-too-big");
            return;
        }
        int[] box = selection(p, false);
        if (box == null) return;
        String world = plugin.selections().first(p.getUniqueId()).world();
        int sizeX = box[3] - box[0] + 1;
        int sizeZ = box[5] - box[2] + 1;
        int created = 0;
        int skipped = 0;
        int index = 1;
        for (int i = 0; i < countX; i++) {
            for (int j = 0; j < countZ; j++) {
                int x1 = box[0] + i * (sizeX + gap);
                int z1 = box[2] + j * (sizeZ + gap);
                int x2 = x1 + sizeX - 1;
                int z2 = z1 + sizeZ - 1;
                String id = prefix + "-" + index++;
                if (plugin.plots().get(id) != null
                        || plugin.plots().findOverlap(world, x1, box[1], z1, x2, box[4], z2) != null) {
                    skipped++;
                    continue;
                }
                Plot plot = new Plot(id, world, x1, box[1], z1, x2, box[4], z2);
                plot.type = type;
                plot.price = price;
                plot.publicAccess = type == Plot.Type.SHOP;
                plugin.plots().add(plot);
                created++;
            }
        }
        msg(p, "admin.grid-done", "created", created, "skipped", skipped);
    }

    private void adminDelete(CommandSender s, String[] a) {
        Plot plot = adminPlot(s, a);
        if (plot == null) return;
        plugin.rentals().clear(plot);
        plugin.business().closeForPlot(plot, "business.closed-admin");
        plugin.snapshots().delete(plot.id);
        plugin.plots().remove(plot);
        msg(s, "admin.deleted", "plot", plot.id);
    }

    private void adminSetOwner(CommandSender s, String[] a) {
        if (a.length < 3) {
            msg(s, "admin.usage");
            return;
        }
        Plot plot = plugin.plots().get(a[1]);
        if (plot == null) {
            msg(s, "admin.unknown-plot", "plot", a[1]);
            return;
        }
        UUID newOwner = null;
        if (!a[2].equalsIgnoreCase("none")) {
            OfflinePlayer target = Bukkit.getPlayerExact(a[2]);
            if (target == null) target = Bukkit.getOfflinePlayerIfCached(a[2]);
            if (target == null) {
                msg(s, "common.player-unknown");
                return;
            }
            newOwner = target.getUniqueId();
        }
        plugin.rentals().clear(plot);
        plugin.business().closeForPlot(plot, "business.closed-admin");
        plot.owner = newOwner;
        plot.trusted.clear();
        plugin.plots().save(plot);
        msg(s, "admin.owner-set", "plot", plot.id, "owner", newOwner == null ? "الدولة" : Text.name(newOwner));
    }

    private void adminSetPrice(CommandSender s, String[] a) {
        if (a.length < 3) {
            msg(s, "admin.usage");
            return;
        }
        Plot plot = plugin.plots().get(a[1]);
        if (plot == null) {
            msg(s, "admin.unknown-plot", "plot", a[1]);
            return;
        }
        double price = parsePrice(s, a[2]);
        if (Double.isNaN(price)) return;
        plot.price = price;
        plugin.plots().save(plot);
        msg(s, "admin.price-set", "plot", plot.id, "price", price < 0 ? "غير معروض" : money(price));
    }

    private void adminSetType(CommandSender s, String[] a) {
        if (a.length < 3) {
            msg(s, "admin.usage");
            return;
        }
        Plot plot = plugin.plots().get(a[1]);
        if (plot == null) {
            msg(s, "admin.unknown-plot", "plot", a[1]);
            return;
        }
        Plot.Type type = parseType(s, a[2]);
        if (type == null) return;
        plot.type = type;
        plugin.plots().save(plot);
        msg(s, "admin.type-set", "plot", plot.id, "type", Names.plotType(type));
    }

    private void adminTp(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Plot plot = adminPlot(p, a);
        if (plot == null) return;
        Location loc = Locations.plotSpawn(plot);
        if (loc == null) {
            msg(p, "common.error-world");
            return;
        }
        p.teleport(loc);
    }

    // ------------------------------------------------------------------ tab completion

    private static List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) if (o.toLowerCase(Locale.ROOT).startsWith(p)) out.add(o);
        return out;
    }

    private static List<String> onlineNames(String prefix) {
        List<String> names = new ArrayList<>();
        for (Player pl : Bukkit.getOnlinePlayers()) names.add(pl.getName());
        return filter(names, prefix);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> subs = new ArrayList<>(PLAYER_SUBS);
            if (sender.hasPermission("frontierestate.admin")) subs.add("admin");
            return filter(subs, args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2) {
            switch (sub) {
                case "rent":
                    return filter(List.of("list", "unlist", "leave", "pay", "info"), args[1]);
                case "business":
                case "shop":
                    return filter(List.of("create", "info", "deposit", "withdraw", "close"), args[1]);
                case "job":
                    return filter(List.of("post", "close", "list"), args[1]);
                case "trust":
                case "untrust":
                case "sell":
                case "fire":
                    return onlineNames(args[1]);
                case "public":
                    return filter(List.of("on", "off"), args[1]);
                case "admin":
                    return sender.hasPermission("frontierestate.admin") ? filter(ADMIN_SUBS, args[1]) : List.of();
                default:
                    return List.of();
            }
        }
        if (sub.equals("admin") && sender.hasPermission("frontierestate.admin")) {
            String adminSub = args[1].toLowerCase(Locale.ROOT);
            if (args.length == 3 && List.of("delete", "setowner", "setprice", "settype", "tp", "info", "evict",
                    "snapshot", "restore").contains(adminSub)) {
                List<String> ids = new ArrayList<>();
                for (Plot plot : plugin.plots().all()) ids.add(plot.id);
                return filter(ids, args[2]);
            }
            if ((adminSub.equals("create") && args.length == 4) || (adminSub.equals("grid") && args.length == 4)
                    || (adminSub.equals("settype") && args.length == 4)) {
                List<String> types = new ArrayList<>();
                for (Plot.Type t : Plot.Type.values()) types.add(t.name().toLowerCase(Locale.ROOT));
                return filter(types, args[3]);
            }
            if (adminSub.equals("setowner") && args.length == 4) return onlineNames(args[3]);
        }
        if (sub.equals("rent") && args.length >= 6) {
            return filter(List.of("build", "nobuild"), args[args.length - 1]);
        }
        return List.of();
    }
}
