package dev.frontier.estate.config;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Loads messages.yml (MiniMessage) and fills placeholders safely (player text is never parsed as markup). */
public final class Messages {

    private final FrontierEstatePlugin plugin;
    private YamlConfiguration yaml;

    public Messages(FrontierEstatePlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) plugin.saveResource("messages.yml", false);
        yaml = YamlConfiguration.loadConfiguration(file);
        try (InputStream in = plugin.getResource("messages.yml")) {
            if (in != null) {
                YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                        new InputStreamReader(in, StandardCharsets.UTF_8));
                yaml.setDefaults(defaults);
            }
        } catch (IOException ignored) {
            // defaults are optional
        }
    }

    public String raw(String key) {
        String s = yaml.getString(key);
        return s != null ? s : "<red>[رسالة مفقودة: " + key + "]";
    }

    private TagResolver resolver(Object... pairs) {
        TagResolver.Builder b = TagResolver.builder();
        b.resolver(Placeholder.parsed("prefix", raw("prefix")));
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            b.resolver(Placeholder.unparsed(String.valueOf(pairs[i]), String.valueOf(pairs[i + 1])));
        }
        return b.build();
    }

    public Component component(String key, Object... pairs) {
        return Text.MM.deserialize(raw(key), resolver(pairs));
    }

    public void send(CommandSender to, String key, Object... pairs) {
        to.sendMessage(component(key, pairs));
    }

    public void sendList(CommandSender to, String key, Object... pairs) {
        List<String> lines = yaml.getStringList(key);
        for (String line : lines) {
            to.sendMessage(Text.MM.deserialize(line, resolver(pairs)));
        }
    }
}
