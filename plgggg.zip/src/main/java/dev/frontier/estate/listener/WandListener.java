package dev.frontier.estate.listener;

import dev.frontier.estate.FrontierEstatePlugin;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/** The admin selection wand: left click = corner 1, right click = corner 2. */
public final class WandListener implements Listener {

    private final FrontierEstatePlugin plugin;

    public WandListener(FrontierEstatePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.LEFT_CLICK_BLOCK && a != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (item == null || item.getType() != Material.BLAZE_ROD) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.getPersistentDataContainer().has(plugin.wandKey(), PersistentDataType.BYTE)) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("frontierestate.admin")) return;
        Block b = e.getClickedBlock();
        if (b == null) return;
        e.setCancelled(true);
        if (a == Action.LEFT_CLICK_BLOCK) {
            plugin.selections().setFirst(p.getUniqueId(), b);
            plugin.messages().send(p, "admin.pos1", "x", b.getX(), "y", b.getY(), "z", b.getZ());
        } else {
            plugin.selections().setSecond(p.getUniqueId(), b);
            plugin.messages().send(p, "admin.pos2", "x", b.getX(), "y", b.getY(), "z", b.getZ());
        }
    }
}
