package dev.frontier.estate.listener;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.model.Plot;
import dev.frontier.estate.service.PlotService;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.AbstractVillager;
import org.bukkit.entity.Animals;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Hanging;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.world.StructureGrowEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Location;
import dev.frontier.estate.util.Text;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Keeps the world from being griefed. Everything is decided by one O(1) plot lookup per event, and nothing
 * here listens to player movement, so it stays cheap with hundreds of players online.
 */
public final class ProtectionListener implements Listener {

    private static final String BYPASS = "frontierestate.admin.bypass";

    /** Blocks that need "use" rights (containers and things that change when right-clicked). */
    private static final Set<Material> RESTRICTED = EnumSet.of(
            Material.CHEST, Material.TRAPPED_CHEST, Material.BARREL, Material.FURNACE, Material.BLAST_FURNACE,
            Material.SMOKER, Material.HOPPER, Material.DROPPER, Material.DISPENSER, Material.BREWING_STAND,
            Material.CHISELED_BOOKSHELF, Material.DECORATED_POT, Material.CRAFTER, Material.JUKEBOX,
            Material.LECTERN, Material.COMPOSTER, Material.BEEHIVE, Material.BEE_NEST,
            Material.SWEET_BERRY_BUSH, Material.CAVE_VINES, Material.CAVE_VINES_PLANT, Material.CAKE,
            Material.FLOWER_POT, Material.CAULDRON, Material.WATER_CAULDRON, Material.LAVA_CAULDRON,
            Material.POWDER_SNOW_CAULDRON, Material.NOTE_BLOCK, Material.REPEATER, Material.COMPARATOR,
            Material.DAYLIGHT_DETECTOR, Material.RESPAWN_ANCHOR);

    private final FrontierEstatePlugin plugin;
    private final Map<UUID, Long> lastDeny = new HashMap<>();

    private final Set<String> worlds = new HashSet<>();
    private final Set<String> pvpWorlds = new HashSet<>();
    private boolean allowBuildOutside;
    private boolean allowContainersOutside;
    private boolean blockExplosions;
    private boolean blockFire;
    private boolean blockMobGriefing;
    private boolean blockCrossFlow;
    private boolean blockCrossHoppers;
    private boolean blockCrossPistons;
    private boolean blockStructureGrowth;
    private boolean controllersUseSigns;

    public ProtectionListener(FrontierEstatePlugin plugin) {
        this.plugin = plugin;
        reloadSettings();
    }

    public void reloadSettings() {
        var cfg = plugin.getConfig();
        worlds.clear();
        worlds.addAll(cfg.getStringList("protection.worlds"));
        pvpWorlds.clear();
        pvpWorlds.addAll(cfg.getStringList("protection.pvp-worlds"));
        allowBuildOutside = cfg.getBoolean("protection.allow-build-outside-plots", false);
        allowContainersOutside = cfg.getBoolean("protection.allow-containers-outside-plots", false);
        blockExplosions = cfg.getBoolean("protection.block-explosions", true);
        blockFire = cfg.getBoolean("protection.block-fire", true);
        blockMobGriefing = cfg.getBoolean("protection.block-mob-griefing", true);
        blockCrossFlow = cfg.getBoolean("protection.block-cross-plot-flow", true);
        blockCrossHoppers = cfg.getBoolean("protection.block-cross-plot-hoppers", true);
        blockCrossPistons = cfg.getBoolean("protection.block-cross-plot-pistons", true);
        blockStructureGrowth = cfg.getBoolean("protection.block-structure-growth", true);
        controllersUseSigns = cfg.getBoolean("protection.controllers-can-use-signs", true);
    }

    public void forget(UUID id) {
        lastDeny.remove(id);
    }

    // ------------------------------------------------------------------ helpers

    private PlotService plots() {
        return plugin.plots();
    }

    private boolean prot(World w) {
        return w != null && worlds.contains(w.getName());
    }

    private static boolean bypass(Player p) {
        return p.hasPermission(BYPASS);
    }

    private void deny(Player p, Plot plot) {
        long now = System.currentTimeMillis();
        Long last = lastDeny.get(p.getUniqueId());
        if (last != null && now - last < 1500L) return;
        lastDeny.put(p.getUniqueId(), now);
        if (plot == null) {
            plugin.messages().send(p, "protect.no-plot");
        } else if (plot.busy) {
            plugin.messages().send(p, "protect.busy");
        } else {
            plugin.messages().send(p, "protect.denied", "plot", plot.label(),
                    "owner", Text.name(plot.controller()));
        }
    }

    private static boolean isSign(Material m) {
        return m.name().endsWith("_SIGN");
    }

    /** May this player place/break the given block? Sends the "denied" message if not. */
    private boolean allowedBuild(Player p, Block block, Material material) {
        if (!prot(block.getWorld()) || bypass(p)) return true;
        Plot plot = plots().getAt(block);
        if (plot == null) {
            if (allowBuildOutside) return true;
            deny(p, null);
            return false;
        }
        UUID id = p.getUniqueId();
        if (plots().canBuild(id, plot)) return true;
        if (controllersUseSigns && material != null && isSign(material) && plots().canManage(id, plot)) return true;
        deny(p, plot);
        return false;
    }

    private static boolean isRestricted(Material m) {
        return RESTRICTED.contains(m) || Tag.SHULKER_BOXES.isTagged(m) || m.name().startsWith("POTTED_");
    }

    private static boolean isDoorLike(Material m) {
        return Tag.DOORS.isTagged(m) || Tag.TRAPDOORS.isTagged(m) || Tag.FENCE_GATES.isTagged(m)
                || Tag.BUTTONS.isTagged(m) || m == Material.LEVER;
    }

    private static boolean isWorldAltering(Material m) {
        String n = m.name();
        return n.endsWith("_AXE") || n.endsWith("_HOE") || n.endsWith("_SHOVEL") || n.endsWith("_SPAWN_EGG")
                || n.endsWith("_BOAT") || n.endsWith("_RAFT") || n.endsWith("_MINECART") || n.endsWith("_DYE")
                || m == Material.MINECART || m == Material.FLINT_AND_STEEL || m == Material.FIRE_CHARGE
                || m == Material.BONE_MEAL || m == Material.ARMOR_STAND || m == Material.END_CRYSTAL
                || m == Material.ITEM_FRAME || m == Material.GLOW_ITEM_FRAME || m == Material.PAINTING
                || m == Material.HONEYCOMB || m == Material.INK_SAC || m == Material.GLOW_INK_SAC
                || m == Material.SHEARS;
    }

    private static Player playerOf(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        return null;
    }

    // ------------------------------------------------------------------ blocks

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (!allowedBuild(e.getPlayer(), e.getBlock(), e.getBlock().getType())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (!allowedBuild(e.getPlayer(), e.getBlockPlaced(), e.getBlockPlaced().getType())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSign(SignChangeEvent e) {
        if (!allowedBuild(e.getPlayer(), e.getBlock(), e.getBlock().getType())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        Block target = e.getBlockClicked().getRelative(e.getBlockFace());
        if (!allowedBuild(e.getPlayer(), target, null)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (!allowedBuild(e.getPlayer(), e.getBlockClicked(), null)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        Action action = e.getAction();
        if (action != Action.RIGHT_CLICK_BLOCK && action != Action.PHYSICAL) return;
        Block block = e.getClickedBlock();
        if (block == null) return;
        Player p = e.getPlayer();
        if (!prot(block.getWorld()) || bypass(p)) return;
        Material m = block.getType();
        Plot plot = plots().getAt(block);
        UUID id = p.getUniqueId();

        if (action == Action.PHYSICAL) {
            if (m == Material.FARMLAND && (plot == null || !plots().canUse(id, plot))) {
                e.setUseInteractedBlock(Event.Result.DENY);
                e.setCancelled(true);
            }
            return;
        }

        if (isRestricted(m)) {
            boolean ok = plot == null ? allowContainersOutside : plots().canUse(id, plot);
            if (!ok) {
                deny(p, plot);
                e.setCancelled(true);
            }
            return;
        }
        if (isDoorLike(m)) {
            if (plot != null && !plots().canUsePublic(id, plot)) {
                deny(p, plot);
                e.setCancelled(true);
            }
            return;
        }
        ItemStack hand = e.getItem();
        if (hand != null && isWorldAltering(hand.getType())) {
            Block target = block.getRelative(e.getBlockFace());
            if (!allowedBuild(p, block, null) || !allowedBuild(p, target, null)) {
                e.setCancelled(true);
            }
        }
    }

    // ------------------------------------------------------------------ entities

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        Entity ent = e.getRightClicked();
        Player p = e.getPlayer();
        if (!prot(ent.getWorld()) || bypass(p)) return;
        boolean decor = ent instanceof Hanging || ent instanceof ArmorStand;
        boolean animal = ent instanceof Animals;
        if (!decor && !animal) return;
        Plot plot = plots().getAt(ent.getLocation());
        if (plot == null) {
            if (decor && !allowBuildOutside) {
                deny(p, null);
                e.setCancelled(true);
            }
            return;
        }
        if (!plots().canUse(p.getUniqueId(), plot)) {
            deny(p, plot);
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onArmorStand(PlayerArmorStandManipulateEvent e) {
        Player p = e.getPlayer();
        Entity ent = e.getRightClicked();
        if (!prot(ent.getWorld()) || bypass(p)) return;
        Plot plot = plots().getAt(ent.getLocation());
        if (plot == null ? !allowBuildOutside : !plots().canUse(p.getUniqueId(), plot)) {
            deny(p, plot);
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        Entity victim = e.getEntity();
        if (!prot(victim.getWorld())) return;
        Player attacker = playerOf(e.getDamager());

        if (victim instanceof Player) {
            if (attacker != null && !pvpWorlds.contains(victim.getWorld().getName()) && !bypass(attacker)) {
                e.setCancelled(true);
            }
            return;
        }
        boolean decor = victim instanceof Hanging || victim instanceof ArmorStand;
        boolean npc = victim instanceof AbstractVillager;
        boolean animal = victim instanceof Animals;
        if (!decor && !npc && !animal) return;
        if (attacker == null) {
            if (decor) e.setCancelled(true);
            return;
        }
        if (bypass(attacker)) return;
        Plot plot = plots().getAt(victim.getLocation());
        if (plot == null) {
            // hunting wild animals is fine; decorations and villagers outside plots are not
            if (!animal && !allowBuildOutside) {
                deny(attacker, null);
                e.setCancelled(true);
            }
            return;
        }
        if (!plots().canBuild(attacker.getUniqueId(), plot)) {
            deny(attacker, plot);
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingPlace(HangingPlaceEvent e) {
        Player p = e.getPlayer();
        if (p == null) return;
        Block b = e.getEntity().getLocation().getBlock();
        if (!allowedBuild(p, b, null)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingBreakByEntity(HangingBreakByEntityEvent e) {
        Entity ent = e.getEntity();
        if (!prot(ent.getWorld())) return;
        Player remover = playerOf(e.getRemover());
        if (remover == null) {
            e.setCancelled(true);
            return;
        }
        if (bypass(remover)) return;
        Plot plot = plots().getAt(ent.getLocation());
        if (plot == null ? !allowBuildOutside : !plots().canBuild(remover.getUniqueId(), plot)) {
            deny(remover, plot);
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakEvent e) {
        if (e instanceof HangingBreakByEntityEvent) return;
        if (!prot(e.getEntity().getWorld())) return;
        if (e.getCause() == HangingBreakEvent.RemoveCause.EXPLOSION) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ explosions, fire, mobs

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        if (blockExplosions && prot(e.getLocation().getWorld())) e.blockList().clear();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        if (blockExplosions && prot(e.getBlock().getWorld())) e.blockList().clear();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        if (blockFire && prot(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        if (!blockFire || !prot(e.getBlock().getWorld())) return;
        // players using flint and steel are checked in onInteract
        if (e.getCause() == BlockIgniteEvent.IgniteCause.FLINT_AND_STEEL) return;
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMobChangeBlock(EntityChangeBlockEvent e) {
        if (!blockMobGriefing) return;
        Entity ent = e.getEntity();
        if (ent instanceof Player) return;
        EntityType t = ent.getType();
        if (t == EntityType.FALLING_BLOCK || t == EntityType.VILLAGER || t == EntityType.SHEEP) return;
        if (!prot(ent.getWorld())) return;
        e.setCancelled(true);
    }

    // ------------------------------------------------------------------ cross-plot leaks

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFlow(BlockFromToEvent e) {
        if (!blockCrossFlow) return;
        Block from = e.getBlock();
        if (!prot(from.getWorld())) return;
        if (plots().getAt(from) != plots().getAt(e.getToBlock())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHopper(InventoryMoveItemEvent e) {
        if (!blockCrossHoppers) return;
        Location a = e.getSource().getLocation();
        Location b = e.getDestination().getLocation();
        if (a == null || b == null || !prot(a.getWorld())) return;
        if (plots().getAt(a) != plots().getAt(b)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        if (pistonLeaks(e.getBlock(), e.getBlocks(), e.getDirection(), true)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        if (pistonLeaks(e.getBlock(), e.getBlocks(), e.getDirection(), false)) e.setCancelled(true);
    }

    private boolean pistonLeaks(Block piston, List<Block> moved, BlockFace dir, boolean extending) {
        if (!blockCrossPistons || !prot(piston.getWorld())) return false;
        Plot home = plots().getAt(piston);
        if (extending && plots().getAt(piston.getRelative(dir)) != home) return true;
        for (Block b : moved) {
            if (plots().getAt(b) != home) return true;
            if (plots().getAt(b.getRelative(dir)) != home) return true;
            if (plots().getAt(b.getRelative(dir.getOppositeFace())) != home) return true;
        }
        return false;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onGrow(StructureGrowEvent e) {
        if (!blockStructureGrowth || !prot(e.getLocation().getWorld())) return;
        Plot origin = plots().getAt(e.getLocation());
        e.getBlocks().removeIf(state -> plots().getAt(state.getLocation()) != origin);
    }
}
