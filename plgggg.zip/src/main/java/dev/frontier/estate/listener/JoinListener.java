package dev.frontier.estate.listener;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.model.Plot;
import dev.frontier.estate.model.Rental;
import dev.frontier.estate.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

public final class JoinListener implements Listener {

    private final FrontierEstatePlugin plugin;

    public JoinListener(FrontierEstatePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            plugin.notices().deliver(p);
            if (plugin.stash().has(id)) plugin.messages().send(p, "stash.reminder");
            for (Plot plot : plugin.plots().rentedBy(id)) {
                Rental r = plot.rental;
                if (r != null && r.status == Rental.Status.GRACE) {
                    plugin.messages().send(p, "rent.grace-warning", "plot", plot.label(),
                            "price", plugin.economy().format(r.price),
                            "left", TimeUtil.formatMillis(r.graceUntilMs - System.currentTimeMillis()));
                }
            }
        }, 60L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        plugin.business().onQuit(p);
        plugin.protection().forget(p.getUniqueId());
        plugin.selections().clear(p.getUniqueId());
    }
}
