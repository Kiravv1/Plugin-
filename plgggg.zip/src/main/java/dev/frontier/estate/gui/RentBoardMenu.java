package dev.frontier.estate.gui;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.model.Plot;
import dev.frontier.estate.model.Rental;
import dev.frontier.estate.util.Locations;
import dev.frontier.estate.util.Names;
import dev.frontier.estate.util.Text;
import dev.frontier.estate.util.TimeUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/** The public real-estate board: every plot currently listed for rent. */
public final class RentBoardMenu extends PagedMenu<Plot> {

    public RentBoardMenu(FrontierEstatePlugin plugin, List<Plot> plots) {
        super(plugin, plugin.messages().component("gui.board-title"), plots);
        draw();
    }

    @Override
    protected ItemStack render(Plot plot) {
        Rental r = plot.rental;
        Material icon = switch (plot.type) {
            case HOUSE -> Material.OAK_DOOR;
            case SHOP -> Material.BARREL;
            case FARM -> Material.WHEAT;
            case LAND -> Material.GRASS_BLOCK;
        };
        String contract = r.periodsTotal == 0 ? "مفتوح" : r.periodsTotal + " دورة";
        return Text.item(icon, "<gold><bold>" + Text.esc(plot.label()),
                "<gray>النوع: <white>" + Names.plotType(plot.type),
                "<gray>المساحة: <white>" + plot.sizeX() + "×" + plot.sizeZ(),
                "<gray>الإيجار: <green>" + plugin.economy().format(r.price)
                        + " <gray>كل <white>" + TimeUtil.format(r.periodSec),
                "<gray>الوديعة: <white>" + plugin.economy().format(r.deposit),
                "<gray>مدة العقد: <white>" + contract,
                "<gray>التعديل بالبناء: " + (r.allowBuild ? "<green>مسموح" : "<red>ممنوع"),
                "<gray>المالك: <white>" + Text.esc(Text.name(plot.owner)),
                "",
                "<yellow>كليك يسار: استئجار",
                "<aqua>كليك يمين: معاينة");
    }

    @Override
    protected void clicked(InventoryClickEvent e, Plot plot) {
        Player p = (Player) e.getWhoClicked();
        Rental r = plot.rental;
        if (r == null || r.status != Rental.Status.LISTED) {
            plugin.messages().send(p, "rent.not-available");
            return;
        }
        if (e.isRightClick()) {
            if (!plugin.getConfig().getBoolean("rental.allow-preview-teleport", true)) return;
            Location loc = Locations.plotSpawn(plot);
            if (loc != null) {
                p.closeInventory();
                p.teleport(loc);
                plugin.messages().send(p, "rent.preview", "plot", Text.esc(plot.label()));
            }
            return;
        }
        double total = r.price + r.deposit;
        new ConfirmMenu(plugin, plugin.messages().component("gui.confirm-rent"), List.of(
                "<gray>العقار: <white>" + Text.esc(plot.label()),
                "<gray>الدفعة الأولى: <green>" + plugin.economy().format(r.price),
                "<gray>الوديعة: <white>" + plugin.economy().format(r.deposit),
                "<gray>المجموع الآن: <gold>" + plugin.economy().format(total)),
                () -> plugin.rentals().rent(p, plot)).open(p);
    }
}
