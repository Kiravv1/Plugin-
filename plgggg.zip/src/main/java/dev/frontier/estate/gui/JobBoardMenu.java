package dev.frontier.estate.gui;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.model.Business;
import dev.frontier.estate.model.Job;
import dev.frontier.estate.util.Text;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/** The public job board: every open vacancy in every shop. */
public final class JobBoardMenu extends PagedMenu<Job> {

    public JobBoardMenu(FrontierEstatePlugin plugin, List<Job> jobs) {
        super(plugin, plugin.messages().component("gui.jobs-title"), jobs);
        draw();
    }

    @Override
    protected ItemStack render(Job job) {
        Business b = plugin.business().business(job.businessId);
        String bname = b == null ? "-" : Text.esc(b.name);
        return Text.item(Material.NAME_TAG, "<gold><bold>" + Text.esc(job.title),
                "<gray>المحل: <white>" + bname,
                "<gray>الأجر: <green>" + plugin.economy().format(job.wage) + " <gray>/ ساعة",
                "<gray>الحد اليومي: <white>" + job.maxHours + " ساعة",
                "<gray>الأماكن الشاغرة: <white>" + plugin.business().freeSlots(job),
                "",
                "<yellow>اضغط للتقديم");
    }

    @Override
    protected void clicked(InventoryClickEvent e, Job job) {
        Player p = (Player) e.getWhoClicked();
        Business b = plugin.business().business(job.businessId);
        new ConfirmMenu(plugin, plugin.messages().component("gui.confirm-apply"), List.of(
                "<gray>الوظيفة: <white>" + Text.esc(job.title),
                "<gray>المحل: <white>" + (b == null ? "-" : Text.esc(b.name)),
                "<gray>الأجر: <green>" + plugin.economy().format(job.wage) + " <gray>/ ساعة"),
                () -> plugin.business().apply(p, job)).open(p);
    }
}
