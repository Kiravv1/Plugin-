package dev.frontier.estate.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Tracks which menu each player has open. Using a map (instead of asking every inventory for its holder)
 * keeps this cheap even when hundreds of players click chests all day.
 */
public final class MenuListener implements Listener {

    private final Map<UUID, Menu> open = new HashMap<>();

    public void register(Player player, Menu menu) {
        open.put(player.getUniqueId(), menu);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Menu m = open.get(p.getUniqueId());
        if (m == null || e.getView().getTopInventory() != m.getInventory()) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != m.getInventory()) return;
        m.handle(e);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Menu m = open.get(p.getUniqueId());
        if (m == null || e.getView().getTopInventory() != m.getInventory()) return;
        e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        Menu m = open.get(p.getUniqueId());
        if (m != null && m.getInventory() == e.getInventory()) open.remove(p.getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        open.remove(e.getPlayer().getUniqueId());
    }
}
