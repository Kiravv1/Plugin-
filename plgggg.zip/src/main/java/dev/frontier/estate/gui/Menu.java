package dev.frontier.estate.gui;

import dev.frontier.estate.FrontierEstatePlugin;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/** Base class for every chest menu. Clicks are always cancelled; each slot can have a handler. */
public abstract class Menu implements InventoryHolder {

    protected final FrontierEstatePlugin plugin;
    protected final Inventory inventory;
    private final Map<Integer, Consumer<InventoryClickEvent>> handlers = new HashMap<>();

    protected Menu(FrontierEstatePlugin plugin, int rows, Component title) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, rows * 9, title);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    protected void set(int slot, ItemStack item) {
        inventory.setItem(slot, item);
        handlers.remove(slot);
    }

    protected void set(int slot, ItemStack item, Consumer<InventoryClickEvent> handler) {
        inventory.setItem(slot, item);
        handlers.put(slot, handler);
    }

    protected void reset() {
        inventory.clear();
        handlers.clear();
    }

    public void handle(InventoryClickEvent event) {
        Consumer<InventoryClickEvent> handler = handlers.get(event.getSlot());
        if (handler != null) handler.accept(event);
    }

    public void open(Player player) {
        plugin.menus().register(player, this);
        player.openInventory(inventory);
    }
}
