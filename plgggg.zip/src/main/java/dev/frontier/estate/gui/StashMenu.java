package dev.frontier.estate.gui;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.util.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Items recovered from a rental. Click an item to move it to your inventory. */
public final class StashMenu extends PagedMenu<StashMenu.StashItem> {

    public record StashItem(String id, ItemStack item) { }

    public StashMenu(FrontierEstatePlugin plugin, List<StashItem> items) {
        super(plugin, plugin.messages().component("gui.stash-title"), items);
        draw();
    }

    @Override
    protected ItemStack render(StashItem entry) {
        ItemStack copy = entry.item().clone();
        ItemMeta meta = copy.getItemMeta();
        if (meta != null) {
            List<Component> existing = meta.lore();
            List<Component> lore = existing == null ? new ArrayList<>() : new ArrayList<>(existing);
            lore.add(Text.mm("<green>اضغط للاستلام"));
            meta.lore(lore);
            copy.setItemMeta(meta);
        }
        return copy;
    }

    @Override
    protected void clicked(InventoryClickEvent e, StashItem entry) {
        Player p = (Player) e.getWhoClicked();
        if (!fits(p.getInventory(), entry.item())) {
            plugin.messages().send(p, "stash.no-space");
            return;
        }
        p.getInventory().addItem(entry.item().clone());
        entries.remove(entry);
        plugin.stash().remove(p.getUniqueId(), entry.id(), entries.size());
        draw();
    }

    private static boolean fits(Inventory inv, ItemStack stack) {
        int need = stack.getAmount();
        for (ItemStack slot : inv.getStorageContents()) {
            if (slot == null || slot.getType().isAir()) {
                need -= stack.getMaxStackSize();
            } else if (slot.isSimilar(stack)) {
                need -= Math.max(0, slot.getMaxStackSize() - slot.getAmount());
            }
            if (need <= 0) return true;
        }
        return false;
    }
}
