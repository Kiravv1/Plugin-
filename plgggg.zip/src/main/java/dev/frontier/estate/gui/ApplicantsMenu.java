package dev.frontier.estate.gui;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.model.Application;
import dev.frontier.estate.model.Business;
import dev.frontier.estate.model.Job;
import dev.frontier.estate.util.Text;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

/** Owner's view of people who applied: left click hires, right click declines. */
public final class ApplicantsMenu extends PagedMenu<Application> {

    private final Business business;

    public ApplicantsMenu(FrontierEstatePlugin plugin, Business business) {
        super(plugin, plugin.messages().component("gui.applicants-title"), plugin.business().applicationsFor(business));
        this.business = business;
        draw();
    }

    @Override
    protected ItemStack render(Application a) {
        Job job = plugin.business().job(a.jobId);
        return Text.item(Material.PAPER, "<gold><bold>" + Text.esc(a.applicantName),
                "<gray>الوظيفة: <white>" + (job == null ? "-" : Text.esc(job.title)),
                "",
                "<green>كليك يسار: توظيف",
                "<red>كليك يمين: رفض");
    }

    @Override
    protected void clicked(InventoryClickEvent e, Application a) {
        Player p = (Player) e.getWhoClicked();
        boolean done = e.isLeftClick()
                ? plugin.business().hire(p, a)
                : plugin.business().decline(p, a);
        if (done) {
            entries.remove(a);
            draw();
        }
    }
}
