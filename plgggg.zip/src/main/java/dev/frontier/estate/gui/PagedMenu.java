package dev.frontier.estate.gui;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.util.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** A 6-row menu showing 45 entries per page with previous / next buttons. */
public abstract class PagedMenu<T> extends Menu {

    private static final int PER_PAGE = 45;

    protected final List<T> entries;
    protected int page = 0;

    protected PagedMenu(FrontierEstatePlugin plugin, Component title, List<T> entries) {
        super(plugin, 6, title);
        this.entries = new ArrayList<>(entries);
    }

    protected abstract ItemStack render(T entry);

    protected abstract void clicked(InventoryClickEvent event, T entry);

    protected void draw() {
        reset();
        int pages = Math.max(1, (entries.size() + PER_PAGE - 1) / PER_PAGE);
        if (page >= pages) page = pages - 1;
        if (page < 0) page = 0;
        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = start + i;
            if (idx >= entries.size()) break;
            T entry = entries.get(idx);
            set(i, render(entry), e -> clicked(e, entry));
        }
        if (page > 0) {
            set(45, Text.item(Material.ARROW, "<yellow>السابق"), e -> {
                page--;
                draw();
            });
        }
        set(49, Text.item(Material.PAPER, "<gray>صفحة " + (page + 1) + " / " + pages,
                "<dark_gray>العدد: " + entries.size()));
        if (page < pages - 1) {
            set(53, Text.item(Material.ARROW, "<yellow>التالي"), e -> {
                page++;
                draw();
            });
        }
    }
}
