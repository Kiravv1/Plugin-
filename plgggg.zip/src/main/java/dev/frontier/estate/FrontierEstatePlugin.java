package dev.frontier.estate;

import dev.frontier.estate.command.EstateCommand;
import dev.frontier.estate.config.Messages;
import dev.frontier.estate.db.Database;
import dev.frontier.estate.db.Schema;
import dev.frontier.estate.gui.MenuListener;
import dev.frontier.estate.listener.JoinListener;
import dev.frontier.estate.listener.ProtectionListener;
import dev.frontier.estate.listener.WandListener;
import dev.frontier.estate.service.BusinessService;
import dev.frontier.estate.service.EconomyService;
import dev.frontier.estate.service.Ledger;
import dev.frontier.estate.service.NoticeService;
import dev.frontier.estate.service.PlotService;
import dev.frontier.estate.service.RentalService;
import dev.frontier.estate.service.SelectionService;
import dev.frontier.estate.service.SnapshotService;
import dev.frontier.estate.service.StashService;
import dev.frontier.estate.util.Text;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

public final class FrontierEstatePlugin extends JavaPlugin {

    private Messages messages;
    private Database database;
    private EconomyService economy;
    private Ledger ledger;
    private PlotService plots;
    private SnapshotService snapshots;
    private StashService stash;
    private NoticeService notices;
    private RentalService rentals;
    private BusinessService business;
    private SelectionService selections;
    private MenuListener menus;
    private ProtectionListener protection;
    private NamespacedKey wandKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        wandKey = new NamespacedKey(this, "wand");
        messages = new Messages(this);

        database = new Database(getLogger(), getConfig().getConfigurationSection("database"), getDataFolder());
        try {
            database.init(Schema.tables());
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Could not open the database. Check the 'database' section of config.yml.", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        ledger = new Ledger(database);
        ledger.purgeOlderThanDays(getConfig().getInt("ledger.retention-days", 60));
        plots = new PlotService(this, database);
        snapshots = new SnapshotService(this);
        stash = new StashService(this, database);
        notices = new NoticeService(this, database);
        rentals = new RentalService(this);
        business = new BusinessService(this, database);
        selections = new SelectionService();
        menus = new MenuListener();

        try {
            plots.load();
            stash.load();
            notices.load();
            business.load();
        } catch (RuntimeException e) {
            getLogger().log(Level.SEVERE, "Could not load saved data.", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        plots.setDutyChecker(business);

        protection = new ProtectionListener(this);
        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(protection, this);
        pm.registerEvents(menus, this);
        pm.registerEvents(new WandListener(this), this);
        pm.registerEvents(new JoinListener(this), this);

        EstateCommand command = new EstateCommand(this);
        PluginCommand pc = getCommand("estate");
        if (pc != null) {
            pc.setExecutor(command);
            pc.setTabCompleter(command);
        }

        // economy plugins register with Vault after us, so hook on the first tick
        getServer().getScheduler().runTask(this, this::hookEconomy);
    }

    private void hookEconomy() {
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            getLogger().severe("No Vault economy found. Install an economy plugin such as EssentialsX. Disabling.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        economy = new EconomyService(rsp.getProvider());
        rentals.start();
        business.start();
        getLogger().info("Economy hooked: " + rsp.getProvider().getName());
    }

    @Override
    public void onDisable() {
        if (business != null) business.shutdown();
        if (rentals != null) rentals.shutdown();
        if (database != null) database.close();
    }

    public void reloadAll() {
        reloadConfig();
        messages.reload();
        if (protection != null) protection.reloadSettings();
    }

    public ItemStack createWand() {
        ItemStack item = Text.item(Material.BLAZE_ROD, "<gold><bold>عصا التحديد",
                "<gray>كليك يسار: النقطة الأولى", "<gray>كليك يمين: النقطة الثانية");
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
            item.setItemMeta(meta);
        }
        return item;
    }

    public void msg(CommandSender to, String key, Object... pairs) {
        messages.send(to, key, pairs);
    }

    public Messages messages() { return messages; }
    public Database db() { return database; }
    public EconomyService economy() { return economy; }
    public Ledger ledger() { return ledger; }
    public PlotService plots() { return plots; }
    public SnapshotService snapshots() { return snapshots; }
    public StashService stash() { return stash; }
    public NoticeService notices() { return notices; }
    public RentalService rentals() { return rentals; }
    public BusinessService business() { return business; }
    public SelectionService selections() { return selections; }
    public MenuListener menus() { return menus; }
    public ProtectionListener protection() { return protection; }
    public NamespacedKey wandKey() { return wandKey; }
}
