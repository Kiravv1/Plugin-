package com.myserver.survivalplus.listeners;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.models.PlayerShopData;
import com.myserver.survivalplus.models.ShopProduct;
import com.myserver.survivalplus.util.GriefPreventionHook;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class GuiListener implements Listener {
    private final SurvivalPlus plugin;
    private static final List<Integer> SHOP_SLOTS = Arrays.asList(10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34);

    public GuiListener(SurvivalPlus plugin) { this.plugin = plugin; }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof GuiHolder holder && !holder.getType().equals("PSHOP_DROPBOX")) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (event.getInventory().getHolder() instanceof GuiHolder holder && holder.getType().equals("PSHOP_DROPBOX")) {
            plugin.getPlayerShopManager().processDropBoxClose(player, event.getInventory());
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getInventory().getHolder() instanceof GuiHolder holder)) return;
        if (holder.getType().equals("PSHOP_DROPBOX")) return;

        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getInventory())) return;

        int slot = event.getSlot();
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.click"));

        switch (holder.getType()) {
            case "NOTIFICATIONS_GUI" -> handleNotifications(player, slot);
            case "RTP_GUI" -> handleRtp(player, slot);
            case "PSHOP_DIRECTORY" -> handlePShopDirectory(player, holder, slot);
            case "PSHOP_MANAGE" -> handlePShopManage(player, slot);
            case "PSHOP_EDIT_PRODUCT" -> handlePShopEditProduct(player, holder, slot);
            case "PSHOP_BOOST" -> handlePShopBoost(player, slot);
            case "PSHOP_VIEW" -> handlePShopView(player, holder, slot);
            case "PSHOP_BUY" -> handlePShopBuy(player, holder, slot);
            case "CLAIM_HUB" -> handleClaimHub(player, slot);
            case "CLAIM_LIST" -> handleClaimList(player, holder, slot);
            case "CLAIM_MANAGE" -> handleClaimManage(player, holder, slot);
            case "CLAIM_SETTINGS" -> handleClaimSettings(player, holder, slot);
            case "CLAIM_TRUST" -> handleClaimTrust(player, holder, slot);
            case "CLAIM_TRUST_ACTION" -> handleClaimTrustAction(player, holder, slot);
            case "CLAIM_TRUST_LEVEL" -> handleTrustLevel(player, holder, slot);
            case "CLAIM_CONFIRM_DELETE" -> handleConfirmDelete(player, holder, slot);
            case "CLAIM_CONFIRM_UNTRUST" -> handleConfirmUntrust(player, holder, slot);
        }
    }

    private boolean isClaimOwnerOrAdmin(Player player, GriefPreventionHook.ClaimInfo claim) {
        if (claim == null) return false;
        if (player.hasPermission("survivalplus.admin")) return true;
        return claim.ownerId() != null && claim.ownerId().equals(player.getUniqueId());
    }

    private void openGlobalBack(Player player) {
        player.closeInventory();
        TextUtil.runConsoleCommand(plugin.getConfigManager().getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                .replace("%player%", player.getName()));
    }

    private void handleNotifications(Player player, int slot) {
        ConfigurationSection cfg = plugin.getConfigManager().getNotifications();
        ConfigurationSection gui = cfg.getConfigurationSection("gui");
        if (slot == gui.getInt("back-slot", 31)) { openGlobalBack(player); return; }
        if (slot == gui.getInt("enable-all-slot", 29)) { plugin.getNotificationManager().setAll(player, true); plugin.getNotificationManager().openGui(player); return; }
        if (slot == gui.getInt("disable-all-slot", 33)) { plugin.getNotificationManager().setAll(player, false); plugin.getNotificationManager().openGui(player); return; }
        ConfigurationSection types = cfg.getConfigurationSection("types");
        if (types != null) {
            for (String key : types.getKeys(false)) {
                if (types.getInt(key + ".slot", -1) == slot) {
                    plugin.getNotificationManager().toggle(player, key);
                    plugin.getNotificationManager().openGui(player);
                    return;
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void handlePShopDirectory(Player player, GuiHolder holder, int slot) {
        ConfigurationSection slots = plugin.getConfigManager().getPlayerShop().getConfigurationSection("gui.slots");
        if (slot == slots.getInt("directory-manage", 48)) { plugin.getPlayerShopManager().openManageShop(player); return; }
        if (slot == slots.getInt("directory-back", 49)) { openGlobalBack(player); return; }
        if (slot == slots.getInt("directory-notif", 50)) { plugin.getNotificationManager().openGui(player); return; }
        int idx = SHOP_SLOTS.indexOf(slot);
        if (idx == -1) return;
        List<UUID> order = holder.get("shopOrder", List.class);
        if (order != null && idx < order.size()) {
            PlayerShopData shop = plugin.getPlayerShopManager().getShop(order.get(idx));
            if (shop != null) plugin.getPlayerShopManager().openPlayerShopView(player, shop);
        }
    }

    private void handlePShopManage(Player player, int slot) {
        PlayerShopData shop = plugin.getPlayerShopManager().getOrCreateShop(player);
        ConfigurationSection slots = plugin.getConfigManager().getPlayerShop().getConfigurationSection("gui.slots");
        if (slot == slots.getInt("manage-back", 45)) { plugin.getPlayerShopManager().openDirectory(player); return; }
        if (slot == slots.getInt("manage-restock-all", 48)) { plugin.getPlayerShopManager().restockAllFromInventoryAndShulkers(player); plugin.getPlayerShopManager().openManageShop(player); return; }
        if (slot == slots.getInt("manage-dropbox", 49)) { plugin.getPlayerShopManager().openDropBox(player); return; }
        if (slot == slots.getInt("manage-boost", 51)) { plugin.getPlayerShopManager().openBoostGui(player); return; }
        if (slot == slots.getInt("manage-add", 47)) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand.getType().isAir()) { plugin.getConfigManager().send(player, "pshop.hold-item"); return; }
            ItemStack copy = hand.clone();
            ShopProduct existing = shop.findMatching(copy);
            if (existing != null) {
                existing.addStock(copy.getAmount());
                player.getInventory().setItemInMainHand(null);
                plugin.getPlayerShopManager().saveData();
                plugin.getConfigManager().send(player, "pshop.merged", "%amount%", String.valueOf(copy.getAmount()), "%item%", copy.getType().name());
                plugin.getPlayerShopManager().openManageShop(player);
                return;
            }
            int max = player.hasPermission("survivalplus.shop.vip")
                    ? plugin.getConfigManager().getPlayerShop().getInt("settings.vip-max-listings", 27)
                    : plugin.getConfigManager().getPlayerShop().getInt("settings.default-max-listings", 9);
            if (shop.getProducts().size() >= max) { plugin.getConfigManager().send(player, "pshop.max-listings", "%max%", String.valueOf(max)); return; }
            player.closeInventory();
            double avg = plugin.getPlayerShopManager().getMarketAveragePrice(copy.getType());
            plugin.getConfigManager().send(player, "pshop.ask-price", "%avg%", avg > 0 ? avg + "$" : "لا يوجد بعد");
            plugin.getChatPromptManager().prompt(player, input -> {
                if (input.equalsIgnoreCase("إلغاء") || input.equalsIgnoreCase("cancel")) return;
                try {
                    double price = Double.parseDouble(input);
                    if (!Double.isFinite(price) || price <= 0 || price > 1_000_000_000) throw new NumberFormatException();
                    ItemStack curHand = player.getInventory().getItemInMainHand();
                    if (!curHand.isSimilar(copy)) { plugin.getConfigManager().send(player, "pshop.hold-item"); return; }
                    int amt = curHand.getAmount();
                    player.getInventory().setItemInMainHand(null);
                    shop.getProducts().add(new ShopProduct(null, copy, price, amt));
                    plugin.getPlayerShopManager().saveData();
                    plugin.getConfigManager().send(player, "pshop.listed", "%amount%", String.valueOf(amt), "%item%", copy.getType().name(), "%price%", String.valueOf(price));
                } catch (NumberFormatException e) { plugin.getConfigManager().send(player, "pshop.invalid-price"); }
            });
            return;
        }
        int idx = SHOP_SLOTS.indexOf(slot);
        if (idx >= 0 && idx < shop.getProducts().size()) plugin.getPlayerShopManager().openEditProductGui(player, idx);
    }

    private void handlePShopEditProduct(Player player, GuiHolder holder, int slot) {
        PlayerShopData shop = plugin.getPlayerShopManager().getOrCreateShop(player);
        int idx = holder.get("productIndex", Integer.class);
        if (slot == 22 || idx < 0 || idx >= shop.getProducts().size()) { plugin.getPlayerShopManager().openManageShop(player); return; }
        ShopProduct p = shop.getProducts().get(idx);

        if (slot == 10) {
            player.closeInventory();
            plugin.getConfigManager().send(player, "pshop.ask-new-price");
            plugin.getChatPromptManager().prompt(player, input -> {
                if (input.equalsIgnoreCase("إلغاء") || input.equalsIgnoreCase("cancel")) return;
                try {
                    double price = Double.parseDouble(input);
                    if (!Double.isFinite(price) || price <= 0 || price > 1_000_000_000) throw new NumberFormatException();
                    p.setUnitPrice(price);
                    plugin.getPlayerShopManager().saveData();
                    plugin.getConfigManager().send(player, "pshop.price-updated", "%item%", p.getTemplate().getType().name(), "%price%", String.valueOf(price));
                } catch (NumberFormatException e) { plugin.getConfigManager().send(player, "pshop.invalid-price"); }
            });
        } else if (slot == 12) {
            plugin.getPlayerShopManager().restockSingleProduct(player, p);
            plugin.getPlayerShopManager().openEditProductGui(player, idx);
        } else if (slot == 14) {
            p.setBulkDiscountEnabled(!p.isBulkDiscountEnabled());
            plugin.getPlayerShopManager().saveData();
            plugin.getPlayerShopManager().openEditProductGui(player, idx);
        } else if (slot == 16) {
            if (p.getStock() > 0) TextUtil.safeGiveItems(player, p.getTemplate(), p.getStock());
            shop.getProducts().remove(idx);
            plugin.getPlayerShopManager().saveData();
            plugin.getPlayerShopManager().openManageShop(player);
        }
    }

    private void handlePShopBoost(Player player, int slot) {
        if (slot == plugin.getConfigManager().getPlayerShop().getInt("gui.slots.boost-back", 22)) { plugin.getPlayerShopManager().openManageShop(player); return; }
        ConfigurationSection tiers = plugin.getConfigManager().getPlayerShop().getConfigurationSection("boost-tiers");
        if (tiers != null) for (String key : tiers.getKeys(false)) if (tiers.getInt(key + ".slot", -1) == slot) { plugin.getPlayerShopManager().activateBoostTier(player, key); return; }
    }

    private void handlePShopView(Player player, GuiHolder holder, int slot) {
        UUID ownerId = holder.get("ownerId", UUID.class);
        PlayerShopData shop = plugin.getPlayerShopManager().getShop(ownerId);
        if (shop == null) { player.closeInventory(); return; }
        ConfigurationSection slots = plugin.getConfigManager().getPlayerShop().getConfigurationSection("gui.slots");
        if (slot == slots.getInt("view-back", 49)) { plugin.getPlayerShopManager().openDirectory(player); return; }
        if (slot == slots.getInt("view-favorite", 48)) {
            if (shop.getFollowers().remove(player.getUniqueId())) plugin.getConfigManager().send(player, "pshop.fav-removed", "%owner%", shop.getOwnerName());
            else { shop.getFollowers().add(player.getUniqueId()); plugin.getConfigManager().send(player, "pshop.fav-added", "%owner%", shop.getOwnerName()); }
            plugin.getPlayerShopManager().saveData();
            plugin.getPlayerShopManager().openPlayerShopView(player, shop);
            return;
        }
        int idx = SHOP_SLOTS.indexOf(slot);
        if (idx >= 0 && idx < shop.getProducts().size()) plugin.getPlayerShopManager().openBuyGui(player, shop, idx);
    }

    private void handlePShopBuy(Player player, GuiHolder holder, int slot) {
        UUID ownerId = holder.get("ownerId", UUID.class);
        int idx = holder.get("productIndex", Integer.class);
        PlayerShopData shop = plugin.getPlayerShopManager().getShop(ownerId);
        if (shop == null) { player.closeInventory(); return; }
        if (slot == 22) { plugin.getPlayerShopManager().openPlayerShopView(player, shop); return; }
        if (slot == 10) plugin.getPlayerShopManager().buyFromShop(player, shop, idx, 1);
        else if (slot == 11) plugin.getPlayerShopManager().buyFromShop(player, shop, idx, 16);
        else if (slot == 15) plugin.getPlayerShopManager().buyFromShop(player, shop, idx, 64);
        else if (slot == 16 && idx < shop.getProducts().size()) {
            ShopProduct p = shop.getProducts().get(idx);
            player.closeInventory();
            plugin.getConfigManager().send(player, "pshop.ask-buy-amount", "%max%", String.valueOf(p.getStock()));
            plugin.getChatPromptManager().prompt(player, input -> {
                if (input.equalsIgnoreCase("إلغاء") || input.equalsIgnoreCase("cancel")) return;
                try {
                    int amt = Integer.parseInt(input);
                    if (amt <= 0 || amt > 10000) throw new NumberFormatException();
                    plugin.getPlayerShopManager().buyFromShop(player, shop, idx, amt);
                } catch (NumberFormatException e) { plugin.getConfigManager().send(player, "pshop.invalid-amount"); }
            });
        }
    }

    private void handleRtp(Player player, int slot) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("rtp");
        if (slot == cfg.getInt("gui.back-slot", 22)) { openGlobalBack(player); return; }
        ConfigurationSection worlds = cfg.getConfigurationSection("worlds");
        if (worlds != null) for (String w : worlds.getKeys(false)) if (worlds.getInt(w + ".slot", -1) == slot) { player.closeInventory(); plugin.getRtpManager().executeRtp(player, w); return; }
    }

    private void handleClaimHub(Player player, int slot) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.hub");
        if (slot == cfg.getInt("close-slot", 36)) player.closeInventory();
        else if (slot == cfg.getInt("back-slot", 44)) openGlobalBack(player);
        else if (slot == cfg.getInt("notif-slot", 40)) plugin.getNotificationManager().openGui(player);
        else if (slot == cfg.getInt("list-slot", 29)) plugin.getClaimGuiManager().openClaimsList(player, 1);
        else if (slot == cfg.getInt("shovel-slot", 11)) giveTool(player, "shovel");
        else if (slot == cfg.getInt("stick-slot", 20)) giveTool(player, "stick");
        else if (slot == cfg.getInt("buy-small-slot", 13)) buyPack(player, "small");
        else if (slot == cfg.getInt("buy-medium-slot", 22)) buyPack(player, "medium");
        else if (slot == cfg.getInt("buy-large-slot", 31)) buyPack(player, "large");
        else if (slot == cfg.getInt("sell-slot", 24)) sellBlocks(player);
    }

    private void giveTool(Player player, String key) {
        ConfigurationSection ts = plugin.getConfigManager().getConfig().getConfigurationSection("claims.tools." + key);
        if (ts == null || !ts.getBoolean("enabled", true)) return;
        if (!player.hasPermission("survivalplus.claim.bypass.cooldown")) {
            long rem = plugin.getCooldownManager().getRemainingSeconds(player.getUniqueId(), "tool_" + key);
            if (rem > 0) { plugin.getConfigManager().send(player, "claims.tool-cooldown", "%cooldown%", plugin.getCooldownManager().format(rem), "%tool%", key); return; }
        }
        Material mat = TextUtil.parseMaterial(ts.getString("material"), Material.GOLDEN_SHOVEL);
        TextUtil.safeGiveItems(player, new ItemStack(mat), 1);
        int cd = ts.getInt("cooldown-seconds", 7200);
        plugin.getCooldownManager().setCooldown(player.getUniqueId(), "tool_" + key, cd);
        plugin.getConfigManager().send(player, "claims.tool-given", "%tool%", mat.name(), "%cooldown%", plugin.getCooldownManager().format(cd));
    }

    private void buyPack(Player player, String pack) {
        if (!plugin.getVaultHook().isConnected()) { plugin.getConfigManager().send(player, "general.economy-missing"); return; }
        if (!plugin.getGpHook().isConnected()) { plugin.getConfigManager().send(player, "general.gp-missing"); return; }
        ConfigurationSection ps = plugin.getConfigManager().getConfig().getConfigurationSection("claims.economy.packs." + pack);
        int blocks = ps.getInt("blocks"); double price = ps.getDouble("price");
        if (!plugin.getVaultHook().has(player, price)) { plugin.getConfigManager().send(player, "claims.buy-no-money", "%price%", price + "$"); return; }
        plugin.getVaultHook().withdraw(player, price);
        plugin.getGpHook().addBonusBlocks(player.getUniqueId(), blocks);
        plugin.getConfigManager().send(player, "claims.buy-success", "%blocks%", String.valueOf(blocks), "%price%", price + "$");
        plugin.getClaimGuiManager().openHub(player);
    }

    private void sellBlocks(Player player) {
        if (!plugin.getVaultHook().isConnected()) { plugin.getConfigManager().send(player, "general.economy-missing"); return; }
        if (!plugin.getGpHook().isConnected()) { plugin.getConfigManager().send(player, "general.gp-missing"); return; }
        ConfigurationSection ss = plugin.getConfigManager().getConfig().getConfigurationSection("claims.economy.sell");
        int blocks = ss.getInt("blocks", 100); double payout = ss.getDouble("payout", 250.0);
        if (plugin.getGpHook().getBonusBlocks(player.getUniqueId()) < blocks || plugin.getGpHook().getRemainingBlocks(player.getUniqueId()) < blocks) {
            plugin.getConfigManager().send(player, "claims.sell-no-blocks", "%blocks%", String.valueOf(blocks)); return;
        }
        plugin.getGpHook().addBonusBlocks(player.getUniqueId(), -blocks);
        plugin.getVaultHook().deposit(player, payout);
        plugin.getConfigManager().send(player, "claims.sell-success", "%blocks%", String.valueOf(blocks), "%payout%", payout + "$");
        plugin.getClaimGuiManager().openHub(player);
    }

    @SuppressWarnings("unchecked")
    private void handleClaimList(Player player, GuiHolder holder, int slot) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.list");
        int page = holder.get("page", Integer.class);
        if (slot == cfg.getInt("close-slot", 48)) { player.closeInventory(); return; }
        if (slot == cfg.getInt("back-slot", 50)) { plugin.getClaimGuiManager().openHub(player); return; }
        if (slot == cfg.getInt("prev-slot", 45) && page > 1) { plugin.getClaimGuiManager().openClaimsList(player, page - 1); return; }
        if (slot == cfg.getInt("next-slot", 53)) { plugin.getClaimGuiManager().openClaimsList(player, page + 1); return; }
        List<Integer> slots = cfg.getIntegerList("claim-slots");
        int idx = slots.indexOf(slot);
        if (idx == -1) return;
        List<GriefPreventionHook.ClaimInfo> claims = holder.get("claims", List.class);
        int realIndex = (page - 1) * slots.size() + idx;
        if (realIndex >= claims.size()) return;
        plugin.getClaimGuiManager().openManage(player, claims.get(realIndex));
    }

    private void startClaimTeleport(Player player, GriefPreventionHook.ClaimInfo claim) {
        player.closeInventory();
        Location target = claim.getSafeTeleportLocation(plugin.getConfigManager().getConfig().getInt("claims.teleport.y-offset", 1));
        if (target == null) return;
        int sec = plugin.getConfigManager().getConfig().getInt("claims.teleport.countdown-seconds", 5);
        plugin.getConfigManager().send(player, "claims.tp-start", "%id%", String.valueOf(claim.id()), "%seconds%", String.valueOf(sec));
        plugin.getTeleportManager().startTeleport(player, target, sec, true, 0.25, "claims.tp-actionbar", "CHERRY_LEAVES", "PORTAL",
                "BLOCK_NOTE_BLOCK_PLING", "BLOCK_NOTE_BLOCK_HAT", "ENTITY_ENDERMAN_TELEPORT", "ENTITY_VILLAGER_NO",
                () -> plugin.getConfigManager().send(player, "claims.tp-success", "%id%", String.valueOf(claim.id()), "%world%", claim.worldName()),
                () -> plugin.getConfigManager().send(player, "claims.tp-cancelled"));
    }

    private void handleClaimManage(Player player, GuiHolder holder, int slot) {
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(holder.get("claimId", Long.class));
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        if (slot == 36) plugin.getClaimGuiManager().openClaimsList(player, 1);
        else if (slot == 11) startClaimTeleport(player, claim);
        else if (slot == 13) plugin.getClaimGuiManager().openTrust(player, claim);
        else if (slot == 15) plugin.getClaimGuiManager().openSettings(player, claim);
        else if (slot == 40) plugin.getClaimGuiManager().openConfirmDelete(player, claim);
    }

    private void handleClaimSettings(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        if (slot == 36) plugin.getClaimGuiManager().openManage(player, claim);
        else if (slot == 20) {
            boolean state = plugin.getGpHook().toggleExplosions(claim);
            plugin.getConfigManager().send(player, state ? "claims.explosives-on" : "claims.explosives-off", "%id%", String.valueOf(claimId));
            plugin.getClaimGuiManager().openSettings(player, plugin.getGpHook().getClaimById(claimId));
        } else if (slot == 24) giveTool(player, "shovel");
        else if (slot == 31) startClaimTeleport(player, claim);
    }

    @SuppressWarnings("unchecked")
    private void handleClaimTrust(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.trust");
        if (slot == 45) { plugin.getClaimGuiManager().openManage(player, claim); return; }
        for (String lvl : cfg.getStringList("level-order")) {
            if (cfg.getInt("level-slots." + lvl, -1) == slot) { plugin.getClaimGuiManager().setSelectedLevel(player.getUniqueId(), lvl); plugin.getClaimGuiManager().openTrust(player, claim); return; }
        }
        if (slot == 49) {
            String lvl = plugin.getClaimGuiManager().getSelectedLevel(player.getUniqueId());
            player.closeInventory();
            plugin.getConfigManager().send(player, "claims.trust-ask", "%level%", lvl);
            plugin.getChatPromptManager().prompt(player, input -> {
                if (input.equalsIgnoreCase("إلغاء") || input.equalsIgnoreCase("cancel")) return;
                OfflinePlayer target = Bukkit.getOfflinePlayer(input);
                if (!target.hasPlayedBefore() && !target.isOnline()) { plugin.getConfigManager().send(player, "claims.trust-invalid"); return; }
                if (target.getUniqueId().equals(player.getUniqueId())) { plugin.getConfigManager().send(player, "claims.trust-self"); return; }
                plugin.getGpHook().setTrust(claim, target.getUniqueId(), lvl);
                plugin.getConfigManager().send(player, "claims.trust-added", "%player%", input, "%level%", lvl, "%id%", String.valueOf(claimId));
                if (target.isOnline() && target.getPlayer() != null) {
                    plugin.getNotificationManager().notify(target.getPlayer(), "claim-trust", "claims.trust-target-added",
                            "%owner%", player.getName(), "%level%", lvl, "%id%", String.valueOf(claimId));
                }
            });
            return;
        }
        int idx = cfg.getIntegerList("player-slots").indexOf(slot);
        List<UUID> uuids = holder.get("trustedUuids", List.class);
        if (idx >= 0 && uuids != null && idx < uuids.size()) plugin.getClaimGuiManager().openTrustPlayerAction(player, claimId, uuids.get(idx));
    }

    private void handleClaimTrustAction(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        UUID targetId = holder.get("targetId", UUID.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        if (slot == 22) plugin.getClaimGuiManager().openTrust(player, claim);
        else if (slot == 11) plugin.getClaimGuiManager().openLevelSelect(player, claimId, targetId);
        else if (slot == 15) plugin.getClaimGuiManager().openConfirmUntrust(player, claimId, targetId);
    }

    private void handleTrustLevel(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        UUID targetId = holder.get("targetId", UUID.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        if (slot == 22) { plugin.getClaimGuiManager().openTrust(player, claim); return; }
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.trust");
        for (String lvl : cfg.getStringList("level-order")) {
            if (cfg.getInt("level-menu-slots." + lvl, -1) == slot) {
                plugin.getGpHook().setTrust(claim, targetId, lvl);
                OfflinePlayer op = Bukkit.getOfflinePlayer(targetId);
                plugin.getConfigManager().send(player, "claims.trust-changed", "%player%", op.getName() != null ? op.getName() : "لاعب", "%level%", lvl);
                if (op.isOnline() && op.getPlayer() != null) {
                    plugin.getNotificationManager().notify(op.getPlayer(), "claim-trust", "claims.trust-target-changed",
                            "%owner%", player.getName(), "%level%", lvl, "%id%", String.valueOf(claimId));
                }
                plugin.getClaimGuiManager().openTrust(player, claim);
                return;
            }
        }
    }

    private void handleConfirmDelete(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.confirm-delete");
        if (cfg.getIntegerList("no-slots").contains(slot)) plugin.getClaimGuiManager().openManage(player, claim);
        else if (cfg.getIntegerList("yes-slots").contains(slot)) {
            player.closeInventory();
            if (plugin.getGpHook().deleteClaim(claim)) plugin.getConfigManager().send(player, "claims.deleted", "%id%", String.valueOf(claimId));
        }
    }

    private void handleConfirmUntrust(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        UUID targetId = holder.get("targetId", UUID.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.confirm-untrust");
        if (cfg.getIntegerList("no-slots").contains(slot)) plugin.getClaimGuiManager().openTrust(player, claim);
        else if (cfg.getIntegerList("yes-slots").contains(slot)) {
            plugin.getGpHook().untrust(claim, targetId);
            OfflinePlayer op = Bukkit.getOfflinePlayer(targetId);
            plugin.getConfigManager().send(player, "claims.trust-removed", "%player%", op.getName() != null ? op.getName() : "لاعب", "%id%", String.valueOf(claimId));
            if (op.isOnline() && op.getPlayer() != null) {
                plugin.getNotificationManager().notify(op.getPlayer(), "claim-trust", "claims.trust-target-removed",
                        "%owner%", player.getName(), "%id%", String.valueOf(claimId));
            }
            plugin.getClaimGuiManager().openTrust(player, claim);
        }
    }
}
