package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class RtpManager {
    private final SurvivalPlus plugin;
    public RtpManager(SurvivalPlus plugin) { this.plugin = plugin; }

    public void openRtpGui(Player player) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("rtp.gui");
        int size = cfg.getInt("size", 27);
        GuiHolder holder = new GuiHolder("RTP_GUI");
        Inventory inv = Bukkit.createInventory(holder, size, TextUtil.color(cfg.getString("title", "RTP")));
        holder.setInventory(inv);
        ItemStack filler = createItem(TextUtil.parseMaterial(cfg.getString("filler-material"), Material.PINK_STAINED_GLASS_PANE), cfg.getString("filler-name", " "), List.of());
        for (int i = 0; i < size; i++) inv.setItem(i, filler);
        ConfigurationSection worlds = plugin.getConfigManager().getConfig().getConfigurationSection("rtp.worlds");
        if (worlds != null) {
            for (String worldKey : worlds.getKeys(false)) {
                ConfigurationSection ws = worlds.getConfigurationSection(worldKey);
                if (ws == null || !ws.getBoolean("enabled", true)) continue;
                double cost = ws.getDouble("cost", 0.0);
                inv.setItem(ws.getInt("slot", 13), createItem(TextUtil.parseMaterial(ws.getString("icon"), Material.GRASS_BLOCK),
                        ws.getString("display-name", worldKey),
                        List.of("", "  &#FF8FA3▪ &fالمدى: &#FFB3C1" + ws.getInt("min-radius") + " → " + ws.getInt("max-radius"),
                                "  &#FF8FA3▪ &fالتكلفة: &#FFD700" + (cost > 0 ? cost + "$" : "مجاني"), "", "  &#55FF55▶ &fاضغط للانتقال العشوائي")));
            }
        }
        inv.setItem(cfg.getInt("back-slot", 22), createItem(TextUtil.parseMaterial(cfg.getString("back-material"), Material.SPECTRAL_ARROW), cfg.getString("back-name", "&eرجوع"), List.of()));
        player.openInventory(inv);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }

    public void executeRtp(Player player, String worldName) {
        ConfigurationSection ws = plugin.getConfigManager().getConfig().getConfigurationSection("rtp.worlds." + worldName);
        if (ws == null || !ws.getBoolean("enabled", false)) { plugin.getConfigManager().send(player, "rtp.world-disabled"); return; }
        World world = Bukkit.getWorld(worldName);
        if (world == null) { plugin.getConfigManager().send(player, "rtp.world-disabled"); return; }
        if (!player.hasPermission("survivalplus.rtp.bypass.cooldown")) {
            long rem = plugin.getCooldownManager().getRemainingSeconds(player.getUniqueId(), "rtp");
            if (rem > 0) { plugin.getConfigManager().send(player, "rtp.cooldown", "%time%", plugin.getCooldownManager().format(rem)); return; }
        }
        double cost = ws.getDouble("cost", 0.0);
        if (cost > 0 && !player.hasPermission("survivalplus.rtp.bypass.cost")) {
            if (!plugin.getVaultHook().isConnected()) { plugin.getConfigManager().send(player, "general.economy-missing"); return; }
            if (!plugin.getVaultHook().has(player, cost)) { plugin.getConfigManager().send(player, "rtp.no-money", "%cost%", cost + "$"); return; }
        }
        plugin.getConfigManager().send(player, "rtp.searching");
        Location safe = findSafeLocation(world, ws);
        if (safe == null) { plugin.getConfigManager().send(player, "rtp.failed-safe"); return; }
        int warmup = plugin.getConfigManager().getConfig().getInt("rtp.warmup-seconds", 5);
        plugin.getConfigManager().send(player, "rtp.start", "%seconds%", String.valueOf(warmup));
        plugin.getTeleportManager().startTeleport(player, safe, warmup,
                plugin.getConfigManager().getConfig().getBoolean("rtp.cancel-on-move", true),
                plugin.getConfigManager().getConfig().getDouble("rtp.move-tolerance", 0.25),
                "rtp.countdown-actionbar",
                plugin.getConfigManager().getConfig().getString("rtp.effects.particle-warmup"),
                plugin.getConfigManager().getConfig().getString("rtp.effects.particle-arrive"),
                plugin.getConfigManager().getConfig().getString("rtp.effects.sound-start"),
                plugin.getConfigManager().getConfig().getString("rtp.effects.sound-tick"),
                plugin.getConfigManager().getConfig().getString("rtp.effects.sound-success"),
                plugin.getConfigManager().getConfig().getString("rtp.effects.sound-cancel"),
                () -> {
                    if (cost > 0 && !player.hasPermission("survivalplus.rtp.bypass.cost") && plugin.getVaultHook().isConnected()) plugin.getVaultHook().withdraw(player, cost);
                    plugin.getCooldownManager().setCooldown(player.getUniqueId(), "rtp", plugin.getConfigManager().getConfig().getInt("rtp.cooldown-seconds", 120));
                    if (plugin.getConfigManager().getConfig().getBoolean("rtp.effects.show-title-on-arrive", true)) plugin.getTeleportManager().showArriveTitle(player, safe);
                    plugin.getConfigManager().send(player, "rtp.arrive-chat", "%x%", String.valueOf(safe.getBlockX()), "%y%", String.valueOf(safe.getBlockY()), "%z%", String.valueOf(safe.getBlockZ()), "%world%", world.getName());
                },
                () -> plugin.getConfigManager().send(player, "rtp.cancelled-move"));
    }

    private Location findSafeLocation(World world, ConfigurationSection ws) {
        int minR = ws.getInt("min-radius", 200), maxR = ws.getInt("max-radius", 5000);
        double centerX = ws.getDouble("center-x", 0), centerZ = ws.getDouble("center-z", 0);
        if (plugin.getConfigManager().getConfig().getBoolean("rtp.safety.respect-world-border", true)) {
            WorldBorder border = world.getWorldBorder();
            int halfSize = (int) (border.getSize() / 2.0) - plugin.getConfigManager().getConfig().getInt("rtp.safety.border-padding", 50);
            if (halfSize > minR) { maxR = Math.min(maxR, halfSize); centerX = border.getCenter().getX(); centerZ = border.getCenter().getZ(); }
        }
        int attempts = plugin.getConfigManager().getConfig().getInt("rtp.max-attempts", 25);
        List<String> blacklist = plugin.getConfigManager().getConfig().getStringList("rtp.safety.blacklisted-blocks");
        boolean avoidClaims = plugin.getConfigManager().getConfig().getBoolean("rtp.safety.avoid-claims", true);
        for (int i = 0; i < attempts; i++) {
            double angle = ThreadLocalRandom.current().nextDouble(0, Math.PI * 2);
            double dist = ThreadLocalRandom.current().nextDouble(minR, Math.max(minR + 1, maxR));
            int x = (int) (centerX + Math.cos(angle) * dist), z = (int) (centerZ + Math.sin(angle) * dist);
            int y = world.getHighestBlockYAt(x, z);
            if (y <= world.getMinHeight()) continue;
            Block ground = world.getBlockAt(x, y, z);
            if (!ground.getType().isSolid() || blacklist.contains(ground.getType().name())) continue;
            Location candidate = new Location(world, x + 0.5, y + 1.0, z + 0.5);
            if (avoidClaims && plugin.getGpHook().isInsideAnyClaim(candidate)) continue;
            return candidate;
        }
        return null;
    }

    private ItemStack createItem(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat); ItemMeta meta = item.getItemMeta();
        if (meta != null) { meta.displayName(TextUtil.color(name)); if (!lore.isEmpty()) meta.lore(TextUtil.colorList(lore)); item.setItemMeta(meta); }
        return item;
    }
}
