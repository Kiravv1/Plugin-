package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class NotificationManager {
    private final SurvivalPlus plugin;
    private final File dataFile;
    private final Map<UUID, Map<String, Boolean>> playerPrefs = new HashMap<>();

    public NotificationManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "notifications-data.yml");
    }

    public void loadData() {
        playerPrefs.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection sec = yml.getConfigurationSection("players");
        if (sec == null) return;
        for (String uuidStr : sec.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidStr);
                ConfigurationSection ps = sec.getConfigurationSection(uuidStr);
                if (ps == null) continue;
                Map<String, Boolean> map = new HashMap<>();
                for (String key : ps.getKeys(false)) map.put(key, ps.getBoolean(key));
                playerPrefs.put(uuid, map);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public void saveData() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, Boolean>> entry : playerPrefs.entrySet()) {
            for (Map.Entry<String, Boolean> pref : entry.getValue().entrySet()) {
                yml.set("players." + entry.getKey() + "." + pref.getKey(), pref.getValue());
            }
        }
        try { yml.save(dataFile); } catch (IOException ignored) {}
    }

    public boolean isGloballyEnabled(String typeKey) {
        return plugin.getConfigManager().getNotifications().getBoolean("types." + typeKey + ".enabled", true);
    }

    public boolean isEnabledFor(UUID playerId, String typeKey) {
        if (!isGloballyEnabled(typeKey)) return false;
        Map<String, Boolean> map = playerPrefs.get(playerId);
        if (map != null && map.containsKey(typeKey)) return map.get(typeKey);
        return plugin.getConfigManager().getNotifications().getBoolean("types." + typeKey + ".default-player-state", true);
    }

    public void toggle(Player player, String typeKey) {
        if (!isGloballyEnabled(typeKey)) {
            plugin.getConfigManager().send(player, "notifications.disabled-by-server");
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.error"));
            return;
        }
        boolean next = !isEnabledFor(player.getUniqueId(), typeKey);
        playerPrefs.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>()).put(typeKey, next);
        saveData();
        String name = plugin.getConfigManager().getNotifications().getString("types." + typeKey + ".name", typeKey);
        plugin.getConfigManager().send(player, next ? "notifications.toggled-on" : "notifications.toggled-off", "%name%", name);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString(next ? "sounds.success" : "sounds.click"));
    }

    public void setAll(Player player, boolean state) {
        ConfigurationSection types = plugin.getConfigManager().getNotifications().getConfigurationSection("types");
        if (types == null) return;
        Map<String, Boolean> map = playerPrefs.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>());
        for (String key : types.getKeys(false)) if (isGloballyEnabled(key)) map.put(key, state);
        saveData();
        plugin.getConfigManager().send(player, state ? "notifications.enabled-all" : "notifications.disabled-all");
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString(state ? "sounds.success" : "sounds.click"));
    }

    public void notify(Player player, String typeKey, String messagePath, String... placeholders) {
        if (player == null || !player.isOnline()) return;
        if (!isEnabledFor(player.getUniqueId(), typeKey)) return;
        plugin.getConfigManager().send(player, messagePath, placeholders);
        ConfigurationSection sec = plugin.getConfigManager().getNotifications().getConfigurationSection("types." + typeKey);
        if (sec != null) {
            if (sec.getBoolean("send-actionbar", false)) player.sendActionBar(plugin.getConfigManager().rawMessage(messagePath, placeholders));
            TextUtil.playSound(player, sec.getString("sound", "ENTITY_EXPERIENCE_ORB_PICKUP"), 1.2f);
        }
    }

    public void broadcast(String typeKey, Component component) {
        if (!isGloballyEnabled(typeKey)) return;
        String sound = plugin.getConfigManager().getNotifications().getString("types." + typeKey + ".sound", "");
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (isEnabledFor(p.getUniqueId(), typeKey)) {
                p.sendMessage(component);
                if (!sound.isBlank()) TextUtil.playSound(p, sound, 1.1f);
            }
        }
    }

    public void openGui(Player player) {
        ConfigurationSection cfg = plugin.getConfigManager().getNotifications();
        ConfigurationSection gui = cfg.getConfigurationSection("gui");
        int size = gui.getInt("size", 36);
        GuiHolder holder = new GuiHolder("NOTIFICATIONS_GUI");
        Inventory inv = Bukkit.createInventory(holder, size, TextUtil.color(gui.getString("title", "Notifications")));
        holder.setInventory(inv);

        ItemStack filler = makeItem(TextUtil.parseMaterial(gui.getString("filler-material"), Material.PINK_STAINED_GLASS_PANE), gui.getString("filler-name", " "), List.of(), false);
        for (int i = 0; i < size; i++) inv.setItem(i, filler);

        ConfigurationSection types = cfg.getConfigurationSection("types");
        if (types != null) {
            for (String key : types.getKeys(false)) {
                ConfigurationSection t = types.getConfigurationSection(key);
                if (t == null) continue;
                boolean globalOn = t.getBoolean("enabled", true);
                boolean playerOn = isEnabledFor(player.getUniqueId(), key);
                String status = !globalOn ? "&8[معطّل من السيرفر]" : (playerOn ? "&#55FF55✔ مفعّل" : "&#FF5555✘ مغلق");
                inv.setItem(t.getInt("slot", 10), makeItem(
                        TextUtil.parseMaterial(t.getString("material"), Material.BELL),
                        t.getString("name", key),
                        List.of("", "  &7" + t.getString("description", ""), "", "  &#FF8FA3▪ &fالحالة: " + status, "  &#55FF55▶ &fاضغط للتبديل (فتح / قفل)"),
                        globalOn && playerOn));
            }
        }

        inv.setItem(gui.getInt("enable-all-slot", 29), makeItem(Material.LIME_DYE, "&#55FF55✔ تفعيل جميع الإشعارات", List.of("", "  &7اضغط لفتح كل الإشعارات"), false));
        inv.setItem(gui.getInt("back-slot", 31), makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ العودة للقائمة الرئيسية", List.of(), false));
        inv.setItem(gui.getInt("disable-all-slot", 33), makeItem(Material.RED_DYE, "&#FF5555✘ كتم جميع الإشعارات", List.of("", "  &7اضغط لإغلاق كل الإشعارات"), false));

        player.openInventory(inv);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }

    private ItemStack makeItem(Material mat, String name, List<String> lore, boolean glow) {
        ItemStack item = new ItemStack(mat); ItemMeta meta = item.getItemMeta();
        if (meta != null) { meta.displayName(TextUtil.color(name)); if (!lore.isEmpty()) meta.lore(TextUtil.colorList(lore)); if (glow) { meta.addEnchant(Enchantment.UNBREAKING, 1, true); meta.addItemFlags(ItemFlag.HIDE_ENCHANTS); } item.setItemMeta(meta); }
        return item;
    }
}
