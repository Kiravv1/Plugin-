package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.util.GriefPreventionHook;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;

public class ClaimGuiManager {
    private final SurvivalPlus plugin;
    private final Map<UUID, String> selectedTrustLevel = new HashMap<>();
    public ClaimGuiManager(SurvivalPlus plugin) { this.plugin = plugin; }
    public String getSelectedLevel(UUID playerId) { return selectedTrustLevel.getOrDefault(playerId, plugin.getConfigManager().getConfig().getString("gui.trust.default-level", "Build")); }
    public void setSelectedLevel(UUID playerId, String level) { selectedTrustLevel.put(playerId, level); }

    public void openHub(Player player) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.hub");
        GuiHolder holder = new GuiHolder("CLAIM_HUB");
        Inventory inv = Bukkit.createInventory(holder, cfg.getInt("size", 45), TextUtil.color(cfg.getString("title")));
        holder.setInventory(inv);
        fill(inv, TextUtil.parseMaterial(cfg.getString("filler-material"), Material.YELLOW_STAINED_GLASS_PANE), cfg.getString("filler-name", " "));
        int remaining = plugin.getGpHook().getRemainingBlocks(player.getUniqueId());
        int bonus = plugin.getGpHook().getBonusBlocks(player.getUniqueId());
        int count = plugin.getGpHook().getPlayerClaims(player.getUniqueId()).size();
        inv.setItem(cfg.getInt("info-slot", 4), makeSkull(player, "&#FFD700🍓 &#FFF0F3" + player.getName(),
                List.of("", "  &#FF8FA3▪ &fالرصيد: &#55FF55" + String.format("%.1f$", plugin.getVaultHook().getBalance(player)),
                        "  &#FF8FA3▪ &fأراضيك: &#FFAA00" + count, "  &#FF8FA3▪ &fالمتبقية: &#55FF55" + remaining, "  &#FF8FA3▪ &fالإضافية: &#FFB3C1" + bonus)));
        inv.setItem(cfg.getInt("shovel-slot", 11), makeItem(Material.GOLDEN_SHOVEL, "&#FFD700مجرفة الحماية", List.of("", "  &7اضغط للاستلام")));
        inv.setItem(cfg.getInt("stick-slot", 20), makeItem(Material.STICK, "&#FFAA00عصا الفحص", List.of("", "  &7اضغط للاستلام")));
        inv.setItem(cfg.getInt("list-slot", 29), makeItem(Material.PAPER, "&#FF4D6D🍓 &#FFF0F3قائمة أراضيك (" + count + ")", List.of("", "  &7عرض وإدارة جميع أراضيك")));
        ConfigurationSection packs = plugin.getConfigManager().getConfig().getConfigurationSection("claims.economy.packs");
        inv.setItem(cfg.getInt("buy-small-slot", 13), makeItem(Material.EMERALD, "&#55FF55شراء " + packs.getInt("small.blocks") + " نقطة", List.of("", "  &fالسعر: &#FFD700" + packs.getDouble("small.price") + "$")));
        inv.setItem(cfg.getInt("buy-medium-slot", 22), makeItem(Material.EMERALD, "&#55FF55شراء " + packs.getInt("medium.blocks") + " نقطة", List.of("", "  &fالسعر: &#FFD700" + packs.getDouble("medium.price") + "$")));
        inv.setItem(cfg.getInt("buy-large-slot", 31), makeItem(Material.EMERALD_BLOCK, "&#55FF55شراء " + packs.getInt("large.blocks") + " نقطة", List.of("", "  &fالسعر: &#FFD700" + packs.getDouble("large.price") + "$")));
        ConfigurationSection sell = plugin.getConfigManager().getConfig().getConfigurationSection("claims.economy.sell");
        inv.setItem(cfg.getInt("sell-slot", 24), makeItem(Material.GOLD_INGOT, "&#FFD700بيع " + sell.getInt("blocks") + " نقطة", List.of("", "  &fتحصل على: &#55FF55" + sell.getDouble("payout") + "$")));
        inv.setItem(cfg.getInt("notif-slot", 40), makeItem(Material.BELL, "&#FFD700🔔 إعدادات الإشعارات", List.of("", "  &7فتح/قفل تنبيهات الأراضي والسوق")));
        inv.setItem(cfg.getInt("close-slot", 36), makeItem(Material.BARRIER, "&#FF5555✘ إغلاق", List.of()));
        inv.setItem(cfg.getInt("back-slot", 44), makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ العودة للقائمة الرئيسية", List.of()));
        player.openInventory(inv);
    }

    public void openClaimsList(Player player, int page) {
        if (!plugin.getGpHook().isConnected()) { plugin.getConfigManager().send(player, "general.gp-missing"); return; }
        List<GriefPreventionHook.ClaimInfo> claims = plugin.getGpHook().getPlayerClaims(player.getUniqueId());
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.list");
        List<Integer> slots = cfg.getIntegerList("claim-slots");
        int perPage = Math.max(1, slots.size()), maxPage = Math.max(1, (int) Math.ceil((double) claims.size() / perPage)), curPage = Math.max(1, Math.min(page, maxPage));
        GuiHolder holder = new GuiHolder("CLAIM_LIST").set("page", curPage).set("claims", claims);
        Inventory inv = Bukkit.createInventory(holder, cfg.getInt("size", 54), TextUtil.color(cfg.getString("title", "Claims").replace("%page%", String.valueOf(curPage)).replace("%maxpage%", String.valueOf(maxPage))));
        holder.setInventory(inv);
        fill(inv, TextUtil.parseMaterial(cfg.getString("filler-material"), Material.PINK_STAINED_GLASS_PANE), cfg.getString("filler-name", " "));
        for (int s : cfg.getIntegerList("accent-slots")) if (s >= 0 && s < inv.getSize()) inv.setItem(s, makeItem(TextUtil.parseMaterial(cfg.getString("accent-material"), Material.RED_STAINED_GLASS_PANE), cfg.getString("accent-name", " "), List.of()));
        if (claims.isEmpty()) inv.setItem(22, makeItem(Material.BARRIER, "&#FF5555🍓 لا تملك أي أراضٍ", List.of()));
        else {
            int start = (curPage - 1) * perPage;
            for (int i = 0; i < perPage && (start + i) < claims.size(); i++) {
                GriefPreventionHook.ClaimInfo c = claims.get(start + i);
                Material icon = c.worldName().equals("world_nether") ? Material.NETHERRACK : (c.worldName().equals("world_the_end") ? Material.END_STONE : Material.GRASS_BLOCK);
                inv.setItem(slots.get(i), makeItem(icon, "&#FF4D6D🍓 &#FFF0F3أرض &#FFAA00#" + c.id(),
                        List.of("", "  &#FF8FA3▪ &fالعالم: &#FFB3C1" + c.worldName(), "  &#FF8FA3▪ &fالمساحة: &#55FF55" + c.area() + " &fبلوك",
                                "  &#FF8FA3▪ &fالمنتصف: &#FFB3C1" + c.centerX() + ", " + c.centerZ(), "", "  &#55FF55▶ &fاضغط لفتح لوحة الأرض (انتقال / ثقة / إعدادات / حذف)")));
            }
        }
        if (curPage > 1) inv.setItem(cfg.getInt("prev-slot", 45), makeItem(Material.ARROW, "&#FFB3C1⬅ السابق", List.of()));
        if (curPage < maxPage) inv.setItem(cfg.getInt("next-slot", 53), makeItem(Material.ARROW, "&#FFB3C1➡ التالي", List.of()));
        inv.setItem(cfg.getInt("close-slot", 48), makeItem(Material.BARRIER, "&#FF5555✘ إغلاق", List.of()));
        inv.setItem(cfg.getInt("info-slot", 49), makeSkull(player, "&#FF4D6D🍓 ملخص أراضيك (" + claims.size() + ")", List.of()));
        inv.setItem(cfg.getInt("back-slot", 50), makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ رجوع", List.of()));
        player.openInventory(inv);
    }

    public void openManage(Player player, GriefPreventionHook.ClaimInfo claim) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.manage");
        GuiHolder holder = new GuiHolder("CLAIM_MANAGE").set("claimId", claim.id());
        Inventory inv = Bukkit.createInventory(holder, 45, TextUtil.color(cfg.getString("title", "Manage").replace("%id%", String.valueOf(claim.id()))));
        holder.setInventory(inv);
        fill(inv, Material.PINK_STAINED_GLASS_PANE, "&#FFB3C1🍓");
        inv.setItem(4, makeItem(Material.PAPER, "&#FF4D6D🍓 أرض #" + claim.id(), List.of("", "  &fالعالم: &#FFB3C1" + claim.worldName(), "  &fالمساحة: &#55FF55" + claim.area() + " بلوك")));
        inv.setItem(11, makeItem(Material.ENDER_PEARL, "&#55FF55الانتقال إلى الأرض", List.of("", "  &7انتقال آمن لمنتصف الأرض")));
        inv.setItem(13, makeItem(Material.PLAYER_HEAD, "&#FFAA00إدارة الثقة والصلاحيات", List.of("", "  &7إضافة أو تعديل أو إزالة لاعبين")));
        inv.setItem(15, makeItem(Material.COMPARATOR, "&#FFB3C1إعدادات الأرض", List.of("", "  &7الانفجارات، التوسيع، الأقسام الفرعية")));
        inv.setItem(40, makeItem(Material.LAVA_BUCKET, "&#FF5555✘ حذف الأرض نهائياً", List.of("", "  &7يفتح شاشة تأكيد الحذف")));
        inv.setItem(36, makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ رجوع لقائمة الأراضي", List.of()));
        player.openInventory(inv);
    }

    public void openSettings(Player player, GriefPreventionHook.ClaimInfo claim) {
        GuiHolder holder = new GuiHolder("CLAIM_SETTINGS").set("claimId", claim.id());
        Inventory inv = Bukkit.createInventory(holder, 45, TextUtil.color("&#FF4D6D🍓 إعدادات #" + claim.id()));
        holder.setInventory(inv);
        fill(inv, Material.PINK_STAINED_GLASS_PANE, "&#FFB3C1🍓");
        inv.setItem(20, makeItem(Material.TNT, "&#FF5555الانفجارات: " + (claim.explosivesAllowed() ? "&aمفعّلة" : "&cمعطّلة"), List.of("", "  &7اضغط للتبديل")));
        inv.setItem(22, makeItem(Material.OAK_FENCE, "&#FFAA00الأقسام الفرعية: &f" + claim.subdivisions(), List.of()));
        inv.setItem(24, makeItem(Material.GOLDEN_SHOVEL, "&#FFD700توسيع الأرض (استلام المجرفة)", List.of()));
        inv.setItem(31, makeItem(Material.ENDER_PEARL, "&#55FF55الانتقال للأرض", List.of()));
        inv.setItem(36, makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ رجوع", List.of()));
        player.openInventory(inv);
    }

    public void openTrust(Player player, GriefPreventionHook.ClaimInfo claim) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.trust");
        GuiHolder holder = new GuiHolder("CLAIM_TRUST").set("claimId", claim.id());
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color("&#FF4D6D🍓 ثقة #" + claim.id()));
        holder.setInventory(inv);
        fill(inv, Material.PINK_STAINED_GLASS_PANE, "&#FFB3C1🍓");
        Map<UUID, String> trusted = plugin.getGpHook().getTrustedPlayers(claim);
        List<Integer> slots = cfg.getIntegerList("player-slots");
        List<UUID> uuids = new ArrayList<>(trusted.keySet());
        holder.set("trustedUuids", uuids);
        if (uuids.isEmpty()) inv.setItem(22, makeItem(Material.BARRIER, "&#FF5555لا يوجد موثوقون", List.of()));
        else for (int i = 0; i < Math.min(uuids.size(), slots.size()); i++) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(uuids.get(i));
            inv.setItem(slots.get(i), makeSkull(op, "&#FF4D6D🍓 " + (op.getName() != null ? op.getName() : "لاعب"),
                    List.of("", "  &fالمستوى: &#FFAA00" + trusted.get(uuids.get(i)), "", "  &#55FF55▶ اضغط للتحكم (تغيير المستوى / إزالة)")));
        }
        String sel = getSelectedLevel(player.getUniqueId());
        for (String lvl : cfg.getStringList("level-order")) {
            inv.setItem(cfg.getInt("level-slots." + lvl, 46), makeItem(TextUtil.parseMaterial(cfg.getString("level-materials." + lvl), Material.BRICK),
                    "&#FFAA00" + cfg.getString("levels." + lvl, lvl) + (lvl.equals(sel) ? " &a✔ محدد" : ""), List.of("", "  &7اضغط لتحديد هذا المستوى قبل الإضافة")));
        }
        inv.setItem(49, makeItem(Material.LIME_DYE, "&#55FF55+ إضافة لاعب جديد", List.of("", "  &7المستوى المحدد: &#FFAA00" + sel)));
        inv.setItem(45, makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ رجوع", List.of()));
        player.openInventory(inv);
    }

    public void openTrustPlayerAction(Player player, long claimId, UUID targetId) {
        GuiHolder holder = new GuiHolder("CLAIM_TRUST_ACTION").set("claimId", claimId).set("targetId", targetId);
        OfflinePlayer op = Bukkit.getOfflinePlayer(targetId);
        String name = op.getName() != null ? op.getName() : "لاعب";
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color("&#FF4D6D🍓 إدارة صلاحية " + name));
        holder.setInventory(inv);
        fill(inv, Material.PINK_STAINED_GLASS_PANE, "&#FFB3C1🍓");
        inv.setItem(11, makeItem(Material.COMPARATOR, "&#FFAA00⚙ تغيير مستوى الصلاحية", List.of("", "  &7اختر بين: بناء / صناديق / دخول / إدارة")));
        inv.setItem(13, makeSkull(op, "&#FF4D6D🍓 " + name, List.of()));
        inv.setItem(15, makeItem(Material.RED_CONCRETE, "&#FF5555✘ إزالة الثقة نهائياً", List.of("", "  &7يفتح شاشة تأكيد الإزالة")));
        inv.setItem(22, makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ رجوع لقائمة الثقة", List.of()));
        player.openInventory(inv);
    }

    public void openLevelSelect(Player player, long claimId, UUID targetId) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.trust");
        GuiHolder holder = new GuiHolder("CLAIM_TRUST_LEVEL").set("claimId", claimId).set("targetId", targetId);
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color("&#FF4D6D🍓 تغيير المستوى"));
        holder.setInventory(inv);
        fill(inv, Material.PINK_STAINED_GLASS_PANE, "&#FFB3C1🍓");
        for (String lvl : cfg.getStringList("level-order")) inv.setItem(cfg.getInt("level-menu-slots." + lvl, 10), makeItem(TextUtil.parseMaterial(cfg.getString("level-materials." + lvl), Material.BRICK), "&#FFAA00" + cfg.getString("levels." + lvl, lvl), List.of("", "  &7اضغط للتطبيق فوراً")));
        inv.setItem(22, makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ رجوع", List.of()));
        player.openInventory(inv);
    }

    public void openConfirmDelete(Player player, GriefPreventionHook.ClaimInfo claim) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.confirm-delete");
        GuiHolder holder = new GuiHolder("CLAIM_CONFIRM_DELETE").set("claimId", claim.id());
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color("&#FF5555تأكيد حذف الأرض"));
        holder.setInventory(inv);
        ItemStack no = makeItem(Material.RED_STAINED_GLASS_PANE, "&#FF5555✘ لا (إلغاء)", List.of()), yes = makeItem(Material.LIME_STAINED_GLASS_PANE, "&#55FF55✔ نعم (حذف نهائي)", List.of());
        for (int s : cfg.getIntegerList("no-slots")) inv.setItem(s, no);
        for (int s : cfg.getIntegerList("yes-slots")) inv.setItem(s, yes);
        inv.setItem(13, makeItem(Material.PAPER, "&#FF4D6Dحذف #" + claim.id(), List.of()));
        player.openInventory(inv);
    }

    public void openConfirmUntrust(Player player, long claimId, UUID targetId) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.confirm-untrust");
        GuiHolder holder = new GuiHolder("CLAIM_CONFIRM_UNTRUST").set("claimId", claimId).set("targetId", targetId);
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color("&#FF5555تأكيد إزالة الثقة"));
        holder.setInventory(inv);
        ItemStack no = makeItem(Material.RED_STAINED_GLASS_PANE, "&#FF5555✘ لا (إلغاء)", List.of()), yes = makeItem(Material.LIME_STAINED_GLASS_PANE, "&#55FF55✔ نعم (إزالة الثقة)", List.of());
        for (int s : cfg.getIntegerList("no-slots")) inv.setItem(s, no);
        for (int s : cfg.getIntegerList("yes-slots")) inv.setItem(s, yes);
        inv.setItem(13, makeSkull(Bukkit.getOfflinePlayer(targetId), "&#FF4D6Dإزالة الثقة", List.of()));
        player.openInventory(inv);
    }

    private void fill(Inventory inv, Material mat, String name) { ItemStack f = makeItem(mat, name, List.of()); for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, f); }
    private ItemStack makeItem(Material mat, String name, List<String> lore) {
        ItemStack i = new ItemStack(mat); ItemMeta m = i.getItemMeta();
        if (m != null) { m.displayName(TextUtil.color(name)); if (!lore.isEmpty()) m.lore(TextUtil.colorList(lore)); i.setItemMeta(m); }
        return i;
    }
    private ItemStack makeSkull(OfflinePlayer owner, String name, List<String> lore) {
        ItemStack s = new ItemStack(Material.PLAYER_HEAD); SkullMeta m = (SkullMeta) s.getItemMeta();
        if (m != null) { m.setOwningPlayer(owner); m.displayName(TextUtil.color(name)); if (!lore.isEmpty()) m.lore(TextUtil.colorList(lore)); s.setItemMeta(m); }
        return s;
    }
}
