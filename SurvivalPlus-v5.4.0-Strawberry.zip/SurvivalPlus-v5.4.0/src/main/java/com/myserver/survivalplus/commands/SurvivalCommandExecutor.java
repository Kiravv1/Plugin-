package com.myserver.survivalplus.commands;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.models.PlayerShopData;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class SurvivalCommandExecutor implements CommandExecutor {
    private final SurvivalPlus plugin;
    public SurvivalCommandExecutor(SurvivalPlus plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        String name = command.getName().toLowerCase();
        if (name.equals("splus")) {
            if (!sender.hasPermission("survivalplus.admin")) { if (sender instanceof Player p) plugin.getConfigManager().send(p, "general.no-permission"); return true; }
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                plugin.getConfigManager().reload();
                if (sender instanceof Player p) plugin.getConfigManager().send(p, "general.reloaded");
                else sender.sendMessage("SurvivalPlus reloaded.");
                return true;
            }
            sender.sendMessage("§d🍓 SurvivalPlus v5.4.0 — /splus reload");
            return true;
        }
        if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }

        switch (name) {
            case "menu" -> TextUtil.runConsoleCommand(plugin.getConfigManager().getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%").replace("%player%", player.getName()));
            case "claimslist" -> plugin.getClaimGuiManager().openClaimsList(player, 1);
            case "notifications" -> plugin.getNotificationManager().openGui(player);
            case "shop" -> {
                if (args.length > 0) {
                    if (args[0].equalsIgnoreCase("manage") || args[0].equalsIgnoreCase("ادارة") || args[0].equalsIgnoreCase("إدارة")) {
                        plugin.getPlayerShopManager().openManageShop(player);
                        return true;
                    }
                    PlayerShopData target = plugin.getPlayerShopManager().getShopByName(args[0]);
                    if (target != null) { plugin.getPlayerShopManager().openPlayerShopView(player, target); return true; }
                }
                plugin.getPlayerShopManager().openDirectory(player);
            }
            case "rtp" -> {
                if (args.length > 0) {
                    plugin.getRtpManager().executeRtp(player, args[0]);
                    return true;
                }
                if (plugin.getConfigManager().getConfig().getBoolean("rtp.open-gui-on-command", true)) plugin.getRtpManager().openRtpGui(player);
                else plugin.getRtpManager().executeRtp(player, player.getWorld().getName());
            }
            case "claim" -> {
                if (args.length > 0 && args[0].equalsIgnoreCase("reload") && player.hasPermission("survivalplus.admin")) {
                    plugin.getConfigManager().reload(); plugin.getConfigManager().send(player, "general.reloaded"); return true;
                }
                if (args.length > 0 && plugin.getConfigManager().getConfig().getStringList("claims.subcommands.list").contains(args[0].toLowerCase())) plugin.getClaimGuiManager().openClaimsList(player, 1);
                else plugin.getClaimGuiManager().openHub(player);
            }
        }
        return true;
    }
}
