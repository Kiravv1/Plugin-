package com.myserver.survivalplus.models;

import java.util.*;

public class PlayerShopData {
    private final UUID ownerId;
    private String ownerName;
    private final List<ShopProduct> products = new ArrayList<>();
    private final Set<UUID> followers = new HashSet<>();
    private double totalEarnings;
    private double offlineEarnings;
    private int offlineItemsSold;
    private long boostExpiresAt;
    private double boostSales;
    private int boostVisits;

    public PlayerShopData(UUID ownerId, String ownerName) {
        this.ownerId = ownerId;
        this.ownerName = ownerName;
    }

    public UUID getOwnerId() { return ownerId; }
    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }
    public List<ShopProduct> getProducts() { return products; }
    public Set<UUID> getFollowers() { return followers; }
    public double getTotalEarnings() { return totalEarnings; }
    public void addEarnings(double amount) { this.totalEarnings += amount; }
    public double getOfflineEarnings() { return offlineEarnings; }
    public int getOfflineItemsSold() { return offlineItemsSold; }
    public void addOfflineSale(double money, int items) { this.offlineEarnings += money; this.offlineItemsSold += items; }
    public void clearOfflineSummary() { this.offlineEarnings = 0; this.offlineItemsSold = 0; }
    public long getBoostExpiresAt() { return boostExpiresAt; }
    public boolean isBoosted() { return boostExpiresAt > System.currentTimeMillis(); }
    public long getBoostRemainingMinutes() { return isBoosted() ? Math.max(1, (boostExpiresAt - System.currentTimeMillis()) / 60000L) : 0; }
    public void activateBoost(int minutes) { this.boostExpiresAt = System.currentTimeMillis() + (minutes * 60000L); this.boostSales = 0; this.boostVisits = 0; }
    public double getBoostSales() { return boostSales; }
    public void addBoostSale(double amount) { if (isBoosted()) this.boostSales += amount; }
    public int getBoostVisits() { return boostVisits; }
    public void addBoostVisit() { if (isBoosted()) this.boostVisits++; }
    public ShopProduct findMatching(org.bukkit.inventory.ItemStack item) {
        for (ShopProduct p : products) if (p.matches(item)) return p;
        return null;
    }
}
