package com.myserver.survivalplus.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TextUtil {
    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private static final LegacyComponentSerializer SERIALIZER = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors()
            .useUnusualXRepeatedCharacterHexFormat()
            .build();

    private TextUtil() {}

    public static Component color(String text) {
        if (text == null) return Component.empty();
        Matcher matcher = HEX_PATTERN.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) matcher.appendReplacement(sb, "&#" + matcher.group(1));
        matcher.appendTail(sb);
        return SERIALIZER.deserialize(sb.toString());
    }

    public static List<Component> colorList(List<String> lines) {
        List<Component> out = new ArrayList<>();
        if (lines == null) return out;
        for (String line : lines) out.add(color(line));
        return out;
    }

    public static Material parseMaterial(String name, Material fallback) {
        if (name == null || name.isBlank()) return fallback;
        try { return Material.valueOf(name.trim().toUpperCase()); } catch (IllegalArgumentException e) { return fallback; }
    }

    public static void playSound(Player player, String soundName) { playSound(player, soundName, 1.0f); }

    public static void playSound(Player player, String soundName, float pitch) {
        if (player == null || soundName == null || soundName.isBlank()) return;
        try {
            Sound sound = Sound.valueOf(soundName.trim().toUpperCase());
            player.playSound(player.getLocation(), sound, 1.0f, pitch);
        } catch (IllegalArgumentException ignored) {}
    }

    public static void spawnParticle(Player player, String particleName, int count) {
        if (player == null || particleName == null || particleName.isBlank()) return;
        try {
            Particle particle = Particle.valueOf(particleName.trim().toUpperCase());
            player.getWorld().spawnParticle(particle, player.getLocation().add(0, 1.0, 0), count, 0.5, 0.5, 0.5, 0.05);
        } catch (IllegalArgumentException ignored) {}
    }

    public static void runConsoleCommand(String command) {
        if (command == null || command.isBlank()) return;
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
    }

    public static void safeGiveItems(Player player, ItemStack template, int totalAmount) {
        if (player == null || template == null || totalAmount <= 0) return;
        int maxStack = Math.max(1, template.getMaxStackSize());
        int remaining = totalAmount;
        while (remaining > 0) {
            int give = Math.min(remaining, maxStack);
            ItemStack stack = template.clone();
            stack.setAmount(give);
            HashMap<Integer, ItemStack> overflow = player.getInventory().addItem(stack);
            for (ItemStack drop : overflow.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), drop);
            }
            remaining -= give;
        }
    }

    public static String stockBar(int stock, int referenceMax) {
        if (stock <= 0) return "&c░░░░░░░░░░ &70% (نفذ المخزون)";
        double ratio = Math.min(1.0, (double) stock / Math.max(1, referenceMax));
        int filled = (int) Math.round(ratio * 10);
        String color = ratio >= 0.5 ? "&a" : (ratio >= 0.2 ? "&e" : "&c");
        return color + "█".repeat(filled) + "&7" + "░".repeat(10 - filled) + " &f" + stock + " حبة";
    }
}
