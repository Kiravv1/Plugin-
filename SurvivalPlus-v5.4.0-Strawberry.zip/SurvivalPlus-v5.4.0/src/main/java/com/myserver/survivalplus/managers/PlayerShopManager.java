package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.models.PlayerShopData;
import com.myserver.survivalplus.models.ShopProduct;
import com.myserver.survivalplus.util.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.ShulkerBox;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class PlayerShopManager {
    private final SurvivalPlus plugin;
    private final Map<UUID, PlayerShopData> shops = new LinkedHashMap<>();
    private final File dataFile;

    public PlayerShopManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "playershops-data.yml");
    }

    public List<String> getAllShopNames() {
        List<String> names = new ArrayList<>();
        for (PlayerShopData s : shops.values()) {
            if (!s.getProducts().isEmpty()) names.add(s.getOwnerName());
        }
        return names;
    }

    public void loadData() {
        shops.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection sec = yml.getConfigurationSection("shops");
        if (sec == null) return;
        for (String uuidStr : sec.getKeys(false)) {
            try {
                UUID ownerId = UUID.fromString(uuidStr);
                ConfigurationSection s = sec.getConfigurationSection(uuidStr);
                if (s == null) continue;
                PlayerShopData data = new PlayerShopData(ownerId, s.getString("ownerName", "Player"));
                data.addEarnings(s.getDouble("totalEarnings", 0.0));
                if (s.getDouble("offlineEarnings", 0.0) > 0) data.addOfflineSale(s.getDouble("offlineEarnings", 0.0), s.getInt("offlineItemsSold", 0));
                long boostExp = s.getLong("boostExpiresAt", 0L);
                if (boostExp > System.currentTimeMillis()) data.activateBoost((int) Math.max(1, (boostExp - System.currentTimeMillis()) / 60000L));
                for (String f : s.getStringList("followers")) {
                    try { data.getFollowers().add(UUID.fromString(f)); } catch (IllegalArgumentException ignored) {}
                }
                ConfigurationSection prods = s.getConfigurationSection("products");
                if (prods != null) {
                    for (String pid : prods.getKeys(false)) {
                        ConfigurationSection p = prods.getConfigurationSection(pid);
                        if (p == null) continue;
                        ItemStack item = p.getItemStack("item");
                        if (item == null || item.getType().isAir()) continue;
                        ShopProduct sp = new ShopProduct(pid, item, p.getDouble("price", 10.0), p.getInt("stock", 0));
                        sp.addSold(p.getInt("sold", 0));
                        sp.setBulkDiscountEnabled(p.getBoolean("bulk", false));
                        data.getProducts().add(sp);
                    }
                }
                shops.put(ownerId, data);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public void saveData() {
        YamlConfiguration yml = new YamlConfiguration();
        for (PlayerShopData s : shops.values()) {
            String base = "shops." + s.getOwnerId();
            yml.set(base + ".ownerName", s.getOwnerName());
            yml.set(base + ".totalEarnings", s.getTotalEarnings());
            yml.set(base + ".offlineEarnings", s.getOfflineEarnings());
            yml.set(base + ".offlineItemsSold", s.getOfflineItemsSold());
            yml.set(base + ".boostExpiresAt", s.getBoostExpiresAt());
            List<String> fl = new ArrayList<>();
            for (UUID f : s.getFollowers()) fl.add(f.toString());
            yml.set(base + ".followers", fl);
            for (ShopProduct p : s.getProducts()) {
                String pb = base + ".products." + p.getId();
                yml.set(pb + ".item", p.getTemplate());
                yml.set(pb + ".price", p.getUnitPrice());
                yml.set(pb + ".stock", p.getStock());
                yml.set(pb + ".sold", p.getSoldCount());
                yml.set(pb + ".bulk", p.isBulkDiscountEnabled());
            }
        }
        try { yml.save(dataFile); } catch (IOException ignored) {}
    }

    public PlayerShopData getOrCreateShop(Player player) { return shops.computeIfAbsent(player.getUniqueId(), id -> new PlayerShopData(id, player.getName())); }
    public PlayerShopData getShop(UUID ownerId) { return shops.get(ownerId); }
    public PlayerShopData getShopByName(String name) {
        for (PlayerShopData s : shops.values()) if (s.getOwnerName().equalsIgnoreCase(name)) return s;
        return null;
    }

    public String getBadge(double totalSales) {
        ConfigurationSection badges = plugin.getConfigManager().getPlayerShop().getConfigurationSection("badges");
        if (badges == null) return "&7🥉 تاجر ناشئ";
        String best = "&7🥉 تاجر ناشئ"; double bestMin = -1;
        for (String key : badges.getKeys(false)) {
            double min = badges.getDouble(key + ".min-sales", 0);
            if (totalSales >= min && min >= bestMin) { bestMin = min; best = badges.getString(key + ".display", best); }
        }
        return best;
    }

    public double getMarketAveragePrice(Material mat) {
        double sum = 0; int count = 0;
        for (PlayerShopData s : shops.values()) for (ShopProduct p : s.getProducts()) if (p.getTemplate().getType() == mat) { sum += p.getUnitPrice(); count++; }
        return count > 0 ? Math.round((sum / count) * 10.0) / 10.0 : 0.0;
    }

    public void openDirectory(Player player) {
        ConfigurationSection gui = plugin.getConfigManager().getPlayerShop().getConfigurationSection("gui");
        GuiHolder holder = new GuiHolder("PSHOP_DIRECTORY");
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(gui.getString("directory-title", "Market")));
        holder.setInventory(inv);
        ItemStack filler = makeItem(TextUtil.parseMaterial(gui.getString("filler-material"), Material.PINK_STAINED_GLASS_PANE), gui.getString("filler-name", " "), List.of(), false);
        for (int i = 0; i < 54; i++) inv.setItem(i, filler);

        List<PlayerShopData> sorted = new ArrayList<>(shops.values());
        sorted.sort((a, b) -> {
            if (a.isBoosted() != b.isBoosted()) return a.isBoosted() ? -1 : 1;
            return Double.compare(b.getTotalEarnings(), a.getTotalEarnings());
        });

        List<UUID> order = new ArrayList<>();
        int[] slots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34};
        for (int i = 0; i < Math.min(sorted.size(), slots.length); i++) {
            PlayerShopData s = sorted.get(i);
            order.add(s.getOwnerId());
            OfflinePlayer op = Bukkit.getOfflinePlayer(s.getOwnerId());
            String title = (s.isBoosted() ? "&#FFD700✨ [مروّج] " : "&#FF4D6D🍓 ") + "&#FFF0F3متجر " + s.getOwnerName();
            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("  &#FF8FA3▪ &fالوسام: " + getBadge(s.getTotalEarnings()));
            lore.add("  &#FF8FA3▪ &fعدد المنتجات: &#55FF55" + s.getProducts().size());
            if (s.isBoosted()) lore.add("  &#FFD700⚡ متجر مروّج &7(متبقي " + s.getBoostRemainingMinutes() + " دقيقة)");
            lore.add("");
            lore.add("  &#55FF55▶ &fاضغط لزيارة المتجر");
            inv.setItem(slots[i], makeSkull(op, title, lore, s.isBoosted()));
        }
        holder.set("shopOrder", order);
        inv.setItem(gui.getInt("slots.directory-manage", 48), makeItem(TextUtil.parseMaterial(gui.getString("buttons.directory-manage-material"), Material.EMERALD), gui.getString("buttons.directory-manage-name", "⚙ إدارة متجرك"), List.of("", "  &7إضافة منتجات، تعبئة شاملة، وبوست"), false));
        inv.setItem(gui.getInt("slots.directory-back", 49), makeItem(TextUtil.parseMaterial(gui.getString("buttons.directory-back-material"), Material.SPECTRAL_ARROW), gui.getString("buttons.directory-back-name", "↩ رجوع"), List.of(), false));
        inv.setItem(gui.getInt("slots.directory-notif", 50), makeItem(TextUtil.parseMaterial(gui.getString("buttons.directory-notif-material"), Material.BELL), gui.getString("buttons.directory-notif-name", "🔔 الإشعارات"), List.of("", "  &7فتح/قفل إشعارات السوق والأراضي"), false));
        player.openInventory(inv);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }

    public void openManageShop(Player player) {
        PlayerShopData shop = getOrCreateShop(player);
        ConfigurationSection gui = plugin.getConfigManager().getPlayerShop().getConfigurationSection("gui");
        int ref = plugin.getConfigManager().getPlayerShop().getInt("settings.stock-bar-reference", 64);
        GuiHolder holder = new GuiHolder("PSHOP_MANAGE");
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(gui.getString("manage-title", "Manage Shop")));
        holder.setInventory(inv);
        ItemStack filler = makeItem(TextUtil.parseMaterial(gui.getString("filler-material"), Material.PINK_STAINED_GLASS_PANE), gui.getString("filler-name", " "), List.of(), false);
        for (int i = 0; i < 54; i++) inv.setItem(i, filler);

        int[] slots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34};
        for (int i = 0; i < Math.min(shop.getProducts().size(), slots.length); i++) {
            ShopProduct p = shop.getProducts().get(i);
            ItemStack display = p.getTemplate();
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                meta.lore(TextUtil.colorList(List.of("",
                        "  &#FF8FA3▪ &fالسعر: &#FFD700" + p.getUnitPrice() + "$ للحبة",
                        "  &#FF8FA3▪ &fالمخزون: " + TextUtil.stockBar(p.getStock(), ref),
                        "  &#FF8FA3▪ &fالمبيعات: &#55FF55" + p.getSoldCount() + " حبة",
                        "  &#FF8FA3▪ &fخصم الجملة (64): " + (p.isBulkDiscountEnabled() ? "&aمفعّل" : "&cمعطّل"),
                        "", "  &#55FF55▶ &fاضغط لتعديل المنتج (سعر / تعبئة / خصم / سحب)")));
                display.setItemMeta(meta);
            }
            inv.setItem(slots[i], display);
        }
        inv.setItem(gui.getInt("slots.manage-back", 45), makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ رجوع لسوق اللاعبين", List.of(), false));
        inv.setItem(gui.getInt("slots.manage-add", 47), makeItem(TextUtil.parseMaterial(gui.getString("buttons.manage-add-material"), Material.LIME_DYE), gui.getString("buttons.manage-add-name", "+ عرض الغرض"), List.of("", "  &7أمسك الغرض بيدك واضغط هنا"), false));
        inv.setItem(gui.getInt("slots.manage-restock-all", 48), makeItem(TextUtil.parseMaterial(gui.getString("buttons.manage-restock-material"), Material.HOPPER), gui.getString("buttons.manage-restock-name", "⚡ التعبئة الشاملة"), List.of("", "  &7يسحب كل الأغراض المطابقة (حقيبة + شلكر)"), false));
        inv.setItem(gui.getInt("slots.manage-dropbox", 49), makeItem(TextUtil.parseMaterial(gui.getString("buttons.manage-dropbox-material"), Material.CHEST), gui.getString("buttons.manage-dropbox-name", "📦 صندوق الإيداع"), List.of("", "  &7ارمِ الأغراض هنا لتتوزع تلقائياً"), false));
        inv.setItem(gui.getInt("slots.manage-boost", 51), makeItem(TextUtil.parseMaterial(gui.getString("buttons.manage-boost-material"), Material.NETHER_STAR), gui.getString("buttons.manage-boost-name", "⚡ ترويج المتجر"), List.of("", "  &7تصدّر السوق + إعلان تفاعلي بالشات"), shop.isBoosted()));
        player.openInventory(inv);
    }

    public void openEditProductGui(Player player, int productIndex) {
        PlayerShopData shop = getOrCreateShop(player);
        if (productIndex < 0 || productIndex >= shop.getProducts().size()) return;
        ShopProduct p = shop.getProducts().get(productIndex);
        GuiHolder holder = new GuiHolder("PSHOP_EDIT_PRODUCT").set("productIndex", productIndex);
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color(plugin.getConfigManager().getPlayerShop().getString("gui.edit-product-title", "Edit Product")));
        holder.setInventory(inv);
        ItemStack filler = makeItem(Material.PINK_STAINED_GLASS_PANE, "&#FFB3C1🍓", List.of(), false);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        inv.setItem(10, makeItem(Material.GOLD_INGOT, "&#FFD700✎ تعديل السعر", List.of("", "  &fالسعر الحالي: &#FFD700" + p.getUnitPrice() + "$", "  &7اضغط لكتابة السعر الجديد بالشات"), false));
        inv.setItem(12, makeItem(Material.HOPPER, "&#55FFFF⚡ تعبئة هذا المنتج فقط", List.of("", "  &7يسحب الأغراض المطابقة من حقيبتك والشلكر"), false));
        inv.setItem(13, p.getTemplate());
        inv.setItem(14, makeItem(p.isBulkDiscountEnabled() ? Material.LIME_DYE : Material.GRAY_DYE,
                "&#55FF55🏷 خصم الجملة (64): " + (p.isBulkDiscountEnabled() ? "&aمفعّل" : "&cمعطّل"),
                List.of("", "  &7خصم تلقائي عند شراء 64 حبة", "  &7اضغط للتبديل"), p.isBulkDiscountEnabled()));
        inv.setItem(16, makeItem(Material.RED_CONCRETE, "&#FF5555✘ سحب المخزون وإزالة العرض", List.of("", "  &7يعيد كل الكمية المتبقية لحقيبتك"), false));
        inv.setItem(22, makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ رجوع لإدارة المتجر", List.of(), false));
        player.openInventory(inv);
    }

    public void openBuyGui(Player buyer, PlayerShopData shop, int productIndex) {
        if (productIndex < 0 || productIndex >= shop.getProducts().size()) return;
        ShopProduct p = shop.getProducts().get(productIndex);
        GuiHolder holder = new GuiHolder("PSHOP_BUY").set("ownerId", shop.getOwnerId()).set("productIndex", productIndex);
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color(plugin.getConfigManager().getPlayerShop().getString("gui.buy-title", "Buy").replace("%owner%", shop.getOwnerName())));
        holder.setInventory(inv);
        ItemStack filler = makeItem(Material.PINK_STAINED_GLASS_PANE, "&#FFB3C1🍓", List.of(), false);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        double unit = p.getUnitPrice();
        double disc = plugin.getConfigManager().getPlayerShop().getDouble("settings.bulk-discount-percent", 10.0);
        double price64 = p.isBulkDiscountEnabled() ? (unit * 64 * (1.0 - disc / 100.0)) : (unit * 64);

        inv.setItem(10, makeItem(Material.LIME_STAINED_GLASS_PANE, "&#55FF55🛒 شراء 1 حبة", List.of("", "  &fالسعر: &#FFD700" + String.format("%.1f$", unit)), false));
        inv.setItem(11, makeItem(Material.LIME_CONCRETE, "&#55FF55🛒 شراء 16 حبة", List.of("", "  &fالسعر: &#FFD700" + String.format("%.1f$", unit * 16)), false));

        ItemStack preview = p.getTemplate();
        ItemMeta pm = preview.getItemMeta();
        if (pm != null) {
            pm.lore(TextUtil.colorList(List.of("", "  &fسعر الحبة: &#FFD700" + unit + "$", "  &fالمتوفر: &#55FF55" + p.getStock() + " حبة")));
            preview.setItemMeta(pm);
        }
        inv.setItem(13, preview);

        inv.setItem(15, makeItem(Material.EMERALD_BLOCK, "&#55FF55🛒 شراء 64 حبة (ستاك)",
                List.of("", "  &fالسعر: &#FFD700" + String.format("%.1f$", price64) + (p.isBulkDiscountEnabled() ? " &a(شامل خصم الجملة!)" : "")), p.isBulkDiscountEnabled()));
        inv.setItem(16, makeItem(Material.OAK_SIGN, "&#FFAA00✎ كمية مخصصة (بالشات)", List.of("", "  &7اضغط واكتب العدد الذي تريده"), false));
        inv.setItem(22, makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ رجوع للمتجر", List.of(), false));
        buyer.openInventory(inv);
    }

    public void openDropBox(Player player) {
        GuiHolder holder = new GuiHolder("PSHOP_DROPBOX");
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color(plugin.getConfigManager().getPlayerShop().getString("gui.dropbox-title", "DropBox")));
        holder.setInventory(inv);
        player.openInventory(inv);
    }

    public void processDropBoxClose(Player player, Inventory inv) {
        PlayerShopData shop = getOrCreateShop(player);
        int addedTotal = 0;
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack item = inv.getItem(i);
            if (item == null || item.getType().isAir()) continue;
            ShopProduct match = shop.findMatching(item);
            if (match != null) { match.addStock(item.getAmount()); addedTotal += item.getAmount(); }
            else TextUtil.safeGiveItems(player, item, item.getAmount());
        }
        if (addedTotal > 0) {
            saveData();
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.restock"), 1.3f);
            TextUtil.spawnParticle(player, "HAPPY_VILLAGER", 15);
            plugin.getConfigManager().send(player, "pshop.restock-all", "%total%", String.valueOf(addedTotal));
            notifyFollowers(shop);
        }
    }

    public void restockSingleProduct(Player player, ShopProduct targetProduct) {
        PlayerShopData shop = getOrCreateShop(player);
        int added = drainMatching(player, targetProduct);
        if (added > 0) {
            saveData();
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.restock"), 1.4f);
            plugin.getConfigManager().send(player, "pshop.restock-all", "%total%", String.valueOf(added));
            notifyFollowers(shop);
        } else plugin.getConfigManager().send(player, "pshop.restock-none");
    }

    public void restockAllFromInventoryAndShulkers(Player player) {
        PlayerShopData shop = getOrCreateShop(player);
        int totalAdded = 0;
        for (ShopProduct p : shop.getProducts()) totalAdded += drainMatching(player, p);
        if (totalAdded > 0) {
            saveData();
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.restock"), 1.4f);
            TextUtil.spawnParticle(player, "CHERRY_LEAVES", 20);
            plugin.getConfigManager().send(player, "pshop.restock-all", "%total%", String.valueOf(totalAdded));
            notifyFollowers(shop);
        } else plugin.getConfigManager().send(player, "pshop.restock-none");
    }

    private int drainMatching(Player player, ShopProduct product) {
        int added = 0;
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack stack = contents[i];
            if (stack == null || stack.getType().isAir()) continue;
            if (stack.getItemMeta() instanceof BlockStateMeta bsm && bsm.getBlockState() instanceof ShulkerBox shulker) {
                Inventory shulkerInv = shulker.getInventory();
                boolean modified = false;
                for (int s = 0; s < shulkerInv.getSize(); s++) {
                    ItemStack inside = shulkerInv.getItem(s);
                    if (inside != null && product.matches(inside)) {
                        product.addStock(inside.getAmount());
                        added += inside.getAmount();
                        shulkerInv.setItem(s, null);
                        modified = true;
                    }
                }
                if (modified) { bsm.setBlockState(shulker); stack.setItemMeta(bsm); }
                continue;
            }
            if (product.matches(stack)) {
                product.addStock(stack.getAmount());
                added += stack.getAmount();
                player.getInventory().setItem(i, null);
            }
        }
        return added;
    }

    public void openBoostGui(Player player) {
        ConfigurationSection cfg = plugin.getConfigManager().getPlayerShop();
        GuiHolder holder = new GuiHolder("PSHOP_BOOST");
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color(cfg.getString("gui.boost-title", "Boost")));
        holder.setInventory(inv);
        ItemStack filler = makeItem(TextUtil.parseMaterial(cfg.getString("gui.boost-filler-material"), Material.YELLOW_STAINED_GLASS_PANE), cfg.getString("gui.boost-filler-name", " "), List.of(), false);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);
        ConfigurationSection tiers = cfg.getConfigurationSection("boost-tiers");
        if (tiers != null) {
            for (String key : tiers.getKeys(false)) {
                ConfigurationSection t = tiers.getConfigurationSection(key);
                inv.setItem(t.getInt("slot", 13), makeItem(TextUtil.parseMaterial(t.getString("material"), Material.GOLD_INGOT), t.getString("name", key),
                        List.of("", "  &#FF8FA3▪ &fالمدة: &#55FF55" + t.getInt("duration-minutes") + " دقيقة", "  &#FF8FA3▪ &fالسعر: &#FFD700" + t.getDouble("price") + "$",
                                "  &#FF8FA3▪ &fالمميزات: &#FFF0F3تصدّر السوق + توهّج + إعلان للسيرفر", "", "  &#55FF55▶ &fاضغط للتفعيل الآن"), true));
            }
        }
        inv.setItem(cfg.getInt("gui.slots.boost-back", 22), makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ رجوع لإدارة المتجر", List.of(), false));
        player.openInventory(inv);
    }

    public void activateBoostTier(Player player, String tierKey) {
        if (!plugin.getVaultHook().isConnected()) { plugin.getConfigManager().send(player, "general.economy-missing"); return; }
        ConfigurationSection t = plugin.getConfigManager().getPlayerShop().getConfigurationSection("boost-tiers." + tierKey);
        if (t == null) return;
        double price = t.getDouble("price", 2500.0);
        int mins = t.getInt("duration-minutes", 60);
        if (!plugin.getVaultHook().has(player, price)) { plugin.getConfigManager().send(player, "pshop.no-money", "%price%", price + "$"); return; }
        long activeCount = shops.values().stream().filter(PlayerShopData::isBoosted).count();
        if (activeCount >= plugin.getConfigManager().getPlayerShop().getInt("settings.max-active-boosts", 5)) { plugin.getConfigManager().send(player, "pshop.boost-max"); return; }
        plugin.getVaultHook().withdraw(player, price);
        PlayerShopData shop = getOrCreateShop(player);
        shop.activateBoost(mins);
        saveData();
        player.closeInventory();
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.boost"), 1.0f);
        TextUtil.spawnParticle(player, "HEART", 25);
        plugin.getConfigManager().send(player, "pshop.boost-activated", "%mins%", String.valueOf(mins));
        if (t.getBoolean("broadcast", true)) {
            Component broadcast = TextUtil.color("&#FFD700⚡ &#FF4D6D🍓 &fقام &e" + player.getName() + " &fبترويج متجره! ")
                    .append(TextUtil.color("&#55FF55&l[اضغط للزيارة] ").clickEvent(ClickEvent.runCommand("/shop " + player.getName())))
                    .append(TextUtil.color("&7(بيدروك: /shop " + player.getName() + ")"));
            plugin.getNotificationManager().broadcast("shop-boosts", broadcast);
        }
    }

    public void openPlayerShopView(Player viewer, PlayerShopData shop) {
        if (!viewer.getUniqueId().equals(shop.getOwnerId())) shop.addBoostVisit();
        ConfigurationSection gui = plugin.getConfigManager().getPlayerShop().getConfigurationSection("gui");
        int ref = plugin.getConfigManager().getPlayerShop().getInt("settings.stock-bar-reference", 64);
        GuiHolder holder = new GuiHolder("PSHOP_VIEW").set("ownerId", shop.getOwnerId());
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(gui.getString("shop-title", "Shop").replace("%owner%", shop.getOwnerName())));
        holder.setInventory(inv);
        ItemStack filler = makeItem(TextUtil.parseMaterial(gui.getString("filler-material"), Material.PINK_STAINED_GLASS_PANE), gui.getString("filler-name", " "), List.of(), false);
        for (int i = 0; i < 54; i++) inv.setItem(i, filler);

        int[] slots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34};
        for (int i = 0; i < Math.min(shop.getProducts().size(), slots.length); i++) {
            ShopProduct p = shop.getProducts().get(i);
            ItemStack display = p.getTemplate();
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                meta.lore(TextUtil.colorList(List.of("",
                        "  &#FF8FA3▪ &fالسعر: &#FFD700" + p.getUnitPrice() + "$ للحبة",
                        "  &#FF8FA3▪ &fالمتوفر: " + TextUtil.stockBar(p.getStock(), ref),
                        "  &#FF8FA3▪ &fتم بيع: &#55FF55" + p.getSoldCount() + " حبة",
                        "", "  &#55FF55▶ &fاضغط لاختيار الكمية والشراء")));
                display.setItemMeta(meta);
            }
            inv.setItem(slots[i], display);
        }
        boolean isFav = shop.getFollowers().contains(viewer.getUniqueId());
        inv.setItem(gui.getInt("slots.view-favorite", 48), makeItem(isFav ? Material.RED_DYE : Material.PINK_DYE,
                isFav ? "&#FF5555❤ في المفضلة (اضغط للإزالة)" : "&#FFB3C1♡ إضافة للمفضلة (تنبيه التعبئة)", List.of(), isFav));
        inv.setItem(gui.getInt("slots.view-back", 49), makeItem(Material.SPECTRAL_ARROW, "&#FFAA00↩ رجوع لسوق اللاعبين", List.of(), false));
        viewer.openInventory(inv);
    }

    public void buyFromShop(Player buyer, PlayerShopData shop, int productIndex, int amount) {
        if (!plugin.getVaultHook().isConnected()) { plugin.getConfigManager().send(buyer, "general.economy-missing"); return; }
        if (buyer.getUniqueId().equals(shop.getOwnerId())) {
            plugin.getConfigManager().send(buyer, "pshop.buy-self");
            TextUtil.playSound(buyer, plugin.getConfigManager().getConfig().getString("sounds.error"));
            return;
        }
        if (productIndex < 0 || productIndex >= shop.getProducts().size()) return;
        ShopProduct p = shop.getProducts().get(productIndex);
        if (p.getStock() <= 0) { plugin.getConfigManager().send(buyer, "pshop.out-of-stock"); TextUtil.playSound(buyer, plugin.getConfigManager().getConfig().getString("sounds.error")); return; }
        int actualAmount = Math.min(amount, p.getStock());
        double total = p.getUnitPrice() * actualAmount;
        if (actualAmount >= 64 && p.isBulkDiscountEnabled()) total *= (1.0 - (plugin.getConfigManager().getPlayerShop().getDouble("settings.bulk-discount-percent", 10.0) / 100.0));
        if (!plugin.getVaultHook().has(buyer, total)) { plugin.getConfigManager().send(buyer, "pshop.no-money", "%price%", String.format("%.1f$", total)); return; }

        plugin.getVaultHook().withdraw(buyer, total);
        plugin.getVaultHook().deposit(Bukkit.getOfflinePlayer(shop.getOwnerId()), total);
        p.removeStock(actualAmount); p.addSold(actualAmount); shop.addEarnings(total); shop.addBoostSale(total);
        TextUtil.safeGiveItems(buyer, p.getTemplate(), actualAmount);
        saveData();

        TextUtil.playSound(buyer, plugin.getConfigManager().getConfig().getString("sounds.success"), 1.3f);
        plugin.getConfigManager().send(buyer, "pshop.buy-success", "%amount%", String.valueOf(actualAmount), "%item%", p.getTemplate().getType().name(), "%owner%", shop.getOwnerName(), "%price%", String.format("%.1f", total));

        Player onlineOwner = Bukkit.getPlayer(shop.getOwnerId());
        if (onlineOwner != null && onlineOwner.isOnline()) {
            plugin.getNotificationManager().notify(onlineOwner, "shop-sales", "pshop.seller-notify",
                    "%amount%", String.valueOf(actualAmount), "%item%", p.getTemplate().getType().name(),
                    "%buyer%", buyer.getName(), "%price%", String.format("%.1f", total));

            int lowThreshold = plugin.getConfigManager().getNotifications().getInt("global.low-stock-threshold", 8);
            if (p.getStock() == 0) {
                plugin.getNotificationManager().notify(onlineOwner, "shop-stock", "pshop.stock-empty-alert", "%item%", p.getTemplate().getType().name());
            } else if (p.getStock() <= lowThreshold) {
                plugin.getNotificationManager().notify(onlineOwner, "shop-stock", "pshop.stock-low-alert", "%item%", p.getTemplate().getType().name(), "%left%", String.valueOf(p.getStock()));
            }
        } else {
            shop.addOfflineSale(total, actualAmount);
            saveData();
        }
        openPlayerShopView(buyer, shop);
    }

    private void notifyFollowers(PlayerShopData shop) {
        for (UUID f : shop.getFollowers()) {
            Player fp = Bukkit.getPlayer(f);
            if (fp != null && fp.isOnline()) plugin.getNotificationManager().notify(fp, "shop-favorites", "pshop.fav-alert", "%owner%", shop.getOwnerName());
        }
    }

    private ItemStack makeItem(Material mat, String name, List<String> lore, boolean glow) {
        ItemStack item = new ItemStack(mat); ItemMeta meta = item.getItemMeta();
        if (meta != null) { meta.displayName(TextUtil.color(name)); if (!lore.isEmpty()) meta.lore(TextUtil.colorList(lore)); if (glow) { meta.addEnchant(Enchantment.UNBREAKING, 1, true); meta.addItemFlags(ItemFlag.HIDE_ENCHANTS); } item.setItemMeta(meta); }
        return item;
    }

    private ItemStack makeSkull(OfflinePlayer owner, String name, List<String> lore, boolean glow) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD); SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta != null) { meta.setOwningPlayer(owner); meta.displayName(TextUtil.color(name)); if (!lore.isEmpty()) meta.lore(TextUtil.colorList(lore)); if (glow) { meta.addEnchant(Enchantment.UNBREAKING, 1, true); meta.addItemFlags(ItemFlag.HIDE_ENCHANTS); } skull.setItemMeta(meta); }
        return skull;
    }
}
