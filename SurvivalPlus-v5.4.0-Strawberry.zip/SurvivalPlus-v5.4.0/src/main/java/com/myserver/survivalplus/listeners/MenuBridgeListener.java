package com.myserver.survivalplus.listeners;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.models.PlayerShopData;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class MenuBridgeListener implements Listener {
    private final SurvivalPlus plugin;
    public MenuBridgeListener(SurvivalPlus plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!plugin.getConfigManager().getConfig().getBoolean("menu-bridge.intercept-menu-command", true)) return;
        String msg = event.getMessage().trim();
        if (!msg.startsWith("/")) return;
        String label = msg.substring(1).split(" ")[0].toLowerCase();
        for (String r : plugin.getConfigManager().getConfig().getStringList("menu-bridge.redirect-commands")) {
            if (r.equalsIgnoreCase(label)) {
                event.setCancelled(true);
                TextUtil.runConsoleCommand(plugin.getConfigManager().getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                        .replace("%player%", event.getPlayer().getName()));
                return;
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        PlayerShopData shop = plugin.getPlayerShopManager().getShop(event.getPlayer().getUniqueId());
        if (shop != null && shop.getOfflineEarnings() > 0) {
            plugin.getNotificationManager().notify(event.getPlayer(), "shop-sales", "pshop.offline-summary",
                    "%earnings%", String.format("%.1f", shop.getOfflineEarnings()),
                    "%items%", String.valueOf(shop.getOfflineItemsSold()));
            shop.clearOfflineSummary();
            plugin.getPlayerShopManager().saveData();
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getTeleportManager().cancel(event.getPlayer().getUniqueId());
        plugin.getChatPromptManager().cancel(event.getPlayer().getUniqueId());
    }
}
