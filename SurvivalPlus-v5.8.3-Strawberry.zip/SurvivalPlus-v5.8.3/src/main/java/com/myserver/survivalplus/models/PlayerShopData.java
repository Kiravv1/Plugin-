package com.myserver.survivalplus.models;

import org.bukkit.Material;
import java.util.*;

public class PlayerShopData {
    private final UUID ownerId;
    private String ownerName;
    private String customName;
    private String customDescription;
    private Material customIcon;
    private boolean open = true;
    private final List<ShopProduct> products = new ArrayList<>();
    private final Set<UUID> followers = new HashSet<>();
    private double totalEarnings;
    private double offlineEarnings;
    private int offlineItemsSold;
    private long boostExpiresAt;

    public PlayerShopData(UUID ownerId, String ownerName) {
        this.ownerId = ownerId;
        this.ownerName = ownerName;
        this.customName = "متجر " + ownerName;
        this.customDescription = "أجود البضائع بأفضل الأسعار";
        this.customIcon = null;
    }

    public UUID getOwnerId() { return ownerId; }
    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }
    public String getCustomName() { return customName != null ? customName : "متجر " + ownerName; }
    public void setCustomName(String customName) { this.customName = customName; }
    public String getCustomDescription() { return customDescription != null ? customDescription : "أجود البضائع بأفضل الأسعار"; }
    public void setCustomDescription(String customDescription) { this.customDescription = customDescription; }
    public Material getCustomIcon() { return customIcon; }
    public void setCustomIcon(Material customIcon) { this.customIcon = customIcon; }
    public boolean isOpen() { return open; }
    public void setOpen(boolean open) { this.open = open; }
    public List<ShopProduct> getProducts() { return products; }
    public Set<UUID> getFollowers() { return followers; }
    public double getTotalEarnings() { return totalEarnings; }
    public void addEarnings(double amount) { this.totalEarnings += amount; }
    public int getTotalItemsSold() {
        int sum = 0;
        for (ShopProduct p : products) sum += p.getSoldCount();
        return sum;
    }
    public double getOfflineEarnings() { return offlineEarnings; }
    public int getOfflineItemsSold() { return offlineItemsSold; }
    public void addOfflineSale(double money, int items) { this.offlineEarnings += money; this.offlineItemsSold += items; }
    public void clearOfflineSummary() { this.offlineEarnings = 0; this.offlineItemsSold = 0; }
    public long getBoostExpiresAt() { return boostExpiresAt; }
    public boolean isBoosted() { return boostExpiresAt > System.currentTimeMillis(); }
    public long getBoostRemainingMinutes() { return isBoosted() ? Math.max(1, (boostExpiresAt - System.currentTimeMillis()) / 60000L) : 0; }
    public void activateBoost(int minutes) { this.boostExpiresAt = System.currentTimeMillis() + (minutes * 60000L); }
    public ShopProduct findMatching(org.bukkit.inventory.ItemStack item) {
        for (ShopProduct p : products) if (p.matches(item)) return p;
        return null;
    }
}
