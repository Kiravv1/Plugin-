package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.models.PlayerShopData;
import com.myserver.survivalplus.models.ShopProduct;
import com.myserver.survivalplus.util.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.ShulkerBox;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class PlayerShopManager {
    private final SurvivalPlus plugin;
    private final Map<UUID, PlayerShopData> shops = new LinkedHashMap<>();
    private final File dataFile;

    public PlayerShopManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "playershops-data.yml");
    }

    public List<String> getAllShopNames() {
        List<String> names = new ArrayList<>();
        for (PlayerShopData s : shops.values()) if (!s.getProducts().isEmpty()) names.add(s.getOwnerName());
        return names;
    }

    public void loadData() {
        shops.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection sec = yml.getConfigurationSection("shops");
        if (sec == null) return;
        for (String uuidStr : sec.getKeys(false)) {
            try {
                UUID ownerId = UUID.fromString(uuidStr);
                ConfigurationSection s = sec.getConfigurationSection(uuidStr);
                if (s == null) continue;
                PlayerShopData data = new PlayerShopData(ownerId, s.getString("ownerName", "Player"));
                if (s.contains("customName")) data.setCustomName(s.getString("customName"));
                if (s.contains("customDescription")) data.setCustomDescription(s.getString("customDescription"));
                if (s.contains("customIcon")) data.setCustomIcon(TextUtil.parseMaterial(s.getString("customIcon"), null));
                data.setOpen(s.getBoolean("open", true));
                data.addEarnings(s.getDouble("totalEarnings", 0.0));
                if (s.getDouble("offlineEarnings", 0.0) > 0) data.addOfflineSale(s.getDouble("offlineEarnings", 0.0), s.getInt("offlineItemsSold", 0));
                long boostExp = s.getLong("boostExpiresAt", 0L);
                if (boostExp > System.currentTimeMillis()) data.activateBoost((int) Math.max(1, (boostExp - System.currentTimeMillis()) / 60000L));
                for (String f : s.getStringList("followers")) {
                    try { data.getFollowers().add(UUID.fromString(f)); } catch (IllegalArgumentException ignored) {}
                }
                ConfigurationSection prods = s.getConfigurationSection("products");
                if (prods != null) {
                    for (String pid : prods.getKeys(false)) {
                        ConfigurationSection p = prods.getConfigurationSection(pid);
                        if (p == null) continue;
                        ItemStack item = p.getItemStack("item");
                        if (item == null || item.getType().isAir()) continue;
                        ShopProduct sp = new ShopProduct(pid, item, p.getDouble("price", 10.0), p.getInt("stock", 0));
                        sp.addSold(p.getInt("sold", 0));
                        sp.setBulkDiscountEnabled(p.getBoolean("bulk", false));
                        data.getProducts().add(sp);
                    }
                }
                shops.put(ownerId, data);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public void saveData() {
        YamlConfiguration yml = new YamlConfiguration();
        for (PlayerShopData s : shops.values()) {
            String base = "shops." + s.getOwnerId();
            yml.set(base + ".ownerName", s.getOwnerName());
            yml.set(base + ".customName", s.getCustomName());
            yml.set(base + ".customDescription", s.getCustomDescription());
            yml.set(base + ".customIcon", s.getCustomIcon() != null ? s.getCustomIcon().name() : null);
            yml.set(base + ".open", s.isOpen());
            yml.set(base + ".totalEarnings", s.getTotalEarnings());
            yml.set(base + ".offlineEarnings", s.getOfflineEarnings());
            yml.set(base + ".offlineItemsSold", s.getOfflineItemsSold());
            yml.set(base + ".boostExpiresAt", s.getBoostExpiresAt());
            List<String> fl = new ArrayList<>();
            for (UUID f : s.getFollowers()) fl.add(f.toString());
            yml.set(base + ".followers", fl);
            for (ShopProduct p : s.getProducts()) {
                String pb = base + ".products." + p.getId();
                yml.set(pb + ".item", p.getTemplate());
                yml.set(pb + ".price", p.getUnitPrice());
                yml.set(pb + ".stock", p.getStock());
                yml.set(pb + ".sold", p.getSoldCount());
                yml.set(pb + ".bulk", p.isBulkDiscountEnabled());
            }
        }
        try { yml.save(dataFile); } catch (IOException ignored) {}
    }

    public PlayerShopData getOrCreateShop(Player player) { return shops.computeIfAbsent(player.getUniqueId(), id -> new PlayerShopData(id, player.getName())); }
    public PlayerShopData getShop(UUID ownerId) { return shops.get(ownerId); }
    public PlayerShopData getShopByName(String name) {
        for (PlayerShopData s : shops.values()) if (s.getOwnerName().equalsIgnoreCase(name)) return s;
        return null;
    }

    public void listHandItemWithPrice(Player player, double price) {
        if (!Double.isFinite(price) || price <= 0 || price > 1_000_000_000) { plugin.getConfigManager().send(player, "pshop.invalid-price"); return; }
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) { plugin.getConfigManager().send(player, "pshop.hold-item"); return; }
        PlayerShopData shop = getOrCreateShop(player);
        ShopProduct existing = shop.findMatching(hand);
        if (existing != null) {
            existing.addStock(hand.getAmount());
            player.getInventory().setItemInMainHand(null);
            saveData();
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.restock"), 1.3f);
            plugin.getConfigManager().send(player, "pshop.merged", "%amount%", TextUtil.formatInt(hand.getAmount()), "%item%", hand.getType().name());
            return;
        }
        int max = player.hasPermission("survivalplus.shop.vip")
                ? plugin.getConfigManager().getPlayerShop().getInt("settings.vip-max-listings", 27)
                : plugin.getConfigManager().getPlayerShop().getInt("settings.default-max-listings", 9);
        if (shop.getProducts().size() >= max) { plugin.getConfigManager().send(player, "pshop.max-listings", "%max%", String.valueOf(max)); return; }
        int amt = hand.getAmount();
        ItemStack copy = hand.clone();
        player.getInventory().setItemInMainHand(null);
        shop.getProducts().add(new ShopProduct(null, copy, price, amt));
        saveData();
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.success"), 1.3f);
        plugin.getConfigManager().send(player, "pshop.listed", "%amount%", TextUtil.formatInt(amt), "%item%", copy.getType().name(), "%price%", TextUtil.formatMoney(price));
    }

    public String getBadge(double totalSales) {
        ConfigurationSection badges = plugin.getConfigManager().getPlayerShop().getConfigurationSection("badges");
        if (badges == null) return "&7تاجر ناشئ";
        String best = "&7تاجر ناشئ"; double bestMin = -1;
        for (String key : badges.getKeys(false)) {
            double min = badges.getDouble(key + ".min-sales", 0);
            if (totalSales >= min && min >= bestMin) { bestMin = min; best = badges.getString(key + ".display", best); }
        }
        return best;
    }

    public double getMarketAveragePrice(Material mat) {
        double sum = 0; int count = 0;
        for (PlayerShopData s : shops.values()) for (ShopProduct p : s.getProducts()) if (p.getTemplate().getType() == mat) { sum += p.getUnitPrice(); count++; }
        return count > 0 ? Math.round((sum / count) * 10.0) / 10.0 : 0.0;
    }

    public void openDirectory(Player player) {
        ConfigurationSection gui = plugin.getConfigManager().getPlayerShop().getConfigurationSection("gui");
        GuiHolder holder = new GuiHolder("PSHOP_DIRECTORY");
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(gui.getString("directory-title", "سوق اللاعبين")));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        List<PlayerShopData> sorted = new ArrayList<>(shops.values());
        sorted.sort((a, b) -> {
            if (a.isOpen() != b.isOpen()) return a.isOpen() ? -1 : 1;
            if (a.isBoosted() != b.isBoosted()) return a.isBoosted() ? -1 : 1;
            return Double.compare(b.getTotalEarnings(), a.getTotalEarnings());
        });

        List<UUID> order = new ArrayList<>();
        int[] slots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34};
        for (int i = 0; i < Math.min(sorted.size(), slots.length); i++) {
            PlayerShopData s = sorted.get(i);
            order.add(s.getOwnerId());
            OfflinePlayer op = Bukkit.getOfflinePlayer(s.getOwnerId());
            String prefix = !s.isOpen() ? "&#EF476F[مغلق] " : (s.isBoosted() ? "&#FFD166★ [مروّج] " : "&#FF4D6D✦ ");
            String title = prefix + "&#FFF0F3" + s.getCustomName();
            List<String> lore = new ArrayList<>();
            lore.add("  &#FFCCD5❝ " + s.getCustomDescription() + " ❞");
            lore.add(TextUtil.DIVIDER);
            lore.add("  &#FF8FA3▪ &fالمالك: &#FFB3C1" + s.getOwnerName());
            lore.add("  &#FF8FA3▪ &fالوسام: " + getBadge(s.getTotalEarnings()));
            lore.add("  &#FF8FA3▪ &fالمنتجات: &#06D6A0" + TextUtil.formatInt(s.getProducts().size()) + " &8| &fالمتابعون: &#FF758F" + TextUtil.formatInt(s.getFollowers().size()));
            double discPct = plugin.getConfigManager().getPlayerShop().getDouble("settings.bulk-discount-percent", 10.0);
            boolean hasBulk = s.getProducts().stream().anyMatch(ShopProduct::isBulkDiscountEnabled);
            if (hasBulk) lore.add("  &#06D6A0★ &#FFF0F3Sale : &#FFD166" + TextUtil.formatMoney(discPct) + "% &#FFB3C1for 64");
            if (s.isBoosted()) lore.add("  &#FFD166✦ ترويج نشط &7(متبقي " + TextUtil.formatInt(s.getBoostRemainingMinutes()) + " دقيقة)");
            lore.add(TextUtil.DIVIDER);
            lore.add(s.isOpen() ? "  &#06D6A0» &fاضغط لزيارة المتجر" : "  &#EF476F✘ &7المتجر مغلق مؤقتاً");

            inv.setItem(slots[i], (s.getCustomIcon() != null)
                    ? TextUtil.makeItem(s.getCustomIcon(), title, lore, s.isBoosted() && s.isOpen())
                    : TextUtil.makeSkull(op, title, lore, s.isBoosted() && s.isOpen()));
        }
        holder.set("shopOrder", order);
        inv.setItem(48, TextUtil.makeItem(Material.EMERALD, "&#06D6A0✦ إدارة متجرك", List.of("", "  &7إضافة منتجات، تخصيص، وترويج"), false));
        inv.setItem(49, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFB703« العودة للقائمة الرئيسية", List.of(), false));
        inv.setItem(50, TextUtil.makeItem(Material.BELL, "&#FFD166✦ إعدادات الإشعارات", List.of(), false));
        player.openInventory(inv);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }

    public void openManageShop(Player player) {
        PlayerShopData shop = getOrCreateShop(player);
        ConfigurationSection gui = plugin.getConfigManager().getPlayerShop().getConfigurationSection("gui");
        GuiHolder holder = new GuiHolder("PSHOP_MANAGE");
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(gui.getString("manage-title", "إدارة متجرك")));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        // Header summary card at slot 4
        inv.setItem(4, TextUtil.makeSkull(player, "&#FF4D6D★ &#FFF0F3" + shop.getCustomName(),
                List.of("  &#FFCCD5❝ " + shop.getCustomDescription() + " ❞",
                        TextUtil.DIVIDER,
                        "  &#FF8FA3▪ &fالحالة: " + (shop.isOpen() ? "&#06D6A0✔ مفتوح" : "&#EF476F✘ مغلق"),
                        "  &#FF8FA3▪ &fإجمالي الأرباح: &#FFD166" + TextUtil.formatPrice(shop.getTotalEarnings()),
                        "  &#FF8FA3▪ &fالمبيعات: &#06D6A0" + TextUtil.formatInt(shop.getTotalItemsSold()) + " حبة",
                        "  &#FF8FA3▪ &fالوسام: " + getBadge(shop.getTotalEarnings())), shop.isBoosted()));

        int[] slots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34};
        for (int i = 0; i < Math.min(shop.getProducts().size(), slots.length); i++) {
            ShopProduct p = shop.getProducts().get(i);
            ItemStack display = p.getTemplate();
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                meta.lore(TextUtil.colorList(List.of(
                        TextUtil.DIVIDER,
                        "  &#FF8FA3▪ &fالسعر: &#FFD166" + TextUtil.formatPrice(p.getUnitPrice()) + " &7للحبة",
                        "  &#FF8FA3▪ &fالمخزون: " + (p.getStock() > 0 ? "&#06D6A0" + TextUtil.formatInt(p.getStock()) + " حبة" : "&#EF476Fنفذ المخزون"),
                        "  &#FF8FA3▪ &fالمبيعات: &#FFB3C1" + TextUtil.formatInt(p.getSoldCount()) + " حبة",
                        "  &#06D6A0★ &#FFF0F3Sale : " + (p.isBulkDiscountEnabled() ? "&#FFD166" + TextUtil.formatMoney(plugin.getConfigManager().getPlayerShop().getDouble("settings.bulk-discount-percent", 10.0)) + "% &#FFB3C1for 64" : "&7معطّل"),
                        TextUtil.DIVIDER,
                        "  &#06D6A0» &fاضغط لتعديل المنتج")));
                display.setItemMeta(meta);
            }
            inv.setItem(slots[i], display);
        }
        inv.setItem(45, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFB703« رجوع للسوق", List.of(), false));
        inv.setItem(47, TextUtil.makeItem(Material.LIME_DYE, "&#06D6A0+ عرض الغرض في يدك", List.of("", "  &7أو استخدم: &#FFD166/shop add <السعر>"), false));
        inv.setItem(48, TextUtil.makeItem(Material.HOPPER, "&#72EFDD✦ تعبئة شاملة", List.of("", "  &7يسحب من الحقيبة والشلكرات تلقائياً"), false));
        inv.setItem(49, TextUtil.makeItem(Material.CHEST, "&#FFB703✦ صندوق الإيداع السريع", List.of("", "  &7ارمِ الأغراض وأغلقه للتوزيع التلقائي"), false));
        inv.setItem(50, TextUtil.makeItem(Material.COMPARATOR, "&#FFB3C1✦ إعدادات وتخصيص المتجر", List.of("", "  &7الاسم، الوصف، الأيقونة، الحالة، والإحصائيات"), false));
        inv.setItem(51, TextUtil.makeItem(Material.NETHER_STAR, "&#FFD166★ ترويج المتجر", List.of("", shop.isBoosted() ? "  &#06D6A0مروّج حالياً &7(متبقي " + shop.getBoostRemainingMinutes() + "د)" : "  &7تصدّر السوق + إعلان للسيرفر"), shop.isBoosted()));
        player.openInventory(inv);
    }

    // EXPANDED 36-Slot Rich Shop Settings GUI!
    public void openShopSettingsGui(Player player) {
        PlayerShopData shop = getOrCreateShop(player);
        GuiHolder holder = new GuiHolder("PSHOP_SETTINGS");
        Inventory inv = Bukkit.createInventory(holder, 36, TextUtil.color(plugin.getConfigManager().getPlayerShop().getString("gui.settings-title", "تخصيص متجرك")));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        inv.setItem(4, TextUtil.makeSkull(player, "&#FFD166★ إحصائيات متجرك",
                List.of(TextUtil.DIVIDER,
                        "  &#FF8FA3▪ &fالأرباح الكلية: &#FFD166" + TextUtil.formatPrice(shop.getTotalEarnings()),
                        "  &#FF8FA3▪ &fإجمالي المبيعات: &#06D6A0" + TextUtil.formatInt(shop.getTotalItemsSold()) + " حبة",
                        "  &#FF8FA3▪ &fالمتابعون: &#FF758F" + TextUtil.formatInt(shop.getFollowers().size()),
                        "  &#FF8FA3▪ &fالوسام: " + getBadge(shop.getTotalEarnings()),
                        TextUtil.DIVIDER), false));

        inv.setItem(10, TextUtil.makeItem(Material.NAME_TAG, "&#FFD166✦ تغيير اسم المتجر",
                List.of("", "  &#FF8FA3▪ &fالحالي: &#FFF0F3" + shop.getCustomName(), "", "  &#06D6A0» &fاضغط للتعديل"), false));

        inv.setItem(12, TextUtil.makeItem(Material.WRITABLE_BOOK, "&#FFB3C1✦ تغيير وصف المتجر",
                List.of("", "  &#FFCCD5❝ " + shop.getCustomDescription() + " ❞", "", "  &#06D6A0» &fاضغط لكتابة وصف جديد"), false));

        inv.setItem(14, TextUtil.makeItem(shop.getCustomIcon() != null ? shop.getCustomIcon() : Material.PLAYER_HEAD,
                "&#72EFDD✦ تغيير أيقونة المتجر",
                List.of("", "  &7أمسك الغرض الذي تريده كأيقونة", "  &7واضغط هنا &8(يد فارغة = رأسك)", "", "  &#06D6A0» &fاضغط للتغيير"), false));

        inv.setItem(16, TextUtil.makeItem(shop.isOpen() ? Material.LIME_DYE : Material.RED_DYE,
                (shop.isOpen() ? "&#06D6A0✦ حالة المتجر: مفتوح" : "&#EF476F✦ حالة المتجر: مغلق"),
                List.of("", "  &7أغلق متجرك مؤقتاً أثناء الترتيب", "  &7أو افتحه لاستقبال المشترين", "", "  &#06D6A0» &fاضغط للتبديل"), shop.isOpen()));

        boolean allBulk = !shop.getProducts().isEmpty() && shop.getProducts().stream().allMatch(ShopProduct::isBulkDiscountEnabled);
        double disc = plugin.getConfigManager().getPlayerShop().getDouble("settings.bulk-discount-percent", 10.0);
        inv.setItem(22, TextUtil.makeItem(Material.GOLD_BLOCK,
                "&#FFD166✦ خصم الجملة الشامل (" + TextUtil.formatMoney(disc) + "%)",
                List.of("", "  &7تفعيل أو تعطيل خصم الجملة (64 حبة)", "  &7على جميع منتجات متجرك دفعة واحدة", "",
                        "  &#FF8FA3▪ &fالحالة: " + (allBulk ? "&#06D6A0مفعّل للكل" : "&7مخصّص / معطّل"),
                        "  &#06D6A0» &fاضغط للتبديل للكل"), allBulk));

        inv.setItem(31, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFB703« رجوع لإدارة المتجر", List.of(), false));
        player.openInventory(inv);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }

    public void openEditProductGui(Player player, int productIndex) {
        PlayerShopData shop = getOrCreateShop(player);
        if (productIndex < 0 || productIndex >= shop.getProducts().size()) return;
        ShopProduct p = shop.getProducts().get(productIndex);
        GuiHolder holder = new GuiHolder("PSHOP_EDIT_PRODUCT").set("productIndex", productIndex);
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color(plugin.getConfigManager().getPlayerShop().getString("gui.edit-product-title", "تعديل المنتج")));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);
        inv.setItem(10, TextUtil.makeItem(Material.GOLD_INGOT, "&#FFD166✦ تعديل السعر", List.of("", "  &#FF8FA3▪ &fالحالي: &#FFD166" + TextUtil.formatPrice(p.getUnitPrice())), false));
        inv.setItem(12, TextUtil.makeItem(Material.HOPPER, "&#72EFDD✦ تعبئة هذا المنتج", List.of("", "  &7يسحب من الحقيبة والشلكرات"), false));
        inv.setItem(13, p.getTemplate());
        inv.setItem(14, TextUtil.makeItem(p.isBulkDiscountEnabled() ? Material.LIME_DYE : Material.GRAY_DYE, "&#06D6A0✦ خصم الجملة: " + (p.isBulkDiscountEnabled() ? "&#06D6A0مفعّل" : "&7معطّل"), List.of("", "  &7خصم عند شراء 64 حبة"), p.isBulkDiscountEnabled()));
        inv.setItem(16, TextUtil.makeItem(Material.RED_CONCRETE, "&#EF476F✘ سحب وإزالة العرض", List.of("", "  &7يعيد كل الكمية لحقيبتك"), false));
        inv.setItem(22, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFB703« رجوع لإدارة المتجر", List.of(), false));
        player.openInventory(inv);
    }

    public void openBuyGui(Player buyer, PlayerShopData shop, int productIndex) {
        if (productIndex < 0 || productIndex >= shop.getProducts().size()) return;
        ShopProduct p = shop.getProducts().get(productIndex);
        GuiHolder holder = new GuiHolder("PSHOP_BUY").set("ownerId", shop.getOwnerId()).set("productIndex", productIndex);
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color(plugin.getConfigManager().getPlayerShop().getString("gui.buy-title", "شراء").replace("%owner%", shop.getOwnerName())));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        double unit = p.getUnitPrice();
        double disc = plugin.getConfigManager().getPlayerShop().getDouble("settings.bulk-discount-percent", 10.0);
        double price64 = p.isBulkDiscountEnabled() ? (unit * 64 * (1.0 - disc / 100.0)) : (unit * 64);

        inv.setItem(10, TextUtil.makeItem(Material.LIME_STAINED_GLASS_PANE, "&#06D6A0✦ شراء 1 حبة", List.of("", "  &#FF8FA3▪ &fالسعر: &#FFD166" + TextUtil.formatPrice(unit)), false));
        inv.setItem(11, TextUtil.makeItem(Material.LIME_CONCRETE, "&#06D6A0✦ شراء 16 حبة", List.of("", "  &#FF8FA3▪ &fالسعر: &#FFD166" + TextUtil.formatPrice(unit * 16)), false));
        ItemStack preview = p.getTemplate();
        ItemMeta pm = preview.getItemMeta();
        if (pm != null) {
            pm.lore(TextUtil.colorList(List.of(TextUtil.DIVIDER, "  &#FF8FA3▪ &fسعر الحبة: &#FFD166" + TextUtil.formatPrice(unit), "  &#FF8FA3▪ &fالمتوفر: &#06D6A0" + TextUtil.formatInt(p.getStock()) + " حبة", TextUtil.DIVIDER)));
            preview.setItemMeta(pm);
        }
        inv.setItem(13, preview);
        inv.setItem(15, TextUtil.makeItem(Material.EMERALD_BLOCK, "&#06D6A0★ شراء 64 حبة", p.isBulkDiscountEnabled() ? List.of("", "  &#FF8FA3▪ &fالسعر: &#FFD166" + TextUtil.formatPrice(price64), "  &#06D6A0★ &#FFF0F3Sale : &#FFD166" + TextUtil.formatMoney(disc) + "% &#FFB3C1for 64") : List.of("", "  &#FF8FA3▪ &fالسعر: &#FFD166" + TextUtil.formatPrice(price64)), p.isBulkDiscountEnabled()));
        inv.setItem(16, TextUtil.makeItem(Material.OAK_SIGN, "&#FFB703✦ كمية مخصصة", List.of("", "  &7اضغط واكتب العدد بالشات"), false));
        inv.setItem(22, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFB703« رجوع للمتجر", List.of(), false));
        buyer.openInventory(inv);
    }

    public void openDropBox(Player player) {
        GuiHolder holder = new GuiHolder("PSHOP_DROPBOX");
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color(plugin.getConfigManager().getPlayerShop().getString("gui.dropbox-title", "صندوق الإيداع")));
        holder.setInventory(inv);
        player.openInventory(inv);
    }

    public void processDropBoxClose(Player player, Inventory inv) {
        PlayerShopData shop = getOrCreateShop(player);
        int addedTotal = 0;
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack item = inv.getItem(i);
            if (item == null || item.getType().isAir()) continue;
            ShopProduct match = shop.findMatching(item);
            if (match != null) { match.addStock(item.getAmount()); addedTotal += item.getAmount(); }
            else TextUtil.safeGiveItems(player, item, item.getAmount());
        }
        if (addedTotal > 0) {
            saveData();
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.restock"), 1.3f);
            TextUtil.spawnParticle(player, "HAPPY_VILLAGER", 15);
            plugin.getConfigManager().send(player, "pshop.restock-all", "%total%", TextUtil.formatInt(addedTotal));
            notifyFollowers(shop);
        }
    }

    public void restockSingleProduct(Player player, ShopProduct targetProduct) {
        PlayerShopData shop = getOrCreateShop(player);
        int added = drainMatching(player, targetProduct);
        if (added > 0) { saveData(); TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.restock"), 1.4f); plugin.getConfigManager().send(player, "pshop.restock-all", "%total%", TextUtil.formatInt(added)); notifyFollowers(shop); }
        else plugin.getConfigManager().send(player, "pshop.restock-none");
    }

    public void restockAllFromInventoryAndShulkers(Player player) {
        PlayerShopData shop = getOrCreateShop(player);
        int totalAdded = 0;
        for (ShopProduct p : shop.getProducts()) totalAdded += drainMatching(player, p);
        if (totalAdded > 0) { saveData(); TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.restock"), 1.4f); TextUtil.spawnParticle(player, "CHERRY_LEAVES", 20); plugin.getConfigManager().send(player, "pshop.restock-all", "%total%", TextUtil.formatInt(totalAdded)); notifyFollowers(shop); }
        else plugin.getConfigManager().send(player, "pshop.restock-none");
    }

    private int drainMatching(Player player, ShopProduct product) {
        int added = 0;
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack stack = contents[i];
            if (stack == null || stack.getType().isAir()) continue;
            if (stack.getItemMeta() instanceof BlockStateMeta bsm && bsm.getBlockState() instanceof ShulkerBox shulker) {
                Inventory shulkerInv = shulker.getInventory();
                boolean modified = false;
                for (int s = 0; s < shulkerInv.getSize(); s++) {
                    ItemStack inside = shulkerInv.getItem(s);
                    if (inside != null && product.matches(inside)) { product.addStock(inside.getAmount()); added += inside.getAmount(); shulkerInv.setItem(s, null); modified = true; }
                }
                if (modified) { bsm.setBlockState(shulker); stack.setItemMeta(bsm); }
                continue;
            }
            if (product.matches(stack)) { product.addStock(stack.getAmount()); added += stack.getAmount(); player.getInventory().setItem(i, null); }
        }
        return added;
    }

    public void openBoostGui(Player player) {
        PlayerShopData shop = getOrCreateShop(player);
        if (shop.isBoosted()) {
            plugin.getConfigManager().send(player, "pshop.boost-already-active", "%mins%", String.valueOf(shop.getBoostRemainingMinutes()));
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.error"));
            return;
        }
        ConfigurationSection cfg = plugin.getConfigManager().getPlayerShop();
        GuiHolder holder = new GuiHolder("PSHOP_BOOST");
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color(cfg.getString("gui.boost-title", "ترويج المتجر")));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);
        ConfigurationSection tiers = cfg.getConfigurationSection("boost-tiers");
        if (tiers != null) {
            for (String key : tiers.getKeys(false)) {
                ConfigurationSection t = tiers.getConfigurationSection(key);
                inv.setItem(t.getInt("slot", 13), TextUtil.makeItem(TextUtil.parseMaterial(t.getString("material"), Material.GOLD_INGOT), t.getString("name", key),
                        List.of(TextUtil.DIVIDER, "  &#FF8FA3▪ &fالمدة: &#06D6A0" + TextUtil.formatInt(t.getInt("duration-minutes")) + " دقيقة", "  &#FF8FA3▪ &fالسعر: &#FFD166" + TextUtil.formatPrice(t.getDouble("price")), TextUtil.DIVIDER, "  &#06D6A0» &fاضغط للتفعيل الآن"), true));
            }
        }
        inv.setItem(22, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFB703« رجوع لإدارة المتجر", List.of(), false));
        player.openInventory(inv);
    }

    public void activateBoostTier(Player player, String tierKey) {
        if (!plugin.getVaultHook().isConnected()) { plugin.getConfigManager().send(player, "general.economy-missing"); return; }
        PlayerShopData shop = getOrCreateShop(player);
        if (shop.isBoosted()) { plugin.getConfigManager().send(player, "pshop.boost-already-active", "%mins%", String.valueOf(shop.getBoostRemainingMinutes())); return; }
        ConfigurationSection t = plugin.getConfigManager().getPlayerShop().getConfigurationSection("boost-tiers." + tierKey);
        if (t == null) return;
        double price = t.getDouble("price", 2500.0); int mins = t.getInt("duration-minutes", 60);
        if (!plugin.getVaultHook().has(player, price)) { plugin.getConfigManager().send(player, "pshop.no-money", "%price%", TextUtil.formatPrice(price)); return; }
        if (shops.values().stream().filter(PlayerShopData::isBoosted).count() >= plugin.getConfigManager().getPlayerShop().getInt("settings.max-active-boosts", 5)) { plugin.getConfigManager().send(player, "pshop.boost-max"); return; }
        plugin.getVaultHook().withdraw(player, price);
        shop.activateBoost(mins);
        saveData();
        player.closeInventory();
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.boost"), 1.0f);
        TextUtil.spawnParticle(player, "HEART", 25);
        plugin.getConfigManager().send(player, "pshop.boost-activated", "%mins%", TextUtil.formatInt(mins));
        if (t.getBoolean("broadcast", true)) {
            Component broadcast = TextUtil.color("&#FFD166★ &#FF4D6D✦ &fقام &e" + player.getName() + " &fبترويج متجره! ")
                    .append(TextUtil.color("&#06D6A0&l[اضغط للزيارة] ").clickEvent(ClickEvent.runCommand("/shop " + player.getName())))
                    .append(TextUtil.color("&7(/shop " + player.getName() + ")"));
            plugin.getNotificationManager().broadcast("shop-boosts", broadcast);
        }
    }

    public void openPlayerShopView(Player viewer, PlayerShopData shop) {
        if (!shop.isOpen() && !viewer.getUniqueId().equals(shop.getOwnerId()) && !viewer.hasPermission("survivalplus.admin")) {
            plugin.getConfigManager().send(viewer, "pshop.shop-closed");
            TextUtil.playSound(viewer, plugin.getConfigManager().getConfig().getString("sounds.error"));
            return;
        }
        ConfigurationSection gui = plugin.getConfigManager().getPlayerShop().getConfigurationSection("gui");
        GuiHolder holder = new GuiHolder("PSHOP_VIEW").set("ownerId", shop.getOwnerId());
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(gui.getString("shop-title", "%shop_name%").replace("%shop_name%", shop.getCustomName())));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        // Header info card at slot 4
        OfflinePlayer ownerOp = Bukkit.getOfflinePlayer(shop.getOwnerId());
        inv.setItem(4, TextUtil.makeSkull(ownerOp, "&#FF4D6D★ &#FFF0F3" + shop.getCustomName(),
                List.of("  &#FFCCD5❝ " + shop.getCustomDescription() + " ❞",
                        TextUtil.DIVIDER,
                        "  &#FF8FA3▪ &fالمالك: &#FFB3C1" + shop.getOwnerName(),
                        "  &#FF8FA3▪ &fالوسام: " + getBadge(shop.getTotalEarnings()),
                        "  &#FF8FA3▪ &fالمتابعون: &#FF758F" + TextUtil.formatInt(shop.getFollowers().size())), shop.isBoosted()));

        int[] slots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34};
        for (int i = 0; i < Math.min(shop.getProducts().size(), slots.length); i++) {
            ShopProduct p = shop.getProducts().get(i);
            ItemStack display = p.getTemplate();
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                List<String> lore = new ArrayList<>();
                lore.add(TextUtil.DIVIDER);
                lore.add("  &#FF8FA3▪ &fالسعر: &#FFD166" + TextUtil.formatPrice(p.getUnitPrice()) + " &7للحبة");
                lore.add("  &#FF8FA3▪ &fالمتوفر: " + (p.getStock() > 0 ? "&#06D6A0" + TextUtil.formatInt(p.getStock()) + " حبة" : "&#EF476Fنفذ المخزون"));
                lore.add("  &#FF8FA3▪ &fتم بيع: &#FFB3C1" + TextUtil.formatInt(p.getSoldCount()) + " حبة");
                if (p.isBulkDiscountEnabled()) lore.add("  &#06D6A0★ &#FFF0F3Sale : &#FFD166" + TextUtil.formatMoney(plugin.getConfigManager().getPlayerShop().getDouble("settings.bulk-discount-percent", 10.0)) + "% &#FFB3C1for 64");
                lore.add(TextUtil.DIVIDER);
                lore.add(p.getStock() > 0 ? "  &#06D6A0» &fاضغط للشراء" : "  &#EF476F✘ &7غير متوفر حالياً");
                meta.lore(TextUtil.colorList(lore));
                display.setItemMeta(meta);
            }
            inv.setItem(slots[i], display);
        }
        boolean isFav = shop.getFollowers().contains(viewer.getUniqueId());
        inv.setItem(48, TextUtil.makeItem(isFav ? Material.RED_DYE : Material.PINK_DYE, isFav ? "&#EF476F★ في المفضلة" : "&#FFB3C1✦ إضافة للمفضلة", List.of("", "  &7يصلك تنبيه عند إعادة التعبئة"), isFav));
        inv.setItem(49, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFB703« رجوع للسوق", List.of(), false));
        viewer.openInventory(inv);
        TextUtil.playSound(viewer, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }

    public void buyFromShop(Player buyer, PlayerShopData shop, int productIndex, int amount) {
        if (!plugin.getVaultHook().isConnected()) { plugin.getConfigManager().send(buyer, "general.economy-missing"); return; }
        if (buyer.getUniqueId().equals(shop.getOwnerId())) { plugin.getConfigManager().send(buyer, "pshop.buy-self"); TextUtil.playSound(buyer, plugin.getConfigManager().getConfig().getString("sounds.error")); return; }
        if (productIndex < 0 || productIndex >= shop.getProducts().size()) return;
        ShopProduct p = shop.getProducts().get(productIndex);
        if (p.getStock() <= 0) { plugin.getConfigManager().send(buyer, "pshop.out-of-stock"); TextUtil.playSound(buyer, plugin.getConfigManager().getConfig().getString("sounds.error")); return; }
        int actualAmount = Math.min(amount, p.getStock());
        double total = p.getUnitPrice() * actualAmount;
        if (actualAmount >= 64 && p.isBulkDiscountEnabled()) total *= (1.0 - (plugin.getConfigManager().getPlayerShop().getDouble("settings.bulk-discount-percent", 10.0) / 100.0));
        if (!plugin.getVaultHook().has(buyer, total)) { plugin.getConfigManager().send(buyer, "pshop.no-money", "%price%", TextUtil.formatPrice(total)); return; }

        plugin.getVaultHook().withdraw(buyer, total);
        plugin.getVaultHook().deposit(Bukkit.getOfflinePlayer(shop.getOwnerId()), total);
        p.removeStock(actualAmount); p.addSold(actualAmount); shop.addEarnings(total);
        TextUtil.safeGiveItems(buyer, p.getTemplate(), actualAmount);
        saveData();

        TextUtil.playSound(buyer, plugin.getConfigManager().getConfig().getString("sounds.purchase"), 1.4f);
        plugin.getConfigManager().send(buyer, "pshop.buy-success", "%amount%", TextUtil.formatInt(actualAmount), "%item%", p.getTemplate().getType().name(), "%owner%", shop.getOwnerName(), "%price%", TextUtil.formatMoney(total));

        Player onlineOwner = Bukkit.getPlayer(shop.getOwnerId());
        if (onlineOwner != null && onlineOwner.isOnline()) {
            plugin.getNotificationManager().notify(onlineOwner, "shop-sales", "pshop.seller-notify", "%amount%", TextUtil.formatInt(actualAmount), "%item%", p.getTemplate().getType().name(), "%buyer%", buyer.getName(), "%price%", TextUtil.formatMoney(total));
            int lowThreshold = plugin.getConfigManager().getNotifications().getInt("global.low-stock-threshold", 8);
            if (p.getStock() == 0) plugin.getNotificationManager().notify(onlineOwner, "shop-stock", "pshop.stock-empty-alert", "%item%", p.getTemplate().getType().name());
            else if (p.getStock() <= lowThreshold) plugin.getNotificationManager().notify(onlineOwner, "shop-stock", "pshop.stock-low-alert", "%item%", p.getTemplate().getType().name(), "%left%", TextUtil.formatInt(p.getStock()));
        } else { shop.addOfflineSale(total, actualAmount); saveData(); }
        openPlayerShopView(buyer, shop);
    }

    private void notifyFollowers(PlayerShopData shop) {
        for (UUID f : shop.getFollowers()) {
            Player fp = Bukkit.getPlayer(f);
            if (fp != null && fp.isOnline()) plugin.getNotificationManager().notify(fp, "shop-favorites", "pshop.fav-alert", "%owner%", shop.getOwnerName());
        }
    }
}
