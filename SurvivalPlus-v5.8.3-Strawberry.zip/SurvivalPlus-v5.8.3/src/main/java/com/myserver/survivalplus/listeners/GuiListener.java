package com.myserver.survivalplus.listeners;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.models.GraveData;
import com.myserver.survivalplus.models.PlayerShopData;
import com.myserver.survivalplus.models.ShopProduct;
import com.myserver.survivalplus.util.GriefPreventionHook;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class GuiListener implements Listener {
    private final SurvivalPlus plugin;
    private static final List<Integer> SHOP_SLOTS = Arrays.asList(10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34);
    private static final List<Integer> CLAIM_SLOTS = Arrays.asList(10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34, 37,38,39,40,41,42,43);

    public GuiListener(SurvivalPlus plugin) { this.plugin = plugin; }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof GuiHolder holder) {
            String t = holder.getType();
            if (!t.equals("PSHOP_DROPBOX") && !t.equals("VAULT_STORAGE") && !t.equals("GRAVE_LOOT")) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (event.getInventory().getHolder() instanceof GuiHolder holder) {
            switch (holder.getType()) {
                case "PSHOP_DROPBOX" -> plugin.getPlayerShopManager().processDropBoxClose(player, event.getInventory());
                case "VAULT_STORAGE" -> plugin.getVaultManager().saveVaultFromInventory(holder.get("vaultKey", String.class), event.getInventory());
                case "GRAVE_LOOT" -> plugin.getGraveManager().syncLootInventory(holder.get("graveKey", String.class), event.getInventory());
            }
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getInventory().getHolder() instanceof GuiHolder holder)) return;
        String type = holder.getType();
        if (type.equals("PSHOP_DROPBOX") || type.equals("VAULT_STORAGE") || type.equals("GRAVE_LOOT")) return;

        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getInventory())) return;

        int slot = event.getSlot();
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.click"));

        switch (type) {
            case "NOTIFICATIONS_GUI" -> handleNotifications(player, slot);
            case "VAULT_SELECTOR" -> handleVaultSelector(player, slot);
            case "GRAVES_GUI" -> handleGraves(player, holder, slot, event.isRightClick());
            case "GRAVE_PREVIEW" -> handleGravePreview(player, holder, slot);
            case "RTP_GUI" -> handleRtp(player, slot);
            case "PSHOP_DIRECTORY" -> handlePShopDirectory(player, holder, slot);
            case "PSHOP_MANAGE" -> handlePShopManage(player, slot);
            case "PSHOP_SETTINGS" -> handlePShopSettings(player, slot);
            case "PSHOP_EDIT_PRODUCT" -> handlePShopEditProduct(player, holder, slot);
            case "PSHOP_BOOST" -> handlePShopBoost(player, slot);
            case "PSHOP_VIEW" -> handlePShopView(player, holder, slot);
            case "PSHOP_BUY" -> handlePShopBuy(player, holder, slot);
            case "CLAIM_HUB" -> handleClaimHub(player, slot);
            case "CLAIM_LIST" -> handleClaimList(player, holder, slot);
            case "CLAIM_MANAGE" -> handleClaimManage(player, holder, slot);
            case "CLAIM_SETTINGS" -> handleClaimSettings(player, holder, slot);
            case "CLAIM_TRUST" -> handleClaimTrust(player, holder, slot);
            case "CLAIM_TRUST_ACTION" -> handleClaimTrustAction(player, holder, slot);
            case "CLAIM_TRUST_LEVEL" -> handleTrustLevel(player, holder, slot);
            case "CLAIM_CONFIRM_DELETE" -> handleConfirmDelete(player, holder, slot);
            case "CLAIM_CONFIRM_UNTRUST" -> handleConfirmUntrust(player, holder, slot);
        }
    }

    private boolean isClaimOwnerOrAdmin(Player player, GriefPreventionHook.ClaimInfo claim) {
        if (claim == null) return false;
        return player.hasPermission("survivalplus.admin") || (claim.ownerId() != null && claim.ownerId().equals(player.getUniqueId()));
    }

    private void openGlobalBack(Player player) {
        player.closeInventory();
        TextUtil.runConsoleCommand(plugin.getConfigManager().getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                .replace("%player%", player.getName()));
    }

    private void handleVaultSelector(Player player, int slot) {
        if (slot == 22) { openGlobalBack(player); return; }
        int[] slots = {11, 12, 13, 14, 15};
        for (int i = 0; i < slots.length; i++) if (slots[i] == slot) { plugin.getVaultManager().openVault(player, i + 1); return; }
    }

    @SuppressWarnings("unchecked")
    private void handleGraves(Player player, GuiHolder holder, int slot, boolean rightClick) {
        if (slot == 31) { openGlobalBack(player); return; }
        List<Integer> slots = Arrays.asList(10,11,12,13,14,15,16, 19,20,21,22,23,24,25);
        int idx = slots.indexOf(slot);
        List<GraveData> list = holder.get("graves", List.class);
        if (idx >= 0 && list != null && idx < list.size()) {
            GraveData g = list.get(idx);
            if (rightClick) plugin.getGraveManager().openGravePreview(player, g);
            else plugin.getGraveManager().teleportToGrave(player, g);
        }
    }

    private void handleGravePreview(Player player, GuiHolder holder, int slot) {
        if (slot == 48) { plugin.getGraveManager().openGravesGui(player); return; }
        if (slot == 50) {
            GraveData g = plugin.getGraveManager().getGraveByKey(holder.get("graveKey", String.class));
            plugin.getGraveManager().teleportToGrave(player, g);
        }
    }

    private void handleNotifications(Player player, int slot) {
        ConfigurationSection cfg = plugin.getConfigManager().getNotifications();
        ConfigurationSection gui = cfg.getConfigurationSection("gui");
        if (slot == gui.getInt("back-slot", 31)) { openGlobalBack(player); return; }
        if (slot == gui.getInt("enable-all-slot", 29)) { plugin.getNotificationManager().setAll(player, true); plugin.getNotificationManager().openGui(player); return; }
        if (slot == gui.getInt("disable-all-slot", 33)) { plugin.getNotificationManager().setAll(player, false); plugin.getNotificationManager().openGui(player); return; }
        ConfigurationSection types = cfg.getConfigurationSection("types");
        if (types != null) for (String key : types.getKeys(false)) if (types.getInt(key + ".slot", -1) == slot) { plugin.getNotificationManager().toggle(player, key); plugin.getNotificationManager().openGui(player); return; }
    }

    @SuppressWarnings("unchecked")
    private void handlePShopDirectory(Player player, GuiHolder holder, int slot) {
        if (slot == 48) { plugin.getPlayerShopManager().openManageShop(player); return; }
        if (slot == 49) { openGlobalBack(player); return; }
        if (slot == 50) { plugin.getNotificationManager().openGui(player); return; }
        int idx = SHOP_SLOTS.indexOf(slot);
        List<UUID> order = holder.get("shopOrder", List.class);
        if (idx >= 0 && order != null && idx < order.size()) {
            PlayerShopData shop = plugin.getPlayerShopManager().getShop(order.get(idx));
            if (shop != null) plugin.getPlayerShopManager().openPlayerShopView(player, shop);
        }
    }

    private void handlePShopManage(Player player, int slot) {
        PlayerShopData shop = plugin.getPlayerShopManager().getOrCreateShop(player);
        if (slot == 45) { plugin.getPlayerShopManager().openDirectory(player); return; }
        if (slot == 48) { plugin.getPlayerShopManager().restockAllFromInventoryAndShulkers(player); plugin.getPlayerShopManager().openManageShop(player); return; }
        if (slot == 49) { plugin.getPlayerShopManager().openDropBox(player); return; }
        if (slot == 50) { plugin.getPlayerShopManager().openShopSettingsGui(player); return; }
        if (slot == 51) { plugin.getPlayerShopManager().openBoostGui(player); return; }
        if (slot == 47) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand.getType().isAir()) { plugin.getConfigManager().send(player, "pshop.hold-item"); return; }
            player.closeInventory();
            double avg = plugin.getPlayerShopManager().getMarketAveragePrice(hand.getType());
            plugin.getConfigManager().send(player, "pshop.ask-price", "%avg%", avg > 0 ? TextUtil.formatMoney(avg) + "$" : "لا يوجد بعد");
            plugin.getChatPromptManager().prompt(player, input -> {
                if (input.equalsIgnoreCase("إلغاء") || input.equalsIgnoreCase("cancel")) return;
                try { plugin.getPlayerShopManager().listHandItemWithPrice(player, Double.parseDouble(input)); }
                catch (NumberFormatException e) { plugin.getConfigManager().send(player, "pshop.invalid-price"); }
            });
            return;
        }
        int idx = SHOP_SLOTS.indexOf(slot);
        if (idx >= 0 && idx < shop.getProducts().size()) plugin.getPlayerShopManager().openEditProductGui(player, idx);
    }

    private void handlePShopSettings(Player player, int slot) {
        PlayerShopData shop = plugin.getPlayerShopManager().getOrCreateShop(player);
        if (slot == 31) { plugin.getPlayerShopManager().openManageShop(player); return; }
        if (slot == 10) {
            player.closeInventory();
            plugin.getConfigManager().send(player, "pshop.ask-shop-name");
            plugin.getChatPromptManager().prompt(player, input -> {
                if (input.equalsIgnoreCase("إلغاء") || input.equalsIgnoreCase("cancel")) return;
                shop.setCustomName(input.substring(0, Math.min(input.length(), 28)));
                plugin.getPlayerShopManager().saveData();
                plugin.getConfigManager().send(player, "pshop.shop-updated");
            });
        } else if (slot == 12) {
            player.closeInventory();
            plugin.getConfigManager().send(player, "pshop.ask-shop-desc");
            plugin.getChatPromptManager().prompt(player, input -> {
                if (input.equalsIgnoreCase("إلغاء") || input.equalsIgnoreCase("cancel")) return;
                shop.setCustomDescription(input.substring(0, Math.min(input.length(), 45)));
                plugin.getPlayerShopManager().saveData();
                plugin.getConfigManager().send(player, "pshop.shop-updated");
            });
        } else if (slot == 14) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            shop.setCustomIcon(hand.getType().isAir() ? null : hand.getType());
            plugin.getPlayerShopManager().saveData();
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.success"), 1.3f);
            plugin.getConfigManager().send(player, "pshop.shop-updated");
            plugin.getPlayerShopManager().openShopSettingsGui(player);
        } else if (slot == 16) {
            shop.setOpen(!shop.isOpen());
            plugin.getPlayerShopManager().saveData();
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.success"), shop.isOpen() ? 1.3f : 0.8f);
            plugin.getPlayerShopManager().openShopSettingsGui(player);
        } else if (slot == 22) {
            boolean allOn = !shop.getProducts().isEmpty() && shop.getProducts().stream().allMatch(ShopProduct::isBulkDiscountEnabled);
            boolean next = !allOn;
            for (ShopProduct p : shop.getProducts()) p.setBulkDiscountEnabled(next);
            plugin.getPlayerShopManager().saveData();
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.success"), next ? 1.3f : 0.9f);
            plugin.getConfigManager().send(player, next ? "pshop.bulk-all-on" : "pshop.bulk-all-off");
            plugin.getPlayerShopManager().openShopSettingsGui(player);
        }
    }

    private void handlePShopEditProduct(Player player, GuiHolder holder, int slot) {
        PlayerShopData shop = plugin.getPlayerShopManager().getOrCreateShop(player);
        int idx = holder.get("productIndex", Integer.class);
        if (slot == 22 || idx < 0 || idx >= shop.getProducts().size()) { plugin.getPlayerShopManager().openManageShop(player); return; }
        ShopProduct p = shop.getProducts().get(idx);
        if (slot == 10) {
            player.closeInventory();
            plugin.getConfigManager().send(player, "pshop.ask-new-price");
            plugin.getChatPromptManager().prompt(player, input -> {
                if (input.equalsIgnoreCase("إلغاء") || input.equalsIgnoreCase("cancel")) return;
                try {
                    double price = Double.parseDouble(input);
                    if (!Double.isFinite(price) || price <= 0 || price > 1_000_000_000) throw new NumberFormatException();
                    p.setUnitPrice(price);
                    plugin.getPlayerShopManager().saveData();
                    plugin.getConfigManager().send(player, "pshop.price-updated", "%item%", p.getTemplate().getType().name(), "%price%", TextUtil.formatMoney(price));
                } catch (NumberFormatException e) { plugin.getConfigManager().send(player, "pshop.invalid-price"); }
            });
        } else if (slot == 12) { plugin.getPlayerShopManager().restockSingleProduct(player, p); plugin.getPlayerShopManager().openEditProductGui(player, idx); }
        else if (slot == 14) { p.setBulkDiscountEnabled(!p.isBulkDiscountEnabled()); plugin.getPlayerShopManager().saveData(); plugin.getPlayerShopManager().openEditProductGui(player, idx); }
        else if (slot == 16) {
            if (p.getStock() > 0) TextUtil.safeGiveItems(player, p.getTemplate(), p.getStock());
            shop.getProducts().remove(idx);
            plugin.getPlayerShopManager().saveData();
            plugin.getPlayerShopManager().openManageShop(player);
        }
    }

    private void handlePShopBoost(Player player, int slot) {
        if (slot == 22) { plugin.getPlayerShopManager().openManageShop(player); return; }
        ConfigurationSection tiers = plugin.getConfigManager().getPlayerShop().getConfigurationSection("boost-tiers");
        if (tiers != null) for (String key : tiers.getKeys(false)) if (tiers.getInt(key + ".slot", -1) == slot) { plugin.getPlayerShopManager().activateBoostTier(player, key); return; }
    }

    private void handlePShopView(Player player, GuiHolder holder, int slot) {
        PlayerShopData shop = plugin.getPlayerShopManager().getShop(holder.get("ownerId", UUID.class));
        if (shop == null) { player.closeInventory(); return; }
        if (slot == 49) { plugin.getPlayerShopManager().openDirectory(player); return; }
        if (slot == 48) {
            if (shop.getFollowers().remove(player.getUniqueId())) plugin.getConfigManager().send(player, "pshop.fav-removed", "%owner%", shop.getOwnerName());
            else { shop.getFollowers().add(player.getUniqueId()); plugin.getConfigManager().send(player, "pshop.fav-added", "%owner%", shop.getOwnerName()); }
            plugin.getPlayerShopManager().saveData();
            plugin.getPlayerShopManager().openPlayerShopView(player, shop);
            return;
        }
        int idx = SHOP_SLOTS.indexOf(slot);
        if (idx >= 0 && idx < shop.getProducts().size()) plugin.getPlayerShopManager().openBuyGui(player, shop, idx);
    }

    private void handlePShopBuy(Player player, GuiHolder holder, int slot) {
        PlayerShopData shop = plugin.getPlayerShopManager().getShop(holder.get("ownerId", UUID.class));
        int idx = holder.get("productIndex", Integer.class);
        if (shop == null) { player.closeInventory(); return; }
        if (slot == 22) { plugin.getPlayerShopManager().openPlayerShopView(player, shop); return; }
        if (slot == 10) plugin.getPlayerShopManager().buyFromShop(player, shop, idx, 1);
        else if (slot == 11) plugin.getPlayerShopManager().buyFromShop(player, shop, idx, 16);
        else if (slot == 15) plugin.getPlayerShopManager().buyFromShop(player, shop, idx, 64);
        else if (slot == 16 && idx < shop.getProducts().size()) {
            ShopProduct p = shop.getProducts().get(idx);
            player.closeInventory();
            plugin.getConfigManager().send(player, "pshop.ask-buy-amount", "%max%", String.valueOf(p.getStock()));
            plugin.getChatPromptManager().prompt(player, input -> {
                if (input.equalsIgnoreCase("إلغاء") || input.equalsIgnoreCase("cancel")) return;
                try {
                    int amt = Integer.parseInt(input);
                    if (amt <= 0 || amt > 10000) throw new NumberFormatException();
                    plugin.getPlayerShopManager().buyFromShop(player, shop, idx, amt);
                } catch (NumberFormatException e) { plugin.getConfigManager().send(player, "pshop.invalid-amount"); }
            });
        }
    }

    private void handleRtp(Player player, int slot) {
        if (slot == 22) { openGlobalBack(player); return; }
        ConfigurationSection worlds = plugin.getConfigManager().getConfig().getConfigurationSection("rtp.worlds");
        if (worlds != null) for (String w : worlds.getKeys(false)) if (worlds.getInt(w + ".slot", -1) == slot) { player.closeInventory(); plugin.getRtpManager().executeRtp(player, w); return; }
    }

    private void handleClaimHub(Player player, int slot) {
        if (slot == 36) player.closeInventory();
        else if (slot == 44) openGlobalBack(player);
        else if (slot == 40) plugin.getNotificationManager().openGui(player);
        else if (slot == 29) plugin.getClaimGuiManager().openClaimsList(player, 1);
        else if (slot == 11) giveTool(player, "shovel");
        else if (slot == 20) giveTool(player, "stick");
        else if (slot == 13) buyPack(player, "small");
        else if (slot == 22) buyPack(player, "medium");
        else if (slot == 31) buyPack(player, "large");
        else if (slot == 24) sellBlocks(player);
    }

    private void giveTool(Player player, String key) {
        ConfigurationSection ts = plugin.getConfigManager().getConfig().getConfigurationSection("claims.tools." + key);
        if (ts == null || !ts.getBoolean("enabled", true)) return;
        if (!player.hasPermission("survivalplus.claim.bypass.cooldown")) {
            long rem = plugin.getCooldownManager().getRemainingSeconds(player.getUniqueId(), "tool_" + key);
            if (rem > 0) { plugin.getConfigManager().send(player, "claims.tool-cooldown", "%cooldown%", plugin.getCooldownManager().format(rem), "%tool%", key); return; }
        }
        Material mat = TextUtil.parseMaterial(ts.getString("material"), Material.GOLDEN_SHOVEL);
        TextUtil.safeGiveItems(player, new ItemStack(mat), 1);
        int cd = ts.getInt("cooldown-seconds", 7200);
        plugin.getCooldownManager().setCooldown(player.getUniqueId(), "tool_" + key, cd);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.success"), 1.2f);
        plugin.getConfigManager().send(player, "claims.tool-given", "%tool%", mat.name(), "%cooldown%", plugin.getCooldownManager().format(cd));
    }

    private void buyPack(Player player, String pack) {
        if (!plugin.getVaultHook().isConnected()) { plugin.getConfigManager().send(player, "general.economy-missing"); return; }
        if (!plugin.getGpHook().isConnected()) { plugin.getConfigManager().send(player, "general.gp-missing"); return; }
        ConfigurationSection ps = plugin.getConfigManager().getConfig().getConfigurationSection("claims.economy.packs." + pack);
        int blocks = ps.getInt("blocks"); double price = ps.getDouble("price");
        if (!plugin.getVaultHook().has(player, price)) { plugin.getConfigManager().send(player, "claims.buy-no-money", "%price%", TextUtil.formatMoney(price) + "$"); TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.error")); return; }
        if (!plugin.getGpHook().addBonusBlocks(player.getUniqueId(), blocks)) { plugin.getConfigManager().send(player, "claims.buy-failed"); TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.error")); return; }
        plugin.getVaultHook().withdraw(player, price);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.claim-buy"), 1.2f);
        plugin.getConfigManager().send(player, "claims.buy-success", "%blocks%", String.valueOf(blocks), "%price%", TextUtil.formatMoney(price) + "$");
        plugin.getClaimGuiManager().openHub(player);
    }

    private void sellBlocks(Player player) {
        if (!plugin.getVaultHook().isConnected()) { plugin.getConfigManager().send(player, "general.economy-missing"); return; }
        if (!plugin.getGpHook().isConnected()) { plugin.getConfigManager().send(player, "general.gp-missing"); return; }
        ConfigurationSection ss = plugin.getConfigManager().getConfig().getConfigurationSection("claims.economy.sell");
        int blocks = ss.getInt("blocks", 100); double payout = ss.getDouble("payout", 250.0);
        if (plugin.getGpHook().getBonusBlocks(player.getUniqueId()) < blocks || plugin.getGpHook().getRemainingBlocks(player.getUniqueId()) < blocks) { plugin.getConfigManager().send(player, "claims.sell-no-blocks", "%blocks%", String.valueOf(blocks)); TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.error")); return; }
        if (!plugin.getGpHook().addBonusBlocks(player.getUniqueId(), -blocks)) return;
        plugin.getVaultHook().deposit(player, payout);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.purchase"), 1.3f);
        plugin.getConfigManager().send(player, "claims.sell-success", "%blocks%", String.valueOf(blocks), "%payout%", TextUtil.formatMoney(payout) + "$");
        plugin.getClaimGuiManager().openHub(player);
    }

    @SuppressWarnings("unchecked")
    private void handleClaimList(Player player, GuiHolder holder, int slot) {
        int page = holder.get("page", Integer.class);
        if (slot == 48) { player.closeInventory(); return; }
        if (slot == 50) { plugin.getClaimGuiManager().openHub(player); return; }
        if (slot == 45 && page > 1) { plugin.getClaimGuiManager().openClaimsList(player, page - 1); return; }
        if (slot == 53) { plugin.getClaimGuiManager().openClaimsList(player, page + 1); return; }
        int idx = CLAIM_SLOTS.indexOf(slot);
        List<GriefPreventionHook.ClaimInfo> claims = holder.get("claims", List.class);
        int realIndex = (page - 1) * CLAIM_SLOTS.size() + idx;
        if (idx >= 0 && claims != null && realIndex < claims.size()) plugin.getClaimGuiManager().openManage(player, claims.get(realIndex));
    }

    private void startClaimTeleport(Player player, GriefPreventionHook.ClaimInfo claim) {
        player.closeInventory();
        Location target = claim.getSafeTeleportLocation(plugin.getConfigManager().getConfig().getInt("claims.teleport.y-offset", 1));
        if (target == null) return;
        int sec = plugin.getConfigManager().getConfig().getInt("claims.teleport.countdown-seconds", 5);
        plugin.getConfigManager().send(player, "claims.tp-start", "%id%", String.valueOf(claim.id()), "%seconds%", String.valueOf(sec));
        plugin.getTeleportManager().startTeleport(player, target, sec, true, 0.25, "claims.tp-actionbar", "CHERRY_LEAVES", "PORTAL",
                "BLOCK_NOTE_BLOCK_PLING", "BLOCK_NOTE_BLOCK_HAT", "ENTITY_ENDERMAN_TELEPORT", "ENTITY_VILLAGER_NO",
                () -> plugin.getConfigManager().send(player, "claims.tp-success", "%id%", String.valueOf(claim.id())),
                () -> plugin.getConfigManager().send(player, "claims.tp-cancelled"));
    }

    private void handleClaimManage(Player player, GuiHolder holder, int slot) {
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(holder.get("claimId", Long.class));
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        if (slot == 36) plugin.getClaimGuiManager().openClaimsList(player, 1);
        else if (slot == 11) startClaimTeleport(player, claim);
        else if (slot == 13) plugin.getClaimGuiManager().openTrust(player, claim);
        else if (slot == 15) plugin.getClaimGuiManager().openSettings(player, claim);
        else if (slot == 40) plugin.getClaimGuiManager().openConfirmDelete(player, claim);
    }

    private void handleClaimSettings(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        if (slot == 36) plugin.getClaimGuiManager().openManage(player, claim);
        else if (slot == 20) { boolean state = plugin.getGpHook().toggleExplosions(claim); plugin.getConfigManager().send(player, state ? "claims.explosives-on" : "claims.explosives-off", "%id%", String.valueOf(claimId)); plugin.getClaimGuiManager().openSettings(player, plugin.getGpHook().getClaimById(claimId)); }
        else if (slot == 24) giveTool(player, "shovel");
        else if (slot == 31) startClaimTeleport(player, claim);
    }

    @SuppressWarnings("unchecked")
    private void handleClaimTrust(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.trust");
        if (slot == 45) { plugin.getClaimGuiManager().openManage(player, claim); return; }
        int[] lvlSlots = {46, 47, 48, 50};
        List<String> order = cfg.getStringList("level-order");
        for (int i = 0; i < Math.min(order.size(), lvlSlots.length); i++) if (lvlSlots[i] == slot) { plugin.getClaimGuiManager().setSelectedLevel(player.getUniqueId(), order.get(i)); plugin.getClaimGuiManager().openTrust(player, claim); return; }
        if (slot == 49) {
            String lvl = plugin.getClaimGuiManager().getSelectedLevel(player.getUniqueId());
            String lvlAr = cfg.getString("levels." + lvl, lvl);
            player.closeInventory();
            plugin.getConfigManager().send(player, "claims.trust-ask", "%level%", lvlAr);
            plugin.getChatPromptManager().prompt(player, input -> {
                if (input.equalsIgnoreCase("إلغاء") || input.equalsIgnoreCase("cancel")) return;
                OfflinePlayer target = Bukkit.getOfflinePlayer(input);
                if (!target.hasPlayedBefore() && !target.isOnline()) { plugin.getConfigManager().send(player, "claims.trust-invalid"); return; }
                if (target.getUniqueId().equals(player.getUniqueId())) { plugin.getConfigManager().send(player, "claims.trust-self"); return; }
                plugin.getGpHook().setTrust(claim, target.getUniqueId(), lvl);
                plugin.getConfigManager().send(player, "claims.trust-added", "%player%", input, "%level%", lvlAr, "%id%", String.valueOf(claimId));
                if (target.isOnline() && target.getPlayer() != null) plugin.getNotificationManager().notify(target.getPlayer(), "claim-trust", "claims.trust-target-added", "%owner%", player.getName(), "%level%", lvlAr, "%id%", String.valueOf(claimId));
            });
            return;
        }
        int idx = CLAIM_SLOTS.indexOf(slot);
        List<UUID> uuids = holder.get("trustedUuids", List.class);
        if (idx >= 0 && uuids != null && idx < uuids.size()) plugin.getClaimGuiManager().openLevelSelect(player, claimId, uuids.get(idx));
    }

    private void handleClaimTrustAction(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        UUID targetId = holder.get("targetId", UUID.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        if (slot == 22) plugin.getClaimGuiManager().openTrust(player, claim);
        else if (slot == 11) plugin.getClaimGuiManager().openLevelSelect(player, claimId, targetId);
        else if (slot == 15) plugin.getClaimGuiManager().openConfirmUntrust(player, claimId, targetId);
    }

    private void handleTrustLevel(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        UUID targetId = holder.get("targetId", UUID.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        if (slot == 31) { plugin.getClaimGuiManager().openTrust(player, claim); return; }
        if (slot == 33) { plugin.getClaimGuiManager().openConfirmUntrust(player, claimId, targetId); return; }

        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.trust");
        int[] slots = {10, 12, 14, 16};
        List<String> order = cfg.getStringList("level-order");
        String current = plugin.getGpHook().getPlayerTrustLevel(claim, targetId);
        OfflinePlayer op = Bukkit.getOfflinePlayer(targetId);
        String targetName = op.getName() != null ? op.getName() : "لاعب";

        for (int i = 0; i < Math.min(order.size(), slots.length); i++) {
            if (slots[i] == slot) {
                String lvl = order.get(i);
                String lvlAr = cfg.getString("levels." + lvl, lvl);
                if (lvl.equals(current)) {
                    // Toggle OFF -> Untrust
                    plugin.getGpHook().untrust(claim, targetId);
                    TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.click"), 0.8f);
                    plugin.getConfigManager().send(player, "claims.trust-removed", "%player%", targetName, "%id%", String.valueOf(claimId));
                    if (op.isOnline() && op.getPlayer() != null) plugin.getNotificationManager().notify(op.getPlayer(), "claim-trust", "claims.trust-target-removed", "%owner%", player.getName(), "%id%", String.valueOf(claimId));
                } else {
                    // Toggle ON -> Switch permission cleanly (drops Manage first!)
                    plugin.getGpHook().setTrust(claim, targetId, lvl);
                    TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.success"), 1.3f);
                    plugin.getConfigManager().send(player, "claims.trust-changed", "%player%", targetName, "%level%", lvlAr);
                    if (op.isOnline() && op.getPlayer() != null) plugin.getNotificationManager().notify(op.getPlayer(), "claim-trust", "claims.trust-target-changed", "%owner%", player.getName(), "%level%", lvlAr, "%id%", String.valueOf(claimId));
                }
                plugin.getClaimGuiManager().openLevelSelect(player, claimId, targetId);
                return;
            }
        }
    }

    private void handleConfirmDelete(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        if (slot == 11) plugin.getClaimGuiManager().openManage(player, claim);
        else if (slot == 15) { player.closeInventory(); if (plugin.getGpHook().deleteClaim(claim)) plugin.getConfigManager().send(player, "claims.deleted", "%id%", String.valueOf(claimId)); }
    }

    private void handleConfirmUntrust(Player player, GuiHolder holder, int slot) {
        long claimId = holder.get("claimId", Long.class);
        UUID targetId = holder.get("targetId", UUID.class);
        GriefPreventionHook.ClaimInfo claim = plugin.getGpHook().getClaimById(claimId);
        if (!isClaimOwnerOrAdmin(player, claim)) { player.closeInventory(); return; }
        if (slot == 11) plugin.getClaimGuiManager().openTrust(player, claim);
        else if (slot == 15) {
            plugin.getGpHook().untrust(claim, targetId);
            OfflinePlayer op = Bukkit.getOfflinePlayer(targetId);
            plugin.getConfigManager().send(player, "claims.trust-removed", "%player%", op.getName() != null ? op.getName() : "لاعب", "%id%", String.valueOf(claimId));
            if (op.isOnline() && op.getPlayer() != null) plugin.getNotificationManager().notify(op.getPlayer(), "claim-trust", "claims.trust-target-removed", "%owner%", player.getName(), "%id%", String.valueOf(claimId));
            plugin.getClaimGuiManager().openTrust(player, claim);
        }
    }
}
