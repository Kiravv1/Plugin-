package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class VaultManager {
    private final SurvivalPlus plugin;
    private final File dataFile;
    private final Map<String, ItemStack[]> vaults = new HashMap<>();

    public VaultManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "vaults-data.yml");
    }

    public void loadData() {
        vaults.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection sec = yml.getConfigurationSection("vaults");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            List<?> list = sec.getList(key);
            if (list == null) continue;
            ItemStack[] contents = new ItemStack[54];
            for (int i = 0; i < Math.min(list.size(), 54); i++) {
                if (list.get(i) instanceof ItemStack item) contents[i] = item;
            }
            vaults.put(key, contents);
        }
    }

    public void saveData() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<String, ItemStack[]> entry : vaults.entrySet()) {
            yml.set("vaults." + entry.getKey(), Arrays.asList(entry.getValue()));
        }
        try { yml.save(dataFile); } catch (IOException ignored) {}
    }

    public int getAllowedVaults(Player player) {
        int max = plugin.getConfigManager().getConfig().getInt("vaults.max-vaults", 5);
        int def = plugin.getConfigManager().getConfig().getInt("vaults.default-vaults", 2);
        if (player.hasPermission("survivalplus.admin")) return max;
        int allowed = def;
        for (int i = 1; i <= max; i++) if (player.hasPermission("survivalplus.vault." + i)) allowed = Math.max(allowed, i);
        return allowed;
    }

    public void openSelector(Player player) {
        int max = plugin.getConfigManager().getConfig().getInt("vaults.max-vaults", 5);
        int allowed = getAllowedVaults(player);
        GuiHolder holder = new GuiHolder("VAULT_SELECTOR");
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color(plugin.getConfigManager().getConfig().getString("vaults.gui-title", "الخزائن")));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        int[] slots = {11, 12, 13, 14, 15};
        for (int i = 0; i < Math.min(max, slots.length); i++) {
            int num = i + 1;
            boolean unlocked = num <= allowed;
            inv.setItem(slots[i], TextUtil.makeItem(
                    unlocked ? Material.ENDER_CHEST : Material.RED_STAINED_GLASS_PANE,
                    unlocked ? "&#C77DFF✦ الخزنة رقم &#FFD166#" + num : "&#EF476F✘ خزنة مغلقة #" + num,
                    List.of("", unlocked ? "  &#06D6A0» &fاضغط لفتح الخزنة" : "  &7تحتاج رتبة أعلى لفتح هذه الخزنة"),
                    unlocked));
        }
        inv.setItem(22, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFB703« العودة للقائمة الرئيسية", List.of(), false));
        player.openInventory(inv);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }

    public void openVault(Player player, int num) {
        if (num < 1 || num > getAllowedVaults(player)) {
            plugin.getConfigManager().send(player, "vaults.no-access");
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.error"));
            return;
        }
        String key = player.getUniqueId() + "_" + num;
        GuiHolder holder = new GuiHolder("VAULT_STORAGE").set("vaultKey", key);
        String title = plugin.getConfigManager().getConfig().getString("vaults.vault-title", "خزنة #%num%").replace("%num%", String.valueOf(num));
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(title));
        holder.setInventory(inv);
        ItemStack[] saved = vaults.get(key);
        if (saved != null) inv.setContents(saved);
        player.openInventory(inv);
        TextUtil.playSound(player, "BLOCK_ENDER_CHEST_OPEN", 1.1f);
    }

    public void saveVaultFromInventory(String key, Inventory inv) {
        if (key == null || inv == null) return;
        vaults.put(key, inv.getContents().clone());
        saveData();
    }
}
