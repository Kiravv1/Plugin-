package com.myserver.survivalplus.commands;

import com.myserver.survivalplus.SurvivalPlus;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class SurvivalTabCompleter implements TabCompleter {
    private final SurvivalPlus plugin;
    public SurvivalTabCompleter(SurvivalPlus plugin) { this.plugin = plugin; }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 2 && command.getName().equalsIgnoreCase("splus") && args[0].equalsIgnoreCase("rtpzone") && sender.hasPermission("survivalplus.admin")) {
            return List.of("pos1", "pos2", "setworld", "clear");
        }
        if (args.length != 1) return List.of();
        String input = args[0].toLowerCase();
        List<String> suggestions = new ArrayList<>();

        switch (command.getName().toLowerCase()) {
            case "shop" -> { suggestions.add("manage"); suggestions.add("add"); suggestions.add("إدارة"); suggestions.add("عرض"); suggestions.addAll(plugin.getPlayerShopManager().getAllShopNames()); }
            case "claim" -> { suggestions.add("menu"); suggestions.add("list"); suggestions.add("ادارة"); suggestions.add("قائمة"); if (sender.hasPermission("survivalplus.admin")) suggestions.add("reload"); }
            case "rtp" -> { ConfigurationSection worlds = plugin.getConfigManager().getConfig().getConfigurationSection("rtp.worlds"); if (worlds != null) for (String w : worlds.getKeys(false)) if (worlds.getBoolean(w + ".enabled", true)) suggestions.add(w); }
            case "pv" -> { for (int i = 1; i <= 5; i++) suggestions.add(String.valueOf(i)); }
            case "splus" -> { if (sender.hasPermission("survivalplus.admin")) { suggestions.add("reload"); suggestions.add("rtpzone"); } }
        }

        List<String> filtered = new ArrayList<>();
        for (String s : suggestions) if (s.toLowerCase().startsWith(input)) filtered.add(s);
        return filtered;
    }
}
