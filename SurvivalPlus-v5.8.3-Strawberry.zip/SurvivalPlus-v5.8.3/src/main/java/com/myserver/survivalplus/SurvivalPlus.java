package com.myserver.survivalplus;

import com.myserver.survivalplus.commands.SurvivalCommandExecutor;
import com.myserver.survivalplus.commands.SurvivalTabCompleter;
import com.myserver.survivalplus.listeners.GameplayListener;
import com.myserver.survivalplus.listeners.GuiListener;
import com.myserver.survivalplus.managers.*;
import com.myserver.survivalplus.util.GriefPreventionHook;
import com.myserver.survivalplus.util.VaultHook;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public class SurvivalPlus extends JavaPlugin {
    private ConfigManager configManager;
    private VaultHook vaultHook;
    private GriefPreventionHook gpHook;
    private NotificationManager notificationManager;
    private VaultManager vaultManager;
    private GraveManager graveManager;
    private CooldownManager cooldownManager;
    private TeleportManager teleportManager;
    private RtpManager rtpManager;
    private GroupRtpManager groupRtpManager;
    private PlayerShopManager playerShopManager;
    private ChatPromptManager chatPromptManager;
    private ClaimGuiManager claimGuiManager;

    @Override
    public void onEnable() {
        this.configManager = new ConfigManager(this);
        this.vaultHook = new VaultHook();
        this.gpHook = new GriefPreventionHook();
        boolean vaultOk = vaultHook.setup();
        boolean gpOk = gpHook.setup();

        this.notificationManager = new NotificationManager(this);
        this.notificationManager.loadData();
        this.vaultManager = new VaultManager(this);
        this.vaultManager.loadData();
        this.graveManager = new GraveManager(this);
        this.graveManager.loadData();
        this.graveManager.startTimerTask();
        this.cooldownManager = new CooldownManager();
        this.teleportManager = new TeleportManager(this);
        this.rtpManager = new RtpManager(this);
        this.groupRtpManager = new GroupRtpManager(this);
        this.groupRtpManager.startTask();
        this.playerShopManager = new PlayerShopManager(this);
        this.playerShopManager.loadData();
        this.chatPromptManager = new ChatPromptManager(this);
        this.claimGuiManager = new ClaimGuiManager(this);

        getServer().getPluginManager().registerEvents(new GuiListener(this), this);
        getServer().getPluginManager().registerEvents(new GameplayListener(this), this);
        getServer().getPluginManager().registerEvents(chatPromptManager, this);

        SurvivalCommandExecutor exec = new SurvivalCommandExecutor(this);
        SurvivalTabCompleter tab = new SurvivalTabCompleter(this);
        for (String cmdName : new String[]{"splus", "menu", "claim", "claimslist", "rtp", "shop", "pv", "grave", "notifications"}) {
            PluginCommand cmd = getCommand(cmdName);
            if (cmd != null) { cmd.setExecutor(exec); cmd.setTabCompleter(tab); }
        }

        getLogger().info("✦ SurvivalPlus v5.8.3 enabled | GriefPrevention: " + (gpOk ? "connected" : "missing") + " | Vault: " + (vaultOk ? "connected" : "missing"));
    }

    @Override
    public void onDisable() {
        if (this.playerShopManager != null) this.playerShopManager.saveData();
        if (this.notificationManager != null) this.notificationManager.saveData();
        if (this.vaultManager != null) this.vaultManager.saveData();
        if (this.graveManager != null) this.graveManager.saveData();
    }

    public ConfigManager getConfigManager() { return configManager; }
    public VaultHook getVaultHook() { return vaultHook; }
    public GriefPreventionHook getGpHook() { return gpHook; }
    public NotificationManager getNotificationManager() { return notificationManager; }
    public VaultManager getVaultManager() { return vaultManager; }
    public GraveManager getGraveManager() { return graveManager; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public TeleportManager getTeleportManager() { return teleportManager; }
    public RtpManager getRtpManager() { return rtpManager; }
    public GroupRtpManager getGroupRtpManager() { return groupRtpManager; }
    public PlayerShopManager getPlayerShopManager() { return playerShopManager; }
    public ChatPromptManager getChatPromptManager() { return chatPromptManager; }
    public ClaimGuiManager getClaimGuiManager() { return claimGuiManager; }
}
