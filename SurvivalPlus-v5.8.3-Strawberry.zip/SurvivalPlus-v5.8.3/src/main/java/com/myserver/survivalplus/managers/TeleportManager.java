package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.util.TextUtil;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TeleportManager {
    private final SurvivalPlus plugin;
    private final Map<UUID, BukkitTask> activeTasks = new HashMap<>();

    public TeleportManager(SurvivalPlus plugin) { this.plugin = plugin; }

    public void cancel(UUID playerId) {
        BukkitTask task = activeTasks.remove(playerId);
        if (task != null) task.cancel();
    }

    public void startTeleport(Player player, Location target, int seconds, boolean cancelOnMove, double tolerance,
                              String actionbarPath, String particleWarmup, String particleArrive,
                              String soundStart, String soundTick, String soundSuccess, String soundCancel,
                              Runnable onSuccess, Runnable onCancel) {
        cancel(player.getUniqueId());
        Location startLoc = player.getLocation().clone();
        boolean fx = plugin.getNotificationManager().isEnabledFor(player.getUniqueId(), "teleport-effects");
        if (fx) TextUtil.playSound(player, soundStart);

        final int[] remaining = {seconds};
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) { cancel(player.getUniqueId()); return; }
            if (cancelOnMove && (!player.getWorld().equals(startLoc.getWorld()) || player.getLocation().distance(startLoc) > tolerance)) {
                cancel(player.getUniqueId());
                if (fx) TextUtil.playSound(player, soundCancel);
                if (onCancel != null) onCancel.run();
                return;
            }
            if (remaining[0] <= 0) {
                cancel(player.getUniqueId());
                player.teleport(target);
                if (fx) { TextUtil.playSound(player, soundSuccess); TextUtil.spawnParticle(player, particleArrive, 30); }
                if (onSuccess != null) onSuccess.run();
                return;
            }
            player.sendActionBar(plugin.getConfigManager().rawMessageFor(player, actionbarPath, "%seconds%", String.valueOf(remaining[0])));
            if (fx) { TextUtil.playSound(player, soundTick); TextUtil.spawnParticle(player, particleWarmup, 12); }
            remaining[0]--;
        }, 0L, 20L);
        activeTasks.put(player.getUniqueId(), task);
    }

    public void showArriveTitle(Player player, Location loc) {
        if (!plugin.getNotificationManager().isEnabledFor(player.getUniqueId(), "teleport-effects")) return;
        player.showTitle(Title.title(
                plugin.getConfigManager().rawMessageFor(player, "rtp.arrive-title"),
                plugin.getConfigManager().rawMessageFor(player, "rtp.arrive-subtitle",
                        "%x%", String.valueOf(loc.getBlockX()), "%y%", String.valueOf(loc.getBlockY()),
                        "%z%", String.valueOf(loc.getBlockZ())),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(2), Duration.ofMillis(500))));
    }
}
