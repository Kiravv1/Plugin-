package com.myserver.survivalplus.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TextUtil {
    public static final String DIVIDER = "&#5C3A45&m────────────────────";
    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private static final Pattern ITALIC_CODE_PATTERN = Pattern.compile("(?i)[&§]o");
    private static final DecimalFormat MONEY_FMT = new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US));
    private static final DecimalFormat INT_FMT = new DecimalFormat("#,##0", DecimalFormatSymbols.getInstance(Locale.US));
    private static final LegacyComponentSerializer SERIALIZER = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors()
            .useUnusualXRepeatedCharacterHexFormat()
            .build();

    private TextUtil() {}

    public static String formatMoney(double amount) {
        if (Math.abs(amount) >= 1_000_000_000) return MONEY_FMT.format(amount / 1_000_000_000.0) + "B";
        if (Math.abs(amount) >= 1_000_000) return MONEY_FMT.format(amount / 1_000_000.0) + "M";
        return MONEY_FMT.format(amount);
    }

    public static String formatPrice(double amount) {
        return "$" + formatMoney(amount);
    }

    public static String formatInt(long value) {
        return INT_FMT.format(value);
    }

    public static Component color(String text) {
        if (text == null || text.isEmpty()) return Component.empty().decoration(TextDecoration.ITALIC, TextDecoration.State.FALSE);
        String noItalicCodes = ITALIC_CODE_PATTERN.matcher(text).replaceAll("");
        Matcher matcher = HEX_PATTERN.matcher(noItalicCodes);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) matcher.appendReplacement(sb, "&#" + matcher.group(1));
        matcher.appendTail(sb);
        return stripItalic(SERIALIZER.deserialize(sb.toString()));
    }

    private static Component stripItalic(Component component) {
        Component clean = component.decoration(TextDecoration.ITALIC, TextDecoration.State.FALSE);
        if (!clean.children().isEmpty()) {
            List<Component> updated = new ArrayList<>(clean.children().size());
            for (Component child : clean.children()) updated.add(stripItalic(child));
            clean = clean.children(updated);
        }
        return clean;
    }

    public static List<Component> colorList(List<String> lines) {
        List<Component> out = new ArrayList<>();
        if (lines == null) return out;
        for (String line : lines) out.add(color(line));
        return out;
    }

    public static Material parseMaterial(String name, Material fallback) {
        if (name == null || name.isBlank()) return fallback;
        try { return Material.valueOf(name.trim().toUpperCase()); } catch (IllegalArgumentException e) { return fallback; }
    }

    public static void playSound(Player player, String soundName) { playSound(player, soundName, 1.0f); }

    public static void playSound(Player player, String soundName, float pitch) {
        if (player == null || soundName == null || soundName.isBlank()) return;
        try {
            Sound sound = Sound.valueOf(soundName.trim().toUpperCase());
            player.playSound(player.getLocation(), sound, 0.85f, pitch);
        } catch (IllegalArgumentException ignored) {}
    }

    public static void spawnParticle(Player player, String particleName, int count) {
        if (player == null || particleName == null || particleName.isBlank()) return;
        try {
            Particle particle = Particle.valueOf(particleName.trim().toUpperCase());
            player.getWorld().spawnParticle(particle, player.getLocation().add(0, 1.0, 0), count, 0.5, 0.5, 0.5, 0.05);
        } catch (IllegalArgumentException ignored) {}
    }

    public static void runConsoleCommand(String command) {
        if (command == null || command.isBlank()) return;
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
    }

    public static void applySleekFrame(Inventory inv) {
        int size = inv.getSize();
        int rows = size / 9;
        ItemStack darkGlass = makeItem(Material.BLACK_STAINED_GLASS_PANE, " ", List.of(), false);
        ItemStack crimsonGlass = makeItem(Material.RED_STAINED_GLASS_PANE, " ", List.of(), false);
        ItemStack blushGlass = makeItem(Material.PINK_STAINED_GLASS_PANE, " ", List.of(), false);

        for (int i = 0; i < 9; i++) inv.setItem(i, darkGlass);
        for (int i = size - 9; i < size; i++) inv.setItem(i, darkGlass);
        for (int r = 1; r < rows - 1; r++) {
            inv.setItem(r * 9, darkGlass);
            inv.setItem(r * 9 + 8, darkGlass);
        }
        inv.setItem(0, crimsonGlass);
        inv.setItem(8, crimsonGlass);
        inv.setItem(size - 9, crimsonGlass);
        inv.setItem(size - 1, crimsonGlass);

        inv.setItem(1, blushGlass);
        inv.setItem(7, blushGlass);
        inv.setItem(size - 8, blushGlass);
        inv.setItem(size - 2, blushGlass);
    }

    public static ItemStack makeItem(Material mat, String name, List<String> lore, boolean glow) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(color(name));
            if (lore != null && !lore.isEmpty()) meta.lore(colorList(lore));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            if (glow) { meta.addEnchant(Enchantment.UNBREAKING, 1, true); meta.addItemFlags(ItemFlag.HIDE_ENCHANTS); }
            item.setItemMeta(meta);
        }
        return item;
    }

    public static ItemStack makeSkull(OfflinePlayer owner, String name, List<String> lore, boolean glow) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(owner);
            meta.displayName(color(name));
            if (lore != null && !lore.isEmpty()) meta.lore(colorList(lore));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            if (glow) { meta.addEnchant(Enchantment.UNBREAKING, 1, true); meta.addItemFlags(ItemFlag.HIDE_ENCHANTS); }
            skull.setItemMeta(meta);
        }
        return skull;
    }

    public static void safeGiveItems(Player player, ItemStack template, int totalAmount) {
        if (player == null || template == null || totalAmount <= 0) return;
        int maxStack = Math.max(1, template.getMaxStackSize());
        int remaining = totalAmount;
        while (remaining > 0) {
            int give = Math.min(remaining, maxStack);
            ItemStack stack = template.clone();
            stack.setAmount(give);
            HashMap<Integer, ItemStack> overflow = player.getInventory().addItem(stack);
            for (ItemStack drop : overflow.values()) player.getWorld().dropItemNaturally(player.getLocation(), drop);
            remaining -= give;
        }
    }
}
