package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.util.TextUtil;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.*;

public class GroupRtpManager {
    private final SurvivalPlus plugin;
    private final Map<UUID, Location> pos1Selection = new HashMap<>();
    private BukkitTask zoneTask;
    private int countdown = -1;

    public GroupRtpManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    public void startTask() {
        if (zoneTask != null) zoneTask.cancel();
        zoneTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tickZone, 20L, 20L);
    }

    public void setPos1(Player player) {
        Location loc = player.getLocation().getBlock().getLocation();
        pos1Selection.put(player.getUniqueId(), loc);
        plugin.getConfigManager().send(player, "rtp.zone-pos1",
                "%x%", String.valueOf(loc.getBlockX()),
                "%y%", String.valueOf(loc.getBlockY()),
                "%z%", String.valueOf(loc.getBlockZ()));
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.success"), 1.2f);
    }

    public void setPos2(Player player) {
        Location p1 = pos1Selection.get(player.getUniqueId());
        Location p2 = player.getLocation().getBlock().getLocation();
        if (p1 == null || !p1.getWorld().equals(p2.getWorld())) {
            p1 = p2;
        }
        int minX = Math.min(p1.getBlockX(), p2.getBlockX());
        int minY = Math.min(p1.getBlockY(), p2.getBlockY());
        int minZ = Math.min(p1.getBlockZ(), p2.getBlockZ());
        int maxX = Math.max(p1.getBlockX(), p2.getBlockX());
        int maxY = Math.max(p1.getBlockY(), p2.getBlockY());
        int maxZ = Math.max(p1.getBlockZ(), p2.getBlockZ());

        var cfg = plugin.getConfigManager().getConfig();
        cfg.set("rtp.group-zone.enabled", true);
        cfg.set("rtp.group-zone.configured", true);
        cfg.set("rtp.group-zone.world", p2.getWorld().getName());
        cfg.set("rtp.group-zone.min-x", minX);
        cfg.set("rtp.group-zone.min-y", minY);
        cfg.set("rtp.group-zone.min-z", minZ);
        cfg.set("rtp.group-zone.max-x", maxX);
        cfg.set("rtp.group-zone.max-y", maxY);
        cfg.set("rtp.group-zone.max-z", maxZ);
        plugin.saveConfig();

        plugin.getConfigManager().send(player, "rtp.zone-pos2");
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.purchase"), 1.3f);
    }

    public void setTargetWorld(Player player, String worldName) {
        plugin.getConfigManager().getConfig().set("rtp.group-zone.target-world", worldName);
        plugin.saveConfig();
        plugin.getConfigManager().send(player, "rtp.zone-world-set", "%world%", worldName);
    }

    public void clearZone(Player player) {
        plugin.getConfigManager().getConfig().set("rtp.group-zone.configured", false);
        plugin.saveConfig();
        countdown = -1;
        plugin.getConfigManager().send(player, "rtp.zone-cleared");
    }

    private void tickZone() {
        ConfigurationSection gz = plugin.getConfigManager().getConfig().getConfigurationSection("rtp.group-zone");
        if (gz == null || !gz.getBoolean("enabled", true) || !gz.getBoolean("configured", false)) {
            countdown = -1;
            return;
        }
        String zoneWorldName = gz.getString("world", "world");
        World zoneWorld = Bukkit.getWorld(zoneWorldName);
        if (zoneWorld == null) return;

        int minX = gz.getInt("min-x"), minY = gz.getInt("min-y"), minZ = gz.getInt("min-z");
        int maxX = gz.getInt("max-x"), maxY = gz.getInt("max-y"), maxZ = gz.getInt("max-z");
        int minPlayers = Math.max(1, gz.getInt("min-players", 2));
        int totalSeconds = Math.max(1, gz.getInt("countdown-seconds", 6));

        List<Player> inside = new ArrayList<>();
        for (Player p : zoneWorld.getPlayers()) {
            if (p.isDead()) continue;
            Location l = p.getLocation();
            int bx = l.getBlockX(), by = l.getBlockY(), bz = l.getBlockZ();
            if (bx >= minX && bx <= maxX && by >= minY && by <= maxY && bz >= minZ && bz <= maxZ) {
                inside.add(p);
            }
        }

        if (inside.size() < minPlayers) {
            if (countdown != -1) {
                countdown = -1;
                String cancelSound = gz.getString("sound-cancel", "ENTITY_VILLAGER_NO");
                for (Player p : inside) {
                    plugin.getConfigManager().send(p, "rtp.group-cancelled");
                    TextUtil.playSound(p, cancelSound, 0.9f);
                }
            } else if (!inside.isEmpty()) {
                int needed = minPlayers - inside.size();
                for (Player p : inside) {
                    p.sendActionBar(plugin.getConfigManager().rawMessage("rtp.group-waiting", "%needed%", String.valueOf(needed)));
                }
            }
            return;
        }

        if (countdown == -1) {
            countdown = totalSeconds;
        }

        String warmupParticle = gz.getString("particle-warmup", "CHERRY_LEAVES");
        String tickSound = gz.getString("sound-tick", "BLOCK_NOTE_BLOCK_CHIME");

        if (countdown > 0) {
            float pitch = 0.8f + ((totalSeconds - countdown) * 0.12f);
            Title title = Title.title(
                    plugin.getConfigManager().rawMessage("rtp.group-title"),
                    plugin.getConfigManager().rawMessage("rtp.group-subtitle", "%seconds%", String.valueOf(countdown)),
                    Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(900), Duration.ofMillis(150))
            );
            for (Player p : inside) {
                boolean fx = plugin.getNotificationManager().isEnabledFor(p.getUniqueId(), "teleport-effects");
                p.sendActionBar(plugin.getConfigManager().rawMessage("rtp.group-actionbar",
                        "%count%", String.valueOf(inside.size()),
                        "%seconds%", String.valueOf(countdown)));
                if (fx) {
                    p.showTitle(title);
                    TextUtil.playSound(p, tickSound, Math.min(2.0f, pitch));
                    TextUtil.spawnParticle(p, warmupParticle, 16);
                }
            }
            countdown--;
            return;
        }

        // Countdown reached 0 -> Teleport everyone together to the SAME safe random location!
        countdown = -1;
        String targetWorldName = gz.getString("target-world", "world");
        Location safe = plugin.getRtpManager().findSafeLocationForWorld(targetWorldName);
        if (safe == null) {
            for (Player p : inside) plugin.getConfigManager().send(p, "rtp.failed-safe");
            return;
        }

        String arriveParticle = gz.getString("particle-arrive", "HEART");
        String successSound = gz.getString("sound-success", "ENTITY_ENDERMAN_TELEPORT");
        Title arriveTitle = Title.title(
                plugin.getConfigManager().rawMessage("rtp.group-arrive-title"),
                plugin.getConfigManager().rawMessage("rtp.group-arrive-subtitle",
                        "%x%", String.valueOf(safe.getBlockX()),
                        "%y%", String.valueOf(safe.getBlockY()),
                        "%z%", String.valueOf(safe.getBlockZ()),
                        "%count%", String.valueOf(inside.size())),
                Title.Times.times(Duration.ofMillis(250), Duration.ofSeconds(2), Duration.ofMillis(400))
        );

        for (Player p : inside) {
            p.teleport(safe);
            boolean fx = plugin.getNotificationManager().isEnabledFor(p.getUniqueId(), "teleport-effects");
            if (fx) {
                TextUtil.playSound(p, successSound, 1.1f);
                TextUtil.spawnParticle(p, arriveParticle, 28);
                TextUtil.spawnParticle(p, "PORTAL", 20);
                p.showTitle(arriveTitle);
            }
            plugin.getConfigManager().send(p, "rtp.group-arrive-chat",
                    "%count%", String.valueOf(inside.size()),
                    "%x%", String.valueOf(safe.getBlockX()),
                    "%y%", String.valueOf(safe.getBlockY()),
                    "%z%", String.valueOf(safe.getBlockZ()),
                    "%world%", safe.getWorld().getName());
        }
    }
}
