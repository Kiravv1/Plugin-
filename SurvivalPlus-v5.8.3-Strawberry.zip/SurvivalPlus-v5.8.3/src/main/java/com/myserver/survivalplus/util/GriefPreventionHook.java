package com.myserver.survivalplus.util;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

public class GriefPreventionHook {
    private Object gpInstance;
    private Object dataStore;

    public boolean setup() {
        Plugin plugin = Bukkit.getPluginManager().getPlugin("GriefPrevention");
        if (plugin == null || !plugin.isEnabled()) return false;
        try {
            this.gpInstance = plugin;
            Field dsField = plugin.getClass().getField("dataStore");
            this.dataStore = dsField.get(plugin);
            return this.dataStore != null;
        } catch (Exception e) { return false; }
    }

    public boolean isConnected() { return gpInstance != null && dataStore != null; }

    public record ClaimInfo(long id, String ownerName, UUID ownerId, String worldName, int minX, int maxX, int minZ, int maxZ,
                            int area, int subdivisions, boolean explosivesAllowed, Object rawClaim) {
        public int width() { return Math.abs(maxX - minX) + 1; }
        public int length() { return Math.abs(maxZ - minZ) + 1; }
        public int centerX() { return (minX + maxX) / 2; }
        public int centerZ() { return (minZ + maxZ) / 2; }
        public Location getSafeTeleportLocation(int yOffset) {
            World world = Bukkit.getWorld(worldName);
            if (world == null) return null;
            int y = world.getHighestBlockYAt(centerX(), centerZ()) + yOffset;
            return new Location(world, centerX() + 0.5, y, centerZ() + 0.5);
        }
    }

    public boolean isInsideAnyClaim(Location loc) { return getClaimOwnerAt(loc) != null; }

    public String getClaimOwnerAt(Location loc) {
        if (!isConnected() || loc == null) return null;
        try {
            Method m = dataStore.getClass().getMethod("getClaimAt", Location.class, boolean.class, Class.forName("me.ryanhamshire.GriefPrevention.Claim"));
            Object claim = m.invoke(dataStore, loc, true, null);
            if (claim == null) return null;
            String owner = (String) claim.getClass().getMethod("getOwnerName").invoke(claim);
            return (owner != null && !owner.isBlank()) ? owner : "إدارة السيرفر";
        } catch (Exception e) { return null; }
    }

    public List<ClaimInfo> getPlayerClaims(UUID playerId) {
        List<ClaimInfo> result = new ArrayList<>();
        if (!isConnected()) return result;
        try {
            Object pd = dataStore.getClass().getMethod("getPlayerData", UUID.class).invoke(dataStore, playerId);
            Collection<?> claims = (Collection<?>) pd.getClass().getMethod("getClaims").invoke(pd);
            for (Object c : claims) { ClaimInfo info = toClaimInfo(c); if (info != null) result.add(info); }
        } catch (Exception ignored) {}
        return result;
    }

    public ClaimInfo getClaimById(long id) {
        if (!isConnected()) return null;
        try {
            Object c = dataStore.getClass().getMethod("getClaim", long.class).invoke(dataStore, id);
            return c != null ? toClaimInfo(c) : null;
        } catch (Exception e) { return null; }
    }

    private ClaimInfo toClaimInfo(Object claim) {
        try {
            Long id = (Long) claim.getClass().getMethod("getID").invoke(claim);
            UUID ownerId = (UUID) claim.getClass().getMethod("getOwnerID").invoke(claim);
            String ownerName = (String) claim.getClass().getMethod("getOwnerName").invoke(claim);
            Location lesser = (Location) claim.getClass().getMethod("getLesserBoundaryCorner").invoke(claim);
            Location greater = (Location) claim.getClass().getMethod("getGreaterBoundaryCorner").invoke(claim);
            int area = (Integer) claim.getClass().getMethod("getArea").invoke(claim);
            boolean explosions = (Boolean) claim.getClass().getField("areExplosivesAllowed").get(claim);
            Collection<?> children = (Collection<?>) claim.getClass().getField("children").get(claim);
            return new ClaimInfo(id != null ? id : -1L, ownerName != null ? ownerName : "إدارة السيرفر", ownerId,
                    lesser.getWorld().getName(), lesser.getBlockX(), greater.getBlockX(), lesser.getBlockZ(), greater.getBlockZ(),
                    area, children != null ? children.size() : 0, explosions, claim);
        } catch (Exception e) { return null; }
    }

    public int getRemainingBlocks(UUID playerId) {
        if (!isConnected()) return 0;
        try {
            Object pd = dataStore.getClass().getMethod("getPlayerData", UUID.class).invoke(dataStore, playerId);
            return (Integer) pd.getClass().getMethod("getRemainingClaimBlocks").invoke(pd);
        } catch (Exception e) { return 0; }
    }

    public int getBonusBlocks(UUID playerId) {
        if (!isConnected()) return 0;
        try {
            Object pd = dataStore.getClass().getMethod("getPlayerData", UUID.class).invoke(dataStore, playerId);
            return (Integer) pd.getClass().getMethod("getBonusClaimBlocks").invoke(pd);
        } catch (Exception e) { return 0; }
    }

    public boolean addBonusBlocks(UUID playerId, int delta) {
        if (!isConnected()) return false;
        int before = getBonusBlocks(playerId);
        try {
            Object pd = dataStore.getClass().getMethod("getPlayerData", UUID.class).invoke(dataStore, playerId);
            pd.getClass().getMethod("setBonusClaimBlocks", int.class).invoke(pd, before + delta);
            for (Method m : dataStore.getClass().getMethods()) {
                if (m.getName().equals("savePlayerData") && m.getParameterCount() == 2) { m.invoke(dataStore, playerId, pd); break; }
            }
            if (getBonusBlocks(playerId) == before + delta) return true;
        } catch (Exception ignored) {}
        OfflinePlayer op = Bukkit.getOfflinePlayer(playerId);
        if (op.getName() != null) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "acb " + op.getName() + " " + delta);
            return getBonusBlocks(playerId) == before + delta;
        }
        return false;
    }

    public boolean toggleExplosions(ClaimInfo info) {
        if (!isConnected() || info == null) return false;
        try {
            Field f = info.rawClaim().getClass().getField("areExplosivesAllowed");
            boolean next = !((Boolean) f.get(info.rawClaim()));
            f.set(info.rawClaim(), next);
            dataStore.getClass().getMethod("saveClaim", info.rawClaim().getClass()).invoke(dataStore, info.rawClaim());
            return next;
        } catch (Exception e) { return false; }
    }

    public boolean deleteClaim(ClaimInfo info) {
        if (!isConnected() || info == null) return false;
        try { dataStore.getClass().getMethod("deleteClaim", info.rawClaim().getClass()).invoke(dataStore, info.rawClaim()); return true; }
        catch (Exception e) { return false; }
    }

    public Map<UUID, String> getTrustedPlayers(ClaimInfo info) {
        Map<UUID, String> map = new LinkedHashMap<>();
        if (!isConnected() || info == null) return map;
        try {
            ArrayList<String> b = new ArrayList<>(), c = new ArrayList<>(), a = new ArrayList<>(), m = new ArrayList<>();
            info.rawClaim().getClass().getMethod("getPermissions", ArrayList.class, ArrayList.class, ArrayList.class, ArrayList.class)
                    .invoke(info.rawClaim(), b, c, a, m);
            for (String s : a) putUuid(map, s, "Access");
            for (String s : c) putUuid(map, s, "Container");
            for (String s : b) putUuid(map, s, "Build");
            for (String s : m) putUuid(map, s, "Manage");
        } catch (Exception ignored) {}
        return map;
    }

    private void putUuid(Map<UUID, String> map, String raw, String level) {
        try { map.put(UUID.fromString(raw), level); } catch (IllegalArgumentException ignored) {}
    }

    public String getPlayerTrustLevel(ClaimInfo info, UUID targetId) {
        if (info == null || targetId == null) return null;
        return getTrustedPlayers(info).get(targetId);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public boolean setTrust(ClaimInfo info, UUID targetId, String level) {
        if (!isConnected() || info == null || targetId == null) return false;
        try {
            // CRITICAL FIX: Drop existing permission & remove from managers list first so downgrading from Manage works!
            clearAllPermissionsInternal(info, targetId);

            Class<?> permClass = Class.forName("me.ryanhamshire.GriefPrevention.ClaimPermission");
            Object perm = switch (level) {
                case "Manage" -> Enum.valueOf((Class<Enum>) permClass, "Manage");
                case "Container" -> Enum.valueOf((Class<Enum>) permClass, "Inventory");
                case "Access" -> Enum.valueOf((Class<Enum>) permClass, "Access");
                default -> Enum.valueOf((Class<Enum>) permClass, "Build");
            };
            info.rawClaim().getClass().getMethod("setPermission", String.class, permClass).invoke(info.rawClaim(), targetId.toString(), perm);
            dataStore.getClass().getMethod("saveClaim", info.rawClaim().getClass()).invoke(dataStore, info.rawClaim());
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean untrust(ClaimInfo info, UUID targetId) {
        if (!isConnected() || info == null || targetId == null) return false;
        try {
            clearAllPermissionsInternal(info, targetId);
            dataStore.getClass().getMethod("saveClaim", info.rawClaim().getClass()).invoke(dataStore, info.rawClaim());
            return true;
        } catch (Exception e) { return false; }
    }

    @SuppressWarnings("unchecked")
    private void clearAllPermissionsInternal(ClaimInfo info, UUID targetId) throws Exception {
        String idStr = targetId.toString();
        info.rawClaim().getClass().getMethod("dropPermission", String.class).invoke(info.rawClaim(), idStr);
        try {
            Field managersField = info.rawClaim().getClass().getField("managers");
            Object managersObj = managersField.get(info.rawClaim());
            if (managersObj instanceof Collection<?> col) {
                col.remove(idStr);
            }
        } catch (NoSuchFieldException ignored) {}
    }
}
