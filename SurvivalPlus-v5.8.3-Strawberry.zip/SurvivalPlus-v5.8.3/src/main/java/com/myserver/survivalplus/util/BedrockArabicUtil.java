package com.myserver.survivalplus.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.*;

public final class BedrockArabicUtil {
    private static Object floodgateApi;
    private static Method isFloodgatePlayerMethod;
    private static boolean initialized = false;
    private static final Map<Character, char[]> FORMS = new HashMap<>();

    static {
        FORMS.put('\u0621', new char[]{'\uFE80', '\uFE80', '\uFE80', '\uFE80'});
        FORMS.put('\u0622', new char[]{'\uFE81', '\uFE82', '\uFE81', '\uFE82'});
        FORMS.put('\u0623', new char[]{'\uFE83', '\uFE84', '\uFE83', '\uFE84'});
        FORMS.put('\u0624', new char[]{'\uFE85', '\uFE86', '\uFE85', '\uFE86'});
        FORMS.put('\u0625', new char[]{'\uFE87', '\uFE88', '\uFE87', '\uFE88'});
        FORMS.put('\u0626', new char[]{'\uFE89', '\uFE8A', '\uFE8B', '\uFE8C'});
        FORMS.put('\u0627', new char[]{'\uFE8D', '\uFE8E', '\uFE8D', '\uFE8E'});
        FORMS.put('\u0628', new char[]{'\uFE8F', '\uFE90', '\uFE91', '\uFE92'});
        FORMS.put('\u0629', new char[]{'\uFE93', '\uFE94', '\uFE93', '\uFE94'});
        FORMS.put('\u062A', new char[]{'\uFE95', '\uFE96', '\uFE97', '\uFE98'});
        FORMS.put('\u062B', new char[]{'\uFE99', '\uFE9A', '\uFE9B', '\uFE9C'});
        FORMS.put('\u062C', new char[]{'\uFE9D', '\uFE9E', '\uFE9F', '\uFEA0'});
        FORMS.put('\u062D', new char[]{'\uFEA1', '\uFEA2', '\uFEA3', '\uFEA4'});
        FORMS.put('\u062E', new char[]{'\uFEA5', '\uFEA6', '\uFEA7', '\uFEA8'});
        FORMS.put('\u062F', new char[]{'\uFEA9', '\uFEAA', '\uFEA9', '\uFEAA'});
        FORMS.put('\u0630', new char[]{'\uFEAB', '\uFEAC', '\uFEAB', '\uFEAC'});
        FORMS.put('\u0631', new char[]{'\uFEAD', '\uFEAE', '\uFEAD', '\uFEAE'});
        FORMS.put('\u0632', new char[]{'\uFEAF', '\uFEB0', '\uFEAF', '\uFEB0'});
        FORMS.put('\u0633', new char[]{'\uFEB1', '\uFEB2', '\uFEB3', '\uFEB4'});
        FORMS.put('\u0634', new char[]{'\uFEB5', '\uFEB6', '\uFEB7', '\uFEB8'});
        FORMS.put('\u0635', new char[]{'\uFEB9', '\uFEBA', '\uFEBB', '\uFEBC'});
        FORMS.put('\u0636', new char[]{'\uFEBD', '\uFEBE', '\uFEBF', '\uFEC0'});
        FORMS.put('\u0637', new char[]{'\uFEC1', '\uFEC2', '\uFEC3', '\uFEC4'});
        FORMS.put('\u0638', new char[]{'\uFEC5', '\uFEC6', '\uFEC7', '\uFEC8'});
        FORMS.put('\u0639', new char[]{'\uFEC9', '\uFECA', '\uFECB', '\uFECC'});
        FORMS.put('\u063A', new char[]{'\uFECD', '\uFECE', '\uFECF', '\uFED0'});
        FORMS.put('\u0640', new char[]{'\u0640', '\u0640', '\u0640', '\u0640'});
        FORMS.put('\u0641', new char[]{'\uFED1', '\uFED2', '\uFED3', '\uFED4'});
        FORMS.put('\u0642', new char[]{'\uFED5', '\uFED6', '\uFED7', '\uFED8'});
        FORMS.put('\u0643', new char[]{'\uFED9', '\uFEDA', '\uFEDB', '\uFEDC'});
        FORMS.put('\u0644', new char[]{'\uFEDD', '\uFEDE', '\uFEDF', '\uFEE0'});
        FORMS.put('\u0645', new char[]{'\uFEE1', '\uFEE2', '\uFEE3', '\uFEE4'});
        FORMS.put('\u0646', new char[]{'\uFEE5', '\uFEE6', '\uFEE7', '\uFEE8'});
        FORMS.put('\u0647', new char[]{'\uFEE9', '\uFEEA', '\uFEEB', '\uFEEC'});
        FORMS.put('\u0648', new char[]{'\uFEED', '\uFEEE', '\uFEED', '\uFEEE'});
        FORMS.put('\u0649', new char[]{'\uFEEF', '\uFEF0', '\uFEEF', '\uFEF0'});
        FORMS.put('\u064A', new char[]{'\uFEF1', '\uFEF2', '\uFEF3', '\uFEF4'});
    }

    private BedrockArabicUtil() {}

    public static void init() {
        if (initialized) return;
        initialized = true;
        if (Bukkit.getPluginManager().getPlugin("floodgate") == null) return;
        try {
            Class<?> apiClass = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
            floodgateApi = apiClass.getMethod("getInstance").invoke(null);
            isFloodgatePlayerMethod = apiClass.getMethod("isFloodgatePlayer", UUID.class);
        } catch (Exception ignored) {
            floodgateApi = null;
            isFloodgatePlayerMethod = null;
        }
    }

    public static boolean isBedrockPlayer(Player player) {
        if (player == null) return false;
        if (!initialized) init();
        if (floodgateApi != null && isFloodgatePlayerMethod != null) {
            try {
                Object res = isFloodgatePlayerMethod.invoke(floodgateApi, player.getUniqueId());
                if (res instanceof Boolean b && b) return true;
            } catch (Exception ignored) {}
        }
        return player.getName().startsWith(".");
    }

    public static Component adaptFor(Player player, Component component) {
        if (player == null || component == null || !isBedrockPlayer(player)) return component;
        return fixComponent(component);
    }

    public static Component fixComponent(Component component) {
        if (component == null) return Component.empty();
        Component updated = component;
        if (component instanceof TextComponent tc) {
            String content = tc.content();
            if (containsArabic(content) && !isAlreadyShaped(content)) {
                updated = tc.content(reorderRtlPreservingLtr(shapeArabic(content)));
            }
        }
        if (!updated.children().isEmpty()) {
            List<Component> kids = new ArrayList<>(updated.children().size());
            for (Component c : updated.children()) kids.add(fixComponent(c));
            updated = updated.children(kids);
        }
        return updated;
    }

    private static boolean containsArabic(String s) {
        if (s == null || s.isEmpty()) return false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '\u0600' && c <= '\u06FF') return true;
        }
        return false;
    }

    private static boolean isAlreadyShaped(String s) {
        boolean hasPres = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '\uFE70' && c <= '\uFEFF') hasPres = true;
            else if (c >= '\u0621' && c <= '\u064A') return false;
        }
        return hasPres;
    }

    private static boolean isTashkeel(char c) { return (c >= '\u064B' && c <= '\u065F') || c == '\u0670'; }
    private static boolean connectsAfter(char c) { char[] f = FORMS.get(c); return f != null && (f[0] != f[2] || c == '\u0640'); }

    private static String shapeArabic(String input) {
        StringBuilder out = new StringBuilder(input.length());
        int len = input.length();
        for (int i = 0; i < len; i++) {
            char curr = input.charAt(i);
            if (!FORMS.containsKey(curr)) { out.append(curr); continue; }
            int prevIdx = i - 1; while (prevIdx >= 0 && isTashkeel(input.charAt(prevIdx))) prevIdx--;
            int nextIdx = i + 1; while (nextIdx < len && isTashkeel(input.charAt(nextIdx))) nextIdx++;
            boolean prevConn = (prevIdx >= 0) && connectsAfter(input.charAt(prevIdx));
            if (curr == '\u0644' && nextIdx == i + 1 && nextIdx < len) {
                char next = input.charAt(nextIdx);
                char lig = switch (next) {
                    case '\u0622' -> prevConn ? '\uFEF6' : '\uFEF5';
                    case '\u0623' -> prevConn ? '\uFEF8' : '\uFEF7';
                    case '\u0625' -> prevConn ? '\uFEFA' : '\uFEF9';
                    case '\u0627' -> prevConn ? '\uFEFC' : '\uFEFB';
                    default -> 0;
                };
                if (lig != 0) { out.append(lig); i++; continue; }
            }
            boolean nextConn = (nextIdx < len) && FORMS.containsKey(input.charAt(nextIdx)) && connectsAfter(curr);
            char[] forms = FORMS.get(curr);
            if (prevConn && nextConn) out.append(forms[3]);
            else if (prevConn) out.append(forms[1]);
            else if (nextConn) out.append(forms[2]);
            else out.append(forms[0]);
        }
        return out.toString();
    }

    private static boolean isLtr(char c) {
        return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')
                || c == '_' || c == '.' || c == '$' || c == '/' || c == '%';
    }

    private static String reorderRtlPreservingLtr(String text) {
        List<String> tokens = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        Boolean inLtr = null;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            boolean ltr = isLtr(c);
            if (inLtr == null || ltr == inLtr) { inLtr = ltr; cur.append(c); }
            else { tokens.add(cur.toString()); cur.setLength(0); inLtr = ltr; cur.append(c); }
        }
        if (!cur.isEmpty()) tokens.add(cur.toString());
        StringBuilder res = new StringBuilder(text.length());
        for (int i = tokens.size() - 1; i >= 0; i--) {
            String tok = tokens.get(i);
            if (isLtr(tok.charAt(0))) res.append(tok);
            else for (int j = tok.length() - 1; j >= 0; j--) res.append(tok.charAt(j));
        }
        return res.toString();
    }
}
