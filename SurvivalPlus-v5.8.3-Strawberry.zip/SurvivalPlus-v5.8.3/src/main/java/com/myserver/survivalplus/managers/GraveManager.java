package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.models.GraveData;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Skull;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class GraveManager {
    private final SurvivalPlus plugin;
    private final File dataFile;
    private final Map<String, GraveData> gravesByBlockKey = new LinkedHashMap<>();
    private BukkitTask timerTask;

    public GraveManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "graves-data.yml");
    }

    public void startTimerTask() {
        if (timerTask != null) timerTask.cancel();
        timerTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            List<GraveData> expired = new ArrayList<>();
            for (GraveData g : gravesByBlockKey.values()) {
                if (g.isExpired()) {
                    expired.add(g);
                } else {
                    updateHologramTimer(g);
                }
            }
            for (GraveData g : expired) {
                removeGrave(g);
            }
        }, 20L, 20L);
    }

    public void loadData() {
        gravesByBlockKey.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection sec = yml.getConfigurationSection("graves");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            ConfigurationSection g = sec.getConfigurationSection(id);
            if (g == null) continue;
            long exp = g.getLong("expiresAt", 0);
            if (System.currentTimeMillis() > exp) continue;
            try {
                UUID owner = UUID.fromString(g.getString("ownerId", ""));
                String ownerName = g.getString("ownerName", "Player");
                String world = g.getString("world", "world");
                int x = g.getInt("x"), y = g.getInt("y"), z = g.getInt("z");
                Map<Integer, ItemStack> items = new LinkedHashMap<>();
                ConfigurationSection itemSec = g.getConfigurationSection("items");
                if (itemSec != null) {
                    for (String slotKey : itemSec.getKeys(false)) {
                        ItemStack is = itemSec.getItemStack(slotKey);
                        if (is != null && !is.getType().isAir()) items.put(Integer.parseInt(slotKey), is);
                    }
                }
                GraveData gd = new GraveData(id, owner, ownerName, world, x, y, z, exp, items);
                if (g.contains("holo1")) gd.setHoloLine1(UUID.fromString(g.getString("holo1")));
                if (g.contains("holo2")) gd.setHoloLine2(UUID.fromString(g.getString("holo2")));
                gravesByBlockKey.put(gd.getBlockKey(), gd);
            } catch (Exception ignored) {}
        }
    }

    public void saveData() {
        YamlConfiguration yml = new YamlConfiguration();
        for (GraveData g : gravesByBlockKey.values()) {
            if (g.isExpired()) continue;
            String base = "graves." + g.getId();
            yml.set(base + ".ownerId", g.getOwnerId().toString());
            yml.set(base + ".ownerName", g.getOwnerName());
            yml.set(base + ".world", g.getWorldName());
            yml.set(base + ".x", g.getX());
            yml.set(base + ".y", g.getY());
            yml.set(base + ".z", g.getZ());
            yml.set(base + ".expiresAt", g.getExpiresAt());
            if (g.getHoloLine1() != null) yml.set(base + ".holo1", g.getHoloLine1().toString());
            if (g.getHoloLine2() != null) yml.set(base + ".holo2", g.getHoloLine2().toString());
            for (Map.Entry<Integer, ItemStack> e : g.getSlotItems().entrySet()) {
                yml.set(base + ".items." + e.getKey(), e.getValue());
            }
        }
        try { yml.save(dataFile); } catch (IOException ignored) {}
    }

    public GraveData getGraveAt(Location loc) {
        if (loc == null || loc.getWorld() == null) return null;
        String key = loc.getWorld().getName() + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
        return gravesByBlockKey.get(key);
    }

    public List<GraveData> getPlayerGraves(UUID ownerId) {
        List<GraveData> list = new ArrayList<>();
        for (GraveData g : gravesByBlockKey.values()) {
            if (!g.isExpired() && g.getOwnerId().equals(ownerId)) list.add(g);
        }
        return list;
    }

    public void createGraveFromDeath(Player player) {
        if (!plugin.getConfigManager().getConfig().getBoolean("graves.enabled", true)) return;
        Map<Integer, ItemStack> slotMap = new LinkedHashMap<>();
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item == null || item.getType().isAir()) continue;
            if (item.containsEnchantment(Enchantment.VANISHING_CURSE)) continue;
            slotMap.put(i, item.clone());
        }
        if (slotMap.isEmpty()) return;

        Location loc = player.getLocation().clone();
        World world = loc.getWorld();
        int x = loc.getBlockX();
        int y = Math.max(world.getMinHeight() + 1, Math.min(world.getMaxHeight() - 2, loc.getBlockY()));
        int z = loc.getBlockZ();
        Block block = world.getBlockAt(x, y, z);
        if (!block.isEmpty() && !block.isReplaceable() && y + 1 < world.getMaxHeight() - 1) {
            Block above = world.getBlockAt(x, y + 1, z);
            if (above.isEmpty() || above.isReplaceable()) { block = above; y++; }
        }

        // Place Player Head with dead player's skin
        block.setType(Material.PLAYER_HEAD, false);
        if (block.getState() instanceof Skull skull) {
            skull.setOwningPlayer(player);
            skull.update(true, false);
        }

        int mins = plugin.getConfigManager().getConfig().getInt("graves.expire-minutes", 30);
        long exp = System.currentTimeMillis() + (mins * 60000L);
        String id = UUID.randomUUID().toString().substring(0, 6);
        GraveData grave = new GraveData(id, player.getUniqueId(), player.getName(), world.getName(), x, y, z, exp, slotMap);

        // Spawn 2-line ArmorStand hologram (100% Java + Bedrock/Geyser compatible!)
        Location baseHolo = new Location(world, x + 0.5, y + 0.95, z + 0.5);
        String line1Text = plugin.getConfigManager().getConfig().getString("graves.hologram-line1", "&#FF4D6D✦ &#FFF0F3قبر &#FFD166%owner%")
                .replace("%owner%", player.getName());
        String line2Text = plugin.getConfigManager().getConfig().getString("graves.hologram-line2", "&#FF8FA3الوقت المتبقي: &#06D6A0%time%")
                .replace("%time%", grave.getFormattedRemaining());

        ArmorStand as1 = spawnHologramLine(baseHolo, line1Text);
        ArmorStand as2 = spawnHologramLine(baseHolo.clone().subtract(0, 0.28, 0), line2Text);
        grave.setHoloLine1(as1.getUniqueId());
        grave.setHoloLine2(as2.getUniqueId());

        gravesByBlockKey.put(grave.getBlockKey(), grave);
        saveData();

        plugin.getConfigManager().send(player, "graves.created",
                "%x%", String.valueOf(x), "%y%", String.valueOf(y), "%z%", String.valueOf(z), "%mins%", String.valueOf(mins));
    }

    private ArmorStand spawnHologramLine(Location loc, String text) {
        return loc.getWorld().spawn(loc, ArmorStand.class, as -> {
            as.setInvisible(true);
            as.setMarker(true);
            as.setGravity(false);
            as.setInvulnerable(true);
            as.setCustomNameVisible(true);
            as.customName(TextUtil.color(text));
            as.setPersistent(true);
        });
    }

    private void updateHologramTimer(GraveData grave) {
        if (grave.getHoloLine2() == null) return;
        Entity entity = Bukkit.getEntity(grave.getHoloLine2());
        if (entity instanceof ArmorStand as) {
            String line2 = plugin.getConfigManager().getConfig().getString("graves.hologram-line2", "&#FF8FA3الوقت المتبقي: &#06D6A0%time%")
                    .replace("%time%", grave.getFormattedRemaining());
            as.customName(TextUtil.color(line2));
        }
    }

    // Normal Right-Click -> Open Grave Inventory (Anyone can loot!)
    public void openGraveLoot(Player player, GraveData grave) {
        if (grave.isExpired()) { removeGrave(grave); return; }
        Inventory inv = grave.getSharedLootInventory();
        if (inv == null) {
            GuiHolder holder = new GuiHolder("GRAVE_LOOT").set("graveKey", grave.getBlockKey());
            String title = plugin.getConfigManager().getConfig().getString("graves.loot-title", "قبر %owner%").replace("%owner%", grave.getOwnerName());
            inv = Bukkit.createInventory(holder, 54, TextUtil.color(title));
            holder.setInventory(inv);
            for (Map.Entry<Integer, ItemStack> entry : grave.getSlotItems().entrySet()) {
                int slot = entry.getKey();
                if (slot >= 0 && slot < 54) inv.setItem(slot, entry.getValue().clone());
            }
            grave.setSharedLootInventory(inv);
        }
        player.openInventory(inv);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }

    // Sync after someone closes GRAVE_LOOT; remove grave if completely empty!
    public void syncLootInventory(String graveKey, Inventory inv) {
        GraveData grave = gravesByBlockKey.get(graveKey);
        if (grave == null) return;
        grave.getSlotItems().clear();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack item = inv.getItem(i);
            if (item != null && !item.getType().isAir()) {
                grave.getSlotItems().put(i, item.clone());
            }
        }
        if (grave.getSlotItems().isEmpty()) {
            removeGrave(grave);
        } else {
            saveData();
        }
    }

    // Shift + Right-Click -> Quick-Loot in exact original slot order + Auto-Equip Armor if owner!
    public void quickLootGrave(Player player, GraveData grave) {
        if (grave.isExpired()) { removeGrave(grave); return; }

        // Sync & close any open viewers first to prevent dupes
        if (grave.getSharedLootInventory() != null) {
            Inventory shared = grave.getSharedLootInventory();
            for (HumanEntity viewer : new ArrayList<>(shared.getViewers())) viewer.closeInventory();
            syncLootInventory(grave.getBlockKey(), shared);
            if (!gravesByBlockKey.containsKey(grave.getBlockKey())) return;
        }

        boolean isOwner = player.getUniqueId().equals(grave.getOwnerId());
        PlayerInventory pInv = player.getInventory();
        List<ItemStack> overflow = new ArrayList<>();

        for (Map.Entry<Integer, ItemStack> entry : grave.getSlotItems().entrySet()) {
            int slot = entry.getKey();
            ItemStack item = entry.getValue().clone();

            // Armor slots: 36=boots, 37=leggings, 38=chestplate, 39=helmet
            if (slot >= 36 && slot <= 39) {
                if (isOwner && isSlotEmpty(pInv.getItem(slot))) {
                    pInv.setItem(slot, item);
                } else {
                    overflow.add(item);
                }
            } else if (slot == 40) { // Offhand
                if (isSlotEmpty(pInv.getItemInOffHand())) {
                    pInv.setItemInOffHand(item);
                } else {
                    overflow.add(item);
                }
            } else if (slot >= 0 && slot <= 35) { // Exact hotbar/main inventory slot
                if (isSlotEmpty(pInv.getItem(slot))) {
                    pInv.setItem(slot, item);
                } else {
                    overflow.add(item);
                }
            } else {
                overflow.add(item);
            }
        }

        for (ItemStack extra : overflow) {
            TextUtil.safeGiveItems(player, extra, extra.getAmount());
        }

        removeGrave(grave);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.purchase"), 1.3f);
        TextUtil.spawnParticle(player, "HAPPY_VILLAGER", 15);
        plugin.getConfigManager().send(player, "graves.claimed");
    }

    private boolean isSlotEmpty(ItemStack item) {
        return item == null || item.getType().isAir();
    }

    public void removeGrave(GraveData grave) {
        gravesByBlockKey.remove(grave.getBlockKey());
        if (grave.getSharedLootInventory() != null) {
            for (HumanEntity viewer : new ArrayList<>(grave.getSharedLootInventory().getViewers())) viewer.closeInventory();
            grave.setSharedLootInventory(null);
        }
        Location loc = grave.getBlockLocation();
        if (loc != null && loc.getBlock().getType() == Material.PLAYER_HEAD) {
            loc.getBlock().setType(Material.AIR, false);
        }
        if (grave.getHoloLine1() != null) { Entity e = Bukkit.getEntity(grave.getHoloLine1()); if (e != null) e.remove(); }
        if (grave.getHoloLine2() != null) { Entity e = Bukkit.getEntity(grave.getHoloLine2()); if (e != null) e.remove(); }
        saveData();
    }

    public void openGravesGui(Player player) {
        List<GraveData> active = getPlayerGraves(player.getUniqueId());
        GuiHolder holder = new GuiHolder("GRAVES_GUI").set("graves", active);
        Inventory inv = Bukkit.createInventory(holder, 36, TextUtil.color(plugin.getConfigManager().getConfig().getString("graves.gui-title", "القبور النشطة")));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        if (active.isEmpty()) {
            inv.setItem(13, TextUtil.makeItem(Material.BARRIER, "&#EF476F✦ لا توجد قبور نشطة", List.of("", "  &7عند موتك سيظهر رأسك في موقع الموت", "  &7محفوظاً فيه جميع أغراضك لمدة 30 دقيقة"), false));
        } else {
            int[] slots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25};
            double tpCost = plugin.getConfigManager().getConfig().getDouble("graves.teleport-cost", 0.0);
            String costTxt = tpCost > 0 ? TextUtil.formatPrice(tpCost) : "مجاني";
            for (int i = 0; i < Math.min(active.size(), slots.length); i++) {
                GraveData g = active.get(i);
                inv.setItem(slots[i], TextUtil.makeSkull(player, "&#FF4D6D★ قبر نشط &7#" + g.getId(),
                        List.of(TextUtil.DIVIDER,
                                "  &#FF8FA3▪ &fالعالم: &#FFB3C1" + g.getWorldName(),
                                "  &#FF8FA3▪ &fالموقع: &#FFD166" + g.getX() + ", " + g.getY() + ", " + g.getZ(),
                                "  &#FF8FA3▪ &fالأغراض: &#06D6A0" + TextUtil.formatInt(g.getSlotItems().size()) + " غرض",
                                "  &#FF8FA3▪ &fالمتبقي: &#72EFDD" + g.getFormattedRemaining(),
                                "  &#FF8FA3▪ &fتكلفة الانتقال: &#FFD166" + costTxt,
                                TextUtil.DIVIDER,
                                "  &#06D6A0» &fكليك يسار: الانتقال إلى القبر",
                                "  &#FFB703» &fكليك يمين: معاينة محتويات القبر"), true));
            }
        }
        inv.setItem(31, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFB703« العودة للقائمة الرئيسية", List.of(), false));
        player.openInventory(inv);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }

    public void openGravePreview(Player player, GraveData grave) {
        if (grave == null || grave.isExpired()) { openGravesGui(player); return; }
        GuiHolder holder = new GuiHolder("GRAVE_PREVIEW").set("graveKey", grave.getBlockKey());
        String title = plugin.getConfigManager().getConfig().getString("graves.preview-title", "&#FF4D6D✦ محتويات قبر #%id%")
                .replace("%id%", grave.getId());
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(title));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        inv.setItem(4, TextUtil.makeSkull(player, "&#FF4D6D★ تفاصيل القبر &7#" + grave.getId(),
                List.of(TextUtil.DIVIDER,
                        "  &#FF8FA3▪ &fالموقع: &#FFD166" + grave.getX() + ", " + grave.getY() + ", " + grave.getZ(),
                        "  &#FF8FA3▪ &fالأغراض: &#06D6A0" + TextUtil.formatInt(grave.getSlotItems().size()),
                        "  &#FF8FA3▪ &fالمتبقي: &#72EFDD" + grave.getFormattedRemaining(),
                        TextUtil.DIVIDER,
                        "  &7هذه معاينة فقط — انتقل للقبر لسحب أغراضك"), false));

        // Display armor & offhand first, then storage items cleanly inside slots 10..43
        int[] displaySlots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34, 37,38,39,40,41,42,43};
        List<ItemStack> ordered = new ArrayList<>();
        for (int s : new int[]{39, 38, 37, 36, 40}) {
            if (grave.getSlotItems().containsKey(s)) ordered.add(grave.getSlotItems().get(s).clone());
        }
        for (Map.Entry<Integer, ItemStack> e : grave.getSlotItems().entrySet()) {
            if (e.getKey() < 36) ordered.add(e.getValue().clone());
        }
        for (int i = 0; i < Math.min(ordered.size(), displaySlots.length); i++) {
            inv.setItem(displaySlots[i], ordered.get(i));
        }

        inv.setItem(48, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFB703« رجوع لقائمة القبور", List.of(), false));
        inv.setItem(50, TextUtil.makeItem(Material.ENDER_PEARL, "&#06D6A0✦ الانتقال إلى هذا القبر", List.of("", "  &7انتقال آمن إلى موقع قبرك"), true));
        player.openInventory(inv);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }

    public void teleportToGrave(Player player, GraveData grave) {
        if (grave == null || grave.isExpired()) { openGravesGui(player); return; }
        if (!plugin.getConfigManager().getConfig().getBoolean("graves.allow-teleport", true)) {
            plugin.getConfigManager().send(player, "graves.tp-disabled");
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.error"));
            return;
        }
        double cost = plugin.getConfigManager().getConfig().getDouble("graves.teleport-cost", 0.0);
        if (cost > 0 && !plugin.getVaultHook().has(player, cost)) {
            plugin.getConfigManager().send(player, "graves.tp-no-money", "%cost%", TextUtil.formatPrice(cost));
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.error"));
            return;
        }
        Location target = grave.getBlockLocation();
        if (target == null) return;
        Location safeTarget = target.clone().add(0.5, 1.0, 0.5);
        player.closeInventory();
        int sec = plugin.getConfigManager().getConfig().getInt("claims.teleport.countdown-seconds", 5);
        plugin.getConfigManager().send(player, "graves.tp-start", "%id%", grave.getId(), "%seconds%", String.valueOf(sec));
        plugin.getTeleportManager().startTeleport(player, safeTarget, sec, true, 0.25,
                "graves.tp-actionbar", "CHERRY_LEAVES", "PORTAL",
                "BLOCK_NOTE_BLOCK_PLING", "BLOCK_NOTE_BLOCK_HAT", "ENTITY_ENDERMAN_TELEPORT", "ENTITY_VILLAGER_NO",
                () -> {
                    if (cost > 0 && plugin.getVaultHook().isConnected()) plugin.getVaultHook().withdraw(player, cost);
                    plugin.getConfigManager().send(player, "graves.tp-success");
                },
                () -> plugin.getConfigManager().send(player, "claims.tp-cancelled"));
    }

    public GraveData getGraveByKey(String key) {
        return key != null ? gravesByBlockKey.get(key) : null;
    }
}
