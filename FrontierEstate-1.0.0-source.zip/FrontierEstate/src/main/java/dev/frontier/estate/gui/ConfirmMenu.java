package dev.frontier.estate.gui;

import dev.frontier.estate.FrontierEstatePlugin;
import dev.frontier.estate.util.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.List;

/** "Are you sure?" screen used before any purchase. */
public final class ConfirmMenu extends Menu {

    public ConfirmMenu(FrontierEstatePlugin plugin, Component title, List<String> lines, Runnable onConfirm) {
        super(plugin, 3, title);
        set(11, Text.item(Material.LIME_CONCRETE, "<green><bold>تأكيد"), e -> {
            Player p = (Player) e.getWhoClicked();
            Bukkit.getScheduler().runTask(plugin, () -> {
                p.closeInventory();
                onConfirm.run();
            });
        });
        set(13, Text.item(Material.PAPER, "<yellow>التفاصيل", lines.toArray(new String[0])));
        set(15, Text.item(Material.RED_CONCRETE, "<red><bold>إلغاء"), e -> {
            Player p = (Player) e.getWhoClicked();
            Bukkit.getScheduler().runTask(plugin, p::closeInventory);
        });
    }
}
