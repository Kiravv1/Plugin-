package com.myserver.survivalplus.util;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

public class GriefPreventionHook {
    public record GPClaimInfo(int index, String worldName, int minX, int minZ, int maxX, int maxZ, Location teleportTarget) {
        public int width() { return (maxX - minX) + 1; }
        public int length() { return (maxZ - minZ) + 1; }
        public int area() { return width() * length(); }
        public int centerX() { return (minX + maxX) / 2; }
        public int centerZ() { return (minZ + maxZ) / 2; }
    }

    private boolean hooked = false;
    private Object dataStore;
    private Method mGetPlayerData;
    private Method mSavePlayerData;
    private Method mGetClaimAt;
    private int getClaimAtParamCount;

    private Method mGetAccrued;
    private Method mGetBonus;
    private Method mSetBonus;
    private Method mGetRemaining;
    private Method mGetClaims;
    private Field fClaimsField;

    // فحص صلاحيات البناء في GriefPrevention الحديثة والقديمة
    private Method mCheckPermission;
    private Object buildClaimPermission;
    private Method mAllowBuildLegacy;
    private int allowBuildParamCount;

    private Field fLesser;
    private Field fGreater;

    private Field findFieldAnywhere(Class<?> clazz, String name) {
        Class<?> current = clazz;
        while (current != null) {
            try {
                Field f = current.getDeclaredField(name);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    private Method findMethodAnywhere(Class<?> clazz, String name, Class<?>... params) {
        Class<?> current = clazz;
        while (current != null) {
            try {
                Method m = current.getDeclaredMethod(name, params);
                m.setAccessible(true);
                return m;
            } catch (NoSuchMethodException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    public boolean setup() {
        Plugin gp = Bukkit.getPluginManager().getPlugin("GriefPrevention");
        if (gp == null || !gp.isEnabled()) {
            this.hooked = false;
            return false;
        }

        try {
            ClassLoader gpLoader = gp.getClass().getClassLoader();
            Class<?> gpClass = Class.forName("me.ryanhamshire.GriefPrevention.GriefPrevention", true, gpLoader);

            Field fInstance = findFieldAnywhere(gpClass, "instance");
            Object instance = (fInstance != null) ? fInstance.get(null) : gp;
            if (instance == null) {
                instance = gp;
            }

            Field fDataStore = findFieldAnywhere(gpClass, "dataStore");
            if (fDataStore != null) {
                this.dataStore = fDataStore.get(instance);
            } else {
                Method mGetDataStore = findMethodAnywhere(gpClass, "getDataStore");
                if (mGetDataStore != null) {
                    this.dataStore = mGetDataStore.invoke(instance);
                }
            }

            if (this.dataStore == null) {
                throw new IllegalStateException("GriefPrevention dataStore is null");
            }

            Class<?> dsClass = dataStore.getClass();
            this.mGetPlayerData = findMethodAnywhere(dsClass, "getPlayerData", UUID.class);
            if (this.mGetPlayerData == null) {
                throw new NoSuchMethodException("DataStore.getPlayerData(UUID) not found");
            }

            // البحث المرن عن دالة savePlayerData
            for (Method m : dsClass.getMethods()) {
                if (m.getName().equals("savePlayerData") && m.getParameterCount() == 2) {
                    m.setAccessible(true);
                    this.mSavePlayerData = m;
                    break;
                }
            }

            // البحث المرن عن دالة getClaimAt (تدعم 3 أو 4 بارامترات)
            for (Method m : dsClass.getMethods()) {
                if (m.getName().equals("getClaimAt") && m.getParameterCount() >= 3) {
                    Class<?>[] params = m.getParameterTypes();
                    if (params[0] == Location.class && params[1] == boolean.class) {
                        m.setAccessible(true);
                        this.mGetClaimAt = m;
                        this.getClaimAtParamCount = m.getParameterCount();
                        break;
                    }
                }
            }
            if (this.mGetClaimAt == null) {
                throw new NoSuchMethodException("DataStore.getClaimAt not found");
            }

            Class<?> claimClass = Class.forName("me.ryanhamshire.GriefPrevention.Claim", true, gpLoader);
            this.fLesser = findFieldAnywhere(claimClass, "lesserBoundaryCorner");
            this.fGreater = findFieldAnywhere(claimClass, "greaterBoundaryCorner");

            // فحص دوال الصلاحيات في Claim بدون كسر الربط لو تغيرت
            try {
                Class<?> permEnum = Class.forName("me.ryanhamshire.GriefPrevention.ClaimPermission", true, gpLoader);
                @SuppressWarnings("unchecked")
                Class<Enum> enumType = (Class<Enum>) permEnum;
                this.buildClaimPermission = Enum.valueOf(enumType, "Build");
                this.mCheckPermission = findMethodAnywhere(claimClass, "checkPermission", Player.class, permEnum, Event.class);
            } catch (Throwable ignored) {
                for (Method m : claimClass.getMethods()) {
                    if (m.getName().equals("allowBuild")) {
                        m.setAccessible(true);
                        this.mAllowBuildLegacy = m;
                        this.allowBuildParamCount = m.getParameterCount();
                        break;
                    }
                }
            }

            Class<?> pdClass = Class.forName("me.ryanhamshire.GriefPrevention.PlayerData", true, gpLoader);
            this.mGetAccrued = findMethodAnywhere(pdClass, "getAccruedClaimBlocks");
            this.mGetBonus = findMethodAnywhere(pdClass, "getBonusClaimBlocks");
            this.mSetBonus = findMethodAnywhere(pdClass, "setBonusClaimBlocks", int.class);
            this.mGetRemaining = findMethodAnywhere(pdClass, "getRemainingClaimBlocks");

            this.mGetClaims = findMethodAnywhere(pdClass, "getClaims");
            if (this.mGetClaims == null) {
                this.fClaimsField = findFieldAnywhere(pdClass, "claims");
            }

            this.hooked = true;
            return true;
        } catch (Throwable e) {
            Bukkit.getLogger().warning("[SurvivalPlus] تعذر الربط مع GriefPrevention: " + e.getClass().getSimpleName() + " - " + e.getMessage());
            this.hooked = false;
            return false;
        }
    }

    public boolean isHooked() {
        if (!hooked) {
            return setup();
        }
        Plugin gp = Bukkit.getPluginManager().getPlugin("GriefPrevention");
        if (gp == null || !gp.isEnabled() || dataStore == null) {
            hooked = false;
            return setup();
        }
        return true;
    }

    private Object invokeGetClaimAt(Location loc) throws Exception {
        if (getClaimAtParamCount == 4) {
            return mGetClaimAt.invoke(dataStore, loc, true, false, null);
        }
        return mGetClaimAt.invoke(dataStore, loc, true, null);
    }

    public boolean isClaimedAt(Location loc) {
        if (!isHooked() || loc == null) return false;
        try {
            return invokeGetClaimAt(loc) != null;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean canBuildAt(Player player, Location loc, Material mat) {
        if (!isHooked() || loc == null) return true;
        try {
            Object claim = invokeGetClaimAt(loc);
            if (claim == null) return true;

            if (mCheckPermission != null && buildClaimPermission != null) {
                Object denialSupplier = mCheckPermission.invoke(claim, player, buildClaimPermission, null);
                return denialSupplier == null;
            }
            if (mAllowBuildLegacy != null) {
                Object denial = (allowBuildParamCount == 2)
                        ? mAllowBuildLegacy.invoke(claim, player, mat)
                        : mAllowBuildLegacy.invoke(claim, player);
                return denial == null;
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    public int getAccruedBlocks(UUID uuid) {
        if (!isHooked() || mGetAccrued == null) return 0;
        try {
            Object pd = mGetPlayerData.invoke(dataStore, uuid);
            return pd != null ? (int) mGetAccrued.invoke(pd) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    public int getBonusBlocks(UUID uuid) {
        if (!isHooked() || mGetBonus == null) return 0;
        try {
            Object pd = mGetPlayerData.invoke(dataStore, uuid);
            return pd != null ? (int) mGetBonus.invoke(pd) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    public int getRemainingBlocks(UUID uuid) {
        if (!isHooked() || mGetRemaining == null) return 0;
        try {
            Object pd = mGetPlayerData.invoke(dataStore, uuid);
            return pd != null ? (int) mGetRemaining.invoke(pd) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    public boolean addBonusBlocks(UUID uuid, int delta) {
        if (!isHooked() || mSetBonus == null) return false;
        try {
            Object pd = mGetPlayerData.invoke(dataStore, uuid);
            if (pd == null) return false;
            int current = mGetBonus != null ? (int) mGetBonus.invoke(pd) : 0;
            int next = current + delta;
            if (next < 0) return false;
            mSetBonus.invoke(pd, next);
            if (mSavePlayerData != null) {
                mSavePlayerData.invoke(dataStore, uuid, pd);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public List<GPClaimInfo> getPlayerClaims(UUID uuid) {
        List<GPClaimInfo> result = new ArrayList<>();
        if (!isHooked() || fLesser == null || fGreater == null) return result;
        try {
            Object pd = mGetPlayerData.invoke(dataStore, uuid);
            if (pd == null) return result;
            Collection<?> claims = (mGetClaims != null)
                    ? (Collection<?>) mGetClaims.invoke(pd)
                    : (fClaimsField != null ? (Collection<?>) fClaimsField.get(pd) : Collections.emptyList());
            if (claims == null) return result;
            int idx = 1;
            for (Object c : claims) {
                Location lesser = (Location) fLesser.get(c);
                Location greater = (Location) fGreater.get(c);
                if (lesser == null || greater == null || lesser.getWorld() == null) continue;
                int minX = Math.min(lesser.getBlockX(), greater.getBlockX());
                int maxX = Math.max(lesser.getBlockX(), greater.getBlockX());
                int minZ = Math.min(lesser.getBlockZ(), greater.getBlockZ());
                int maxZ = Math.max(lesser.getBlockZ(), greater.getBlockZ());
                int cx = (minX + maxX) / 2;
                int cz = (minZ + maxZ) / 2;
                int y = lesser.getWorld().getHighestBlockYAt(cx, cz) + 1;
                Location tp = new Location(lesser.getWorld(), cx + 0.5, y, cz + 0.5);
                result.add(new GPClaimInfo(idx++, lesser.getWorld().getName(), minX, minZ, maxX, maxZ, tp));
            }
        } catch (Exception ignored) {}
        return result;
    }
}
