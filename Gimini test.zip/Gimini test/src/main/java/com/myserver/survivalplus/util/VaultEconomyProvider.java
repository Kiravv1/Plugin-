package com.myserver.survivalplus.util;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

public class VaultEconomyProvider implements EconomyProvider {
    private Economy economy;

    public boolean setup() {
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        this.economy = rsp.getProvider();
        return this.economy != null;
    }

    @Override
    public boolean isReady() { return economy != null; }

    @Override
    public double getBalance(OfflinePlayer player) { return isReady() ? economy.getBalance(player) : 0.0; }

    @Override
    public boolean has(OfflinePlayer player, double amount) { return isReady() && economy.has(player, amount); }

    @Override
    public boolean withdraw(OfflinePlayer player, double amount) {
        if (!isReady()) return false;
        if (amount <= 0) return true;
        EconomyResponse resp = economy.withdrawPlayer(player, amount);
        return resp.transactionSuccess();
    }

    @Override
    public boolean deposit(OfflinePlayer player, double amount) {
        if (!isReady()) return false;
        if (amount <= 0) return true;
        EconomyResponse resp = economy.depositPlayer(player, amount);
        return resp.transactionSuccess();
    }
}
