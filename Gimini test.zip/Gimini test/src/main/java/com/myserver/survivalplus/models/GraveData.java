package com.myserver.survivalplus.models;

import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class GraveData {
    private final String id;
    private final UUID ownerUuid;
    private final String ownerName;
    private final Location location;
    private final List<ItemStack> items;
    private final int storedExp;
    private final long createdAt;
    private final long expiresAt;
    private UUID hologramEntityUuid;
    private boolean claimed;

    public GraveData(String id, UUID ownerUuid, String ownerName, Location location, List<ItemStack> items, int storedExp, long createdAt, long expiresAt) {
        this.id = id;
        this.ownerUuid = ownerUuid;
        this.ownerName = ownerName;
        this.location = location;
        this.items = new ArrayList<>(items);
        this.storedExp = storedExp;
        this.createdAt = createdAt;
        this.expiresAt = expiresAt;
        this.claimed = false;
    }

    public String getId() { return id; }
    public UUID getOwnerUuid() { return ownerUuid; }
    public String getOwnerName() { return ownerName; }
    public Location getLocation() { return location; }
    public List<ItemStack> getItems() { return items; }
    public int getStoredExp() { return storedExp; }
    public long getCreatedAt() { return createdAt; }
    public long getExpiresAt() { return expiresAt; }
    public UUID getHologramEntityUuid() { return hologramEntityUuid; }
    public void setHologramEntityUuid(UUID hologramEntityUuid) { this.hologramEntityUuid = hologramEntityUuid; }
    public boolean isClaimed() { return claimed; }
    public void setClaimed(boolean claimed) { this.claimed = claimed; }

    public long getRemainingSeconds() {
        return Math.max(0L, (expiresAt - System.currentTimeMillis()) / 1000L);
    }

    public boolean isExpired() {
        return System.currentTimeMillis() >= expiresAt;
    }
}
