package com.myserver.survivalplus.util;

import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachmentInfo;

public final class PermissionUtil {
    private PermissionUtil() {}

    public static int getMaxNumericPermission(Player player, String prefix, int defaultValue, int opDefault) {
        if (player.isOp() || player.hasPermission("survivalplus.admin")) {
            return opDefault;
        }
        String normalized = prefix.toLowerCase();
        int max = defaultValue;
        for (PermissionAttachmentInfo info : player.getEffectivePermissions()) {
            if (!info.getValue()) continue;
            String perm = info.getPermission().toLowerCase();
            if (perm.startsWith(normalized)) {
                String suffix = perm.substring(normalized.length());
                try {
                    int val = Integer.parseInt(suffix);
                    if (val > max) max = val;
                } catch (NumberFormatException ignored) {}
            }
        }
        return max;
    }

    public static int getMinNumericPermission(Player player, String prefix, int defaultValue, int opDefault) {
        if (player.isOp() || player.hasPermission("survivalplus.admin")) {
            return opDefault;
        }
        String normalized = prefix.toLowerCase();
        int min = defaultValue;
        boolean found = false;
        for (PermissionAttachmentInfo info : player.getEffectivePermissions()) {
            if (!info.getValue()) continue;
            String perm = info.getPermission().toLowerCase();
            if (perm.startsWith(normalized)) {
                String suffix = perm.substring(normalized.length());
                try {
                    int val = Integer.parseInt(suffix);
                    if (val >= 0 && (!found || val < min)) {
                        min = val;
                        found = true;
                    }
                } catch (NumberFormatException ignored) {}
            }
        }
        return min;
    }
}
