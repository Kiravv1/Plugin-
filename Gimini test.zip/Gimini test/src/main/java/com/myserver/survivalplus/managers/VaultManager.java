package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.util.PermissionUtil;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class VaultManager {
    private final SurvivalPlus plugin;
    private final File folder;
    private final Set<String> openSessions = new HashSet<>();

    public static class VaultInventoryHolder implements InventoryHolder {
        private final UUID ownerUuid;
        private final int vaultNumber;

        public VaultInventoryHolder(UUID ownerUuid, int vaultNumber) {
            this.ownerUuid = ownerUuid;
            this.vaultNumber = vaultNumber;
        }

        public UUID getOwnerUuid() { return ownerUuid; }
        public int getVaultNumber() { return vaultNumber; }

        @Override
        public Inventory getInventory() { return null; }
    }

    public VaultManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.folder = new File(plugin.getDataFolder(), "vaults");
        if (!folder.exists()) folder.mkdirs();
    }

    private File getPlayerFile(UUID uuid) {
        return new File(folder, uuid.toString() + ".yml");
    }

    public int getAllowedVaults(Player player) {
        int def = plugin.getConfig().getInt("vaults.default-vaults", 1);
        int cap = plugin.getConfig().getInt("vaults.max-vaults-cap", 54);
        int allowed = PermissionUtil.getMaxNumericPermission(player, "survivalplus.vaults.", def, cap);
        return Math.max(1, Math.min(cap, allowed));
    }

    public Material getVaultIcon(UUID uuid, int vaultNum) {
        File f = getPlayerFile(uuid);
        if (!f.exists()) return Material.CHEST;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        String matName = cfg.getString("vaults." + vaultNum + ".icon", "CHEST");
        Material mat = Material.matchMaterial(matName);
        return (mat != null && mat.isItem()) ? mat : Material.CHEST;
    }

    public void setVaultIcon(UUID uuid, int vaultNum, Material mat) {
        File f = getPlayerFile(uuid);
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        cfg.set("vaults." + vaultNum + ".icon", mat != null ? mat.name() : "CHEST");
        try { cfg.save(f); } catch (IOException e) { e.printStackTrace(); }
    }

    public int getUsedSlots(UUID uuid, int vaultNum) {
        File f = getPlayerFile(uuid);
        if (!f.exists()) return 0;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        int count = 0;
        for (int i = 0; i < 54; i++) {
            ItemStack item = cfg.getItemStack("vaults." + vaultNum + ".items." + i);
            if (item != null && item.getType() != Material.AIR) count++;
        }
        return count;
    }

    public void openVault(Player player, UUID ownerUuid, int vaultNum) {
        String sessionKey = ownerUuid + ":" + vaultNum;
        if (openSessions.contains(sessionKey)) {
            player.sendMessage(plugin.msg("vaults.already-open"));
            return;
        }

        openSessions.add(sessionKey);
        Inventory inv = Bukkit.createInventory(new VaultInventoryHolder(ownerUuid, vaultNum), 54,
                TextUtil.color("&8❖ &5الخزنة الشخصية &d#" + vaultNum + " &8❖"));

        File f = getPlayerFile(ownerUuid);
        if (f.exists()) {
            FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
            for (int i = 0; i < 54; i++) {
                ItemStack item = cfg.getItemStack("vaults." + vaultNum + ".items." + i);
                if (item != null) inv.setItem(i, item);
            }
        }

        player.openInventory(inv);
    }

    public void saveAndCloseVault(UUID ownerUuid, int vaultNum, Inventory inv) {
        String sessionKey = ownerUuid + ":" + vaultNum;
        try {
            File f = getPlayerFile(ownerUuid);
            FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
            cfg.set("vaults." + vaultNum + ".items", null);
            for (int i = 0; i < 54; i++) {
                ItemStack item = inv.getItem(i);
                if (item != null && item.getType() != Material.AIR) {
                    cfg.set("vaults." + vaultNum + ".items." + i, item);
                }
            }
            cfg.save(f);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            openSessions.remove(sessionKey);
        }
    }
}
