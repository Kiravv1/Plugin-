package com.myserver.survivalplus.gui;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.managers.ShopManager;
import com.myserver.survivalplus.models.GraveData;
import com.myserver.survivalplus.models.PlayerShop;
import com.myserver.survivalplus.models.SaleRecord;
import com.myserver.survivalplus.models.ShopListing;
import com.myserver.survivalplus.util.GriefPreventionHook;
import com.myserver.survivalplus.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.*;

public class GuiManager {
    private final SurvivalPlus plugin;
    public final NamespacedKey keyData;
    public final NamespacedKey keyIntData;

    public static final List<Material> SHOP_ICONS = Arrays.asList(
            Material.DIAMOND_SWORD, Material.NETHERITE_SWORD, Material.BOW, Material.CROSSBOW, Material.TRIDENT, Material.MACE, Material.SHIELD,
            Material.DIAMOND_PICKAXE, Material.NETHERITE_PICKAXE, Material.DIAMOND_AXE, Material.GOLDEN_APPLE, Material.ENCHANTED_GOLDEN_APPLE, Material.TOTEM_OF_UNDYING, Material.ELYTRA,
            Material.DIAMOND, Material.EMERALD, Material.GOLD_INGOT, Material.IRON_INGOT, Material.NETHERITE_INGOT, Material.AMETHYST_SHARD, Material.LAPIS_LAZULI,
            Material.REDSTONE, Material.QUARTZ, Material.COAL, Material.COPPER_INGOT, Material.RAW_GOLD, Material.RAW_IRON, Material.ANCIENT_DEBRIS,
            Material.ENCHANTED_BOOK, Material.EXPERIENCE_BOTTLE, Material.BREWING_STAND, Material.POTION, Material.SPLASH_POTION, Material.BLAZE_ROD, Material.GHAST_TEAR,
            Material.NETHER_STAR, Material.BEACON, Material.DRAGON_EGG, Material.ENDER_PEARL, Material.ENDER_EYE, Material.SHULKER_BOX, Material.END_CRYSTAL,
            Material.GRASS_BLOCK, Material.OAK_LOG, Material.SPRUCE_LOG, Material.CHERRY_LOG, Material.STONE_BRICKS, Material.DEEPSLATE_BRICKS, Material.QUARTZ_BLOCK,
            Material.WHITE_WOOL, Material.GLASS, Material.SEA_LANTERN, Material.GLOWSTONE, Material.LANTERN, Material.BOOKSHELF, Material.CHEST,
            Material.COOKED_BEEF, Material.GOLDEN_CARROT, Material.CAKE, Material.PUMPKIN_PIE, Material.HONEY_BOTTLE, Material.WHEAT, Material.MELON_SLICE,
            Material.SADDLE, Material.NAME_TAG, Material.LEAD, Material.SPYGLASS, Material.COMPASS, Material.CLOCK, Material.MUSIC_DISC_PIGSTEP,
            Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.NETHERITE_HELMET, Material.NETHERITE_CHESTPLATE, Material.TURTLE_HELMET, Material.WIND_CHARGE, Material.HEART_OF_THE_SEA
    );

    public GuiManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.keyData = new NamespacedKey(plugin, "splus_str_data");
        this.keyIntData = new NamespacedKey(plugin, "splus_int_data");
    }

    public ItemStack makeItem(Material mat, String name, List<String> lore, boolean glow) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(TextUtil.color(name));
        if (lore != null && !lore.isEmpty()) meta.lore(TextUtil.colorList(lore));
        if (glow) meta.setEnchantmentGlintOverride(true);
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack withStr(ItemStack item, String val) {
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(keyData, PersistentDataType.STRING, val);
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack withInt(ItemStack item, int val) {
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(keyIntData, PersistentDataType.INTEGER, val);
        item.setItemMeta(meta);
        return item;
    }

    private void fillBorder(Inventory inv, Material mat) {
        ItemStack glass = makeItem(mat, " ", null, false);
        int size = inv.getSize();
        for (int i = 0; i < size; i++) {
            if (i < 9 || i >= size - 9 || i % 9 == 0 || i % 9 == 8) {
                inv.setItem(i, glass);
            }
        }
    }

    private void fillBottom(Inventory inv, int start) {
        ItemStack glass = makeItem(Material.GRAY_STAINED_GLASS_PANE, " ", null, false);
        for (int i = start; i < inv.getSize(); i++) inv.setItem(i, glass);
    }

    public void openClaimsDashboard(Player player) {
        if (!plugin.getGpHook().isHooked()) {
            player.sendMessage(plugin.msg("claims-gui.gp-missing"));
            return;
        }
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.CLAIMS_DASHBOARD);
        Inventory inv = Bukkit.createInventory(holder, 45, TextUtil.color("&8❖ &6إدارة الأراضي ونقاط الحماية &8❖"));
        fillBorder(inv, Material.YELLOW_STAINED_GLASS_PANE);

        UUID uuid = player.getUniqueId();
        int available = plugin.getGpHook().getRemainingBlocks(uuid);
        int accrued = plugin.getGpHook().getAccruedBlocks(uuid);
        int bonus = plugin.getGpHook().getBonusBlocks(uuid);
        int claimsCount = plugin.getGpHook().getPlayerClaims(uuid).size();
        String sym = plugin.getCurrencySymbol();

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        sm.setOwningPlayer(player);
        sm.displayName(TextUtil.color("&6&l❖ معلومات أراضيك"));
        sm.lore(TextUtil.colorList(Arrays.asList(
                "&7المالك: &e" + player.getName(),
                "&7نقاط الحماية المتاحة: &a" + available,
                "&7إجمالي النقاط المكتسبة: &b" + (accrued + bonus),
                "&7عدد أراضيك المحمية: &6" + claimsCount,
                "",
                "&e✦ نظام حماية متطور من سيرفرنا"
        )));
        head.setItemMeta(sm);
        inv.setItem(4, head);

        inv.setItem(11, makeItem(Material.GOLDEN_SHOVEL, "&6&l❖ استلام مجرفة الحماية", Arrays.asList(
                "&7أداة تحديد زوايا الأرض وتوسيعها.",
                "&e✦ اضغط للاستلام مجاناً"
        ), true));

        inv.setItem(20, makeItem(Material.STICK, "&b&l❖ استلام عصا الفحص", Arrays.asList(
                "&7لمعرفة صاحب الأرض وإظهار حدودها.",
                "&e✦ اضغط للاستلام مجاناً"
        ), false));

        inv.setItem(29, makeItem(Material.PAPER, "&e&l❖ قائمة أراضيك &7(Claims List)", Arrays.asList(
                "&7عرض جميع أراضيك المحمية وإحداثياتها",
                "&7والانتقال السريع إليها بضغطة زر.",
                "",
                "&e✦ انقر للاستعراض"
        ), false));

        int p1Blocks = plugin.getConfig().getInt("claims-gui.pack-small.blocks", 100);
        double p1Price = plugin.getConfig().getDouble("claims-gui.pack-small.price", 500.0);
        inv.setItem(13, makeItem(Material.EMERALD, "&aشراء &e" + p1Blocks + " &aنقطة حماية", Arrays.asList(
                "&7السعر: &6" + TextUtil.formatMoney(p1Price, sym),
                "&7المساحة الإضافية: &a+" + p1Blocks + " بلوكة",
                "",
                "&e✦ انقر للشراء"
        ), false));

        int p2Blocks = plugin.getConfig().getInt("claims-gui.pack-medium.blocks", 1000);
        double p2Price = plugin.getConfig().getDouble("claims-gui.pack-medium.price", 5000.0);
        ItemStack emStack = makeItem(Material.EMERALD, "&aشراء &e" + p2Blocks + " &aنقطة حماية", Arrays.asList(
                "&7السعر: &6" + TextUtil.formatMoney(p2Price, sym),
                "&7المساحة الإضافية: &a+" + p2Blocks + " بلوكة",
                "",
                "&e✦ انقر للشراء"
        ), false);
        emStack.setAmount(5);
        inv.setItem(22, emStack);

        int p3Blocks = plugin.getConfig().getInt("claims-gui.pack-large.blocks", 5000);
        double p3Price = plugin.getConfig().getDouble("claims-gui.pack-large.price", 25000.0);
        inv.setItem(31, makeItem(Material.EMERALD_BLOCK, "&aحزمة كبرى &7(&e" + p3Blocks + " &aنقطة حماية&7)", Arrays.asList(
                "&7السعر: &6" + TextUtil.formatMoney(p3Price, sym),
                "&7المساحة الإضافية: &a+" + p3Blocks + " بلوكة",
                "",
                "&e✦ انقر للشراء"
        ), true));

        int sellBlocks = plugin.getConfig().getInt("claims-gui.sell-pack.blocks", 100);
        double sellPayout = plugin.getConfig().getDouble("claims-gui.sell-pack.payout", 250.0);
        inv.setItem(24, makeItem(Material.GOLD_INGOT, "&6بيع &e" + sellBlocks + " &6نقطة حماية", Arrays.asList(
                "&7ستحصل على: &a+" + TextUtil.formatMoney(sellPayout, sym),
                "&7يتم خصمها من نقاط الحماية الإضافية المتاحة لديك.",
                "",
                "&e✦ انقر للبيع"
        ), false));

        inv.setItem(40, makeItem(Material.BOOK, "&6&l❖ دليل متجر وإدارة الأراضي", Arrays.asList(
                "&7دليل شامل لنظام حماية الأراضي:",
                "&8• &fاستخدم &eمجرفة الذهب &fلتحديد زاويتين لحماية أرضك.",
                "&8• &fاستخدم &bالعصا &fللتحقق من ملكية البلوكات والحدود.",
                "&8• &fيمكنك شراء وبيع نقاط الحماية من هذه القائمة.",
                "&8• &fلإعطاء صلاحيات لأصدقائك: &a/ثقة <اللاعب>"
        ), false));

        inv.setItem(36, makeItem(Material.BARRIER, "&c&l✘ إغلاق", null, false));
        player.openInventory(inv);
    }

    public void openClaimsList(Player player) {
        List<GriefPreventionHook.GPClaimInfo> claims = plugin.getGpHook().getPlayerClaims(player.getUniqueId());
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.CLAIMS_LIST);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color("&8❖ &6قائمة أراضيك المحمية &8❖"));

        int slot = 0;
        for (GriefPreventionHook.GPClaimInfo c : claims) {
            if (slot >= 45) break;
            ItemStack item = makeItem(Material.GRASS_BLOCK, "&e&l❖ الأرض المحمية #" + c.index(), Arrays.asList(
                    "&7العالم: &b" + c.worldName(),
                    "&7الإحداثيات: &fX:" + c.centerX() + " , Z:" + c.centerZ(),
                    "&7الأبعاد: &a" + c.width() + "x" + c.length() + " &7(" + c.area() + " بلوكة)",
                    "",
                    "&e✦ اضغط للانتقال إلى هذه الأرض"
            ), false);
            inv.setItem(slot++, withInt(item, c.index() - 1));
        }

        if (claims.isEmpty()) {
            inv.setItem(22, makeItem(Material.BARRIER, "&cلا توجد لديك أراضٍ محمية حالياً!", Arrays.asList(
                    "&7استلم مجرفة الذهب من القائمة السابقة",
                    "&7وحدد زاويتين لحماية منزلك."
            ), false));
        }

        fillBottom(inv, 45);
        inv.setItem(49, makeItem(Material.ARROW, "&c⬅ العودة لإدارة الأراضي", null, false));
        player.openInventory(inv);
    }

    public void openRtpSelector(Player player) {
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.RTP_WORLD_SELECTOR);
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color("&8❖ &bالانتقال العشوائي &7(RTP) &8❖"));
        fillBorder(inv, Material.CYAN_STAINED_GLASS_PANE);

        addRtpWorldSlot(inv, 11, "overworld");
        addRtpWorldSlot(inv, 13, "nether");
        addRtpWorldSlot(inv, 15, "end");

        player.openInventory(inv);
    }

    private void addRtpWorldSlot(Inventory inv, int slot, String dimKey) {
        boolean enabled = plugin.getRtpManager().isDimensionEnabled(dimKey);
        String name = plugin.getConfig().getString("rtp.worlds." + dimKey + ".display-name", dimKey);
        Material icon = Material.matchMaterial(plugin.getConfig().getString("rtp.worlds." + dimKey + ".icon", "GRASS_BLOCK"));
        if (icon == null) icon = Material.GRASS_BLOCK;
        if (!enabled) icon = Material.GRAY_DYE;

        String worldName = plugin.getConfig().getString("rtp.worlds." + dimKey + ".world-name", "world");
        World w = Bukkit.getWorld(worldName);
        int playersCount = (w != null) ? w.getPlayers().size() : 0;

        ItemStack item = makeItem(icon, name, Arrays.asList(
                "&7الحالة: " + (enabled ? "&aمفعل ومفتوح ✔" : "&cمغلق من الإدارة ✘"),
                "&7اللاعبون المتواجدون: &b" + playersCount,
                "&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                enabled ? "&e✦ اضغط للانتقال العشوائي الآمن" : "&cهذا العالم مغلق حالياً"
        ), enabled);
        inv.setItem(slot, withStr(item, dimKey));
    }

    public void openVaultsList(Player player) {
        int allowed = plugin.getVaultManager().getAllowedVaults(player);
        int rows = Math.min(6, Math.max(2, (int) Math.ceil((allowed + 9) / 9.0)));
        int size = rows * 9;

        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.VAULTS_LIST);
        Inventory inv = Bukkit.createInventory(holder, size, TextUtil.color("&8❖ &5خزائنك الشخصية &8❖"));

        for (int i = 1; i <= Math.min(allowed, size - 9); i++) {
            Material icon = plugin.getVaultManager().getVaultIcon(player.getUniqueId(), i);
            int used = plugin.getVaultManager().getUsedSlots(player.getUniqueId(), i);
            ItemStack item = makeItem(icon, "&6&l❖ الخزنة #" + i, Arrays.asList(
                    "&7المساحة المستخدمة: &e" + used + "&7/54",
                    "&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "&a✦ اضغط &7- لفتح الخزنة",
                    "&e✦ Shift + اضغط &7- لتغيير الأيقونة للغرض بيدك"
            ), used > 0);
            inv.setItem(i - 1, withInt(item, i));
        }

        fillBottom(inv, size - 9);
        inv.setItem(size - 5, makeItem(Material.BARRIER, "&c&l✘ إغلاق", null, false));
        player.openInventory(inv);
    }

    public void openGravesList(Player player) {
        List<GraveData> graves = plugin.getGraveManager().getPlayerGraves(player.getUniqueId());
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.GRAVES_LIST);
        Inventory inv = Bukkit.createInventory(holder, 45, TextUtil.color("&8❖ &6القبور النشطة الخاصة بك &8❖"));

        double tpCost = plugin.getConfig().getDouble("graves.teleport-cost", 100.0);
        boolean free = tpCost <= 0 || player.hasPermission("survivalplus.graves.free");
        String sym = plugin.getCurrencySymbol();

        int slot = 0;
        for (GraveData g : graves) {
            if (slot >= 36) break;
            Location loc = g.getLocation();
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(player);
            sm.displayName(TextUtil.color("&6&l⚰ قبر #" + (slot + 1)));
            sm.lore(TextUtil.colorList(Arrays.asList(
                    "&7العالم: &b" + loc.getWorld().getName(),
                    "&7الإحداثيات: &e" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ(),
                    "&7عدد الأغراض: &a" + g.getItems().size() + " &8| &7الخبرة: &b" + g.getStoredExp() + " XP",
                    "&7الوقت المتبقي: &c" + TextUtil.formatMMSS(g.getRemainingSeconds()),
                    "&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                    "&a✦ كليك يسار: &fالانتقال للقبر " + (free ? "&a(مجاني)" : "&6(" + TextUtil.formatMoney(tpCost, sym) + ")"),
                    "&e✦ كليك يمين: &fمعاينة الأغراض داخل القبر"
            )));
            head.setItemMeta(sm);
            inv.setItem(slot++, withStr(head, g.getId()));
        }

        if (graves.isEmpty()) {
            inv.setItem(22, makeItem(Material.TOTEM_OF_UNDYING, "&a✔ ليس لديك أي قبور نشطة!", Arrays.asList(
                    "&7عند موتك في السيرفر، يتم حفظ جميع أغراضك",
                    "&7ونقاط خبرتك داخل قبر آمن لا يفتحه غيرك."
            ), false));
        }

        fillBottom(inv, 36);
        inv.setItem(40, makeItem(Material.BARRIER, "&c&l✘ إغلاق", null, false));
        player.openInventory(inv);
    }

    public void openGravePreview(Player player, GraveData grave) {
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.GRAVE_PREVIEW, 0, null, grave.getOwnerUuid(), grave.getId(), 0);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color("&8❖ &6معاينة محتويات القبر &8❖"));

        int slot = 0;
        for (ItemStack item : grave.getItems()) {
            if (slot >= 45) break;
            inv.setItem(slot++, item.clone());
        }
        fillBottom(inv, 45);
        inv.setItem(49, makeItem(Material.ARROW, "&c⬅ العودة لقائمة القبور", null, false));
        player.openInventory(inv);
    }

    public void openEssentialsHomes(Player player) {
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.HOMES_LIST);
        Inventory inv = Bukkit.createInventory(holder, 45, TextUtil.color("&8❖ &cمنازلك المحفوظة &8❖"));

        List<String> homeNames = readEssentialsHomes(player.getUniqueId());
        Material[] beds = {Material.RED_BED, Material.CYAN_BED, Material.LIME_BED, Material.YELLOW_BED, Material.PURPLE_BED, Material.ORANGE_BED};

        int slot = 0;
        for (String home : homeNames) {
            if (slot >= 36) break;
            Material bed = beds[slot % beds.length];
            ItemStack item = makeItem(bed, "&c&l❖ منزل: &f" + home, Arrays.asList(
                    "&7اضغط للانتقال الفوري إلى هذا المنزل.",
                    "",
                    "&e✦ انقر للانتقال"
            ), false);
            inv.setItem(slot++, withStr(item, home));
        }

        if (homeNames.isEmpty()) {
            inv.setItem(22, makeItem(Material.BARRIER, "&cلا توجد لديك منازل محفوظة!", Arrays.asList(
                    "&7لحفظ موقع منزلك اكتب في الشات:",
                    "&e/sethome <اسم_المنزل>"
            ), false));
        }

        fillBottom(inv, 36);
        inv.setItem(40, makeItem(Material.BARRIER, "&c&l✘ إغلاق", null, false));
        player.openInventory(inv);
    }

    private List<String> readEssentialsHomes(UUID uuid) {
        List<String> list = new ArrayList<>();
        File essUserFile = new File(plugin.getDataFolder().getParentFile(), "Essentials/userdata/" + uuid + ".yml");
        if (!essUserFile.exists()) return list;
        try {
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(essUserFile);
            ConfigurationSection sec = cfg.getConfigurationSection("homes");
            if (sec != null) list.addAll(sec.getKeys(false));
        } catch (Exception ignored) {}
        return list;
    }

    public void openShopDirectory(Player viewer, int page, ShopManager.SortMode sortMode) {
        List<PlayerShop> visible = plugin.getShopManager().getVisibleShops(sortMode);
        int perPage = 45;
        int totalPages = Math.max(1, (int) Math.ceil((double) visible.size() / perPage));
        int safePage = Math.max(0, Math.min(page, totalPages - 1));

        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.SHOP_DIRECTORY, safePage, sortMode, null, null, 0);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color("&8❖ &aسوق متاجر اللاعبين &7(" + (safePage + 1) + "/" + totalPages + ") &8❖"));

        int start = safePage * perPage;
        int end = Math.min(start + perPage, visible.size());
        String sym = plugin.getCurrencySymbol();

        for (int i = start; i < end; i++) {
            inv.setItem(i - start, buildShopDirectoryIcon(visible.get(i)));
        }

        if (visible.isEmpty()) {
            inv.setItem(22, makeItem(Material.BARRIER, "&cلا توجد متاجر مفتوحة حالياً!", Arrays.asList(
                    "&7امسك أي غرض في يدك واكتب:",
                    "&e/متجر بيع <السعر> &7أو &e/shop sell <السعر>"
            ), false));
        }

        fillBottom(inv, 45);
        if (safePage > 0) inv.setItem(45, makeItem(Material.ARROW, "&e⬅ الصفحة السابقة", null, false));

        inv.setItem(47, makeItem(Material.HOPPER, "&bترتيب المتاجر: &e" + sortMode.getDisplay(), Arrays.asList(
                "&7اضغط للتبديل بين طرق الترتيب"
        ), false));

        inv.setItem(49, makeItem(Material.ENDER_CHEST, "&a&l❖ متجري ولوحة التحكم", Arrays.asList(
                "&7إدارة السلع، سجل المبيعات، وتغيير الأيقونة!",
                "&e✦ اضغط لفتح لوحة التحكم"
        ), true));

        double bal = plugin.getEconomy().getBalance(viewer);
        inv.setItem(51, makeItem(Material.GOLD_INGOT, "&6رصيدك: &e" + TextUtil.formatMoney(bal, sym), Arrays.asList(
                "&7لعرض سلعة للبيع: &a/متجر بيع <السعر>"
        ), false));

        if (safePage < totalPages - 1) inv.setItem(53, makeItem(Material.ARROW, "&eالصفحة التالية ➡", null, false));
        viewer.openInventory(inv);
    }

    private ItemStack buildShopDirectoryIcon(PlayerShop shop) {
        ItemStack item;
        if (shop.getIconMaterial() != null) {
            item = new ItemStack(shop.getIconMaterial());
        } else {
            item = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta skull = (SkullMeta) item.getItemMeta();
            skull.setOwningPlayer(Bukkit.getOfflinePlayer(shop.getOwnerUuid()));
            item.setItemMeta(skull);
        }

        ItemMeta meta = item.getItemMeta();
        boolean featured = shop.isFeatured();
        meta.displayName(TextUtil.color((featured ? "&6★ &l" : "") + shop.getCustomName() + (featured ? " &6★" : "")));

        boolean online = Bukkit.getPlayer(shop.getOwnerUuid()) != null;
        List<String> lore = new ArrayList<>();
        if (featured) lore.add("&6✦ متجر مميز ومروّج ✦");
        lore.add(shop.getDescription());
        lore.add("&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        lore.add("&7المالك: &f" + shop.getOwnerName() + (online ? " &a● متصل" : " &8● غير متصل"));
        lore.add("&7السلع المتوفرة: &a" + shop.getListings().size());
        lore.add("&7المبيعات: &b" + shop.getTotalItemsSold() + " &8| &7الإعجابات: &c❤ " + shop.getLikes().size());
        lore.add("&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        lore.add("&e✦ اضغط لدخول المتجر");
        meta.lore(TextUtil.colorList(lore));
        if (featured) meta.setEnchantmentGlintOverride(true);
        item.setItemMeta(meta);
        return withStr(item, shop.getOwnerUuid().toString());
    }

    public void openPlayerShop(Player viewer, UUID ownerUuid, boolean countView) {
        PlayerShop shop = plugin.getShopManager().getShop(ownerUuid);
        if (shop == null) return;
        boolean isOwner = viewer.getUniqueId().equals(ownerUuid);
        if (!shop.isOpen() && !isOwner) return;
        if (countView && !isOwner) shop.incrementViews();

        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.PLAYER_SHOP, 0, ShopManager.SortMode.TOP_SALES, ownerUuid, null, 0);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(shop.getCustomName()));

        String sym = plugin.getCurrencySymbol();
        int slot = 0;
        for (ShopListing listing : shop.getListings().values()) {
            if (slot >= 45) break;
            ItemStack display = listing.getItem();
            ItemMeta meta = display.getItemMeta();
            List<Component> lore = meta.hasLore() && meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
            lore.add(TextUtil.color("&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            lore.add(TextUtil.color("&7السعر: &6&l" + TextUtil.formatMoney(listing.getPrice(), sym)));
            if (isOwner) {
                lore.add(TextUtil.color("&e✦ كليك يسار: &fتعديل السعر"));
                lore.add(TextUtil.color("&c✦ كليك يمين: &fسحب السلعة لحقيبتك"));
            } else {
                lore.add(TextUtil.color("&a✦ اضغط للشراء والمراجعة"));
            }
            meta.lore(lore);
            display.setItemMeta(meta);
            inv.setItem(slot++, withStr(display, listing.getId()));
        }

        fillBottom(inv, 45);
        inv.setItem(45, makeItem(Material.ARROW, "&c⬅ العودة للسوق", null, false));

        if (!isOwner) {
            boolean liked = shop.getLikes().contains(viewer.getUniqueId());
            inv.setItem(48, makeItem(liked ? Material.RED_DYE : Material.PINK_DYE,
                    liked ? "&c❤ أعجبك هذا المتجر" : "&d♡ أعجبني هذا المتجر",
                    Arrays.asList("&7الإعجابات: &c" + shop.getLikes().size()), liked));
        }

        inv.setItem(49, makeItem(Material.BOOK, shop.getCustomName(), Arrays.asList(
                shop.getDescription(),
                "&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬",
                "&7المالك: &f" + shop.getOwnerName(),
                "&7الزيارات: &e" + shop.getViews() + " &8| &7المبيعات: &b" + shop.getTotalItemsSold()
        ), false));

        if (isOwner) {
            inv.setItem(50, makeItem(Material.COMPARATOR, "&aلوحة تحكم متجرك", null, true));
        }
        viewer.openInventory(inv);
    }

    public void openShopConfirm(Player buyer, PlayerShop shop, ShopListing listing) {
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.SHOP_CONFIRM, 0, ShopManager.SortMode.TOP_SALES,
                shop.getOwnerUuid(), listing.getId(), listing.getPrice());
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color("&8❖ &aتأكيد عملية الشراء &8❖"));

        ItemStack bg = makeItem(Material.BLACK_STAINED_GLASS_PANE, " ", null, false);
        for (int i = 0; i < 27; i++) inv.setItem(i, bg);

        String sym = plugin.getCurrencySymbol();
        double bal = plugin.getEconomy().getBalance(buyer);
        boolean enough = bal >= listing.getPrice();

        inv.setItem(11, makeItem(Material.LIME_STAINED_GLASS_PANE, "&a&l✔ تأكيد الشراء", Arrays.asList(
                "&7البائع: &f" + shop.getOwnerName(),
                "&7السعر: &6" + TextUtil.formatMoney(listing.getPrice(), sym),
                "&7رصيدك: " + (enough ? "&a" : "&c") + TextUtil.formatMoney(bal, sym)
        ), enough));
        inv.setItem(13, listing.getItem());
        inv.setItem(15, makeItem(Material.RED_STAINED_GLASS_PANE, "&c&l✘ إلغاء والعودة", null, false));
        buyer.openInventory(inv);
    }

    public void openShopOwnerDashboard(Player owner) {
        PlayerShop shop = plugin.getShopManager().getOrCreateShop(owner);
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.OWNER_DASHBOARD);
        Inventory inv = Bukkit.createInventory(holder, 45, TextUtil.color("&8❖ &bلوحة تحكم متجرك &8❖"));
        fillBorder(inv, Material.CYAN_STAINED_GLASS_PANE);

        String sym = plugin.getCurrencySymbol();
        int maxSlots = plugin.getShopManager().getMaxSlots(owner);

        inv.setItem(11, makeItem(Material.CHEST, "&e&l❖ إدارة سلع متجرك &7(" + shop.getListings().size() + "/" + maxSlots + ")", Arrays.asList(
                "&7تعديل الأسعار أو سحب السلع."
        ), false));

        inv.setItem(13, makeItem(Material.WRITABLE_BOOK, "&b&l❖ سجل المبيعات والأرباح", Arrays.asList(
                "&7إجمالي الأرباح: &6" + TextUtil.formatMoney(shop.getTotalRevenue(), sym),
                "&7المبيعات: &a" + shop.getTotalItemsSold() + " &8| &7الزيارات: &e" + shop.getViews()
        ), true));

        Material currentIcon = shop.getIconMaterial() != null ? shop.getIconMaterial() : Material.PLAYER_HEAD;
        inv.setItem(15, makeItem(currentIcon, "&d&l❖ تخصيص أيقونة المتجر", Arrays.asList(
                "&7اختر من بين أكثر من 80 أيقونة جاهزة",
                "&7أو الغرض الممسوك في يدك!"
        ), false));

        double boostCost = plugin.getConfig().getDouble("shop.boost-cost", 500.0);
        int boostHours = plugin.getConfig().getInt("shop.boost-hours", 24);
        inv.setItem(20, makeItem(Material.NETHER_STAR, "&6&l★ ترويج المتجر (Boost)", Arrays.asList(
                shop.isFeatured()
                        ? "&aمروّج حالياً! المتبقي: &e" + TextUtil.formatDuration((shop.getFeaturedUntil() - System.currentTimeMillis()) / 1000L)
                        : "&7التكلفة: &6" + TextUtil.formatMoney(boostCost, sym) + " &7لمدة &e" + boostHours + " ساعة"
        ), shop.isFeatured()));

        inv.setItem(22, makeItem(Material.NAME_TAG, "&e&l❖ تعديل اسم المتجر", Arrays.asList(
                "&7الحالي: " + shop.getCustomName()
        ), false));

        inv.setItem(24, makeItem(Material.OAK_SIGN, "&e&l❖ تعديل وصف المتجر", Arrays.asList(
                "&7الحالي: " + shop.getDescription()
        ), false));

        inv.setItem(30, makeItem(shop.isOpen() ? Material.LIME_DYE : Material.RED_DYE,
                shop.isOpen() ? "&aحالة المتجر: مفتوح ✔" : "&cحالة المتجر: مغلق ✘", null, false));

        inv.setItem(32, makeItem(Material.ENDER_EYE, "&bمعاينة متجري", null, false));
        inv.setItem(36, makeItem(Material.ARROW, "&c⬅ العودة للسوق", null, false));
        owner.openInventory(inv);
    }

    public void openShopOwnerListings(Player owner) {
        PlayerShop shop = plugin.getShopManager().getOrCreateShop(owner);
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.OWNER_LISTINGS);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color("&8❖ &eإدارة سلع متجرك &8❖"));

        String sym = plugin.getCurrencySymbol();
        int slot = 0;
        for (ShopListing listing : shop.getListings().values()) {
            if (slot >= 45) break;
            ItemStack item = listing.getItem();
            ItemMeta meta = item.getItemMeta();
            List<Component> lore = meta.hasLore() && meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
            lore.add(TextUtil.color("&8▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            lore.add(TextUtil.color("&7السعر: &6" + TextUtil.formatMoney(listing.getPrice(), sym)));
            lore.add(TextUtil.color("&a✦ كليك يسار: &fتعديل السعر"));
            lore.add(TextUtil.color("&c✦ كليك يمين: &fسحب السلعة"));
            meta.lore(lore);
            item.setItemMeta(meta);
            inv.setItem(slot++, withStr(item, listing.getId()));
        }

        fillBottom(inv, 45);
        inv.setItem(49, makeItem(Material.ARROW, "&c⬅ العودة للوحة التحكم", null, false));
        owner.openInventory(inv);
    }

    public void openShopSalesLog(Player owner) {
        PlayerShop shop = plugin.getShopManager().getOrCreateShop(owner);
        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.OWNER_SALES_LOG);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color("&8❖ &bسجل مبيعات متجرك &8❖"));

        String sym = plugin.getCurrencySymbol();
        int slot = 0;
        for (SaleRecord rec : shop.getSalesHistory()) {
            if (slot >= 45) break;
            inv.setItem(slot++, makeItem(rec.getItemMaterial(), "&e" + rec.getItemName() + " &7(x" + rec.getAmount() + ")", Arrays.asList(
                    "&7المشتري: &f" + rec.getBuyerName(),
                    "&7صافي الربح: &6" + TextUtil.formatMoney(rec.getPrice(), sym),
                    "&7التاريخ: &7" + TextUtil.formatDate(rec.getTimestamp())
            ), false));
        }

        fillBottom(inv, 45);
        inv.setItem(49, makeItem(Material.ARROW, "&c⬅ العودة للوحة التحكم", null, false));
        owner.openInventory(inv);
    }

    public void openShopIconPicker(Player owner, int page) {
        int perPage = 36;
        int totalPages = Math.max(1, (int) Math.ceil((double) SHOP_ICONS.size() / perPage));
        int safePage = Math.max(0, Math.min(page, totalPages - 1));

        GuiHolder holder = new GuiHolder(GuiHolder.MenuType.OWNER_ICON_PICKER, safePage, null, null, null, 0);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color("&8❖ &dاختر أيقونة متجرك &7(" + (safePage + 1) + "/" + totalPages + ") &8❖"));

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        sm.setOwningPlayer(owner);
        sm.displayName(TextUtil.color("&eالعودة لرأس اللاعب الافتراضي"));
        head.setItemMeta(sm);
        inv.setItem(2, head);

        ItemStack hand = owner.getInventory().getItemInMainHand();
        Material handMat = hand.getType() != Material.AIR ? hand.getType() : Material.BARRIER;
        inv.setItem(6, makeItem(handMat, "&aاستخدام الغرض الممسوك في يدك", Arrays.asList(
                hand.getType() != Material.AIR ? "&7الغرض: &e" + TextUtil.getItemFriendlyName(hand) : "&cيدك فارغة حالياً!",
                "&7(لن يتم سحب الغرض من يدك)"
        ), hand.getType() != Material.AIR));

        int start = safePage * perPage;
        int end = Math.min(start + perPage, SHOP_ICONS.size());
        for (int i = start; i < end; i++) {
            Material mat = SHOP_ICONS.get(i);
            ItemStack icon = makeItem(mat, "&b" + mat.name().toLowerCase().replace('_', ' '),
                    Arrays.asList("&e✦ اضغط لاختيار هذه الأيقونة"), false);
            inv.setItem(9 + (i - start), withStr(icon, mat.name()));
        }

        fillBottom(inv, 45);
        if (safePage > 0) inv.setItem(45, makeItem(Material.ARROW, "&e⬅ الصفحة السابقة", null, false));
        inv.setItem(49, makeItem(Material.BARRIER, "&c⬅ العودة للوحة التحكم", null, false));
        if (safePage < totalPages - 1) inv.setItem(53, makeItem(Material.ARROW, "&eالصفحة التالية ➡", null, false));

        owner.openInventory(inv);
    }
}
