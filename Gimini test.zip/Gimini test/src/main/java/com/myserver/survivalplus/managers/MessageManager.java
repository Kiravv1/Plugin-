package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class MessageManager {
    private final SurvivalPlus plugin;
    private final File file;
    private FileConfiguration config;

    public MessageManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "messages.yml");
        reload();
    }

    public void reload() {
        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        config = YamlConfiguration.loadConfiguration(file);
        InputStream defStream = plugin.getResource("messages.yml");
        if (defStream != null) {
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(new InputStreamReader(defStream, StandardCharsets.UTF_8));
            config.setDefaults(defaults);
            config.options().copyDefaults(true);
            try {
                config.save(file);
            } catch (IOException ignored) {}
        }
    }

    public String raw(String path, String... placeholders) {
        String text = config.getString(path, "&c[Missing: " + path + "]");
        for (int i = 0; i + 1 < placeholders.length; i += 2) {
            text = text.replace(placeholders[i], placeholders[i + 1]);
        }
        return text;
    }

    public Component get(String path, String... placeholders) {
        String prefix = plugin.getConfig().getString("prefix", "&8[&b✦ &3سيرفايفل &b✦&8] &r");
        return TextUtil.color(prefix + raw(path, placeholders));
    }

    public Component getNoPrefix(String path, String... placeholders) {
        return TextUtil.color(raw(path, placeholders));
    }
}
