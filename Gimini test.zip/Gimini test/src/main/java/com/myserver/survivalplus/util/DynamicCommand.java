package com.myserver.survivalplus.util;

import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.command.defaults.BukkitCommand;

import java.util.Collections;
import java.util.List;

public class DynamicCommand extends BukkitCommand {
    private final CommandExecutor executor;
    private final TabCompleter tabCompleter;

    public DynamicCommand(String name, String description, List<String> aliases, CommandExecutor executor, TabCompleter tabCompleter) {
        super(name, description, "/" + name, aliases != null ? aliases : Collections.emptyList());
        this.executor = executor;
        this.tabCompleter = tabCompleter;
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        return executor.onCommand(sender, this, commandLabel, args);
    }

    @Override
    public List<String> tabComplete(CommandSender sender, String alias, String[] args) throws IllegalArgumentException {
        if (tabCompleter != null) {
            List<String> res = tabCompleter.onTabComplete(sender, this, alias, args);
            if (res != null) return res;
        }
        return super.tabComplete(sender, alias, args);
    }
}
