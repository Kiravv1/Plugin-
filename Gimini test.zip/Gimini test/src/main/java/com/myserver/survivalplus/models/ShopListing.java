package com.myserver.survivalplus.models;

import org.bukkit.inventory.ItemStack;
import java.util.UUID;

public class ShopListing {
    private final String id;
    private final UUID sellerUuid;
    private final ItemStack item;
    private double price;
    private final long createdAt;
    private boolean sold;

    public ShopListing(String id, UUID sellerUuid, ItemStack item, double price, long createdAt) {
        this.id = id;
        this.sellerUuid = sellerUuid;
        this.item = item.clone();
        this.price = price;
        this.createdAt = createdAt;
        this.sold = false;
    }

    public String getId() { return id; }
    public UUID getSellerUuid() { return sellerUuid; }
    public ItemStack getItem() { return item.clone(); }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public long getCreatedAt() { return createdAt; }
    public boolean isSold() { return sold; }
    public void setSold(boolean sold) { this.sold = sold; }
}
