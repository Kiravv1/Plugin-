package com.myserver.survivalplus.gui;

import com.myserver.survivalplus.managers.ShopManager;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.UUID;

public class GuiHolder implements InventoryHolder {
    public enum MenuType {
        SHOP_DIRECTORY,
        PLAYER_SHOP,
        SHOP_CONFIRM,
        OWNER_DASHBOARD,
        OWNER_LISTINGS,
        OWNER_SALES_LOG,
        OWNER_ICON_PICKER,
        CLAIMS_DASHBOARD,
        CLAIMS_LIST,
        RTP_WORLD_SELECTOR,
        VAULTS_LIST,
        GRAVES_LIST,
        GRAVE_PREVIEW,
        HOMES_LIST
    }

    private final MenuType type;
    private final int page;
    private final ShopManager.SortMode sortMode;
    private final UUID targetUuid;
    private final String extraId;
    private final double expectedPrice;

    public GuiHolder(MenuType type) {
        this(type, 0, ShopManager.SortMode.TOP_SALES, null, null, 0.0);
    }

    public GuiHolder(MenuType type, int page, ShopManager.SortMode sortMode, UUID targetUuid, String extraId, double expectedPrice) {
        this.type = type;
        this.page = page;
        this.sortMode = sortMode;
        this.targetUuid = targetUuid;
        this.extraId = extraId;
        this.expectedPrice = expectedPrice;
    }

    public MenuType getType() { return type; }
    public int getPage() { return page; }
    public ShopManager.SortMode getSortMode() { return sortMode; }
    public UUID getTargetUuid() { return targetUuid; }
    public String getExtraId() { return extraId; }
    public double getExpectedPrice() { return expectedPrice; }

    @Override
    public Inventory getInventory() { return null; }
}
