package com.myserver.survivalplus.util;

import org.bukkit.OfflinePlayer;

public interface EconomyProvider {
    boolean isReady();
    double getBalance(OfflinePlayer player);
    boolean has(OfflinePlayer player, double amount);
    boolean withdraw(OfflinePlayer player, double amount);
    boolean deposit(OfflinePlayer player, double amount);

    EconomyProvider NONE = new EconomyProvider() {
        @Override public boolean isReady() { return false; }
        @Override public double getBalance(OfflinePlayer player) { return 0.0; }
        @Override public boolean has(OfflinePlayer player, double amount) { return false; }
        @Override public boolean withdraw(OfflinePlayer player, double amount) { return false; }
        @Override public boolean deposit(OfflinePlayer player, double amount) { return false; }
    };
}
