package com.myserver.survivalplus.models;

import org.bukkit.Material;

public class SaleRecord {
    private final String buyerName;
    private final String itemName;
    private final Material itemMaterial;
    private final int amount;
    private final double price;
    private final long timestamp;

    public SaleRecord(String buyerName, String itemName, Material itemMaterial, int amount, double price, long timestamp) {
        this.buyerName = buyerName;
        this.itemName = itemName;
        this.itemMaterial = itemMaterial != null ? itemMaterial : Material.PAPER;
        this.amount = amount;
        this.price = price;
        this.timestamp = timestamp;
    }

    public String getBuyerName() { return buyerName; }
    public String getItemName() { return itemName; }
    public Material getItemMaterial() { return itemMaterial; }
    public int getAmount() { return amount; }
    public double getPrice() { return price; }
    public long getTimestamp() { return timestamp; }
}
