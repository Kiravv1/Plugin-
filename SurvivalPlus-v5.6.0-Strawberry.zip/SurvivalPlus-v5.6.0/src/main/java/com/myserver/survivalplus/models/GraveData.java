package com.myserver.survivalplus.models;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class GraveData {
    private final String id;
    private final UUID ownerId;
    private final String ownerName;
    private final String worldName;
    private final int x, y, z;
    private final long expiresAt;
    // Exact slot index (0-35 storage/hotbar, 36-39 armor, 40 offhand) -> ItemStack
    private final Map<Integer, ItemStack> slotItems = new LinkedHashMap<>();
    private UUID holoLine1;
    private UUID holoLine2;
    private transient Inventory sharedLootInventory;

    public GraveData(String id, UUID ownerId, String ownerName, String worldName, int x, int y, int z, long expiresAt, Map<Integer, ItemStack> items) {
        this.id = id;
        this.ownerId = ownerId;
        this.ownerName = ownerName;
        this.worldName = worldName;
        this.x = x;
        this.y = y;
        this.z = z;
        this.expiresAt = expiresAt;
        if (items != null) this.slotItems.putAll(items);
    }

    public String getId() { return id; }
    public UUID getOwnerId() { return ownerId; }
    public String getOwnerName() { return ownerName; }
    public String getWorldName() { return worldName; }
    public int getX() { return x; }
    public int getY() { return y; }
    public int getZ() { return z; }
    public long getExpiresAt() { return expiresAt; }
    public Map<Integer, ItemStack> getSlotItems() { return slotItems; }
    public UUID getHoloLine1() { return holoLine1; }
    public void setHoloLine1(UUID holoLine1) { this.holoLine1 = holoLine1; }
    public UUID getHoloLine2() { return holoLine2; }
    public void setHoloLine2(UUID holoLine2) { this.holoLine2 = holoLine2; }
    public Inventory getSharedLootInventory() { return sharedLootInventory; }
    public void setSharedLootInventory(Inventory sharedLootInventory) { this.sharedLootInventory = sharedLootInventory; }

    public boolean isExpired() { return System.currentTimeMillis() > expiresAt; }

    public String getFormattedRemaining() {
        long sec = Math.max(0, (expiresAt - System.currentTimeMillis()) / 1000L);
        long mins = sec / 60;
        long remSec = sec % 60;
        return String.format("%dm %02ds", mins, remSec);
    }

    public Location getBlockLocation() {
        World w = Bukkit.getWorld(worldName);
        return w != null ? new Location(w, x, y, z) : null;
    }

    public String getBlockKey() {
        return worldName + ":" + x + ":" + y + ":" + z;
    }
}
