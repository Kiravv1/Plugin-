package com.myserver.survivalplus.models;

import org.bukkit.inventory.ItemStack;
import java.util.UUID;

public class ShopProduct {
    private final String id;
    private final ItemStack template;
    private double unitPrice;
    private int stock;
    private int soldCount;
    private boolean bulkDiscountEnabled;

    public ShopProduct(String id, ItemStack template, double unitPrice, int stock) {
        this.id = id != null ? id : UUID.randomUUID().toString().substring(0, 8);
        this.template = template.clone();
        this.template.setAmount(1);
        this.unitPrice = unitPrice;
        this.stock = stock;
        this.soldCount = 0;
        this.bulkDiscountEnabled = false;
    }

    public String getId() { return id; }
    public ItemStack getTemplate() { return template.clone(); }
    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }
    public int getStock() { return stock; }
    public void addStock(int amount) { this.stock += amount; }
    public void removeStock(int amount) { this.stock = Math.max(0, this.stock - amount); }
    public int getSoldCount() { return soldCount; }
    public void addSold(int amount) { this.soldCount += amount; }
    public boolean isBulkDiscountEnabled() { return bulkDiscountEnabled; }
    public void setBulkDiscountEnabled(boolean bulkDiscountEnabled) { this.bulkDiscountEnabled = bulkDiscountEnabled; }
    public boolean matches(ItemStack other) { return other != null && template.isSimilar(other); }
}
