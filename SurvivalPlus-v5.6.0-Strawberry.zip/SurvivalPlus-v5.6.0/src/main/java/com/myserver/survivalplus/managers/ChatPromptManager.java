package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public class ChatPromptManager implements Listener {
    private final SurvivalPlus plugin;
    private final Map<UUID, Consumer<String>> prompts = new ConcurrentHashMap<>();

    public ChatPromptManager(SurvivalPlus plugin) { this.plugin = plugin; }
    public void prompt(Player player, Consumer<String> callback) { prompts.put(player.getUniqueId(), callback); }
    public void cancel(UUID playerId) { prompts.remove(playerId); }

    @EventHandler
    public void onChat(AsyncChatEvent event) {
        Consumer<String> cb = prompts.remove(event.getPlayer().getUniqueId());
        if (cb == null) return;
        event.setCancelled(true);
        String msg = PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        Bukkit.getScheduler().runTask(plugin, () -> cb.accept(msg));
    }
}
