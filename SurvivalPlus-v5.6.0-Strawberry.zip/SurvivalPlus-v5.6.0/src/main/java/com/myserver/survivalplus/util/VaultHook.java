package com.myserver.survivalplus.util;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

public class VaultHook {
    private Economy economy;

    public boolean setup() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        this.economy = rsp.getProvider();
        return this.economy != null;
    }

    public boolean isConnected() { return economy != null; }
    public double getBalance(OfflinePlayer player) { return isConnected() ? economy.getBalance(player) : 0.0; }
    public boolean has(OfflinePlayer player, double amount) { return isConnected() && economy.has(player, amount); }
    public boolean withdraw(OfflinePlayer player, double amount) { return isConnected() && economy.withdrawPlayer(player, amount).transactionSuccess(); }
    public boolean deposit(OfflinePlayer player, double amount) { return isConnected() && economy.depositPlayer(player, amount).transactionSuccess(); }
}
