package com.myserver.survivalplus.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class GuiHolder implements InventoryHolder {
    private final String type;
    private final Map<String, Object> data = new HashMap<>();
    private Inventory inventory;

    public GuiHolder(String type) { this.type = type; }
    public String getType() { return type; }
    public GuiHolder set(String key, Object value) { data.put(key, value); return this; }
    @SuppressWarnings("unchecked")
    public <T> T get(String key, Class<T> clazz) {
        Object v = data.get(key);
        return clazz.isInstance(v) ? (T) v : null;
    }
    public void setInventory(Inventory inventory) { this.inventory = inventory; }
    @Override public @NotNull Inventory getInventory() { return inventory; }
}
