package com.myserver.survivalplus.listeners;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.models.GraveData;
import com.myserver.survivalplus.models.PlayerShopData;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;

import java.util.*;

public class GameplayListener implements Listener {
    private final SurvivalPlus plugin;
    private final Map<UUID, String> lastClaimOwner = new HashMap<>();

    public GameplayListener(SurvivalPlus plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!plugin.getConfigManager().getConfig().getBoolean("menu-bridge.intercept-menu-command", true)) return;
        String msg = event.getMessage().trim();
        if (!msg.startsWith("/")) return;
        String label = msg.substring(1).split(" ")[0].toLowerCase();
        for (String r : plugin.getConfigManager().getConfig().getStringList("menu-bridge.redirect-commands")) {
            if (r.equalsIgnoreCase(label)) {
                event.setCancelled(true);
                TextUtil.runConsoleCommand(plugin.getConfigManager().getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                        .replace("%player%", event.getPlayer().getName()));
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (event.getFrom().getBlockX() == event.getTo().getBlockX() && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;
        if (!plugin.getGpHook().isConnected()) return;
        Player player = event.getPlayer();
        if (!plugin.getNotificationManager().isEnabledFor(player.getUniqueId(), "claim-enter")) return;

        String currentOwner = plugin.getGpHook().getClaimOwnerAt(event.getTo());
        String prevOwner = lastClaimOwner.get(player.getUniqueId());
        if (Objects.equals(currentOwner, prevOwner)) return;

        if (currentOwner != null) {
            lastClaimOwner.put(player.getUniqueId(), currentOwner);
            player.sendActionBar(plugin.getConfigManager().rawMessage("claims.enter-actionbar", "%owner%", currentOwner));
        } else {
            lastClaimOwner.remove(player.getUniqueId());
            player.sendActionBar(plugin.getConfigManager().rawMessage("claims.leave-actionbar"));
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        if (!plugin.getConfigManager().getConfig().getBoolean("graves.enabled", true)) return;
        if (event.getKeepInventory() || event.getDrops().isEmpty()) return;
        event.getDrops().clear();
        plugin.getGraveManager().createGraveFromDeath(event.getEntity());
    }

    // Physical Grave Interaction: Right-Click = Open GUI | Shift + Right-Click = Quick-Loot in exact slot order
    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null) return;
        GraveData grave = plugin.getGraveManager().getGraveAt(block.getLocation());
        if (grave == null) return;
        event.setCancelled(true);
        if (event.getPlayer().isSneaking()) {
            plugin.getGraveManager().quickLootGrave(event.getPlayer(), grave);
        } else {
            plugin.getGraveManager().openGraveLoot(event.getPlayer(), grave);
        }
    }

    // Grave Protections: Cannot break, explode (Creeper/TNT/Wither), wash away by water/lava, or push by piston!
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (plugin.getGraveManager().getGraveAt(event.getBlock().getLocation()) != null) {
            event.setCancelled(true);
            plugin.getConfigManager().send(event.getPlayer(), "graves.cannot-break");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        event.blockList().removeIf(b -> plugin.getGraveManager().getGraveAt(b.getLocation()) != null);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        event.blockList().removeIf(b -> plugin.getGraveManager().getGraveAt(b.getLocation()) != null);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLiquidFlow(BlockFromToEvent event) {
        if (plugin.getGraveManager().getGraveAt(event.getToBlock().getLocation()) != null) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent event) {
        for (Block b : event.getBlocks()) if (plugin.getGraveManager().getGraveAt(b.getLocation()) != null) { event.setCancelled(true); return; }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent event) {
        for (Block b : event.getBlocks()) if (plugin.getGraveManager().getGraveAt(b.getLocation()) != null) { event.setCancelled(true); return; }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        PlayerShopData shop = plugin.getPlayerShopManager().getShop(event.getPlayer().getUniqueId());
        if (shop != null && shop.getOfflineEarnings() > 0) {
            plugin.getNotificationManager().notify(event.getPlayer(), "shop-sales", "pshop.offline-summary",
                    "%earnings%", TextUtil.formatMoney(shop.getOfflineEarnings()),
                    "%items%", String.valueOf(shop.getOfflineItemsSold()));
            shop.clearOfflineSummary();
            plugin.getPlayerShopManager().saveData();
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        lastClaimOwner.remove(id);
        plugin.getTeleportManager().cancel(id);
        plugin.getChatPromptManager().cancel(id);
    }
}
