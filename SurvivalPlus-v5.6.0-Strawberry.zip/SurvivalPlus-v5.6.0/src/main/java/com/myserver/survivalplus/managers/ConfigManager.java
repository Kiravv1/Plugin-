package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;

public class ConfigManager {
    private final SurvivalPlus plugin;
    private FileConfiguration messages;
    private FileConfiguration playerShop;
    private FileConfiguration notifications;

    public ConfigManager(SurvivalPlus plugin) { this.plugin = plugin; reload(); }

    public void reload() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        messages = loadCustom("messages.yml");
        playerShop = loadCustom("playershop.yml");
        notifications = loadCustom("notifications.yml");
    }

    private FileConfiguration loadCustom(String name) {
        File file = new File(plugin.getDataFolder(), name);
        if (!file.exists()) plugin.saveResource(name, false);
        return YamlConfiguration.loadConfiguration(file);
    }

    public FileConfiguration getConfig() { return plugin.getConfig(); }
    public FileConfiguration getMessages() { return messages; }
    public FileConfiguration getPlayerShop() { return playerShop; }
    public FileConfiguration getNotifications() { return notifications; }
    public String getPrefix() { return getConfig().getString("general.prefix", "&#FF4D6D✦ &#FF758FStrawberry &8| &r"); }

    public void send(Player player, String path, String... placeholders) {
        String raw = messages.getString(path, "&cMissing: " + path);
        for (int i = 0; i + 1 < placeholders.length; i += 2) raw = raw.replace(placeholders[i], placeholders[i + 1]);
        player.sendMessage(TextUtil.color(getPrefix() + raw));
    }

    public Component rawMessage(String path, String... placeholders) {
        String raw = messages.getString(path, "");
        for (int i = 0; i + 1 < placeholders.length; i += 2) raw = raw.replace(placeholders[i], placeholders[i + 1]);
        return TextUtil.color(raw);
    }
}
