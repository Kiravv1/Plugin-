package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.util.GriefPreventionHook;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.*;

public class ClaimGuiManager {
    private final SurvivalPlus plugin;
    private final Map<UUID, String> selectedTrustLevel = new HashMap<>();
    private static final List<Integer> LIST_SLOTS = Arrays.asList(10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34, 37,38,39,40,41,42,43);

    public ClaimGuiManager(SurvivalPlus plugin) { this.plugin = plugin; }
    public String getSelectedLevel(UUID playerId) { return selectedTrustLevel.getOrDefault(playerId, plugin.getConfigManager().getConfig().getString("gui.trust.default-level", "Build")); }
    public void setSelectedLevel(UUID playerId, String level) { selectedTrustLevel.put(playerId, level); }

    public void openHub(Player player) {
        GuiHolder holder = new GuiHolder("CLAIM_HUB");
        Inventory inv = Bukkit.createInventory(holder, 45, TextUtil.color(plugin.getConfigManager().getConfig().getString("gui.hub.title", "إدارة الأراضي")));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        int remaining = plugin.getGpHook().getRemainingBlocks(player.getUniqueId());
        int bonus = plugin.getGpHook().getBonusBlocks(player.getUniqueId());
        int count = plugin.getGpHook().getPlayerClaims(player.getUniqueId()).size();
        double bal = plugin.getVaultHook().getBalance(player);

        inv.setItem(4, TextUtil.makeSkull(player, "&#FFD700★ &#FFF0F3" + player.getName(),
                List.of("", "  &#FF8FA3▪ &fالرصيد: &#55FF55" + TextUtil.formatMoney(bal) + "$",
                        "  &#FF8FA3▪ &fأراضيك المحمية: &#FFAA00" + count,
                        "  &#FF8FA3▪ &fنقاط الحماية المتبقية: &#55FF55" + remaining,
                        "  &#FF8FA3▪ &fالنقاط الإضافية: &#FFB3C1" + bonus), false));

        inv.setItem(11, TextUtil.makeItem(Material.GOLDEN_SHOVEL, "&#FFD700✦ مجرفة الحماية", List.of("", "  &7تُستخدم لتحديد وحماية أرضك", "", "  &#55FF55» &fاضغط للاستلام"), false));
        inv.setItem(20, TextUtil.makeItem(Material.STICK, "&#FFAA00✦ عصا الفحص", List.of("", "  &7تُستخدم لمعرفة حدود ومالك أي أرض", "", "  &#55FF55» &fاضغط للاستلام"), false));
        inv.setItem(29, TextUtil.makeItem(Material.PAPER, "&#FF4D6D★ قائمة أراضيك &7(" + count + ")", List.of("", "  &7استعرض جميع أراضيك للانتقال", "  &7أو إدارة الصلاحيات والحذف", "", "  &#55FF55» &fاضغط للفتح"), true));

        ConfigurationSection packs = plugin.getConfigManager().getConfig().getConfigurationSection("claims.economy.packs");
        inv.setItem(13, TextUtil.makeItem(TextUtil.parseMaterial(packs.getString("small.material"), Material.GOLD_NUGGET), "&#FFD700✦ حزمة " + packs.getInt("small.blocks") + " نقطة حماية", List.of("", "  &#FF8FA3▪ &fالسعر: &#55FF55" + TextUtil.formatMoney(packs.getDouble("small.price")) + "$", "", "  &#55FF55» &fاضغط للشراء"), false));
        inv.setItem(22, TextUtil.makeItem(TextUtil.parseMaterial(packs.getString("medium.material"), Material.GOLD_INGOT), "&#FFD700✦ حزمة " + packs.getInt("medium.blocks") + " نقطة حماية", List.of("", "  &#FF8FA3▪ &fالسعر: &#55FF55" + TextUtil.formatMoney(packs.getDouble("medium.price")) + "$", "", "  &#55FF55» &fاضغط للشراء"), false));
        inv.setItem(31, TextUtil.makeItem(TextUtil.parseMaterial(packs.getString("large.material"), Material.RAW_GOLD_BLOCK), "&#FFD700★ حزمة " + packs.getInt("large.blocks") + " نقطة حماية", List.of("", "  &#FF8FA3▪ &fالسعر: &#55FF55" + TextUtil.formatMoney(packs.getDouble("large.price")) + "$", "", "  &#55FF55» &fاضغط للشراء"), true));

        ConfigurationSection sell = plugin.getConfigManager().getConfig().getConfigurationSection("claims.economy.sell");
        inv.setItem(24, TextUtil.makeItem(Material.EMERALD, "&#55FF55✦ بيع " + sell.getInt("blocks") + " نقطة حماية", List.of("", "  &#FF8FA3▪ &fتحصل على: &#FFD700" + TextUtil.formatMoney(sell.getDouble("payout")) + "$", "", "  &#55FF55» &fاضغط للبيع"), false));

        inv.setItem(40, TextUtil.makeItem(Material.BELL, "&#FFD700✦ إعدادات الإشعارات", List.of("", "  &7فتح أو كتم تنبيهات الأراضي والسوق"), false));
        inv.setItem(36, TextUtil.makeItem(Material.BARRIER, "&#FF5555✘ إغلاق", List.of(), false));
        inv.setItem(44, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFAA00« العودة للقائمة الرئيسية", List.of(), false));
        player.openInventory(inv);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }

    public void openClaimsList(Player player, int page) {
        if (!plugin.getGpHook().isConnected()) { plugin.getConfigManager().send(player, "general.gp-missing"); return; }
        List<GriefPreventionHook.ClaimInfo> claims = plugin.getGpHook().getPlayerClaims(player.getUniqueId());
        int perPage = LIST_SLOTS.size(), maxPage = Math.max(1, (int) Math.ceil((double) claims.size() / perPage)), curPage = Math.max(1, Math.min(page, maxPage));
        String title = plugin.getConfigManager().getConfig().getString("gui.list.title", "أراضيك").replace("%page%", String.valueOf(curPage)).replace("%maxpage%", String.valueOf(maxPage));

        GuiHolder holder = new GuiHolder("CLAIM_LIST").set("page", curPage).set("claims", claims);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(title));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        if (claims.isEmpty()) inv.setItem(22, TextUtil.makeItem(Material.BARRIER, "&#FF5555✦ لا تملك أي أراضٍ محمية", List.of("", "  &7استخدم مجرفة الحماية لتحديد أول أرض لك"), false));
        else {
            int start = (curPage - 1) * perPage;
            for (int i = 0; i < perPage && (start + i) < claims.size(); i++) {
                GriefPreventionHook.ClaimInfo c = claims.get(start + i);
                Material icon = c.worldName().equals("world_nether") ? Material.NETHERRACK : (c.worldName().equals("world_the_end") ? Material.END_STONE : Material.GRASS_BLOCK);
                inv.setItem(LIST_SLOTS.get(i), TextUtil.makeItem(icon, "&#FF4D6D✦ &#FFF0F3أرض &#FFAA00#" + c.id(),
                        List.of("", "  &#FF8FA3▪ &fالعالم: &#FFB3C1" + c.worldName(), "  &#FF8FA3▪ &fالمساحة: &#55FF55" + c.area() + " بلوك",
                                "  &#FF8FA3▪ &fالمنتصف: &#FFB3C1" + c.centerX() + ", " + c.centerZ(), "", "  &#55FF55» &fاضغط لفتح لوحة الأرض"), false));
            }
        }
        if (curPage > 1) inv.setItem(45, TextUtil.makeItem(Material.ARROW, "&#FFB3C1« الصفحة السابقة", List.of(), false));
        if (curPage < maxPage) inv.setItem(53, TextUtil.makeItem(Material.ARROW, "&#FFB3C1الصفحة التالية »", List.of(), false));
        inv.setItem(48, TextUtil.makeItem(Material.BARRIER, "&#FF5555✘ إغلاق", List.of(), false));
        inv.setItem(49, TextUtil.makeSkull(player, "&#FF4D6D★ ملخص أراضيك &7(" + claims.size() + ")", List.of("", "  &#FF8FA3▪ &fالنقاط المتبقية: &#55FF55" + plugin.getGpHook().getRemainingBlocks(player.getUniqueId())), false));
        inv.setItem(50, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFAA00« العودة لإدارة الأراضي", List.of(), false));
        player.openInventory(inv);
    }

    public void openManage(Player player, GriefPreventionHook.ClaimInfo claim) {
        GuiHolder holder = new GuiHolder("CLAIM_MANAGE").set("claimId", claim.id());
        Inventory inv = Bukkit.createInventory(holder, 45, TextUtil.color(plugin.getConfigManager().getConfig().getString("gui.manage.title", "إدارة الأرض").replace("%id%", String.valueOf(claim.id()))));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);
        inv.setItem(4, TextUtil.makeItem(Material.PAPER, "&#FF4D6D★ أرض #" + claim.id(), List.of("", "  &#FF8FA3▪ &fالعالم: &#FFB3C1" + claim.worldName(), "  &#FF8FA3▪ &fالمساحة: &#55FF55" + claim.area() + " بلوك"), false));
        inv.setItem(11, TextUtil.makeItem(Material.ENDER_PEARL, "&#55FF55✦ الانتقال إلى الأرض", List.of("", "  &7انتقال آمن لمنتصف الأرض"), false));
        inv.setItem(13, TextUtil.makeItem(Material.PLAYER_HEAD, "&#FFAA00✦ إدارة الصلاحيات", List.of("", "  &7إضافة أو تعديل أو سحب صلاحيات اللاعبين"), false));
        inv.setItem(15, TextUtil.makeItem(Material.COMPARATOR, "&#FFB3C1✦ إعدادات الأرض", List.of("", "  &7الانفجارات، التوسيع، والأقسام الفرعية"), false));
        inv.setItem(40, TextUtil.makeItem(Material.LAVA_BUCKET, "&#FF5555✘ حذف الأرض نهائياً", List.of("", "  &7يفتح شاشة تأكيد الحذف"), false));
        inv.setItem(36, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFAA00« رجوع لقائمة الأراضي", List.of(), false));
        player.openInventory(inv);
    }

    public void openSettings(Player player, GriefPreventionHook.ClaimInfo claim) {
        GuiHolder holder = new GuiHolder("CLAIM_SETTINGS").set("claimId", claim.id());
        Inventory inv = Bukkit.createInventory(holder, 45, TextUtil.color(plugin.getConfigManager().getConfig().getString("gui.settings.title", "إعدادات الأرض").replace("%id%", String.valueOf(claim.id()))));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);
        inv.setItem(20, TextUtil.makeItem(Material.TNT, "&#FF5555✦ الانفجارات: " + (claim.explosivesAllowed() ? "&aمفعّلة" : "&cمعطّلة"), List.of("", "  &#55FF55» &fاضغط للتبديل"), claim.explosivesAllowed()));
        inv.setItem(22, TextUtil.makeItem(Material.OAK_FENCE, "&#FFAA00✦ الأقسام الفرعية: &f" + claim.subdivisions(), List.of(), false));
        inv.setItem(24, TextUtil.makeItem(Material.GOLDEN_SHOVEL, "&#FFD700✦ توسيع الأرض", List.of("", "  &7اضغط لاستلام مجرفة التوسيع"), false));
        inv.setItem(31, TextUtil.makeItem(Material.ENDER_PEARL, "&#55FF55✦ الانتقال للأرض", List.of(), false));
        inv.setItem(36, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFAA00« رجوع", List.of(), false));
        player.openInventory(inv);
    }

    public void openTrust(Player player, GriefPreventionHook.ClaimInfo claim) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.trust");
        GuiHolder holder = new GuiHolder("CLAIM_TRUST").set("claimId", claim.id());
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.color(cfg.getString("title", "صلاحيات الأرض").replace("%id%", String.valueOf(claim.id()))));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        Map<UUID, String> trusted = plugin.getGpHook().getTrustedPlayers(claim);
        List<UUID> uuids = new ArrayList<>(trusted.keySet());
        holder.set("trustedUuids", uuids);

        if (uuids.isEmpty()) inv.setItem(22, TextUtil.makeItem(Material.BARRIER, "&#FF5555✦ لا يوجد لاعبون مضافون", List.of("", "  &7اختر الصلاحية بالأسفل ثم اضغط إضافة لاعب"), false));
        else for (int i = 0; i < Math.min(uuids.size(), LIST_SLOTS.size()); i++) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(uuids.get(i));
            String lvlAr = cfg.getString("levels." + trusted.get(uuids.get(i)), trusted.get(uuids.get(i)));
            inv.setItem(LIST_SLOTS.get(i), TextUtil.makeSkull(op, "&#FF4D6D✦ &#FFF0F3" + (op.getName() != null ? op.getName() : "لاعب"), List.of("", "  &#FF8FA3▪ &fالصلاحية: &#FFAA00" + lvlAr, "", "  &#55FF55» &fاضغط للتحكم"), false));
        }

        String sel = getSelectedLevel(player.getUniqueId());
        int[] lvlSlots = {46, 47, 48, 50};
        List<String> order = cfg.getStringList("level-order");
        for (int i = 0; i < Math.min(order.size(), lvlSlots.length); i++) {
            String lvl = order.get(i);
            boolean isSel = lvl.equals(sel);
            inv.setItem(lvlSlots[i], TextUtil.makeItem(TextUtil.parseMaterial(cfg.getString("level-materials." + lvl), Material.BRICK),
                    "&#FFAA00✦ صلاحية: " + cfg.getString("levels." + lvl, lvl) + (isSel ? " &a✔" : ""), List.of("", "  &7اضغط لتحديد هذه الصلاحية قبل الإضافة"), isSel));
        }
        inv.setItem(49, TextUtil.makeItem(Material.LIME_DYE, "&#55FF55+ إضافة لاعب جديد", List.of("", "  &fالصلاحية المحددة: &#FFAA00" + cfg.getString("levels." + sel, sel)), true));
        inv.setItem(45, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFAA00« رجوع", List.of(), false));
        player.openInventory(inv);
    }

    public void openTrustPlayerAction(Player player, long claimId, UUID targetId) {
        GuiHolder holder = new GuiHolder("CLAIM_TRUST_ACTION").set("claimId", claimId).set("targetId", targetId);
        OfflinePlayer op = Bukkit.getOfflinePlayer(targetId);
        String name = op.getName() != null ? op.getName() : "لاعب";
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color("&#FF4D6D✦ صلاحية " + name));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);
        inv.setItem(11, TextUtil.makeItem(Material.COMPARATOR, "&#FFAA00✦ تغيير الصلاحية", List.of("", "  &7بناء / صناديق / دخول / إدارة"), false));
        inv.setItem(13, TextUtil.makeSkull(op, "&#FF4D6D★ " + name, List.of(), false));
        inv.setItem(15, TextUtil.makeItem(Material.RED_CONCRETE, "&#FF5555✘ سحب الصلاحية", List.of("", "  &7إزالة اللاعب من الأرض"), false));
        inv.setItem(22, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFAA00« رجوع", List.of(), false));
        player.openInventory(inv);
    }

    public void openLevelSelect(Player player, long claimId, UUID targetId) {
        ConfigurationSection cfg = plugin.getConfigManager().getConfig().getConfigurationSection("gui.trust");
        GuiHolder holder = new GuiHolder("CLAIM_TRUST_LEVEL").set("claimId", claimId).set("targetId", targetId);
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color("&#FF4D6D✦ اختر الصلاحية"));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);
        int[] slots = {10, 12, 14, 16};
        List<String> order = cfg.getStringList("level-order");
        for (int i = 0; i < Math.min(order.size(), slots.length); i++) {
            String lvl = order.get(i);
            inv.setItem(slots[i], TextUtil.makeItem(TextUtil.parseMaterial(cfg.getString("level-materials." + lvl), Material.BRICK), "&#FFAA00✦ " + cfg.getString("levels." + lvl, lvl), List.of("", "  &#55FF55» &fاضغط للتطبيق"), false));
        }
        inv.setItem(22, TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFAA00« رجوع", List.of(), false));
        player.openInventory(inv);
    }

    public void openConfirmDelete(Player player, GriefPreventionHook.ClaimInfo claim) {
        GuiHolder holder = new GuiHolder("CLAIM_CONFIRM_DELETE").set("claimId", claim.id());
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color("&#FF5555✦ تأكيد حذف الأرض"));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);
        inv.setItem(11, TextUtil.makeItem(Material.RED_CONCRETE, "&#FF5555✘ إلغاء الحذف", List.of(), false));
        inv.setItem(13, TextUtil.makeItem(Material.PAPER, "&#FF4D6D★ حذف الأرض #" + claim.id(), List.of("", "  &#FF5555لا يمكن التراجع بعد الحذف!"), false));
        inv.setItem(15, TextUtil.makeItem(Material.LIME_CONCRETE, "&#55FF55✔ تأكيد الحذف النهائي", List.of(), true));
        player.openInventory(inv);
    }

    public void openConfirmUntrust(Player player, long claimId, UUID targetId) {
        GuiHolder holder = new GuiHolder("CLAIM_CONFIRM_UNTRUST").set("claimId", claimId).set("targetId", targetId);
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.color("&#FF5555✦ تأكيد سحب الصلاحية"));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);
        inv.setItem(11, TextUtil.makeItem(Material.RED_CONCRETE, "&#FF5555✘ إلغاء", List.of(), false));
        inv.setItem(13, TextUtil.makeSkull(Bukkit.getOfflinePlayer(targetId), "&#FF4D6D★ سحب الصلاحية", List.of(), false));
        inv.setItem(15, TextUtil.makeItem(Material.LIME_CONCRETE, "&#55FF55✔ تأكيد السحب", List.of(), true));
        player.openInventory(inv);
    }
}
