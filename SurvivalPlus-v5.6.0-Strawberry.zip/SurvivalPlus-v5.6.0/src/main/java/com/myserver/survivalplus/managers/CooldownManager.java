package com.myserver.survivalplus.managers;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {
    private final Map<String, Long> cooldowns = new HashMap<>();

    public long getRemainingSeconds(UUID playerId, String key) {
        Long expires = cooldowns.get(playerId + ":" + key);
        if (expires == null) return 0;
        return Math.max(0, (expires - System.currentTimeMillis()) / 1000L);
    }

    public void setCooldown(UUID playerId, String key, int seconds) {
        cooldowns.put(playerId + ":" + key, System.currentTimeMillis() + (seconds * 1000L));
    }

    public String format(long seconds) {
        long h = seconds / 3600, m = (seconds % 3600) / 60, s = seconds % 60;
        if (h > 0) return h + "س " + m + "د";
        if (m > 0) return m + "د " + s + "ث";
        return s + "ث";
    }
}
