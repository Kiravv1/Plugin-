package com.myserver.survivalplus.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TextUtil {
    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private static final DecimalFormat MONEY_FMT = new DecimalFormat("#,##0.##");
    private static final LegacyComponentSerializer SERIALIZER = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors()
            .useUnusualXRepeatedCharacterHexFormat()
            .build();

    private TextUtil() {}

    public static String formatMoney(double amount) { return MONEY_FMT.format(amount); }

    public static Component color(String text) {
        if (text == null) return Component.empty();
        Matcher matcher = HEX_PATTERN.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) matcher.appendReplacement(sb, "&#" + matcher.group(1));
        matcher.appendTail(sb);
        return SERIALIZER.deserialize(sb.toString());
    }

    public static List<Component> colorList(List<String> lines) {
        List<Component> out = new ArrayList<>();
        if (lines == null) return out;
        for (String line : lines) out.add(color(line));
        return out;
    }

    public static Material parseMaterial(String name, Material fallback) {
        if (name == null || name.isBlank()) return fallback;
        try { return Material.valueOf(name.trim().toUpperCase()); } catch (IllegalArgumentException e) { return fallback; }
    }

    public static void playSound(Player player, String soundName) { playSound(player, soundName, 1.0f); }

    public static void playSound(Player player, String soundName, float pitch) {
        if (player == null || soundName == null || soundName.isBlank()) return;
        try {
            Sound sound = Sound.valueOf(soundName.trim().toUpperCase());
            player.playSound(player.getLocation(), sound, 0.85f, pitch);
        } catch (IllegalArgumentException ignored) {}
    }

    public static void spawnParticle(Player player, String particleName, int count) {
        if (player == null || particleName == null || particleName.isBlank()) return;
        try {
            Particle particle = Particle.valueOf(particleName.trim().toUpperCase());
            player.getWorld().spawnParticle(particle, player.getLocation().add(0, 1.0, 0), count, 0.5, 0.5, 0.5, 0.05);
        } catch (IllegalArgumentException ignored) {}
    }

    public static void runConsoleCommand(String command) {
        if (command == null || command.isBlank()) return;
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
    }

    public static void applySleekFrame(Inventory inv) {
        int size = inv.getSize();
        int rows = size / 9;
        ItemStack darkGlass = makeItem(Material.BLACK_STAINED_GLASS_PANE, " ", List.of(), false);
        ItemStack accentGlass = makeItem(Material.RED_STAINED_GLASS_PANE, " ", List.of(), false);

        for (int i = 0; i < 9; i++) inv.setItem(i, darkGlass);
        for (int i = size - 9; i < size; i++) inv.setItem(i, darkGlass);
        for (int r = 1; r < rows - 1; r++) {
            inv.setItem(r * 9, darkGlass);
            inv.setItem(r * 9 + 8, darkGlass);
        }
        inv.setItem(0, accentGlass);
        inv.setItem(8, accentGlass);
        inv.setItem(size - 9, accentGlass);
        inv.setItem(size - 1, accentGlass);
    }

    public static ItemStack makeItem(Material mat, String name, List<String> lore, boolean glow) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(color(name));
            if (lore != null && !lore.isEmpty()) meta.lore(colorList(lore));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            if (glow) { meta.addEnchant(Enchantment.UNBREAKING, 1, true); meta.addItemFlags(ItemFlag.HIDE_ENCHANTS); }
            item.setItemMeta(meta);
        }
        return item;
    }

    public static ItemStack makeSkull(OfflinePlayer owner, String name, List<String> lore, boolean glow) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(owner);
            meta.displayName(color(name));
            if (lore != null && !lore.isEmpty()) meta.lore(colorList(lore));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            if (glow) { meta.addEnchant(Enchantment.UNBREAKING, 1, true); meta.addItemFlags(ItemFlag.HIDE_ENCHANTS); }
            skull.setItemMeta(meta);
        }
        return skull;
    }

    public static void safeGiveItems(Player player, ItemStack template, int totalAmount) {
        if (player == null || template == null || totalAmount <= 0) return;
        int maxStack = Math.max(1, template.getMaxStackSize());
        int remaining = totalAmount;
        while (remaining > 0) {
            int give = Math.min(remaining, maxStack);
            ItemStack stack = template.clone();
            stack.setAmount(give);
            HashMap<Integer, ItemStack> overflow = player.getInventory().addItem(stack);
            for (ItemStack drop : overflow.values()) player.getWorld().dropItemNaturally(player.getLocation(), drop);
            remaining -= give;
        }
    }
}
