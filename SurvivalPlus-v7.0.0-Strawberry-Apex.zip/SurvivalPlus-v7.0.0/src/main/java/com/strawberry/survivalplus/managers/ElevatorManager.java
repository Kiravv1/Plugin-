package com.strawberry.survivalplus.managers;

import com.destroystokyo.paper.event.player.PlayerJumpEvent;
import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ClaimTrustHelper;
import com.strawberry.survivalplus.utils.ColorUtils;
import com.strawberry.survivalplus.utils.GuiBuilder;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class ElevatorManager implements Listener {

    public enum AccessMode {
        PUBLIC("عام للجميع", Material.LIME_DYE, "&#06D6A0"),
        CLAIM("أعضاء الكليم فقط", Material.GOLD_INGOT, "&#FFD166"),
        PRIVATE("المالك فقط", Material.RED_DYE, "&#FF4D6D");

        public final String label;
        public final Material icon;
        public final String color;

        AccessMode(String label, Material icon, String color) {
            this.label = label;
            this.icon = icon;
            this.color = color;
        }

        public AccessMode next() {
            AccessMode[] vals = values();
            return vals[(ordinal() + 1) % vals.length];
        }
    }

    public static class ElevatorNode {
        public final String key;
        public final String world;
        public final int x, y, z;
        public UUID ownerId;
        public String floorName;
        public AccessMode accessMode = AccessMode.PUBLIC;
        public String theme = "CHERRY";

        public ElevatorNode(String world, int x, int y, int z, UUID ownerId, String floorName) {
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.key = makeKey(world, x, y, z);
            this.ownerId = ownerId;
            this.floorName = floorName;
        }
    }

    private final SurvivalPlus plugin;
    private final NamespacedKey itemTagKey;
    private final NamespacedKey recipeKey;
    private final File dataFile;
    private final Map<String, ElevatorNode> nodes = new HashMap<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, String> awaitingRename = new HashMap<>();

    public ElevatorManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.itemTagKey = new NamespacedKey(plugin, "strawberry_elevator");
        this.recipeKey = new NamespacedKey(plugin, "strawberry_elevator_recipe");
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        this.dataFile = new File(plugin.getDataFolder(), "elevators.yml");
        loadAll();
        registerCraftingRecipe();
    }

    public void reload() {
        registerCraftingRecipe();
    }

    public static String makeKey(String world, int x, int y, int z) {
        return world + ":" + x + ":" + y + ":" + z;
    }

    public ItemStack createElevatorItem(int amount) {
        Material mat = GuiBuilder.parseMaterial(plugin.getConfig().getString("elevators.block-material"), Material.WHITE_CONCRETE);
        ItemStack item = new ItemStack(mat, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(ColorUtils.component(plugin.getConfig().getString("elevators.item-name", "&f&lElevator")));
            List<String> lore = plugin.getConfig().getStringList("elevators.item-lore");
            if (!lore.isEmpty()) meta.lore(ColorUtils.loreFor(null, lore));
            meta.getPersistentDataContainer().set(itemTagKey, PersistentDataType.BYTE, (byte) 1);
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isElevatorItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(itemTagKey, PersistentDataType.BYTE);
    }

    public void registerCraftingRecipe() {
        Bukkit.removeRecipe(recipeKey);
        if (!plugin.getConfig().getBoolean("elevators.enabled", true)) return;
        if (!plugin.getConfig().getBoolean("elevators.crafting.enabled", true)) return;

        int resultAmt = plugin.getConfig().getInt("elevators.crafting.result-amount", 2);
        List<String> shape = plugin.getConfig().getStringList("elevators.crafting.shape");
        ConfigurationSection ingSec = plugin.getConfig().getConfigurationSection("elevators.crafting.ingredients");
        if (shape.size() != 3 || ingSec == null) return;

        ShapedRecipe recipe = new ShapedRecipe(recipeKey, createElevatorItem(resultAmt));
        recipe.shape(shape.get(0), shape.get(1), shape.get(2));
        for (String key : ingSec.getKeys(false)) {
            if (key.length() != 1) continue;
            Material m = GuiBuilder.parseMaterial(ingSec.getString(key), Material.WHITE_CONCRETE);
            recipe.setIngredient(key.charAt(0), m);
        }
        Bukkit.addRecipe(recipe);
    }

    public void loadAll() {
        nodes.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection root = cfg.getConfigurationSection("elevators");
        if (root == null) return;
        for (String k : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(k);
            if (s == null) continue;
            try {
                String world = s.getString("world", "world");
                int x = s.getInt("x"), y = s.getInt("y"), z = s.getInt("z");
                UUID owner = UUID.fromString(s.getString("owner"));
                String name = s.getString("name", "طابق " + y);
                ElevatorNode node = new ElevatorNode(world, x, y, z, owner, name);
                node.accessMode = AccessMode.valueOf(s.getString("access", "PUBLIC"));
                node.theme = s.getString("theme", "CHERRY");
                nodes.put(node.key, node);
            } catch (Exception ignored) {}
        }
    }

    public void saveAll() {
        YamlConfiguration cfg = new YamlConfiguration();
        int idx = 0;
        for (ElevatorNode n : nodes.values()) {
            String p = "elevators.e" + (idx++);
            cfg.set(p + ".world", n.world);
            cfg.set(p + ".x", n.x);
            cfg.set(p + ".y", n.y);
            cfg.set(p + ".z", n.z);
            cfg.set(p + ".owner", n.ownerId.toString());
            cfg.set(p + ".name", n.floorName);
            cfg.set(p + ".access", n.accessMode.name());
            cfg.set(p + ".theme", n.theme);
        }
        try { cfg.save(dataFile); } catch (IOException e) {
            plugin.getLogger().warning("Failed to save elevators.yml: " + e.getMessage());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!plugin.getConfig().getBoolean("elevators.enabled", true)) return;
        if (!isElevatorItem(event.getItemInHand())) return;

        Block b = event.getBlockPlaced();
        Player p = event.getPlayer();
        List<ElevatorNode> shaft = getShaftFloors(b.getWorld().getName(), b.getX(), b.getZ());
        int floorIdx = shaft.size() + 1;
        ElevatorNode node = new ElevatorNode(b.getWorld().getName(), b.getX(), b.getY(), b.getZ(),
                p.getUniqueId(), "الطابق #" + floorIdx);
        nodes.put(node.key, node);
        saveAll();

        String prefix = plugin.getConfig().getString("general.prefix", "");
        p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ تم تركيب مصعد ذكي (&f&l" + node.floorName
                + "&#06D6A0&l)! اضغط &#FFD166&lShift + كليك يمين &aعليه للتحكم وتسمية الطابق."));
        plugin.getSoundManager().play(p, "success");
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block b = event.getBlock();
        String key = makeKey(b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
        ElevatorNode node = nodes.remove(key);
        if (node == null) return;

        saveAll();
        if (event.getPlayer().getGameMode() != GameMode.CREATIVE) {
            event.setDropItems(false);
            b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), createElevatorItem(1));
        }
        plugin.getSoundManager().play(event.getPlayer(), "click");
    }

    @EventHandler(ignoreCancelled = true)
    public void onJump(PlayerJumpEvent event) {
        if (!plugin.getConfig().getBoolean("elevators.enabled", true)) return;
        Player p = event.getPlayer();
        ElevatorNode current = getStandingElevator(p);
        if (current == null) return;
        tryTravel(p, current, true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSneak(PlayerToggleSneakEvent event) {
        if (!event.isSneaking() || !plugin.getConfig().getBoolean("elevators.enabled", true)) return;
        Player p = event.getPlayer();
        ElevatorNode current = getStandingElevator(p);
        if (current == null) return;
        tryTravel(p, current, false);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) return;
        Player p = event.getPlayer();
        if (!p.isSneaking()) return;

        Block b = event.getClickedBlock();
        ElevatorNode node = nodes.get(makeKey(b.getWorld().getName(), b.getX(), b.getY(), b.getZ()));
        if (node == null) return;

        event.setCancelled(true);
        openControlGui(p, node);
    }

    private ElevatorNode getStandingElevator(Player p) {
        Location loc = p.getLocation();
        Block below = loc.getBlock().getRelative(0, -1, 0);
        ElevatorNode n = nodes.get(makeKey(below.getWorld().getName(), below.getX(), below.getY(), below.getZ()));
        if (n != null) return n;
        Block at = loc.getBlock();
        return nodes.get(makeKey(at.getWorld().getName(), at.getX(), at.getY(), at.getZ()));
    }

    private void tryTravel(Player p, ElevatorNode current, boolean goingUp) {
        long now = System.currentTimeMillis();
        long cd = plugin.getConfig().getLong("elevators.mechanics.cooldown-millis", 450);
        if (cooldowns.getOrDefault(p.getUniqueId(), 0L) > now) return;

        int minDist = plugin.getConfig().getInt("elevators.mechanics.min-distance-between-floors", 3);
        int maxDist = plugin.getConfig().getInt("elevators.mechanics.max-distance-between-floors", 40);

        List<ElevatorNode> shaft = getShaftFloors(current.world, current.x, current.z);
        int idx = -1;
        for (int i = 0; i < shaft.size(); i++) {
            if (shaft.get(i).key.equals(current.key)) { idx = i; break; }
        }
        if (idx == -1) return;

        int targetIdx = goingUp ? idx + 1 : idx - 1;
        if (targetIdx < 0 || targetIdx >= shaft.size()) return;

        ElevatorNode target = shaft.get(targetIdx);
        int dy = Math.abs(target.y - current.y);
        if (dy < minDist || dy > maxDist) return;

        teleportToFloor(p, target, shaft.size(), targetIdx + 1, goingUp);
    }

    public void teleportToFloor(Player p, ElevatorNode target, int totalFloors, int floorNumber, boolean goingUp) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        World w = Bukkit.getWorld(target.world);
        if (w == null) return;
        Location destBlock = new Location(w, target.x, target.y, target.z);

        if (!canUseNode(p, target, destBlock)) {
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&cهذا الطابق مقفل (" + target.accessMode.label + ")!"));
            plugin.getSoundManager().play(p, "error");
            return;
        }

        if (plugin.getConfig().getBoolean("elevators.mechanics.require-safe-headroom", true)) {
            Block b1 = w.getBlockAt(target.x, target.y + 1, target.z);
            Block b2 = w.getBlockAt(target.x, target.y + 2, target.z);
            if (!b1.isPassable() || !b2.isPassable()) {
                p.sendMessage(ColorUtils.componentFor(p, prefix + "&cمسار الطابق الهدف مسدود ببلوكات!"));
                plugin.getSoundManager().play(p, "error");
                return;
            }
        }

        cooldowns.put(p.getUniqueId(), System.currentTimeMillis() + plugin.getConfig().getLong("elevators.mechanics.cooldown-millis", 450));

        Location tpLoc = new Location(w, target.x + 0.5, target.y + 1.0, target.z + 0.5,
                p.getLocation().getYaw(), p.getLocation().getPitch());
        p.teleport(tpLoc);

        Particle part = parseThemeParticle(target.theme);
        w.spawnParticle(part, tpLoc.clone().add(0, 0.5, 0), 18, 0.35, 0.5, 0.35, 0.02);
        plugin.getSoundManager().play(p, goingUp ? "elevator-up" : "elevator-down");

        String arrow = goingUp ? "&#06D6A0&l▲" : "&#FF758F&l▼";
        p.sendActionBar(ColorUtils.componentFor(p,
                arrow + " &f&l" + target.floorName + " &8| &#FFD166&lالطابق " + floorNumber + "/" + totalFloors));
    }

    private boolean canUseNode(Player p, ElevatorNode node, Location loc) {
        if (p.hasPermission("survivalplus.admin") || node.ownerId.equals(p.getUniqueId())) return true;
        return switch (node.accessMode) {
            case PUBLIC -> true;
            case CLAIM -> ClaimTrustHelper.canAccessContainer(p, loc, false);
            case PRIVATE -> false;
        };
    }

    private boolean canEditNode(Player p, ElevatorNode node) {
        World w = Bukkit.getWorld(node.world);
        if (p.hasPermission("survivalplus.admin") || node.ownerId.equals(p.getUniqueId())) return true;
        return w != null && ClaimTrustHelper.canAccessContainer(p, new Location(w, node.x, node.y, node.z), true);
    }

    public List<ElevatorNode> getShaftFloors(String world, int x, int z) {
        List<ElevatorNode> list = new ArrayList<>();
        for (ElevatorNode n : nodes.values()) {
            if (n.world.equals(world) && n.x == x && n.z == z) list.add(n);
        }
        list.sort(Comparator.comparingInt(a -> a.y));
        return list;
    }

    public void openControlGui(Player p, ElevatorNode node) {
        String title = plugin.getConfig().getString("elevators.gui.control-title", "لوحة تحكم المصعد")
                .replace("%floor%", node.floorName);
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.ELEVATOR_CONTROL)
                .with("node_key", node.key);
        Inventory inv = GuiBuilder.create(p, holder, 36, title);

        List<ElevatorNode> shaft = getShaftFloors(node.world, node.x, node.z);
        boolean canEdit = canEditNode(p, node);

        inv.setItem(10, GuiBuilder.makeItem(p, Material.COMPASS, "&#C77DFF&l✦ الانتقال المباشر لأي طابق (" + shaft.size() + " طوابق)",
                Arrays.asList("&7اختر أي طابق في المبنى وانتقل له فوراً", "&7دون المرور بباقي الطوابق!")));
        inv.setItem(12, GuiBuilder.makeItem(p, Material.NAME_TAG, "&#FFD166&l✦ تسمية الطابق السريعة (Bedrock)",
                Arrays.asList("&7الاسم الحالي: &f&l" + node.floorName,
                        canEdit ? "&7اختر من أسماء جاهزة أو اكتب اسماً مخصصاً." : "&cللمالك وأعضاء الكليم فقط.")));
        inv.setItem(14, GuiBuilder.makeItem(p, node.accessMode.icon,
                node.accessMode.color + "&l✦ خصوصية الطابق: " + node.accessMode.label,
                Arrays.asList("&7اضغط للتبديل بين:", "&aعام للجميع &8| &eأعضاء الكليم &8| &cالمالك فقط")));
        inv.setItem(16, GuiBuilder.makeItem(p, getThemeIcon(node.theme),
                "&#FF758F&l✦ ثيم الجزيئات: " + getThemeName(node.theme),
                Collections.singletonList("&7اضغط لتبديل شكل جزيئات الصعود والنزول!")));

        inv.setItem(31, GuiBuilder.makeItem(p, Material.BARRIER, "&c&lإغلاق اللوحة", null));
        p.openInventory(inv);
        plugin.getSoundManager().play(p, "open-gui");
    }

    public void openFloorDirectory(Player p, ElevatorNode origin) {
        String title = plugin.getConfig().getString("elevators.gui.directory-title", "الانتقال بين الطوابق");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.ELEVATOR_DIRECTORY)
                .with("origin_key", origin.key);
        Inventory inv = GuiBuilder.create(p, holder, 45, title);

        List<ElevatorNode> shaft = getShaftFloors(origin.world, origin.x, origin.z);
        int[] slots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34};
        for (int i = 0; i < shaft.size() && i < slots.length; i++) {
            ElevatorNode f = shaft.get(i);
            boolean isCurrent = f.key.equals(origin.key);
            holder.with("floor_" + slots[i], f.key);
            inv.setItem(slots[i], GuiBuilder.makeItem(p,
                    isCurrent ? Material.LIME_CONCRETE : Material.WHITE_CONCRETE,
                    (isCurrent ? "&#06D6A0&l● " : "&#FFD166&l✦ ") + f.floorName + " &8(#" + (i + 1) + ")",
                    Arrays.asList(
                            "&7الارتفاع: &fY=" + f.y,
                            "&7الخصوصية: " + f.accessMode.color + f.accessMode.label,
                            isCurrent ? "&aأنت تقف في هذا الطابق حالياً." : "&#FF758F&l» اضغط للانتقال المباشر"
                    )));
        }
        inv.setItem(36, GuiBuilder.makeItem(p, Material.ARROW, "&#FF4D6D&l« رجوع للوحة المصعد", null));
        p.openInventory(inv);
        plugin.getSoundManager().play(p, "click");
    }

    public void openRenamePresetsGui(Player p, ElevatorNode node) {
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.ELEVATOR_PRESETS)
                .with("node_key", node.key);
        Inventory inv = GuiBuilder.create(p, holder, 36, "&#FFD166&l✦ اختر اسماً للطابق");

        List<String> presets = plugin.getConfig().getStringList("elevators.preset-floor-names");
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        for (int i = 0; i < presets.size() && i < slots.length; i++) {
            holder.with("preset_" + slots[i], presets.get(i));
            inv.setItem(slots[i], GuiBuilder.makeItem(p, Material.PAPER, "&#FFD166&l✦ " + presets.get(i),
                    Collections.singletonList("&7اضغط لتعيين هذا الاسم فوراً.")));
        }

        inv.setItem(31, GuiBuilder.makeItem(p, Material.WRITABLE_BOOK, "&#06D6A0&l✎ كتابة اسم مخصص في الشات",
                Collections.singletonList("&7اضغط ثم اكتب الاسم الذي تريده في الشات.")));
        inv.setItem(27, GuiBuilder.makeItem(p, Material.ARROW, "&#FF4D6D&l« رجوع", null));
        p.openInventory(inv);
        plugin.getSoundManager().play(p, "click");
    }

    public void handleControlClick(Player p, StrawberryGuiHolder holder, int slot) {
        ElevatorNode node = nodes.get(holder.getString("node_key", ""));
        if (node == null || slot == 31) { p.closeInventory(); return; }
        if (slot == 10) { openFloorDirectory(p, node); return; }

        if (!canEditNode(p, node)) {
            p.sendMessage(ColorUtils.componentFor(p, plugin.getConfig().getString("general.prefix", "") + "&cفقط مالك المصعد أو أعضاء الكليم يمكنهم تعديل إعداداته!"));
            plugin.getSoundManager().play(p, "error");
            return;
        }

        if (slot == 12) {
            openRenamePresetsGui(p, node);
        } else if (slot == 14) {
            node.accessMode = node.accessMode.next();
            saveAll();
            plugin.getSoundManager().play(p, "click");
            openControlGui(p, node);
        } else if (slot == 16) {
            List<String> themeKeys = new ArrayList<>(getThemeKeys());
            int cur = Math.max(0, themeKeys.indexOf(node.theme));
            node.theme = themeKeys.get((cur + 1) % themeKeys.size());
            saveAll();
            plugin.getSoundManager().play(p, "click");
            openControlGui(p, node);
        }
    }

    public void handleDirectoryClick(Player p, StrawberryGuiHolder holder, int slot) {
        ElevatorNode origin = nodes.get(holder.getString("origin_key", ""));
        if (origin == null) { p.closeInventory(); return; }
        if (slot == 36) { openControlGui(p, origin); return; }

        Object targetKey = holder.get("floor_" + slot);
        if (targetKey == null) return;
        ElevatorNode target = nodes.get(targetKey.toString());
        if (target == null || target.key.equals(origin.key)) return;

        List<ElevatorNode> shaft = getShaftFloors(origin.world, origin.x, origin.z);
        int floorNum = 1;
        for (int i = 0; i < shaft.size(); i++) {
            if (shaft.get(i).key.equals(target.key)) { floorNum = i + 1; break; }
        }
        p.closeInventory();
        teleportToFloor(p, target, shaft.size(), floorNum, target.y > origin.y);
    }

    public void handlePresetsClick(Player p, StrawberryGuiHolder holder, int slot) {
        ElevatorNode node = nodes.get(holder.getString("node_key", ""));
        if (node == null) { p.closeInventory(); return; }
        if (slot == 27) { openControlGui(p, node); return; }

        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (slot == 31) {
            awaitingRename.put(p.getUniqueId(), node.key);
            p.closeInventory();
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&#FFD166&l✎ اكتب اسم الطابق الجديد في الشات الآن &7(أو اكتب &ccancel &7للإلغاء):"));
            plugin.getSoundManager().play(p, "click");
            return;
        }
        Object preset = holder.get("preset_" + slot);
        if (preset != null) {
            node.floorName = preset.toString();
            saveAll();
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ تم تعيين اسم الطابق إلى: &f&l" + node.floorName));
            plugin.getSoundManager().play(p, "success");
            openControlGui(p, node);
        }
    }

    @EventHandler
    public void onChatRename(AsyncChatEvent event) {
        Player p = event.getPlayer();
        String nodeKey = awaitingRename.remove(p.getUniqueId());
        if (nodeKey == null) return;

        event.setCancelled(true);
        String msg = PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        Bukkit.getScheduler().runTask(plugin, () -> {
            ElevatorNode node = nodes.get(nodeKey);
            if (node == null || msg.equalsIgnoreCase("cancel") || msg.isEmpty()) return;
            node.floorName = msg.length() > 28 ? msg.substring(0, 28) : msg;
            saveAll();
            String prefix = plugin.getConfig().getString("general.prefix", "");
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ تم تغيير اسم الطابق إلى: &#FFD166&l" + node.floorName));
            plugin.getSoundManager().play(p, "success");
        });
    }

    private Set<String> getThemeKeys() {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("elevators.themes");
        return sec != null && !sec.getKeys(false).isEmpty() ? sec.getKeys(false) : Collections.singleton("CHERRY");
    }

    private Particle parseThemeParticle(String theme) {
        String pName = plugin.getConfig().getString("elevators.themes." + theme + ".particle", "CHERRY_LEAVES");
        try { return Particle.valueOf(pName.toUpperCase()); } catch (Exception e) { return Particle.CHERRY_LEAVES; }
    }

    private Material getThemeIcon(String theme) {
        return GuiBuilder.parseMaterial(plugin.getConfig().getString("elevators.themes." + theme + ".icon"), Material.CHERRY_SAPLING);
    }

    private String getThemeName(String theme) {
        return plugin.getConfig().getString("elevators.themes." + theme + ".name", theme);
    }
}
