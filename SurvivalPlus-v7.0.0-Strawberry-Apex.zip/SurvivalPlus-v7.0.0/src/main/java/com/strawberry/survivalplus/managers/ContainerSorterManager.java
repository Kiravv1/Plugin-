package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ClaimTrustHelper;
import com.strawberry.survivalplus.utils.ColorUtils;
import com.strawberry.survivalplus.utils.GuiBuilder;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class ContainerSorterManager implements Listener {

    public enum SortMode {
        CATEGORY_ALPHA,
        QUANTITY_DESC,
        MERGE_ONLY
    }

    private final SurvivalPlus plugin;
    private final Map<UUID, Location> selectedContainers = new HashMap<>();

    public ContainerSorterManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onShiftLeftClickContainer(PlayerInteractEvent event) {
        if (!plugin.getConfig().getBoolean("container-sorter.enabled", true)) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.LEFT_CLICK_BLOCK || event.getClickedBlock() == null) return;
        if (!event.getPlayer().isSneaking()) return;

        Block b = event.getClickedBlock();
        if (!isSupportedContainer(b)) return;
        event.setCancelled(true);
        openSorterGui(event.getPlayer(), b);
    }

    public void openForLookedBlock(Player p) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        int dist = plugin.getConfig().getInt("container-sorter.max-look-distance", 6);
        Block target = p.getTargetBlockExact(dist);
        if (target == null || !isSupportedContainer(target)) {
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&cانظر إلى صندوق أو برميل أو شالكر أولاً! &7(الترتيب للحاويات فقط وليس للإنفنتوري)"));
            plugin.getSoundManager().play(p, "error");
            return;
        }
        openSorterGui(p, target);
    }

    public void openSorterGui(Player p, Block block) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        boolean reqTrust = plugin.getConfig().getBoolean("container-sorter.require-claim-trust", true);
        if (reqTrust && !ClaimTrustHelper.canAccessContainer(p, block.getLocation(), false)) {
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&cليس لديك صلاحية ترتيب الصناديق داخل هذه الأرض!"));
            plugin.getSoundManager().play(p, "error");
            return;
        }

        selectedContainers.put(p.getUniqueId(), block.getLocation());
        String title = plugin.getConfig().getString("container-sorter.gui-title", "الترتيب الذكي للحاوية");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.CONTAINER_SORTER);
        Inventory inv = GuiBuilder.create(p, holder, 27, title);

        inv.setItem(10, GuiBuilder.makeItem(p, Material.HOPPER, "&#06D6A0&l✦ ترتيب ذكي (الفئة + الأبجدية)",
                Arrays.asList(
                        "&7يدمج الستاكات المتفرقة ويرتب الحاوية",
                        "&7حسب النوع (أدوات، دروع، أكل، بلوكات) وأبجدياً.",
                        "&8(للحاوية فقط — لا يمس حقيبتك!)"
                )));
        inv.setItem(12, GuiBuilder.makeItem(p, Material.CHEST, "&#FFD166&l✦ ترتيب حسب الأكبر كمية",
                Arrays.asList("&7يدمج الستاكات ويضع الأغراض الأكثر عدداً", "&7في الصفوف الأولى من الحاوية.")));
        inv.setItem(14, GuiBuilder.makeItem(p, Material.BUNDLE, "&#48CAE4&l✦ دمج الستاكات المتفرقة فقط",
                Collections.singletonList("&7يدمج الأغراض المتشابهة بدون تغيير ترتيبها.")));
        inv.setItem(16, GuiBuilder.makeItem(p, Material.ENDER_EYE, "&#FF758F&l✦ إيداع سريع للمتشابهات (Quick-Stack)",
                Arrays.asList(
                        "&7ينقل الأغراض من حقيبتك إلى هذه الحاوية",
                        "&7فقط إذا كان نفس النوع موجوداً فيها مسبقاً.",
                        "&8(يتجاهل شريط الـ Hotbar تماماً!)"
                )));

        inv.setItem(22, GuiBuilder.makeItem(p, Material.BARRIER, "&c&lإغلاق", null));
        p.openInventory(inv);
        plugin.getSoundManager().play(p, "open-gui");
    }

    public void handleClick(Player p, int slot) {
        if (slot == 22) { p.closeInventory(); return; }
        Location loc = selectedContainers.get(p.getUniqueId());
        if (loc == null) { p.closeInventory(); return; }

        Block b = loc.getBlock();
        BlockState state = b.getState();
        if (!(state instanceof Container container)) { p.closeInventory(); return; }

        Inventory targetInv = container.getInventory();
        String prefix = plugin.getConfig().getString("general.prefix", "");

        if (slot == 10) {
            sortContainerInventory(targetInv, SortMode.CATEGORY_ALPHA);
            finishAction(p, loc, prefix + "&#06D6A0&l✔ تم ترتيب الحاوية ذكياً (الفئة + الأبجدية) ودمج الستاكات!");
        } else if (slot == 12) {
            sortContainerInventory(targetInv, SortMode.QUANTITY_DESC);
            finishAction(p, loc, prefix + "&#FFD166&l✔ تم ترتيب الحاوية حسب الكمية ودمج الستاكات!");
        } else if (slot == 14) {
            sortContainerInventory(targetInv, SortMode.MERGE_ONLY);
            finishAction(p, loc, prefix + "&#48CAE4&l✔ تم دمج جميع الستاكات المتفرقة داخل الحاوية!");
        } else if (slot == 16) {
            int moved = quickStackIntoContainer(p, targetInv);
            finishAction(p, loc, prefix + "&#FF758F&l✔ تم إيداع &#FFD166&l" + moved + " &fغرض مطابق داخل الحاوية بنجاح!");
        }
    }

    private void finishAction(Player p, Location loc, String msg) {
        p.closeInventory();
        p.sendMessage(ColorUtils.componentFor(p, msg));
        plugin.getSoundManager().play(p, "sort");
        if (loc.getWorld() != null) {
            loc.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc.clone().add(0.5, 1.0, 0.5), 10, 0.35, 0.25, 0.35, 0.02);
        }
    }

    private void sortContainerInventory(Inventory inv, SortMode mode) {
        ItemStack[] contents = inv.getContents();
        List<ItemStack> merged = new ArrayList<>();

        for (ItemStack item : contents) {
            if (item == null || item.getType().isAir()) continue;
            ItemStack remaining = item.clone();
            for (ItemStack existing : merged) {
                if (existing.isSimilar(remaining) && existing.getAmount() < existing.getMaxStackSize()) {
                    int space = existing.getMaxStackSize() - existing.getAmount();
                    int transfer = Math.min(space, remaining.getAmount());
                    existing.setAmount(existing.getAmount() + transfer);
                    remaining.setAmount(remaining.getAmount() - transfer);
                    if (remaining.getAmount() <= 0) break;
                }
            }
            if (remaining.getAmount() > 0) merged.add(remaining);
        }

        if (mode == SortMode.CATEGORY_ALPHA) {
            merged.sort((a, b) -> {
                int catCmp = Integer.compare(getCategoryWeight(a.getType()), getCategoryWeight(b.getType()));
                if (catCmp != 0) return catCmp;
                int nameCmp = a.getType().name().compareTo(b.getType().name());
                if (nameCmp != 0) return nameCmp;
                return Integer.compare(b.getAmount(), a.getAmount());
            });
        } else if (mode == SortMode.QUANTITY_DESC) {
            merged.sort((a, b) -> {
                int amtCmp = Integer.compare(b.getAmount(), a.getAmount());
                if (amtCmp != 0) return amtCmp;
                return a.getType().name().compareTo(b.getType().name());
            });
        }

        inv.clear();
        for (int i = 0; i < merged.size() && i < inv.getSize(); i++) {
            inv.setItem(i, merged.get(i));
        }
    }

    private int quickStackIntoContainer(Player p, Inventory containerInv) {
        Set<Material> presentMaterials = new HashSet<>();
        for (ItemStack it : containerInv.getContents()) {
            if (it != null && !it.getType().isAir()) presentMaterials.add(it.getType());
        }
        int totalMoved = 0;
        for (int slot = 9; slot < 36; slot++) {
            ItemStack item = p.getInventory().getItem(slot);
            if (item == null || item.getType().isAir()) continue;
            if (!presentMaterials.contains(item.getType())) continue;

            int before = item.getAmount();
            HashMap<Integer, ItemStack> leftover = containerInv.addItem(item.clone());
            if (leftover.isEmpty()) {
                p.getInventory().setItem(slot, null);
                totalMoved += before;
            } else {
                ItemStack rem = leftover.values().iterator().next();
                p.getInventory().setItem(slot, rem);
                totalMoved += (before - rem.getAmount());
            }
        }
        return totalMoved;
    }

    private int getCategoryWeight(Material m) {
        String n = m.name();
        if (n.endsWith("_SWORD") || n.endsWith("_AXE") || n.contains("BOW") || n.equals("TRIDENT") || n.equals("MACE")) return 1;
        if (n.endsWith("_PICKAXE") || n.endsWith("_SHOVEL") || n.endsWith("_HOE") || n.equals("SHEARS") || n.equals("FISHING_ROD")) return 2;
        if (n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE") || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS") || n.equals("ELYTRA") || n.equals("SHIELD")) return 3;
        if (m.isEdible()) return 4;
        if (n.contains("ORE") || n.contains("INGOT") || n.contains("DIAMOND") || n.contains("EMERALD") || n.contains("NETHERITE") || n.contains("SHARD")) return 5;
        if (n.contains("REDSTONE") || n.contains("PISTON") || n.contains("HOPPER") || n.contains("OBSERVER") || n.contains("REPEATER")) return 6;
        if (m.isBlock()) return 7;
        return 8;
    }

    private boolean isSupportedContainer(Block b) {
        if (!(b.getState() instanceof Container)) return false;
        String name = b.getType().name();
        if (name.endsWith("SHULKER_BOX")) return true;
        return plugin.getConfig().getStringList("container-sorter.supported-containers").contains(name);
    }
}
