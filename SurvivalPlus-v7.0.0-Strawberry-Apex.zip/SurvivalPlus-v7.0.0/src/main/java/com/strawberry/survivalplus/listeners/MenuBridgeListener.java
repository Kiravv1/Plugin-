package com.strawberry.survivalplus.listeners;

import com.strawberry.survivalplus.SurvivalPlus;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.List;

public class MenuBridgeListener implements Listener {

    private final SurvivalPlus plugin;

    public MenuBridgeListener(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        String msg = event.getMessage();
        if (!msg.startsWith("/") || msg.length() <= 1) return;
        String raw = msg.substring(1).split(" ")[0].toLowerCase();

        String secretCmd = plugin.getConfig().getString("utility-hub.secret-command", "sbx_apex_9k4m_hub7").toLowerCase();
        if (raw.equals(secretCmd)) {
            event.setCancelled(true);
            plugin.getUtilityHubManager().openHubWithFee(event.getPlayer());
            return;
        }

        if (!plugin.getConfig().getBoolean("menu-bridge.intercept-menu-command", true)) return;
        List<String> aliases = plugin.getConfig().getStringList("menu-bridge.redirect-commands");
        for (String alias : aliases) {
            if (alias.equalsIgnoreCase(raw)) {
                event.setCancelled(true);
                String backCmd = plugin.getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                        .replace("%player%", event.getPlayer().getName());
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), backCmd);
                plugin.getSoundManager().play(event.getPlayer(), "open-gui");
                return;
            }
        }
    }
}
