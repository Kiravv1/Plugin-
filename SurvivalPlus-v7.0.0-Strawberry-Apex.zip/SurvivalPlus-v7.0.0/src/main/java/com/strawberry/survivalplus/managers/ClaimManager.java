package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ColorUtils;
import com.strawberry.survivalplus.utils.GuiBuilder;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class ClaimManager {

    private final SurvivalPlus plugin;
    private final Map<UUID, Long> shovelCooldown = new HashMap<>();

    public ClaimManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    public void openHub(Player player) {
        String title = plugin.getConfig().getString("gui.hub.title", "إدارة الأراضي");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.CLAIM_HUB);
        Inventory inv = GuiBuilder.create(player, holder, 36, title);

        inv.setItem(10, GuiBuilder.makeItem(player, Material.GRASS_BLOCK, "&#06D6A0&l✦ قائمة أراضيك",
                Arrays.asList("&7عرض جميع أراضيك المحمية وإحداثياتها", "&7في السيرفر بضغطة واحدة.")));
        inv.setItem(12, GuiBuilder.makeItem(player, Material.GOLD_INGOT, "&#FFD166&l✦ متجر بلوكات الأراضي",
                Arrays.asList("&7اشترِ باقات بلوكات حماية لتوسيع أرضك", "&7أو بع البلوكات الفائضة لديك.")));
        inv.setItem(14, GuiBuilder.makeItem(player, Material.GOLDEN_SHOVEL, "&#FF758F&l✦ استلام أدوات الحماية",
                Arrays.asList("&7احصل على المجرفة الذهبية وعصا الفحص", "&7لتحديد حدود أرضك بسهولة.")));
        inv.setItem(16, GuiBuilder.makeItem(player, Material.CHERRY_SAPLING, "&#C77DFF&l✦ إظهار حدود المنطقة (جزيئات)",
                Arrays.asList("&7يرسم لك إطاراً مرئياً ببتلات الكرز", "&7حول موقعك الحالي لمدة 15 ثانية!")));

        inv.setItem(31, GuiBuilder.backButton(player));
        player.openInventory(inv);
        plugin.getSoundManager().play(player, "open-gui");
    }

    public void openBlockShop(Player player) {
        String title = plugin.getConfig().getString("gui.shop-blocks.title", "متجر بلوكات الأراضي");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.CLAIM_BLOCKS_SHOP);
        Inventory inv = GuiBuilder.create(player, holder, 36, title);

        ConfigurationSection packs = plugin.getConfig().getConfigurationSection("claims.economy.packs");
        if (packs != null) {
            for (String key : packs.getKeys(false)) {
                ConfigurationSection pSec = packs.getConfigurationSection(key);
                if (pSec == null) continue;
                int slot = pSec.getInt("slot", 11);
                int blocks = pSec.getInt("blocks", 100);
                double price = pSec.getDouble("price", 500.0);
                String name = pSec.getString("name", key);
                Material mat = GuiBuilder.parseMaterial(pSec.getString("material"), Material.GOLD_INGOT);

                holder.with("pack_" + slot, key);
                inv.setItem(slot, GuiBuilder.makeItem(player, mat, name, Arrays.asList(
                        "&#FFB3C1&l━━━━━━━━━━━━━━━━━━",
                        "&7الكمية: &#06D6A0&l+" + blocks + " بلوكة حماية",
                        "&7السعر: &#FFD166&l" + price + "$",
                        "&#FFB3C1&l━━━━━━━━━━━━━━━━━━",
                        "&#06D6A0&l» اضغط للشراء الفوري"
                )));
            }
        }

        int sellSlot = plugin.getConfig().getInt("claims.economy.sell.slot", 22);
        int sellBlocks = plugin.getConfig().getInt("claims.economy.sell.blocks", 100);
        double sellPayout = plugin.getConfig().getDouble("claims.economy.sell.payout", 250.0);
        inv.setItem(sellSlot, GuiBuilder.makeItem(player, Material.EMERALD, "&#FF4D6D&l✦ بيع بلوكات حماية فائضة", Arrays.asList(
                "&7بيع: &#FFD166&l" + sellBlocks + " بلوكة",
                "&7تستلم: &#06D6A0&l+" + sellPayout + "$",
                "",
                "&#FF758F&l» اضغط للبيع"
        )));

        inv.setItem(27, GuiBuilder.makeItem(player, Material.ARROW, "&#FF4D6D&l« رجوع لإدارة الأراضي", null));
        player.openInventory(inv);
        plugin.getSoundManager().play(player, "open-gui");
    }

    public void handleHubClick(Player p, int slot) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (slot == 10) {
            p.closeInventory();
            p.performCommand("claimslist");
        } else if (slot == 12) {
            openBlockShop(p);
        } else if (slot == 14) {
            giveClaimTools(p);
            p.closeInventory();
        } else if (slot == 16) {
            p.closeInventory();
            startBorderVisualizer(p);
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&#FF758F&l✦ تم تفعيل العرض البصري لحدود المنطقة حولك!"));
            plugin.getSoundManager().play(p, "success");
        } else if (slot == 31) {
            String cmd = plugin.getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                    .replace("%player%", p.getName());
            p.closeInventory();
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }
    }

    public void handleBlockShopClick(Player p, StrawberryGuiHolder holder, int slot) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (slot == 27) { openHub(p); return; }

        int sellSlot = plugin.getConfig().getInt("claims.economy.sell.slot", 22);
        if (slot == sellSlot) {
            int blocks = plugin.getConfig().getInt("claims.economy.sell.blocks", 100);
            double payout = plugin.getConfig().getDouble("claims.economy.sell.payout", 250.0);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "acb " + p.getName() + " -" + blocks);
            if (plugin.getEconomy() != null) plugin.getEconomy().depositPlayer(p, payout);
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ تم بيع " + blocks + " بلوكة واستلام &#FFD166&l+" + payout + "$"));
            plugin.getSoundManager().play(p, "claim-buy");
            return;
        }

        Object packKey = holder.get("pack_" + slot);
        if (packKey == null) return;
        ConfigurationSection pSec = plugin.getConfig().getConfigurationSection("claims.economy.packs." + packKey);
        if (pSec == null) return;

        int blocks = pSec.getInt("blocks", 100);
        double price = pSec.getDouble("price", 500.0);
        if (plugin.getEconomy() != null) {
            if (!plugin.getEconomy().has(p, price)) {
                p.sendMessage(ColorUtils.componentFor(p, prefix + "&cرصيدك غير كافٍ! المطلوب: &#FFD166&l" + price + "$"));
                plugin.getSoundManager().play(p, "error");
                return;
            }
            plugin.getEconomy().withdrawPlayer(p, price);
        }
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "acb " + p.getName() + " " + blocks);
        p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ تم شراء &#FFD166&l" + blocks + " بلوكة حماية &aبنجاح!"));
        plugin.getSoundManager().play(p, "claim-buy");
    }

    private void giveClaimTools(Player p) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        long now = System.currentTimeMillis();
        long shovelCd = plugin.getConfig().getLong("claims.tools.shovel.cooldown-seconds", 7200) * 1000L;
        if (shovelCooldown.getOrDefault(p.getUniqueId(), 0L) > now) {
            long mins = (shovelCooldown.get(p.getUniqueId()) - now) / 60000L;
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&cيمكنك استلام أدوات الحماية مجدداً بعد &#FFD166&l" + Math.max(1, mins) + " دقيقة."));
            plugin.getSoundManager().play(p, "error");
            return;
        }
        shovelCooldown.put(p.getUniqueId(), now + shovelCd);

        ItemStack shovel = GuiBuilder.makeItem(p,
                GuiBuilder.parseMaterial(plugin.getConfig().getString("claims.tools.shovel.material"), Material.GOLDEN_SHOVEL),
                plugin.getConfig().getString("claims.tools.shovel.name", "&#FFD166&lمجرفة الحماية"),
                Collections.singletonList("&7اضغط كليك يمين على الزاويتين لحماية أرضك."));
        ItemStack stick = GuiBuilder.makeItem(p,
                GuiBuilder.parseMaterial(plugin.getConfig().getString("claims.tools.stick.material"), Material.STICK),
                plugin.getConfig().getString("claims.tools.stick.name", "&#FF758F&lعصا الفحص"),
                Collections.singletonList("&7اضغط كليك يمين على الأرض لفحص مالكها وحدودها."));

        p.getInventory().addItem(shovel, stick);
        p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ تم تسليمك أدوات حماية الأراضي بنجاح!"));
        plugin.getSoundManager().play(p, "success");
    }

    public void startBorderVisualizer(Player p) {
        int radius = plugin.getConfig().getInt("claims.visualizer.radius", 8);
        int durationSec = plugin.getConfig().getInt("claims.visualizer.duration-seconds", 15);
        Location center = p.getLocation().getBlock().getLocation().add(0.5, 0.5, 0.5);
        World w = center.getWorld();
        if (w == null) return;

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!p.isOnline() || ticks >= durationSec * 2) { cancel(); return; }
                for (int i = -radius; i <= radius; i += 2) {
                    w.spawnParticle(Particle.CHERRY_LEAVES, center.getX() + i, center.getY() + 0.5, center.getZ() + radius, 1, 0, 0.1, 0, 0.01);
                    w.spawnParticle(Particle.CHERRY_LEAVES, center.getX() + i, center.getY() + 0.5, center.getZ() - radius, 1, 0, 0.1, 0, 0.01);
                    w.spawnParticle(Particle.CHERRY_LEAVES, center.getX() + radius, center.getY() + 0.5, center.getZ() + i, 1, 0, 0.1, 0, 0.01);
                    w.spawnParticle(Particle.CHERRY_LEAVES, center.getX() - radius, center.getY() + 0.5, center.getZ() + i, 1, 0, 0.1, 0, 0.01);
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 10L);
    }
}
