package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ColorUtils;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.World;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerBedLeaveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SmoothSleepManager implements Listener {

    private final SurvivalPlus plugin;
    private final Map<UUID, BukkitRunnable> activeAccelerators = new HashMap<>();
    private final Map<UUID, BossBar> worldBars = new HashMap<>();

    public SmoothSleepManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBedEnter(PlayerBedEnterEvent event) {
        if (!plugin.getConfig().getBoolean("smooth-sleep.enabled", true)) return;
        if (event.getBedEnterResult() != PlayerBedEnterEvent.BedEnterResult.OK) return;
        World world = event.getPlayer().getWorld();
        Bukkit.getScheduler().runTaskLater(plugin, () -> evaluateWorld(world), 2L);
    }

    @EventHandler
    public void onBedLeave(PlayerBedLeaveEvent event) {
        World world = event.getPlayer().getWorld();
        Bukkit.getScheduler().runTaskLater(plugin, () -> evaluateWorld(world), 2L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        World world = event.getPlayer().getWorld();
        Bukkit.getScheduler().runTaskLater(plugin, () -> evaluateWorld(world), 2L);
    }

    public void evaluateWorld(World world) {
        if (world == null || world.getEnvironment() != World.Environment.NORMAL) return;
        if (!plugin.getConfig().getBoolean("smooth-sleep.enabled", true)) return;

        int sleeping = 0;
        int eligible = 0;
        boolean excludeAfk = plugin.getConfig().getBoolean("smooth-sleep.exclude-afk-players", true);

        for (Player p : world.getPlayers()) {
            if (p.getGameMode() == GameMode.SPECTATOR) continue;
            if (excludeAfk && plugin.getAfkManager().isAfk(p)) continue;
            eligible++;
            if (p.isSleeping()) sleeping++;
        }

        if (eligible == 0) {
            stopAccelerator(world);
            return;
        }

        double pct = plugin.getConfig().getDouble("smooth-sleep.required-percentage", 50.0);
        int required = Math.max(1, (int) Math.ceil(eligible * (pct / 100.0)));
        boolean isNightOrStorm = (world.getTime() >= 12541 && world.getTime() < 23850) || world.isThundering();

        if (sleeping >= required && isNightOrStorm) {
            startSmoothDawn(world);
        } else if (sleeping == 0 || sleeping < required) {
            stopAccelerator(world);
        }
    }

    private void startSmoothDawn(World world) {
        if (activeAccelerators.containsKey(world.getUID())) return;

        BossBar bar = worldBars.computeIfAbsent(world.getUID(),
                k -> Bukkit.createBossBar("", BarColor.YELLOW, BarStyle.SEGMENTED_10));
        bar.setVisible(true);

        long step = Math.max(20L, plugin.getConfig().getLong("smooth-sleep.time-step-per-tick", 110L));
        boolean excludeAfk = plugin.getConfig().getBoolean("smooth-sleep.exclude-afk-players", true);
        double pct = plugin.getConfig().getDouble("smooth-sleep.required-percentage", 50.0);

        BukkitRunnable runner = new BukkitRunnable() {
            @Override
            public void run() {
                int sleeping = 0;
                int eligible = 0;
                for (Player p : world.getPlayers()) {
                    if (p.getGameMode() == GameMode.SPECTATOR) continue;
                    if (excludeAfk && plugin.getAfkManager().isAfk(p)) continue;
                    eligible++;
                    if (p.isSleeping()) sleeping++;
                }
                int required = Math.max(1, (int) Math.ceil(Math.max(1, eligible) * (pct / 100.0)));

                if (sleeping < required) {
                    stopAccelerator(world);
                    return;
                }

                long currentTime = world.getTime();
                long nextTime = currentTime + step;

                bar.removeAll();
                world.getPlayers().forEach(bar::addPlayer);
                String title = plugin.getConfig().getString("smooth-sleep.bossbar-title", "تسريع الليل نحو الشروق...")
                        .replace("%sleeping%", String.valueOf(sleeping))
                        .replace("%required%", String.valueOf(required));
                bar.setTitle(ColorUtils.translateLegacy(title));

                double progress = Math.max(0.0, Math.min(1.0, (currentTime - 12541.0) / (24000.0 - 12541.0)));
                bar.setProgress(progress);

                if (nextTime >= 24000L || currentTime < 12000L) {
                    world.setTime(0L);
                    if (plugin.getConfig().getBoolean("smooth-sleep.clear-weather-on-dawn", true)) {
                        world.setStorm(false);
                        world.setThundering(false);
                    }
                    for (Player p : world.getPlayers()) {
                        p.sendActionBar(ColorUtils.componentFor(p, "&#FFD166&l☀ صباح الخير! &fأشرقت الشمس بسلاسة."));
                        plugin.getSoundManager().play(p, "success");
                        if (p.isSleeping()) p.wakeup(false);
                    }
                    stopAccelerator(world);
                    return;
                }

                world.setTime(nextTime);
            }
        };

        activeAccelerators.put(world.getUID(), runner);
        runner.runTaskTimer(plugin, 1L, 1L);
    }

    private void stopAccelerator(World world) {
        BukkitRunnable task = activeAccelerators.remove(world.getUID());
        if (task != null) task.cancel();
        BossBar bar = worldBars.remove(world.getUID());
        if (bar != null) {
            bar.setVisible(false);
            bar.removeAll();
        }
    }

    public void shutdown() {
        activeAccelerators.values().forEach(BukkitRunnable::cancel);
        activeAccelerators.clear();
        worldBars.values().forEach(b -> { b.setVisible(false); b.removeAll(); });
        worldBars.clear();
    }
}
