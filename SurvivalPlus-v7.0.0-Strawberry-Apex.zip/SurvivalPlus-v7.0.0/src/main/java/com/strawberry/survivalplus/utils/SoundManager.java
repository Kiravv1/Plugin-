package com.strawberry.survivalplus.utils;

import com.strawberry.survivalplus.SurvivalPlus;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class SoundManager {

    private final SurvivalPlus plugin;

    public SoundManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    public void reload() {}

    public void play(Player player, String key) {
        if (player == null) return;
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("sounds." + key);
        if (sec == null) return;
        String soundKey = sec.getString("sound", "ui.button.click");
        float volume = (float) sec.getDouble("volume", 1.0);
        float pitch = (float) sec.getDouble("pitch", 1.0);
        playRaw(player, soundKey, volume, pitch);
    }

    public void playRaw(Player player, String soundName, float volume, float pitch) {
        if (player == null || soundName == null || soundName.isEmpty()) return;
        String normalized = normalizeSoundKey(soundName);
        player.playSound(player.getLocation(), normalized, volume, pitch);
    }

    private String normalizeSoundKey(String raw) {
        String s = raw.trim().toLowerCase();
        if (s.contains(".")) return s;
        String[] prefixes = {"block_", "entity_", "item_", "ui_", "ambient_", "music_", "weather_"};
        for (String p : prefixes) {
            if (s.startsWith(p)) {
                String rest = s.substring(p.length());
                String cat = p.substring(0, p.length() - 1);
                return cat + "." + rest;
            }
        }
        return s.replace('_', '.');
    }
}
