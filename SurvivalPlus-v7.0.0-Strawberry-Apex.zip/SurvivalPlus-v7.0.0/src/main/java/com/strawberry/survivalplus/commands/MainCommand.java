package com.strawberry.survivalplus.commands;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.managers.HistoryManager;
import com.strawberry.survivalplus.utils.ColorUtils;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public class MainCommand implements CommandExecutor, TabCompleter {

    private final SurvivalPlus plugin;

    public MainCommand(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        String cmd = command.getName().toLowerCase();
        String prefix = plugin.getConfig().getString("general.prefix", "");

        if (cmd.equals("splus")) {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                if (!sender.hasPermission("survivalplus.admin")) {
                    sender.sendMessage(ColorUtils.component(prefix + "&cليس لديك صلاحية لهذا الأمر."));
                    return true;
                }
                plugin.reloadPlugin();
                sender.sendMessage(ColorUtils.component(prefix + "&#06D6A0&l✔ تم تحديث جميع إعدادات SurvivalPlus v7.0.0 بنجاح!"));
                if (sender instanceof Player p) plugin.getSoundManager().play(p, "success");
                return true;
            }
            if (args.length > 0 && args[0].equalsIgnoreCase("giveelevator")) {
                if (!sender.hasPermission("survivalplus.admin")) return true;
                Player target = args.length >= 2 ? Bukkit.getPlayer(args[1]) : (sender instanceof Player p ? p : null);
                int amount = 2;
                if (args.length >= 3) {
                    try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                }
                if (target != null) {
                    target.getInventory().addItem(plugin.getElevatorManager().createElevatorItem(amount));
                    sender.sendMessage(ColorUtils.component(prefix + "&#06D6A0&l✔ تم منح " + amount + "x Elevator إلى " + target.getName()));
                }
                return true;
            }
            if (sender instanceof Player p && args.length > 0) {
                if (args[0].equalsIgnoreCase("refill")) {
                    boolean now = plugin.getAutoRefillManager().toggleFor(p);
                    p.sendMessage(ColorUtils.componentFor(p, prefix + (now ? "&#06D6A0&l✔ تم تفعيل التعبئة التلقائية للبلوكات." : "&eتم إيقاف التعبئة التلقائية للبلوكات.")));
                    plugin.getSoundManager().play(p, "click");
                    return true;
                }
                if (p.hasPermission("survivalplus.admin")) {
                    if (args[0].equalsIgnoreCase("setgroupzone")) {
                        plugin.getGroupRtpManager().saveQuickZone(p);
                        p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ تم تحديد بوابة الانتقال الجماعي (7x7) في السباون!"));
                        plugin.getSoundManager().play(p, "success");
                        return true;
                    }
                    if (args[0].equalsIgnoreCase("pos1")) { plugin.getGroupRtpManager().setPos1(p); return true; }
                    if (args[0].equalsIgnoreCase("pos2")) { plugin.getGroupRtpManager().setPos2(p); return true; }
                }
            }
            sender.sendMessage(ColorUtils.component(prefix + "&#FF758F&lSurvivalPlus v7.0.0 Apex &7— /splus reload | setgroupzone | pos1 | pos2 | giveelevator | refill"));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command is for players only.");
            return true;
        }

        switch (cmd) {
            case "sbx_apex_9k4m_hub7" -> plugin.getUtilityHubManager().openHubWithFee(player);
            case "afk" -> plugin.getAfkManager().toggleAfk(player);
            case "sort" -> plugin.getContainerSorterManager().openForLookedBlock(player);
            case "find" -> {
                if (args.length == 0) plugin.getChestRadarManager().openQuickSearchGui(player);
                else plugin.getChestRadarManager().searchByQuery(player, String.join("_", args));
            }
            case "history" -> plugin.getHistoryManager().openHistoryGui(player, HistoryManager.EntryType.ALL, 0);
            case "trade" -> {
                if (args.length == 0) {
                    player.sendMessage(ColorUtils.componentFor(player, prefix + "&eالاستخدام: &f/trade <اسم_اللاعب> &7أو &a/trade accept"));
                } else if (args[0].equalsIgnoreCase("accept")) {
                    plugin.getTradeManager().acceptRequest(player);
                } else {
                    Player target = Bukkit.getPlayer(args[0]);
                    if (target == null) {
                        player.sendMessage(ColorUtils.componentFor(player, prefix + "&cاللاعب غير متصل حالياً!"));
                    } else {
                        plugin.getTradeManager().sendRequest(player, target);
                    }
                }
            }
            case "mail" -> {
                if (args.length >= 2 && args[0].equalsIgnoreCase("send")) {
                    OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                    double cod = 0.0;
                    if (args.length >= 3) {
                        try { cod = Double.parseDouble(args[2]); } catch (NumberFormatException ignored) {}
                    }
                    plugin.getMailManager().sendHandParcel(player, target, cod);
                } else if (args.length >= 3 && args[0].equalsIgnoreCase("pay")) {
                    OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                    try {
                        double amt = Double.parseDouble(args[2]);
                        plugin.getMailManager().sendMoneyParcel(player, target, amt);
                    } catch (NumberFormatException e) {
                        player.sendMessage(ColorUtils.componentFor(player, prefix + "&cالاستخدام: &e/mail pay <اللاعب> <المبلغ>"));
                    }
                } else {
                    plugin.getMailManager().openInboxGui(player);
                }
            }
            case "shop" -> {
                if (args.length >= 2 && args[0].equalsIgnoreCase("add")) {
                    try {
                        double price = Double.parseDouble(args[1]);
                        boolean bulk = args.length >= 3 && (args[2].equalsIgnoreCase("true") || args[2].equalsIgnoreCase("bulk"));
                        plugin.getPlayerShopManager().addHandItemToShop(player, price, bulk);
                    } catch (NumberFormatException e) {
                        player.sendMessage(ColorUtils.componentFor(player, prefix + "&cالاستخدام: &e/shop add <السعر> [bulk]"));
                    }
                } else if (args.length >= 1 && args[0].equalsIgnoreCase("manage")) {
                    plugin.getPlayerShopManager().openManageGui(player, 0);
                } else if (args.length >= 1 && (args[0].equalsIgnoreCase("stats") || args[0].equalsIgnoreCase("analytics"))) {
                    plugin.getPlayerShopManager().openAnalyticsGui(player);
                } else if (args.length >= 1 && args[0].equalsIgnoreCase("upgrades")) {
                    plugin.getPlayerShopManager().openUpgradePathGui(player);
                } else {
                    plugin.getPlayerShopManager().openDirectoryGui(player, 0);
                }
            }
            case "claims" -> {
                if (args.length > 0 && args[0].equalsIgnoreCase("border")) {
                    plugin.getClaimManager().startBorderVisualizer(player);
                    player.sendMessage(ColorUtils.componentFor(player, prefix + "&#FF758F&l✦ تم تفعيل العرض البصري لحدود المنطقة!"));
                } else {
                    plugin.getClaimManager().openHub(player);
                }
            }
            case "vault" -> plugin.getVaultManager().openVaultSelector(player);
            case "grave" -> plugin.getGraveManager().openGravesGui(player);
        }
        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        String cmd = command.getName().toLowerCase();
        if (cmd.equals("splus") && args.length == 1) {
            return Arrays.asList("reload", "setgroupzone", "pos1", "pos2", "giveelevator", "refill");
        }
        if (cmd.equals("shop") && args.length == 1) {
            return Arrays.asList("add", "manage", "stats", "upgrades");
        }
        if (cmd.equals("mail") && args.length == 1) {
            return Arrays.asList("send", "pay");
        }
        if (cmd.equals("trade") && args.length == 1) {
            List<String> list = new ArrayList<>();
            list.add("accept");
            Bukkit.getOnlinePlayers().forEach(p -> list.add(p.getName()));
            return list;
        }
        if (cmd.equals("claims") && args.length == 1) {
            return Collections.singletonList("border");
        }
        return Collections.emptyList();
    }
}
