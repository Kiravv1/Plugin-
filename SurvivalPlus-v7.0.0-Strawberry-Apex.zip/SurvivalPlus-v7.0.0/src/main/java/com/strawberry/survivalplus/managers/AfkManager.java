package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ColorUtils;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.player.*;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.*;

public class AfkManager implements Listener {

    private static final String AFK_TEAM_NAME = "splus_afk";

    private final SurvivalPlus plugin;
    private final Map<UUID, Long> lastActivity = new HashMap<>();
    private final Set<UUID> afkPlayers = new HashSet<>();
    private BukkitRunnable ticker;

    public AfkManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        for (Player p : Bukkit.getOnlinePlayers()) {
            lastActivity.put(p.getUniqueId(), System.currentTimeMillis());
        }
        startTicker();
    }

    public void startTicker() {
        if (ticker != null) ticker.cancel();
        ticker = new BukkitRunnable() {
            @Override
            public void run() {
                if (!plugin.getConfig().getBoolean("smart-afk.enabled", true)) return;
                long now = System.currentTimeMillis();
                long timeoutMs = plugin.getConfig().getLong("smart-afk.idle-timeout-seconds", 180) * 1000L;
                Particle halo = parseParticle(plugin.getConfig().getString("smart-afk.afk-halo-particle"), Particle.CHERRY_LEAVES);

                for (Player p : Bukkit.getOnlinePlayers()) {
                    UUID id = p.getUniqueId();
                    long last = lastActivity.getOrDefault(id, now);
                    if (!afkPlayers.contains(id) && (now - last) >= timeoutMs) {
                        setAfk(p, true);
                    } else if (afkPlayers.contains(id)) {
                        p.getWorld().spawnParticle(halo, p.getLocation().add(0, 2.2, 0), 2, 0.25, 0.05, 0.25, 0.01);
                    }
                }
            }
        };
        ticker.runTaskTimer(plugin, 20L, 20L);
    }

    public boolean isAfk(Player player) {
        return player != null && afkPlayers.contains(player.getUniqueId());
    }

    public void toggleAfk(Player player) {
        setAfk(player, !isAfk(player));
    }

    public void setAfk(Player player, boolean state) {
        if (player == null) return;
        UUID id = player.getUniqueId();
        boolean currently = afkPlayers.contains(id);
        if (currently == state) return;

        String prefix = plugin.getConfig().getString("general.prefix", "");
        String tabPrefix = plugin.getConfig().getString("smart-afk.tab-prefix", "&8[&#FF758F&lAFK&8] &7");

        if (state) {
            afkPlayers.add(id);
            applyAfkVisualsAndAntiPush(player, tabPrefix, true);
            player.sendMessage(ColorUtils.componentFor(player,
                    prefix + "&#FF758F&l✦ دخلت وضع AFK &7(محمي من اللاعبين والدفع، بينما الموبات تظل قادرة على مهاجمتك!)."));
            plugin.getSoundManager().play(player, "click");
            plugin.getSmoothSleepManager().evaluateWorld(player.getWorld());
        } else {
            afkPlayers.remove(id);
            lastActivity.put(id, System.currentTimeMillis());
            applyAfkVisualsAndAntiPush(player, tabPrefix, false);
            player.sendMessage(ColorUtils.componentFor(player, prefix + "&#06D6A0&l✔ مرحباً بعودتك! تم إلغاء وضع AFK."));
            plugin.getSoundManager().play(player, "success");
        }
    }

    private void applyAfkVisualsAndAntiPush(Player p, String tabPrefix, boolean enable) {
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        Team team = sb.getTeam(AFK_TEAM_NAME);
        if (team == null) {
            team = sb.registerNewTeam(AFK_TEAM_NAME);
        }
        team.prefix(ColorUtils.component(tabPrefix));
        if (plugin.getConfig().getBoolean("smart-afk.prevent-player-push", true)) {
            team.setOption(Team.Option.COLLISION_RULE, Team.OptionStatus.NEVER);
        }

        if (enable) {
            team.addEntry(p.getName());
            p.playerListName(ColorUtils.componentFor(p, tabPrefix + p.getName()));
        } else {
            team.removeEntry(p.getName());
            p.playerListName(null);
        }
    }

    private void markActive(Player p) {
        if (p == null) return;
        lastActivity.put(p.getUniqueId(), System.currentTimeMillis());
        if (afkPlayers.contains(p.getUniqueId())) {
            setAfk(p, false);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!plugin.getConfig().getBoolean("smart-afk.enabled", true)) return;

        Player attackerPlayer = resolvePlayerAttacker(event.getDamager());
        if (attackerPlayer != null && isAfk(attackerPlayer)) {
            markActive(attackerPlayer);
        }

        if (!(event.getEntity() instanceof Player victim)) return;
        if (!isAfk(victim)) return;

        if (attackerPlayer != null && !attackerPlayer.getUniqueId().equals(victim.getUniqueId())) {
            if (plugin.getConfig().getBoolean("smart-afk.protect-against-players", true)) {
                event.setCancelled(true);
                String prefix = plugin.getConfig().getString("general.prefix", "");
                attackerPlayer.sendMessage(ColorUtils.componentFor(attackerPlayer,
                        prefix + "&cلا يمكنك مهاجمة &#FFD166&l" + victim.getName() + " &cلأنه في وضع AFK حالياً!"));
                plugin.getSoundManager().play(attackerPlayer, "error");
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPotionSplash(PotionSplashEvent event) {
        if (!plugin.getConfig().getBoolean("smart-afk.protect-against-players", true)) return;
        ProjectileSource shooter = event.getPotion().getShooter();
        if (!(shooter instanceof Player thrower)) return;

        for (LivingEntity entity : event.getAffectedEntities()) {
            if (entity instanceof Player victim && isAfk(victim) && !victim.getUniqueId().equals(thrower.getUniqueId())) {
                event.setIntensity(victim, 0.0);
            }
        }
    }

    private Player resolvePlayerAttacker(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        if (damager instanceof AreaEffectCloud cloud && cloud.getSource() instanceof Player p) return p;
        if (damager instanceof TNTPrimed tnt && tnt.getSource() instanceof Player p) return p;
        return null;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        lastActivity.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player p = event.getPlayer();
        if (afkPlayers.remove(p.getUniqueId())) {
            Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
            Team team = sb.getTeam(AFK_TEAM_NAME);
            if (team != null) team.removeEntry(p.getName());
        }
        lastActivity.remove(p.getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) return;
        if (from.getBlockX() != to.getBlockX() || from.getBlockY() != to.getBlockY() || from.getBlockZ() != to.getBlockZ()
                || Math.abs(from.getYaw() - to.getYaw()) > 3.0f || Math.abs(from.getPitch() - to.getPitch()) > 3.0f) {
            markActive(event.getPlayer());
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) { markActive(event.getPlayer()); }

    @EventHandler
    public void onBreak(BlockBreakEvent event) { markActive(event.getPlayer()); }

    @EventHandler
    public void onPlace(BlockPlaceEvent event) { markActive(event.getPlayer()); }

    @EventHandler
    public void onChat(AsyncChatEvent event) {
        Bukkit.getScheduler().runTask(plugin, () -> markActive(event.getPlayer()));
    }

    private Particle parseParticle(String name, Particle def) {
        if (name == null) return def;
        try { return Particle.valueOf(name.toUpperCase()); } catch (Exception e) { return def; }
    }

    public void shutdown() {
        if (ticker != null) ticker.cancel();
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        Team team = sb.getTeam(AFK_TEAM_NAME);
        for (UUID id : new ArrayList<>(afkPlayers)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                p.playerListName(null);
                if (team != null) team.removeEntry(p.getName());
            }
        }
        afkPlayers.clear();
    }
}
