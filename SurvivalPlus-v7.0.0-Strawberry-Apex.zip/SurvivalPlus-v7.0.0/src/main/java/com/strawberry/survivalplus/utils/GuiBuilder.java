package com.strawberry.survivalplus.utils;

import com.strawberry.survivalplus.SurvivalPlus;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Collections;
import java.util.List;

public class GuiBuilder {

    public static Inventory create(Player viewer, StrawberryGuiHolder holder, int size, String title) {
        Inventory inv = Bukkit.createInventory(holder, size, ColorUtils.componentFor(viewer, title));
        holder.setInventory(inv);

        Material border = parseMaterial(SurvivalPlus.getInstance().getConfig().getString("gui.border-material"), Material.BLACK_STAINED_GLASS_PANE);
        Material filler = parseMaterial(SurvivalPlus.getInstance().getConfig().getString("gui.filler-material"), Material.PINK_STAINED_GLASS_PANE);
        Material accent = parseMaterial(SurvivalPlus.getInstance().getConfig().getString("gui.accent-material"), Material.MAGENTA_STAINED_GLASS_PANE);

        ItemStack borderItem = makeItem(viewer, border, " ", null);
        ItemStack fillerItem = makeItem(viewer, filler, " ", null);
        ItemStack accentItem = makeItem(viewer, accent, " ", null);

        int rows = size / 9;
        for (int i = 0; i < size; i++) {
            int r = i / 9;
            int c = i % 9;
            if ((r == 0 || r == rows - 1) && (c == 0 || c == 8)) {
                inv.setItem(i, accentItem);
            } else if (r == 0 || r == rows - 1 || c == 0 || c == 8) {
                inv.setItem(i, borderItem);
            } else {
                inv.setItem(i, fillerItem);
            }
        }
        return inv;
    }

    public static ItemStack makeItem(Player viewer, Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat != null ? mat : Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(ColorUtils.componentFor(viewer, name));
            if (lore != null && !lore.isEmpty()) {
                meta.lore(ColorUtils.loreFor(viewer, lore));
            }
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    public static ItemStack backButton(Player viewer) {
        return makeItem(viewer, Material.ARROW, "&#FF4D6D&l✦ رجوع للقائمة الرئيسية",
                Collections.singletonList("&7العودة إلى قائمة ستروبيري الرئيسية."));
    }

    public static Material parseMaterial(String name, Material fallback) {
        if (name == null) return fallback;
        try {
            return Material.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }
}
