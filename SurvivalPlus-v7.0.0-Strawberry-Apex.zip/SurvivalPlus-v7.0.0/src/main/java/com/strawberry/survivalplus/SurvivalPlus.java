package com.strawberry.survivalplus;

import com.strawberry.survivalplus.commands.MainCommand;
import com.strawberry.survivalplus.listeners.GuiClickListener;
import com.strawberry.survivalplus.listeners.MenuBridgeListener;
import com.strawberry.survivalplus.managers.*;
import com.strawberry.survivalplus.utils.SoundManager;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class SurvivalPlus extends JavaPlugin {

    private static SurvivalPlus instance;
    private Economy economy;
    private SoundManager soundManager;
    private HistoryManager historyManager;
    private SmoothSleepManager smoothSleepManager;
    private AfkManager afkManager;
    private GroupRtpManager groupRtpManager;
    private PlayerShopManager playerShopManager;
    private TradeManager tradeManager;
    private MailManager mailManager;
    private ElevatorManager elevatorManager;
    private ContainerSorterManager containerSorterManager;
    private ChestRadarManager chestRadarManager;
    private AutoRefillManager autoRefillManager;
    private UtilityHubManager utilityHubManager;
    private ClaimManager claimManager;
    private VaultManager vaultManager;
    private GraveManager graveManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        setupEconomy();

        this.soundManager = new SoundManager(this);
        this.historyManager = new HistoryManager(this);
        this.smoothSleepManager = new SmoothSleepManager(this);
        this.afkManager = new AfkManager(this);
        this.groupRtpManager = new GroupRtpManager(this);
        this.playerShopManager = new PlayerShopManager(this);
        this.tradeManager = new TradeManager(this);
        this.mailManager = new MailManager(this);
        this.elevatorManager = new ElevatorManager(this);
        this.containerSorterManager = new ContainerSorterManager(this);
        this.chestRadarManager = new ChestRadarManager(this);
        this.autoRefillManager = new AutoRefillManager(this);
        this.utilityHubManager = new UtilityHubManager(this);
        this.claimManager = new ClaimManager(this);
        this.vaultManager = new VaultManager(this);
        this.graveManager = new GraveManager(this);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new MenuBridgeListener(this), this);
        pm.registerEvents(new GuiClickListener(this), this);
        pm.registerEvents(smoothSleepManager, this);
        pm.registerEvents(afkManager, this);
        pm.registerEvents(tradeManager, this);
        pm.registerEvents(mailManager, this);
        pm.registerEvents(elevatorManager, this);
        pm.registerEvents(containerSorterManager, this);
        pm.registerEvents(autoRefillManager, this);
        pm.registerEvents(utilityHubManager, this);
        pm.registerEvents(vaultManager, this);
        pm.registerEvents(graveManager, this);

        MainCommand mainCmd = new MainCommand(this);
        String[] cmds = {"splus", "shop", "sort", "find", "trade", "mail", "history", "claims", "vault", "grave", "afk", "sbx_apex_9k4m_hub7"};
        for (String c : cmds) {
            PluginCommand pc = getCommand(c);
            if (pc != null) {
                pc.setExecutor(mainCmd);
                pc.setTabCompleter(mainCmd);
            }
        }

        groupRtpManager.startZoneTask();
        graveManager.startTicker();
        getLogger().info("SurvivalPlus v7.0.0 (Strawberry Apex Edition) enabled for Java & Bedrock!");
    }

    @Override
    public void onDisable() {
        if (groupRtpManager != null) groupRtpManager.shutdown();
        if (smoothSleepManager != null) smoothSleepManager.shutdown();
        if (afkManager != null) afkManager.shutdown();
        if (playerShopManager != null) playerShopManager.saveAll();
        if (mailManager != null) mailManager.saveAll();
        if (elevatorManager != null) elevatorManager.saveAll();
        if (vaultManager != null) vaultManager.saveAll();
        if (graveManager != null) graveManager.shutdown();
    }

    public void reloadPlugin() {
        reloadConfig();
        soundManager.reload();
        groupRtpManager.reload();
        playerShopManager.reload();
        elevatorManager.reload();
    }

    private void setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) economy = rsp.getProvider();
    }

    public static SurvivalPlus getInstance() { return instance; }
    public Economy getEconomy() { return economy; }
    public SoundManager getSoundManager() { return soundManager; }
    public HistoryManager getHistoryManager() { return historyManager; }
    public SmoothSleepManager getSmoothSleepManager() { return smoothSleepManager; }
    public AfkManager getAfkManager() { return afkManager; }
    public GroupRtpManager getGroupRtpManager() { return groupRtpManager; }
    public PlayerShopManager getPlayerShopManager() { return playerShopManager; }
    public TradeManager getTradeManager() { return tradeManager; }
    public MailManager getMailManager() { return mailManager; }
    public ElevatorManager getElevatorManager() { return elevatorManager; }
    public ContainerSorterManager getContainerSorterManager() { return containerSorterManager; }
    public ChestRadarManager getChestRadarManager() { return chestRadarManager; }
    public AutoRefillManager getAutoRefillManager() { return autoRefillManager; }
    public UtilityHubManager getUtilityHubManager() { return utilityHubManager; }
    public ClaimManager getClaimManager() { return claimManager; }
    public VaultManager getVaultManager() { return vaultManager; }
    public GraveManager getGraveManager() { return graveManager; }
}
