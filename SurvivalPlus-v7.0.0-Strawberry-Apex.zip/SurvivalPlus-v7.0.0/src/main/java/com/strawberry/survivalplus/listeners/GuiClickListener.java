package com.strawberry.survivalplus.listeners;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public class GuiClickListener implements Listener {

    private final SurvivalPlus plugin;

    public GuiClickListener(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onGuiClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getView().getTopInventory().getHolder() instanceof StrawberryGuiHolder holder)) return;

        if (holder.getType() == StrawberryGuiHolder.GuiType.VAULT_STORAGE) return;

        if (holder.getType() == StrawberryGuiHolder.GuiType.UTILITY_TRASH) {
            int raw = event.getRawSlot();
            if (raw >= 27 && raw < 36) {
                event.setCancelled(true);
                plugin.getUtilityHubManager().handleTrashBarClick(player, event.getView().getTopInventory(), raw);
            }
            return;
        }

        if (holder.getType() == StrawberryGuiHolder.GuiType.SAFE_TRADE) {
            event.setCancelled(true);
            plugin.getTradeManager().handleTradeClick(player, event.getRawSlot(), event.getClick().isRightClick(), event.getCurrentItem());
            return;
        }

        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
            return;
        }

        int slot = event.getRawSlot();
        switch (holder.getType()) {
            case SHOP_DIRECTORY -> plugin.getPlayerShopManager().handleDirectoryClick(player, holder, slot);
            case SHOP_VIEW -> plugin.getPlayerShopManager().handleShopViewClick(player, holder, slot, event.getClick());
            case SHOP_MANAGE -> plugin.getPlayerShopManager().handleManageClick(player, holder, slot, event.getClick());
            case SHOP_ANALYTICS -> plugin.getPlayerShopManager().handleAnalyticsClick(player, slot);
            case SHOP_UPGRADES -> plugin.getPlayerShopManager().handleUpgradesClick(player, holder, slot);
            case SHOP_RATE -> plugin.getPlayerShopManager().handleRateClick(player, holder, slot);
            case CLAIM_HUB -> plugin.getClaimManager().handleHubClick(player, slot);
            case CLAIM_BLOCKS_SHOP -> plugin.getClaimManager().handleBlockShopClick(player, holder, slot);
            case VAULT_SELECTOR -> plugin.getVaultManager().handleSelectorClick(player, holder, slot, event.getClick());
            case VAULT_ICON_PICKER -> plugin.getVaultManager().handleIconPickerClick(player, holder, slot);
            case GRAVES_LIST -> plugin.getGraveManager().handleListClick(player, holder, slot);
            case GRAVE_PREVIEW -> plugin.getGraveManager().handlePreviewClick(player, holder, slot);
            case HISTORY_LEDGER -> plugin.getHistoryManager().handleClick(player, holder, slot);
            case MAIL_INBOX -> plugin.getMailManager().handleInboxClick(player, holder, slot);
            case MAIL_CONFIRM_COD -> plugin.getMailManager().handleCodClick(player, holder, slot);
            case ELEVATOR_CONTROL -> plugin.getElevatorManager().handleControlClick(player, holder, slot);
            case ELEVATOR_DIRECTORY -> plugin.getElevatorManager().handleDirectoryClick(player, holder, slot);
            case ELEVATOR_PRESETS -> plugin.getElevatorManager().handlePresetsClick(player, holder, slot);
            case CONTAINER_SORTER -> plugin.getContainerSorterManager().handleClick(player, slot);
            case RADAR_PICKER -> plugin.getChestRadarManager().handlePickerClick(player, holder, slot);
            case RADAR_RESULTS -> plugin.getChestRadarManager().handleResultsClick(player, slot);
            case UTILITY_HUB -> plugin.getUtilityHubManager().handleHubClick(player, holder, slot);
            default -> {}
        }
    }

    @EventHandler
    public void onGuiDrag(InventoryDragEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof StrawberryGuiHolder holder)) return;
        if (holder.getType() == StrawberryGuiHolder.GuiType.VAULT_STORAGE) return;
        if (holder.getType() == StrawberryGuiHolder.GuiType.UTILITY_TRASH) {
            for (int raw : event.getRawSlots()) {
                if (raw >= 27 && raw < 36) {
                    event.setCancelled(true);
                    return;
                }
            }
            return;
        }
        event.setCancelled(true);
    }
}
