package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ColorUtils;
import com.strawberry.survivalplus.utils.GuiBuilder;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class UtilityHubManager implements Listener {

    private static class TrashBackup {
        final List<ItemStack> items;
        final long expiresAt;

        TrashBackup(List<ItemStack> items, long expiresAt) {
            this.items = items;
            this.expiresAt = expiresAt;
        }
    }

    private final SurvivalPlus plugin;
    private final Map<UUID, TrashBackup> undoBuffers = new HashMap<>();

    public UtilityHubManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    public void openHubWithFee(Player player) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (!plugin.getConfig().getBoolean("utility-hub.enabled", true)) {
            player.sendMessage(ColorUtils.componentFor(player, prefix + "&cمحطة الأدوات السحابية معطلة حالياً."));
            return;
        }

        double openCost = plugin.getConfig().getDouble("utility-hub.open-cost", 150.0);
        if (openCost > 0 && !player.hasPermission("survivalplus.utility.free") && plugin.getEconomy() != null) {
            if (!plugin.getEconomy().has(player, openCost)) {
                player.sendMessage(ColorUtils.componentFor(player, prefix + "&cتحتاج إلى &#FFD166&l" + openCost + "$ &cلفتح محطة الأدوات السحابية!"));
                plugin.getSoundManager().play(player, "error");
                return;
            }
            plugin.getEconomy().withdrawPlayer(player, openCost);
            player.sendMessage(ColorUtils.componentFor(player, prefix + "&#06D6A0&l✔ تم فتح محطة الأدوات السحابية &7(رسم الدخول: &#FFD166&l" + openCost + "$&7)"));
        }

        openHubGui(player);
    }

    public void openHubGui(Player player) {
        String title = plugin.getConfig().getString("utility-hub.gui-title", "محطة الأدوات السحابية");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.UTILITY_HUB);
        Inventory inv = GuiBuilder.create(player, holder, 36, title);

        ConfigurationSection stations = plugin.getConfig().getConfigurationSection("utility-hub.stations");
        if (stations != null) {
            for (String key : stations.getKeys(false)) {
                ConfigurationSection s = stations.getConfigurationSection(key);
                if (s == null || !s.getBoolean("enabled", true)) continue;

                int slot = s.getInt("slot", 10);
                double cost = s.getDouble("cost", 0.0);
                String perm = s.getString("permission", "");
                String name = s.getString("name", key);
                Material icon = GuiBuilder.parseMaterial(s.getString("icon"), Material.CRAFTING_TABLE);

                boolean hasPerm = perm.isEmpty() || player.hasPermission(perm) || player.hasPermission("survivalplus.admin");
                boolean isFree = cost <= 0 || player.hasPermission("survivalplus.utility.free");

                List<String> lore = new ArrayList<>();
                lore.add("&#FFB3C1&l━━━━━━━━━━━━━━━━━━");
                lore.add("&7التكلفة: " + (isFree ? "&#06D6A0&lمجاني ✔" : "&#FFD166&l" + cost + "$"));
                if (!hasPerm) {
                    lore.add("&c🔒 مقفل — يتطلب صلاحية خاصة.");
                } else {
                    lore.add("&#FF758F&l» &f&lاضغط للفتح الفوري");
                }
                lore.add("&#FFB3C1&l━━━━━━━━━━━━━━━━━━");

                holder.with("station_" + slot, key);
                inv.setItem(slot, GuiBuilder.makeItem(player, hasPerm ? icon : Material.BARRIER, name, lore));
            }
        }

        inv.setItem(27, GuiBuilder.backButton(player));
        player.openInventory(inv);
        plugin.getSoundManager().play(player, "open-gui");
    }

    public void handleHubClick(Player player, StrawberryGuiHolder holder, int slot) {
        if (slot == 27) {
            String cmd = plugin.getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                    .replace("%player%", player.getName());
            player.closeInventory();
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            return;
        }

        Object keyObj = holder.get("station_" + slot);
        if (keyObj == null) return;
        String key = keyObj.toString();

        ConfigurationSection s = plugin.getConfig().getConfigurationSection("utility-hub.stations." + key);
        if (s == null || !s.getBoolean("enabled", true)) return;

        String prefix = plugin.getConfig().getString("general.prefix", "");
        String perm = s.getString("permission", "");
        if (!perm.isEmpty() && !player.hasPermission(perm) && !player.hasPermission("survivalplus.admin")) {
            player.sendMessage(ColorUtils.componentFor(player, prefix + "&cلا تملك صلاحية استخدام هذه المحطة!"));
            plugin.getSoundManager().play(player, "error");
            return;
        }

        double cost = s.getDouble("cost", 0.0);
        if (cost > 0 && !player.hasPermission("survivalplus.utility.free") && plugin.getEconomy() != null) {
            if (!plugin.getEconomy().has(player, cost)) {
                player.sendMessage(ColorUtils.componentFor(player, prefix + "&cرصيدك غير كافٍ! المطلوب: &#FFD166&l" + cost + "$"));
                plugin.getSoundManager().play(player, "error");
                return;
            }
            plugin.getEconomy().withdrawPlayer(player, cost);
        }

        openStation(player, key);
    }

    @SuppressWarnings("deprecation")
    private void openStation(Player player, String key) {
        plugin.getSoundManager().play(player, "click");
        switch (key.toLowerCase()) {
            case "crafting" -> player.openWorkbench(null, true);
            case "anvil" -> player.openAnvil(null, true);
            case "enderchest" -> player.openInventory(player.getEnderChest());
            case "grindstone" -> player.openGrindstone(null, true);
            case "smithing" -> player.openSmithingTable(null, true);
            case "stonecutter" -> player.openStonecutter(null, true);
            case "loom" -> player.openLoom(null, true);
            case "cartography" -> player.openCartographyTable(null, true);
            case "trash" -> openSafeTrashGui(player);
        }
    }

    public void openSafeTrashGui(Player player) {
        String title = plugin.getConfig().getString("utility-hub.trash-title", "سلة المهملات الآمنة");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.UTILITY_TRASH);
        Inventory inv = Bukkit.createInventory(holder, 36, ColorUtils.componentFor(player, title));
        holder.setInventory(inv);

        ItemStack bar = GuiBuilder.makeItem(player, Material.BLACK_STAINED_GLASS_PANE, " ", null);
        for (int i = 27; i < 36; i++) inv.setItem(i, bar);

        inv.setItem(27, GuiBuilder.makeItem(player, Material.ARROW, "&#FF4D6D&l« رجوع لمحطة الأدوات",
                Collections.singletonList("&7أي أغراض لم تؤكد حذفها ستعود لحقيبتك بأمان.")));

        TrashBackup backup = getValidBackup(player.getUniqueId());
        if (backup != null) {
            long remSec = Math.max(1, (backup.expiresAt - System.currentTimeMillis()) / 1000L);
            inv.setItem(30, GuiBuilder.makeItem(player, Material.TOTEM_OF_UNDYING,
                    "&#FFD166&l↺ استرجاع آخر محذوفات (" + backup.items.size() + " غرض)",
                    Arrays.asList("&7الوقت المتبقي للاسترجاع: &#06D6A0&l" + remSec + "ث", "&7اضغط لإعادة كل ما حذفته مؤخراً لحقيبتك!")));
        } else {
            inv.setItem(30, GuiBuilder.makeItem(player, Material.GRAY_DYE, "&7لا توجد محذوفات قابلة للاسترجاع", null));
        }

        inv.setItem(32, GuiBuilder.makeItem(player, Material.LIME_CONCRETE, "&#06D6A0&l✔ تأكيد تفريغ السلة",
                Arrays.asList(
                        "&7ضع الأغراض في الصفوف الـ 3 العلوية",
                        "&7ثم اضغط هنا للحذف (يمكنك التراجع خلال " + plugin.getConfig().getInt("utility-hub.trash-undo-seconds", 60) + "ث)."
                )));

        player.openInventory(inv);
        plugin.getSoundManager().play(player, "open-gui");
    }

    public void handleTrashBarClick(Player player, Inventory topInv, int slot) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (slot == 27) {
            returnTrashContents(player, topInv);
            openHubGui(player);
            return;
        }
        if (slot == 30) {
            TrashBackup backup = getValidBackup(player.getUniqueId());
            if (backup == null) return;
            undoBuffers.remove(player.getUniqueId());
            for (ItemStack it : backup.items) {
                HashMap<Integer, ItemStack> left = player.getInventory().addItem(it);
                left.values().forEach(rem -> player.getWorld().dropItemNaturally(player.getLocation(), rem));
            }
            player.sendMessage(ColorUtils.componentFor(player, prefix + "&#06D6A0&l✔ تم استرجاع &#FFD166&l" + backup.items.size() + " &aغرض من سلة المهملات بنجاح!"));
            plugin.getSoundManager().play(player, "success");
            openSafeTrashGui(player);
            return;
        }
        if (slot == 32) {
            List<ItemStack> trashed = new ArrayList<>();
            for (int i = 0; i < 27; i++) {
                ItemStack it = topInv.getItem(i);
                if (it != null && !it.getType().isAir()) {
                    trashed.add(it.clone());
                    topInv.setItem(i, null);
                }
            }
            if (trashed.isEmpty()) {
                player.sendMessage(ColorUtils.componentFor(player, prefix + "&eالسلة فارغة! ضع الأغراض في الصفوف العلوية أولاً."));
                plugin.getSoundManager().play(player, "error");
                return;
            }
            int undoSec = plugin.getConfig().getInt("utility-hub.trash-undo-seconds", 60);
            undoBuffers.put(player.getUniqueId(), new TrashBackup(trashed, System.currentTimeMillis() + (undoSec * 1000L)));
            player.sendMessage(ColorUtils.componentFor(player, prefix + "&#FF758F&l✦ تم تفريغ " + trashed.size()
                    + " غرض! يمكنك استرجاعها خلال &#FFD166&l" + undoSec + " ثانية &7من زر الاسترجاع."));
            plugin.getSoundManager().play(player, "success");
            openSafeTrashGui(player);
        }
    }

    @EventHandler
    public void onTrashClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (!(event.getInventory().getHolder() instanceof StrawberryGuiHolder holder)) return;
        if (holder.getType() != StrawberryGuiHolder.GuiType.UTILITY_TRASH) return;
        returnTrashContents(player, event.getInventory());
    }

    private void returnTrashContents(Player player, Inventory inv) {
        for (int i = 0; i < 27; i++) {
            ItemStack it = inv.getItem(i);
            if (it != null && !it.getType().isAir()) {
                inv.setItem(i, null);
                HashMap<Integer, ItemStack> left = player.getInventory().addItem(it);
                left.values().forEach(rem -> player.getWorld().dropItemNaturally(player.getLocation(), rem));
            }
        }
    }

    private TrashBackup getValidBackup(UUID id) {
        TrashBackup b = undoBuffers.get(id);
        if (b == null) return null;
        if (b.expiresAt <= System.currentTimeMillis()) {
            undoBuffers.remove(id);
            return null;
        }
        return b;
    }
}
