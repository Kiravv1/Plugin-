package com.strawberry.survivalplus.utils;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class StrawberryGuiHolder implements InventoryHolder {

    public enum GuiType {
        SHOP_DIRECTORY,
        SHOP_VIEW,
        SHOP_MANAGE,
        SHOP_ANALYTICS,
        SHOP_UPGRADES,
        SHOP_RATE,
        CLAIM_HUB,
        CLAIM_BLOCKS_SHOP,
        VAULT_SELECTOR,
        VAULT_ICON_PICKER,
        VAULT_STORAGE,
        GRAVES_LIST,
        GRAVE_PREVIEW,
        HISTORY_LEDGER,
        SAFE_TRADE,
        MAIL_INBOX,
        MAIL_CONFIRM_COD,
        ELEVATOR_CONTROL,
        ELEVATOR_DIRECTORY,
        ELEVATOR_PRESETS,
        CONTAINER_SORTER,
        RADAR_PICKER,
        RADAR_RESULTS,
        UTILITY_HUB,
        UTILITY_TRASH
    }

    private final GuiType type;
    private final Map<String, Object> data = new HashMap<>();
    private Inventory inventory;

    public StrawberryGuiHolder(GuiType type) {
        this.type = type;
    }

    public GuiType getType() {
        return type;
    }

    public StrawberryGuiHolder with(String key, Object value) {
        data.put(key, value);
        return this;
    }

    public Object get(String key) {
        return data.get(key);
    }

    public int getInt(String key, int def) {
        Object v = data.get(key);
        return v instanceof Number n ? n.intValue() : def;
    }

    public String getString(String key, String def) {
        Object v = data.get(key);
        return v != null ? v.toString() : def;
    }

    public boolean getBool(String key, boolean def) {
        Object v = data.get(key);
        return v instanceof Boolean b ? b : def;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}
