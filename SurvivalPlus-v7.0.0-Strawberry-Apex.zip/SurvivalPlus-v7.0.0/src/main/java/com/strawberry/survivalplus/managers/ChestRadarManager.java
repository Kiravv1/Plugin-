package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ClaimTrustHelper;
import com.strawberry.survivalplus.utils.ColorUtils;
import com.strawberry.survivalplus.utils.GuiBuilder;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import org.bukkit.*;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

public class ChestRadarManager {

    public static class RadarMatch {
        public final Location location;
        public final Material containerType;
        public final int amount;
        public final double distance;

        public RadarMatch(Location location, Material containerType, int amount, double distance) {
            this.location = location;
            this.containerType = containerType;
            this.amount = amount;
            this.distance = distance;
        }
    }

    private final SurvivalPlus plugin;

    public ChestRadarManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    public void openQuickSearchGui(Player p) {
        String title = plugin.getConfig().getString("chest-radar.gui-title", "رادار المخازن");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.RADAR_PICKER);
        Inventory inv = GuiBuilder.create(p, holder, 45, title);

        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!hand.getType().isAir()) {
            holder.with("search_13", hand.getType().name());
            inv.setItem(13, GuiBuilder.makeItem(p, hand.getType(),
                    "&#06D6A0&l✦ البحث عن الغرض في يدك: &f&l" + hand.getType().name(),
                    Collections.singletonList("&7يفحص فقط صناديق أرضك والأراضي الموثوق بك فيها.")));
        } else {
            inv.setItem(13, GuiBuilder.makeItem(p, Material.SPYGLASS, "&#48CAE4&l✦ امسك غرضاً للبحث عنه فوراً",
                    Collections.singletonList("&7أو اختر من الموارد الشائعة بالأسفل أو اكتب &e/find <الاسم>")));
        }

        Material[] popular = {
                Material.DIAMOND, Material.IRON_INGOT, Material.GOLD_INGOT, Material.EMERALD,
                Material.NETHERITE_INGOT, Material.REDSTONE, Material.QUARTZ, Material.COAL,
                Material.OAK_LOG, Material.COBBLESTONE, Material.ENDER_PEARL, Material.EXPERIENCE_BOTTLE,
                Material.ENCHANTED_BOOK, Material.TOTEM_OF_UNDYING
        };
        int[] slots = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        for (int i = 0; i < popular.length && i < slots.length; i++) {
            holder.with("search_" + slots[i], popular[i].name());
            inv.setItem(slots[i], GuiBuilder.makeItem(p, popular[i], "&#FFD166&l✦ بحث عن: &f" + popular[i].name(),
                    Collections.singletonList("&7اضغط لتحديد الصناديق بشعاع جزيئات مضيء!")));
        }

        inv.setItem(36, GuiBuilder.backButton(p));
        p.openInventory(inv);
        plugin.getSoundManager().play(p, "open-gui");
    }

    public void searchByQuery(Player p, String query) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (!plugin.getConfig().getBoolean("chest-radar.enabled", true)) return;

        Material exact = Material.matchMaterial(query.trim().toUpperCase().replace(" ", "_"));
        String lowerQ = query.trim().toLowerCase().replace(" ", "_");

        int radius = plugin.getConfig().getInt("chest-radar.radius", 32);
        int maxScan = plugin.getConfig().getInt("chest-radar.max-containers-scanned", 250);
        boolean mustBeClaimedTrusted = plugin.getConfig().getBoolean("chest-radar.require-claim-owner-or-trust", true);

        Location pLoc = p.getLocation();
        World w = pLoc.getWorld();
        if (w == null) return;

        int minCx = (pLoc.getBlockX() - radius) >> 4;
        int maxCx = (pLoc.getBlockX() + radius) >> 4;
        int minCz = (pLoc.getBlockZ() - radius) >> 4;
        int maxCz = (pLoc.getBlockZ() + radius) >> 4;

        List<RadarMatch> matches = new ArrayList<>();
        int scanned = 0;
        int blockedByClaim = 0;

        outer:
        for (int cx = minCx; cx <= maxCx; cx++) {
            for (int cz = minCz; cz <= maxCz; cz++) {
                if (!w.isChunkLoaded(cx, cz)) continue;
                for (BlockState tile : w.getChunkAt(cx, cz).getTileEntities()) {
                    if (!(tile instanceof Container container)) continue;
                    Location cLoc = tile.getLocation();
                    double dist = cLoc.distance(pLoc);
                    if (dist > radius) continue;

                    scanned++;
                    if (scanned > maxScan) break outer;

                    if (!ClaimTrustHelper.canAccessContainer(p, cLoc, mustBeClaimedTrusted)) {
                        blockedByClaim++;
                        continue;
                    }

                    int foundAmt = 0;
                    for (ItemStack it : container.getInventory().getContents()) {
                        if (it == null || it.getType().isAir()) continue;
                        boolean isMatch = (exact != null)
                                ? it.getType() == exact
                                : it.getType().name().toLowerCase().contains(lowerQ);
                        if (isMatch) foundAmt += it.getAmount();
                    }

                    if (foundAmt > 0) {
                        matches.add(new RadarMatch(cLoc, tile.getType(), foundAmt, dist));
                    }
                }
            }
        }

        if (matches.isEmpty()) {
            if (blockedByClaim > 0 && mustBeClaimedTrusted) {
                p.sendMessage(ColorUtils.componentFor(p, prefix + "&cلم يُعثر على الغرض داخل أراضيك! &7(الرادار مقفول أمنياً على أراضيك والأراضي الموثوق بك فيها فقط)."));
            } else {
                p.sendMessage(ColorUtils.componentFor(p, prefix + "&eلم يُعثر على &f&l" + query + " &eفي الصناديق المسموح لك بها ضمن " + radius + " بلوكة."));
            }
            plugin.getSoundManager().play(p, "error");
            return;
        }

        matches.sort(Comparator.comparingDouble(m -> m.distance));
        int totalItems = matches.stream().mapToInt(m -> m.amount).sum();

        p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ وجد الرادار &#FFD166&l" + totalItems
                + "x " + (exact != null ? exact.name() : query) + " &aفي &#48CAE4&l" + matches.size() + " &aصندوق! اتبع الأشعة المضيئة."));
        plugin.getSoundManager().play(p, "radar-ping");

        spawnRadarBeams(p, matches);
        openResultsGui(p, exact != null ? exact.name() : query, matches);
    }

    private void openResultsGui(Player p, String label, List<RadarMatch> matches) {
        String title = plugin.getConfig().getString("chest-radar.results-title", "نتائج البحث: %item%")
                .replace("%item%", label);
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.RADAR_RESULTS);
        Inventory inv = GuiBuilder.create(p, holder, 45, title);

        int[] slots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34};
        for (int i = 0; i < matches.size() && i < slots.length; i++) {
            RadarMatch m = matches.get(i);
            inv.setItem(slots[i], GuiBuilder.makeItem(p, m.containerType,
                    "&#48CAE4&l✦ " + m.containerType.name() + " &8(#" + (i + 1) + ")",
                    Arrays.asList(
                            "&#FFB3C1&l━━━━━━━━━━━━━━━━━━",
                            "&7الكمية الموجودة: &#06D6A0&l" + m.amount + " قطعة",
                            "&7المسافة: &#FFD166&l" + Math.round(m.distance) + " بلوكة",
                            "&7الإحداثيات: &fX:" + m.location.getBlockX() + " Y:" + m.location.getBlockY() + " Z:" + m.location.getBlockZ(),
                            "&#FFB3C1&l━━━━━━━━━━━━━━━━━━"
                    )));
        }

        inv.setItem(36, GuiBuilder.makeItem(p, Material.ARROW, "&#FF4D6D&l« بحث جديد", null));
        p.openInventory(inv);
    }

    private void spawnRadarBeams(Player p, List<RadarMatch> matches) {
        int durationSec = plugin.getConfig().getInt("chest-radar.beam-duration-seconds", 12);
        Particle beamP = parseParticle(plugin.getConfig().getString("chest-radar.beam-particle"), Particle.END_ROD);
        Particle hiP = parseParticle(plugin.getConfig().getString("chest-radar.highlight-particle"), Particle.CHERRY_LEAVES);

        List<RadarMatch> topMatches = matches.subList(0, Math.min(8, matches.size()));
        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!p.isOnline() || ticks >= durationSec * 2) { cancel(); return; }
                Location eye = p.getEyeLocation().clone().add(0, -0.35, 0);
                for (RadarMatch m : topMatches) {
                    Location target = m.location.clone().add(0.5, 0.7, 0.5);
                    if (!eye.getWorld().equals(target.getWorld())) continue;
                    p.spawnParticle(hiP, target.clone().add(0, 0.5, 0), 6, 0.25, 0.25, 0.25, 0.01);

                    Vector dir = target.toVector().subtract(eye.toVector());
                    double len = dir.length();
                    if (len < 1.0) continue;
                    dir.normalize();
                    for (double d = 1.5; d < len; d += 1.4) {
                        Location pt = eye.clone().add(dir.clone().multiply(d));
                        p.spawnParticle(beamP, pt, 1, 0, 0, 0, 0);
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 10L);
    }

    public void handlePickerClick(Player p, StrawberryGuiHolder holder, int slot) {
        if (slot == 36) {
            String cmd = plugin.getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                    .replace("%player%", p.getName());
            p.closeInventory();
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            return;
        }
        Object mat = holder.get("search_" + slot);
        if (mat != null) {
            p.closeInventory();
            searchByQuery(p, mat.toString());
        }
    }

    public void handleResultsClick(Player p, int slot) {
        if (slot == 36) openQuickSearchGui(p);
    }

    private Particle parseParticle(String name, Particle def) {
        if (name == null) return def;
        try { return Particle.valueOf(name.toUpperCase()); } catch (Exception e) { return def; }
    }
}
