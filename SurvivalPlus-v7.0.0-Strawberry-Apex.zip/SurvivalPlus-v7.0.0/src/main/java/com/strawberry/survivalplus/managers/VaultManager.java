package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ColorUtils;
import com.strawberry.survivalplus.utils.GuiBuilder;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class VaultManager implements Listener {

    private final SurvivalPlus plugin;
    private final File vaultsDir;
    private final Set<UUID> iconEditMode = new HashSet<>();

    public VaultManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.vaultsDir = new File(plugin.getDataFolder(), "vaults");
        if (!vaultsDir.exists()) vaultsDir.mkdirs();
    }

    public void saveAll() {}

    private File getPlayerFile(UUID id) {
        return new File(vaultsDir, id.toString() + ".yml");
    }

    private YamlConfiguration loadPlayerConfig(UUID id) {
        return YamlConfiguration.loadConfiguration(getPlayerFile(id));
    }

    private void savePlayerConfig(UUID id, YamlConfiguration cfg) {
        if (!vaultsDir.exists()) vaultsDir.mkdirs();
        try {
            cfg.save(getPlayerFile(id));
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save vault for " + id + ": " + e.getMessage());
        }
    }

    public int getUnlockedCount(UUID id) {
        int def = plugin.getConfig().getInt("vaults.default-vaults", 2);
        return Math.max(def, loadPlayerConfig(id).getInt("unlocked", def));
    }

    public void openVaultSelector(Player player) {
        String title = plugin.getConfig().getString("vaults.gui-title", "الخزائن السحابية");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.VAULT_SELECTOR);
        Inventory inv = GuiBuilder.create(player, holder, 36, title);

        int max = plugin.getConfig().getInt("vaults.max-vaults", 5);
        int unlocked = getUnlockedCount(player.getUniqueId());
        double unlockCost = plugin.getConfig().getDouble("vaults.unlock-cost-per-vault", 3000.0);
        YamlConfiguration cfg = loadPlayerConfig(player.getUniqueId());
        boolean editingIcon = iconEditMode.contains(player.getUniqueId());

        int startSlot = 11;
        for (int i = 1; i <= max && (startSlot + i - 1) <= 15; i++) {
            int slot = startSlot + i - 1;
            holder.with("vault_" + slot, i);
            if (i <= unlocked) {
                Material icon = GuiBuilder.parseMaterial(cfg.getString("icons." + i), Material.ENDER_CHEST);
                inv.setItem(slot, GuiBuilder.makeItem(player, icon, "&#C77DFF&l✦ خزنتك السحابية &#FFD166&l#" + i,
                        Arrays.asList(
                                "&#06D6A0&l✔ مفتوحة ومتاحة من أي مكان",
                                editingIcon ? "&#FFD166&l» اضغط لتغيير أيقونة هذه الخزنة!" : "&7اضغط لفتح الخزنة وتخزين أغراضك.",
                                "&7(كليك يمين لتغيير الأيقونة)"
                        )));
            } else {
                inv.setItem(slot, GuiBuilder.makeItem(player, Material.RED_STAINED_GLASS_PANE, "&c&l🔒 خزنة مقفلة #" + i,
                        Arrays.asList(
                                "&7افتح خزنة سحابية إضافية بـ 54 خانة!",
                                "&7تكلفة الفتح: &#FFD166&l" + unlockCost + "$",
                                "",
                                "&#06D6A0&l» اضغط للشراء والفتح"
                        )));
            }
        }

        if (plugin.getConfig().getBoolean("vaults.allow-custom-icons", true)) {
            inv.setItem(31, GuiBuilder.makeItem(player,
                    editingIcon ? Material.NAME_TAG : Material.PAINTING,
                    editingIcon ? "&#FFD166&l✦ وضع تخصيص الأيقونات: مفعل" : "&#FF758F&l✦ تخصيص أيقونة خزنة (Bedrock)",
                    Arrays.asList("&7اضغط هنا ثم اضغط على أي خزنة مفتوحة", "&7لتغيير شكل أيقونتها بسهولة على الجوال!")));
        }

        inv.setItem(27, GuiBuilder.backButton(player));
        player.openInventory(inv);
        plugin.getSoundManager().play(player, "open-gui");
    }

    public void openVaultStorage(Player player, int vaultNum) {
        int size = plugin.getConfig().getInt("vaults.vault-size", 54);
        String title = plugin.getConfig().getString("vaults.vault-title", "خزنتك #%num%")
                .replace("%num%", String.valueOf(vaultNum));
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.VAULT_STORAGE)
                .with("vault_num", vaultNum);
        Inventory inv = Bukkit.createInventory(holder, size, ColorUtils.componentFor(player, title));
        holder.setInventory(inv);

        YamlConfiguration cfg = loadPlayerConfig(player.getUniqueId());
        List<?> raw = cfg.getList("storage." + vaultNum);
        if (raw != null) {
            for (int i = 0; i < raw.size() && i < size; i++) {
                if (raw.get(i) instanceof ItemStack item) inv.setItem(i, item);
            }
        }

        player.openInventory(inv);
        plugin.getSoundManager().play(player, "open-gui");
    }

    public void openIconPicker(Player player, int vaultNum) {
        String title = plugin.getConfig().getString("vaults.icon-picker-title", "اختر أيقونة #%num%")
                .replace("%num%", String.valueOf(vaultNum));
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.VAULT_ICON_PICKER)
                .with("vault_num", vaultNum);
        Inventory inv = GuiBuilder.create(player, holder, 27, title);

        List<String> icons = plugin.getConfig().getStringList("vaults.custom-icon-options");
        int[] slots = {10, 11, 12, 13, 14, 15, 16};
        for (int i = 0; i < icons.size() && i < slots.length; i++) {
            Material m = GuiBuilder.parseMaterial(icons.get(i), Material.ENDER_CHEST);
            holder.with("icon_" + slots[i], m.name());
            inv.setItem(slots[i], GuiBuilder.makeItem(player, m, "&#FFD166&l✦ اختيار: &f" + m.name(),
                    Collections.singletonList("&7اضغط لتعيينها أيقونة لخزنتك #" + vaultNum)));
        }

        inv.setItem(18, GuiBuilder.makeItem(player, Material.ARROW, "&#FF4D6D&l« رجوع", null));
        player.openInventory(inv);
        plugin.getSoundManager().play(player, "click");
    }

    public void handleSelectorClick(Player p, StrawberryGuiHolder holder, int slot, ClickType clickType) {
        if (slot == 27) {
            String cmd = plugin.getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                    .replace("%player%", p.getName());
            p.closeInventory();
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            return;
        }
        if (slot == 31) {
            if (iconEditMode.contains(p.getUniqueId())) iconEditMode.remove(p.getUniqueId());
            else iconEditMode.add(p.getUniqueId());
            plugin.getSoundManager().play(p, "click");
            openVaultSelector(p);
            return;
        }

        Object vObj = holder.get("vault_" + slot);
        if (!(vObj instanceof Integer vaultNum)) return;

        int unlocked = getUnlockedCount(p.getUniqueId());
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (vaultNum <= unlocked) {
            if (clickType.isRightClick() || iconEditMode.contains(p.getUniqueId())) {
                iconEditMode.remove(p.getUniqueId());
                openIconPicker(p, vaultNum);
            } else {
                openVaultStorage(p, vaultNum);
            }
        } else if (vaultNum == unlocked + 1) {
            double cost = plugin.getConfig().getDouble("vaults.unlock-cost-per-vault", 3000.0);
            if (plugin.getEconomy() != null && !plugin.getEconomy().has(p, cost)) {
                p.sendMessage(ColorUtils.componentFor(p, prefix + "&cرصيدك غير كافٍ! المطلوب: &#FFD166&l" + cost + "$"));
                plugin.getSoundManager().play(p, "error");
                return;
            }
            if (plugin.getEconomy() != null) plugin.getEconomy().withdrawPlayer(p, cost);
            YamlConfiguration cfg = loadPlayerConfig(p.getUniqueId());
            cfg.set("unlocked", vaultNum);
            savePlayerConfig(p.getUniqueId(), cfg);
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ مبروك! تم فتح الخزنة السحابية #" + vaultNum + "!"));
            plugin.getSoundManager().play(p, "purchase");
            openVaultSelector(p);
        } else {
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&cافتح الخزنة #" + (unlocked + 1) + " أولاً!"));
            plugin.getSoundManager().play(p, "error");
        }
    }

    public void handleIconPickerClick(Player p, StrawberryGuiHolder holder, int slot) {
        if (slot == 18) { openVaultSelector(p); return; }
        Object matName = holder.get("icon_" + slot);
        if (matName == null) return;
        int vaultNum = holder.getInt("vault_num", 1);
        YamlConfiguration cfg = loadPlayerConfig(p.getUniqueId());
        cfg.set("icons." + vaultNum, matName.toString());
        savePlayerConfig(p.getUniqueId(), cfg);
        plugin.getSoundManager().play(p, "success");
        openVaultSelector(p);
    }

    @EventHandler
    public void onVaultClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player p)) return;
        if (!(event.getInventory().getHolder() instanceof StrawberryGuiHolder holder)) return;
        if (holder.getType() != StrawberryGuiHolder.GuiType.VAULT_STORAGE) return;

        int vaultNum = holder.getInt("vault_num", 1);
        YamlConfiguration cfg = loadPlayerConfig(p.getUniqueId());
        cfg.set("storage." + vaultNum, Arrays.asList(event.getInventory().getContents()));
        savePlayerConfig(p.getUniqueId(), cfg);
    }
}
