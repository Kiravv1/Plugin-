package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ColorUtils;
import com.strawberry.survivalplus.utils.GuiBuilder;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import org.bukkit.*;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class GraveManager implements Listener {

    public static class GraveData {
        public final int id;
        public final UUID ownerId;
        public final String ownerName;
        public final Location location;
        public final long expiresAt;
        public final List<ItemStack> items;
        public final int storedXp;
        public UUID holoLine1Id;
        public UUID holoLine2Id;

        public GraveData(int id, UUID ownerId, String ownerName, Location location, long expiresAt, List<ItemStack> items, int storedXp) {
            this.id = id;
            this.ownerId = ownerId;
            this.ownerName = ownerName;
            this.location = location;
            this.expiresAt = expiresAt;
            this.items = items;
            this.storedXp = storedXp;
        }
    }

    private final SurvivalPlus plugin;
    private final Map<Integer, GraveData> graves = new LinkedHashMap<>();
    private int nextGraveId = 1;
    private BukkitRunnable ticker;

    public GraveManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    public void startTicker() {
        if (ticker != null) ticker.cancel();
        ticker = new BukkitRunnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                List<Integer> expired = new ArrayList<>();
                for (GraveData g : graves.values()) {
                    if (g.expiresAt <= now) {
                        expired.add(g.id);
                    } else {
                        updateHologramTimer(g, now);
                    }
                }
                for (int id : expired) removeGrave(id);
            }
        };
        ticker.runTaskTimer(plugin, 20L, 20L);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerDeath(PlayerDeathEvent event) {
        if (!plugin.getConfig().getBoolean("graves.enabled", true)) return;
        if (event.getDrops().isEmpty() && event.getDroppedExp() <= 0) return;

        Player p = event.getEntity();
        Location loc = p.getLocation().getBlock().getLocation().add(0.5, 0.0, 0.5);
        List<ItemStack> saved = new ArrayList<>();
        for (ItemStack item : event.getDrops()) {
            if (item != null && !item.getType().isAir()) saved.add(item.clone());
        }
        event.getDrops().clear();

        int keepPct = plugin.getConfig().getInt("graves.keep-xp-percent", 50);
        int savedXp = (int) Math.round(event.getDroppedExp() * (keepPct / 100.0));
        event.setDroppedExp(0);

        long expireMs = plugin.getConfig().getLong("graves.expire-minutes", 30) * 60_000L;
        GraveData grave = new GraveData(nextGraveId++, p.getUniqueId(), p.getName(), loc, System.currentTimeMillis() + expireMs, saved, savedXp);
        spawnHolograms(grave);
        graves.put(grave.id, grave);

        if (plugin.getConfig().getBoolean("graves.send-coordinates-on-death", true)) {
            String prefix = plugin.getConfig().getString("general.prefix", "");
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&f&lتم حفظ أغراضك في قبر آمن &#FFD166&l#" + grave.id
                    + " &7عند: &#06D6A0&lX:" + loc.getBlockX() + " Y:" + loc.getBlockY() + " Z:" + loc.getBlockZ()
                    + " &7— استخدم &#FF758F&l/grave"));
        }
    }

    @EventHandler
    public void onInteractHolo(PlayerInteractAtEntityEvent event) {
        Entity e = event.getRightClicked();
        GraveData target = findByHolo(e.getUniqueId());
        if (target == null) return;
        event.setCancelled(true);
        handleWorldGraveInteract(event.getPlayer(), target);
    }

    @EventHandler
    public void onInteractBlock(PlayerInteractEvent event) {
        if (event.getClickedBlock() == null) return;
        Location bLoc = event.getClickedBlock().getLocation();
        for (GraveData g : graves.values()) {
            if (g.location.getWorld() != null && g.location.getWorld().equals(bLoc.getWorld())
                    && g.location.getBlockX() == bLoc.getBlockX()
                    && g.location.getBlockY() == bLoc.getBlockY()
                    && g.location.getBlockZ() == bLoc.getBlockZ()) {
                event.setCancelled(true);
                handleWorldGraveInteract(event.getPlayer(), g);
                return;
            }
        }
    }

    private void handleWorldGraveInteract(Player p, GraveData grave) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        boolean ownerOnly = plugin.getConfig().getBoolean("graves.owner-only-protection", true);
        if (ownerOnly && !grave.ownerId.equals(p.getUniqueId()) && !p.hasPermission("survivalplus.admin")) {
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&cهذا القبر محمي ولا يفتحه إلا صاحبه &#FFD166&l" + grave.ownerName));
            plugin.getSoundManager().play(p, "error");
            return;
        }
        if (p.isSneaking() && plugin.getConfig().getBoolean("graves.quick-equip-on-shift-click", true)) {
            collectGrave(p, grave);
        } else {
            openGravePreview(p, grave, true);
        }
    }

    public void collectGrave(Player p, GraveData grave) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        PlayerInventory inv = p.getInventory();
        for (ItemStack item : grave.items) {
            if (item == null || item.getType().isAir()) continue;
            if (!tryAutoEquipArmor(inv, item)) {
                HashMap<Integer, ItemStack> left = inv.addItem(item);
                left.values().forEach(rem -> p.getWorld().dropItemNaturally(p.getLocation(), rem));
            }
        }
        if (grave.storedXp > 0) p.giveExp(grave.storedXp);

        plugin.getHistoryManager().log(p.getUniqueId(), HistoryManager.EntryType.GRAVE,
                "استرجاع قبر #" + grave.id,
                grave.items.size() + " غرض عند X:" + grave.location.getBlockX() + " Y:" + grave.location.getBlockY() + " Z:" + grave.location.getBlockZ(), 0.0);

        removeGrave(grave.id);
        p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ تم استرجاع جميع أغراضك وتلبيس الدروع تلقائياً من قبر #" + grave.id + "!"));
        plugin.getSoundManager().play(p, "grave-collect");
        p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, p.getLocation().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0.05);
    }

    private boolean tryAutoEquipArmor(PlayerInventory inv, ItemStack item) {
        String name = item.getType().name();
        if (name.endsWith("_HELMET") && inv.getHelmet() == null) { inv.setHelmet(item); return true; }
        if ((name.endsWith("_CHESTPLATE") || name.equals("ELYTRA")) && inv.getChestplate() == null) { inv.setChestplate(item); return true; }
        if (name.endsWith("_LEGGINGS") && inv.getLeggings() == null) { inv.setLeggings(item); return true; }
        if (name.endsWith("_BOOTS") && inv.getBoots() == null) { inv.setBoots(item); return true; }
        return false;
    }

    public void openGravesGui(Player player) {
        String title = plugin.getConfig().getString("graves.gui-title", "القبور النشطة");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.GRAVES_LIST);
        Inventory inv = GuiBuilder.create(player, holder, 36, title);

        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        int idx = 0;
        long now = System.currentTimeMillis();
        double tpCost = plugin.getConfig().getDouble("graves.teleport-cost", 100.0);

        for (GraveData g : graves.values()) {
            if (!g.ownerId.equals(player.getUniqueId()) && !player.hasPermission("survivalplus.admin")) continue;
            if (idx >= slots.length) break;
            int slot = slots[idx++];
            holder.with("grave_" + slot, g.id);
            inv.setItem(slot, GuiBuilder.makeItem(player, Material.PLAYER_HEAD, "&#FF4D6D&l✦ قبر &#FFD166&l#" + g.id, Arrays.asList(
                    "&#FFB3C1&l━━━━━━━━━━━━━━━━━━",
                    "&7الموقع: &#FFD166&lX:" + g.location.getBlockX() + " Y:" + g.location.getBlockY() + " Z:" + g.location.getBlockZ(),
                    "&7العالم: &f" + (g.location.getWorld() != null ? g.location.getWorld().getName() : "world"),
                    "&7الأغراض: &#06D6A0&l" + g.items.size() + " غرض",
                    "&7الوقت المتبقي: &#06D6A0&l" + formatRemaining(g.expiresAt - now),
                    "&#FFB3C1&l━━━━━━━━━━━━━━━━━━",
                    "&#FF758F&l» &f&lاضغط للمعاينة أو الانتقال (" + tpCost + "$)"
            )));
        }

        if (idx == 0) {
            inv.setItem(13, GuiBuilder.makeItem(player, Material.TOTEM_OF_UNDYING, "&#06D6A0&l✔ لا توجد لديك قبور نشطة حالياً",
                    Collections.singletonList("&7أغراضك بأمان معك! استمر في المغامرة.")));
        }

        inv.setItem(31, GuiBuilder.backButton(player));
        player.openInventory(inv);
        plugin.getSoundManager().play(player, "open-gui");
    }

    public void openGravePreview(Player player, GraveData grave, boolean canCollectHere) {
        String title = plugin.getConfig().getString("graves.preview-title", "محتويات قبر #%id%")
                .replace("%id%", String.valueOf(grave.id));
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.GRAVE_PREVIEW)
                .with("grave_id", grave.id)
                .with("can_collect", canCollectHere);
        Inventory inv = GuiBuilder.create(player, holder, 54, title);

        int[] itemSlots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34, 37,38,39,40,41,42};
        for (int i = 0; i < grave.items.size() && i < itemSlots.length; i++) {
            inv.setItem(itemSlots[i], grave.items.get(i));
        }

        inv.setItem(45, GuiBuilder.makeItem(player, Material.ARROW, "&#FF4D6D&l« رجوع لقائمة القبور", null));
        if (canCollectHere) {
            inv.setItem(49, GuiBuilder.makeItem(player, Material.CHEST, "&#06D6A0&l✔ استرجاع الكل وتلبيس الدروع تلقائياً",
                    Collections.singletonList("&7مثالي للاعبي Bedrock — يسحب كل أغراضك بضغطة واحدة!")));
        } else if (plugin.getConfig().getBoolean("graves.allow-teleport", true)) {
            double tpCost = plugin.getConfig().getDouble("graves.teleport-cost", 100.0);
            inv.setItem(49, GuiBuilder.makeItem(player, Material.ENDER_PEARL, "&#C77DFF&l✦ انتقال فوري إلى القبر",
                    Arrays.asList("&7التكلفة: &#FFD166&l" + tpCost + "$", "&7ينقلك مباشرة فوق موقع قبرك لاسترجاع أغراضك.")));
        }

        player.openInventory(inv);
        plugin.getSoundManager().play(player, "open-gui");
    }

    public void handleListClick(Player p, StrawberryGuiHolder holder, int slot) {
        if (slot == 31) {
            String cmd = plugin.getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                    .replace("%player%", p.getName());
            p.closeInventory();
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            return;
        }
        Object idObj = holder.get("grave_" + slot);
        if (!(idObj instanceof Integer id)) return;
        GraveData g = graves.get(id);
        if (g == null) return;
        boolean nearby = p.getWorld().equals(g.location.getWorld()) && p.getLocation().distanceSquared(g.location) <= 25.0;
        openGravePreview(p, g, nearby);
    }

    public void handlePreviewClick(Player p, StrawberryGuiHolder holder, int slot) {
        if (slot == 45) { openGravesGui(p); return; }
        if (slot != 49) return;
        int id = holder.getInt("grave_id", -1);
        GraveData g = graves.get(id);
        if (g == null) { p.closeInventory(); return; }

        if (holder.getBool("can_collect", false)) {
            p.closeInventory();
            collectGrave(p, g);
        } else if (plugin.getConfig().getBoolean("graves.allow-teleport", true)) {
            String prefix = plugin.getConfig().getString("general.prefix", "");
            double cost = plugin.getConfig().getDouble("graves.teleport-cost", 100.0);
            if (plugin.getEconomy() != null && !plugin.getEconomy().has(p, cost)) {
                p.sendMessage(ColorUtils.componentFor(p, prefix + "&cرصيدك غير كافٍ للانتقال! المطلوب: &#FFD166&l" + cost + "$"));
                plugin.getSoundManager().play(p, "error");
                return;
            }
            if (plugin.getEconomy() != null) plugin.getEconomy().withdrawPlayer(p, cost);
            plugin.getHistoryManager().log(p.getUniqueId(), HistoryManager.EntryType.GRAVE,
                    "انتقال فوري لقبر #" + g.id, "رسوم الانتقال للقبر", -cost);
            p.closeInventory();
            p.teleport(g.location.clone().add(0, 1, 0));
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ تم نقلك إلى قبرك #" + g.id + "! اضغط عليه مع Shift لاسترجاع كل شيء فوراً."));
            plugin.getSoundManager().play(p, "success");
        }
    }

    private void spawnHolograms(GraveData g) {
        World w = g.location.getWorld();
        if (w == null) return;
        String l1 = plugin.getConfig().getString("graves.hologram-line1", "قبر %owner%").replace("%owner%", g.ownerName);
        String l2 = plugin.getConfig().getString("graves.hologram-line2", "%time%").replace("%time%", formatRemaining(g.expiresAt - System.currentTimeMillis()));

        ArmorStand s1 = w.spawn(g.location.clone().add(0, 0.9, 0), ArmorStand.class, as -> {
            as.setInvisible(true);
            as.setGravity(false);
            as.setInvulnerable(true);
            as.setSilent(true);
            as.setSmall(true);
            as.setCustomNameVisible(true);
            as.customName(ColorUtils.component(l1));
        });
        ArmorStand s2 = w.spawn(g.location.clone().add(0, 0.6, 0), ArmorStand.class, as -> {
            as.setInvisible(true);
            as.setGravity(false);
            as.setInvulnerable(true);
            as.setSilent(true);
            as.setSmall(true);
            as.setCustomNameVisible(true);
            as.customName(ColorUtils.component(l2));
        });
        g.holoLine1Id = s1.getUniqueId();
        g.holoLine2Id = s2.getUniqueId();
    }

    private void updateHologramTimer(GraveData g, long now) {
        if (g.holoLine2Id == null) return;
        Entity e = Bukkit.getEntity(g.holoLine2Id);
        if (e != null) {
            String l2 = plugin.getConfig().getString("graves.hologram-line2", "%time%")
                    .replace("%time%", formatRemaining(g.expiresAt - now));
            e.customName(ColorUtils.component(l2));
        }
    }

    private GraveData findByHolo(UUID entityId) {
        for (GraveData g : graves.values()) {
            if (entityId.equals(g.holoLine1Id) || entityId.equals(g.holoLine2Id)) return g;
        }
        return null;
    }

    private void removeGrave(int id) {
        GraveData g = graves.remove(id);
        if (g == null) return;
        if (g.holoLine1Id != null) {
            Entity e1 = Bukkit.getEntity(g.holoLine1Id);
            if (e1 != null) e1.remove();
        }
        if (g.holoLine2Id != null) {
            Entity e2 = Bukkit.getEntity(g.holoLine2Id);
            if (e2 != null) e2.remove();
        }
    }

    private String formatRemaining(long ms) {
        long totalSec = Math.max(0, ms / 1000L);
        long min = totalSec / 60L;
        long sec = totalSec % 60L;
        return String.format("%02d:%02d", min, sec);
    }

    public void shutdown() {
        if (ticker != null) ticker.cancel();
        for (Integer id : new ArrayList<>(graves.keySet())) removeGrave(id);
    }
}
