package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ColorUtils;
import com.strawberry.survivalplus.utils.GuiBuilder;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class TradeManager implements Listener {

    public static class TradeSession {
        public final UUID playerA;
        public final UUID playerB;
        public Inventory invA;
        public Inventory invB;
        public final ItemStack[] itemsA = new ItemStack[12];
        public final ItemStack[] itemsB = new ItemStack[12];
        public double moneyA = 0.0, moneyB = 0.0;
        public int xpA = 0, xpB = 0;
        public boolean readyA = false, readyB = false;
        public BukkitRunnable countdownTask;
        public boolean completed = false;

        public TradeSession(UUID a, UUID b) {
            this.playerA = a;
            this.playerB = b;
        }

        public boolean isA(UUID id) { return playerA.equals(id); }
    }

    private static final int[] LEFT_SLOTS = {10, 11, 12, 19, 20, 21, 28, 29, 30, 37, 38, 39};
    private static final int[] RIGHT_SLOTS = {14, 15, 16, 23, 24, 25, 32, 33, 34, 41, 42, 43};
    private static final int[] DIVIDER_SLOTS = {4, 13, 22, 31, 40, 49};

    private final SurvivalPlus plugin;
    private final Map<UUID, UUID> pendingRequests = new HashMap<>();
    private final Map<UUID, TradeSession> activeSessions = new HashMap<>();

    public TradeManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    public void sendRequest(Player sender, Player target) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (sender.getUniqueId().equals(target.getUniqueId())) {
            sender.sendMessage(ColorUtils.componentFor(sender, prefix + "&cلا يمكنك المقايضة مع نفسك!"));
            return;
        }
        double maxDist = plugin.getConfig().getDouble("safe-trade.max-distance", 25.0);
        if (!sender.getWorld().equals(target.getWorld()) || sender.getLocation().distance(target.getLocation()) > maxDist) {
            sender.sendMessage(ColorUtils.componentFor(sender, prefix + "&cيجب أن تكون ضمن مسافة " + (int) maxDist + " بلوكة من &#FFD166&l" + target.getName()));
            plugin.getSoundManager().play(sender, "error");
            return;
        }

        if (target.getUniqueId().equals(pendingRequests.get(sender.getUniqueId()))) {
            pendingRequests.remove(sender.getUniqueId());
            startSession(target, sender);
            return;
        }

        pendingRequests.put(target.getUniqueId(), sender.getUniqueId());
        sender.sendMessage(ColorUtils.componentFor(sender, prefix + "&#06D6A0&l✔ تم إرسال طلب مقايضة آمنة إلى &#FFD166&l" + target.getName()));
        target.sendMessage(ColorUtils.componentFor(target, prefix + "&#FFD166&l✦ " + sender.getName()
                + " &fيدعوك لمقايضة آمنة! اكتب &#06D6A0&l/trade accept &fللقبول."));
        plugin.getSoundManager().play(target, "mail-notify");

        long expireTicks = plugin.getConfig().getLong("safe-trade.request-expire-seconds", 45) * 20L;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (sender.getUniqueId().equals(pendingRequests.get(target.getUniqueId()))) {
                pendingRequests.remove(target.getUniqueId());
            }
        }, expireTicks);
    }

    public void acceptRequest(Player accepter) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        UUID reqId = pendingRequests.remove(accepter.getUniqueId());
        if (reqId == null) {
            accepter.sendMessage(ColorUtils.componentFor(accepter, prefix + "&cلا يوجد لديك طلب مقايضة نشط حالياً."));
            return;
        }
        Player requester = Bukkit.getPlayer(reqId);
        if (requester == null || !requester.isOnline()) {
            accepter.sendMessage(ColorUtils.componentFor(accepter, prefix + "&cاللاعب غير متصل حالياً."));
            return;
        }
        startSession(requester, accepter);
    }

    private void startSession(Player pA, Player pB) {
        TradeSession s = new TradeSession(pA.getUniqueId(), pB.getUniqueId());
        activeSessions.put(pA.getUniqueId(), s);
        activeSessions.put(pB.getUniqueId(), s);

        String titleA = plugin.getConfig().getString("safe-trade.gui-title", "مقايضة | %partner%").replace("%partner%", pB.getName());
        String titleB = plugin.getConfig().getString("safe-trade.gui-title", "مقايضة | %partner%").replace("%partner%", pA.getName());

        s.invA = GuiBuilder.create(pA, new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.SAFE_TRADE), 54, titleA);
        s.invB = GuiBuilder.create(pB, new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.SAFE_TRADE), 54, titleB);

        refreshBoth(s, -1);
        pA.openInventory(s.invA);
        pB.openInventory(s.invB);
        plugin.getSoundManager().play(pA, "open-gui");
        plugin.getSoundManager().play(pB, "open-gui");
    }

    private void refreshBoth(TradeSession s, int countdownSec) {
        Player pA = Bukkit.getPlayer(s.playerA);
        Player pB = Bukkit.getPlayer(s.playerB);
        if (pA == null || pB == null) return;

        renderFor(pA, s.invA, s.itemsA, s.itemsB, s.moneyA, s.moneyB, s.xpA, s.xpB, s.readyA, s.readyB, countdownSec);
        renderFor(pB, s.invB, s.itemsB, s.itemsA, s.moneyB, s.moneyA, s.xpB, s.xpA, s.readyB, s.readyA, countdownSec);
    }

    private void renderFor(Player viewer, Inventory inv, ItemStack[] ownItems, ItemStack[] partnerItems,
                           double ownMoney, double partnerMoney, int ownXp, int partnerXp,
                           boolean ownReady, boolean partnerReady, int countdown) {
        for (int i = 0; i < 12; i++) {
            inv.setItem(LEFT_SLOTS[i], ownItems[i]);
            inv.setItem(RIGHT_SLOTS[i], partnerItems[i]);
        }

        Material divMat = countdown > 0 ? Material.LIME_STAINED_GLASS_PANE : Material.MAGENTA_STAINED_GLASS_PANE;
        String divName = countdown > 0 ? "&#06D6A0&l✦ تأكيد خلال " + countdown + "ث..." : "&#FF758F&l✦ فاصل الحماية";
        for (int slot : DIVIDER_SLOTS) inv.setItem(slot, GuiBuilder.makeItem(viewer, divMat, divName, null));

        inv.setItem(45, GuiBuilder.makeItem(viewer, Material.GOLD_INGOT, "&#FFD166&l+$100 &7(عرضك: " + ownMoney + "$)",
                Arrays.asList("&7كليك يسار: &a+$100", "&7كليك يمين: &cتصفير المبلغ")));
        inv.setItem(46, GuiBuilder.makeItem(viewer, Material.GOLD_BLOCK, "&#FFD166&l+$1,000",
                Collections.singletonList("&7إضافة 1,000$ لعرضك في المقايضة.")));
        inv.setItem(47, GuiBuilder.makeItem(viewer, Material.EXPERIENCE_BOTTLE, "&#06D6A0&l+5 XP Levels &7(عرضك: " + ownXp + "L)",
                Arrays.asList("&7كليك يسار: &a+5 لفلات", "&7كليك يمين: &cتصفير الـ XP")));
        inv.setItem(48, GuiBuilder.makeItem(viewer, ownReady ? Material.LIME_CONCRETE : Material.RED_CONCRETE,
                ownReady ? "&#06D6A0&l✔ أنت جاهز للتنفيذ" : "&#FF4D6D&l✦ اضغط لتأكيد عرضك",
                Collections.singletonList("&7أي تعديل من الطرف الآخر يلغي التأكيد تلقائياً!")));

        inv.setItem(50, GuiBuilder.makeItem(viewer, partnerReady ? Material.LIME_WOOL : Material.GRAY_WOOL,
                partnerReady ? "&#06D6A0&l✔ الطرف الآخر موافق" : "&7⏳ بانتظار موافقة الطرف الآخر",
                Arrays.asList("&7عرضه المالي: &#FFD166&l" + partnerMoney + "$", "&7عرض الـ XP: &#06D6A0&l" + partnerXp + " Levels")));
        inv.setItem(53, GuiBuilder.makeItem(viewer, Material.BARRIER, "&c&l✖ إلغاء المقايضة",
                Collections.singletonList("&7تُعاد جميع أغراضك لحقيبتك بأمان.")));
    }

    public void handleTradeClick(Player p, int rawSlot, boolean isRightClick, ItemStack clickedFromPlayerInv) {
        TradeSession s = activeSessions.get(p.getUniqueId());
        if (s == null || s.completed) return;

        boolean isA = s.isA(p.getUniqueId());
        ItemStack[] ownItems = isA ? s.itemsA : s.itemsB;
        String prefix = plugin.getConfig().getString("general.prefix", "");

        if (rawSlot >= 54) {
            if (clickedFromPlayerInv == null || clickedFromPlayerInv.getType().isAir()) return;
            for (int i = 0; i < 12; i++) {
                if (ownItems[i] == null) {
                    ownItems[i] = clickedFromPlayerInv.clone();
                    clickedFromPlayerInv.setAmount(0);
                    resetReady(s);
                    plugin.getSoundManager().play(p, "click");
                    return;
                }
            }
            return;
        }

        for (int i = 0; i < 12; i++) {
            if (LEFT_SLOTS[i] == rawSlot && ownItems[i] != null) {
                HashMap<Integer, ItemStack> left = p.getInventory().addItem(ownItems[i]);
                left.values().forEach(rem -> p.getWorld().dropItemNaturally(p.getLocation(), rem));
                ownItems[i] = null;
                resetReady(s);
                plugin.getSoundManager().play(p, "click");
                return;
            }
        }

        if (rawSlot == 53) {
            cancelSession(s, "&cتم إلغاء المقايضة وإرجاع الأغراض بأمان.");
            return;
        }

        if (rawSlot == 45 || rawSlot == 46) {
            if (!plugin.getConfig().getBoolean("safe-trade.allow-money", true) || plugin.getEconomy() == null) return;
            double delta = (rawSlot == 45) ? 100.0 : 1000.0;
            double current = isA ? s.moneyA : s.moneyB;
            double next = isRightClick ? 0.0 : current + delta;
            if (next > plugin.getEconomy().getBalance(p)) {
                p.sendMessage(ColorUtils.componentFor(p, prefix + "&cرصيدك لا يكفي لهذا المبلغ!"));
                plugin.getSoundManager().play(p, "error");
                return;
            }
            if (isA) s.moneyA = next; else s.moneyB = next;
            resetReady(s);
            plugin.getSoundManager().play(p, "click");
            return;
        }

        if (rawSlot == 47) {
            if (!plugin.getConfig().getBoolean("safe-trade.allow-xp-levels", true)) return;
            int current = isA ? s.xpA : s.xpB;
            int next = isRightClick ? 0 : current + 5;
            if (next > p.getLevel()) {
                p.sendMessage(ColorUtils.componentFor(p, prefix + "&cلفلات الـ XP لديك غير كافية!"));
                plugin.getSoundManager().play(p, "error");
                return;
            }
            if (isA) s.xpA = next; else s.xpB = next;
            resetReady(s);
            plugin.getSoundManager().play(p, "click");
            return;
        }

        if (rawSlot == 48) {
            if (isA) s.readyA = !s.readyA; else s.readyB = !s.readyB;
            plugin.getSoundManager().play(p, "success");
            if (s.readyA && s.readyB) {
                startCountdown(s);
            } else {
                stopCountdown(s);
                refreshBoth(s, -1);
            }
        }
    }

    private void resetReady(TradeSession s) {
        s.readyA = false;
        s.readyB = false;
        stopCountdown(s);
        refreshBoth(s, -1);
    }

    private void stopCountdown(TradeSession s) {
        if (s.countdownTask != null) {
            s.countdownTask.cancel();
            s.countdownTask = null;
        }
    }

    private void startCountdown(TradeSession s) {
        stopCountdown(s);
        int startSec = plugin.getConfig().getInt("safe-trade.confirm-countdown-seconds", 3);
        s.countdownTask = new BukkitRunnable() {
            int rem = startSec;

            @Override
            public void run() {
                if (!s.readyA || !s.readyB || s.completed) { cancel(); return; }
                Player pA = Bukkit.getPlayer(s.playerA);
                Player pB = Bukkit.getPlayer(s.playerB);
                if (pA == null || pB == null) {
                    cancelSession(s, "&cانقطع اتصال أحد الطرفين.");
                    cancel();
                    return;
                }
                if (rem <= 0) {
                    completeTrade(s, pA, pB);
                    cancel();
                    return;
                }
                refreshBoth(s, rem);
                plugin.getSoundManager().play(pA, "click");
                plugin.getSoundManager().play(pB, "click");
                rem--;
            }
        };
        s.countdownTask.runTaskTimer(plugin, 0L, 20L);
    }

    private void completeTrade(TradeSession s, Player pA, Player pB) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (plugin.getEconomy() != null) {
            if (s.moneyA > 0 && !plugin.getEconomy().has(pA, s.moneyA)) {
                cancelSession(s, "&cفشلت المقايضة لعدم كفاية رصيد " + pA.getName());
                return;
            }
            if (s.moneyB > 0 && !plugin.getEconomy().has(pB, s.moneyB)) {
                cancelSession(s, "&cفشلت المقايضة لعدم كفاية رصيد " + pB.getName());
                return;
            }
        }
        if (s.xpA > pA.getLevel() || s.xpB > pB.getLevel()) {
            cancelSession(s, "&cفشلت المقايضة لعدم كفاية لفلات XP لدى أحد الطرفين.");
            return;
        }

        s.completed = true;
        activeSessions.remove(s.playerA);
        activeSessions.remove(s.playerB);

        if (plugin.getEconomy() != null) {
            if (s.moneyA > 0) { plugin.getEconomy().withdrawPlayer(pA, s.moneyA); plugin.getEconomy().depositPlayer(pB, s.moneyA); }
            if (s.moneyB > 0) { plugin.getEconomy().withdrawPlayer(pB, s.moneyB); plugin.getEconomy().depositPlayer(pA, s.moneyB); }
        }
        if (s.xpA > 0) { pA.setLevel(pA.getLevel() - s.xpA); pB.setLevel(pB.getLevel() + s.xpA); }
        if (s.xpB > 0) { pB.setLevel(pB.getLevel() - s.xpB); pA.setLevel(pA.getLevel() + s.xpB); }

        giveItems(pA, s.itemsB);
        giveItems(pB, s.itemsA);

        plugin.getHistoryManager().log(pA.getUniqueId(), HistoryManager.EntryType.TRADE,
                "مقايضة مع " + pB.getName(), "أرسلت " + s.moneyA + "$ / " + s.xpA + "L — استلمت " + s.moneyB + "$ / " + s.xpB + "L", s.moneyB - s.moneyA);
        plugin.getHistoryManager().log(pB.getUniqueId(), HistoryManager.EntryType.TRADE,
                "مقايضة مع " + pA.getName(), "أرسلت " + s.moneyB + "$ / " + s.xpB + "L — استلمت " + s.moneyA + "$ / " + s.xpA + "L", s.moneyA - s.moneyB);

        pA.closeInventory();
        pB.closeInventory();
        pA.sendMessage(ColorUtils.componentFor(pA, prefix + "&#06D6A0&l✔ تمت المقايضة الآمنة مع &#FFD166&l" + pB.getName() + " &#06D6A0&lبنجاح!"));
        pB.sendMessage(ColorUtils.componentFor(pB, prefix + "&#06D6A0&l✔ تمت المقايضة الآمنة مع &#FFD166&l" + pA.getName() + " &#06D6A0&lبنجاح!"));
        plugin.getSoundManager().play(pA, "purchase");
        plugin.getSoundManager().play(pB, "purchase");
    }

    private void cancelSession(TradeSession s, String msg) {
        if (s.completed) return;
        s.completed = true;
        stopCountdown(s);
        activeSessions.remove(s.playerA);
        activeSessions.remove(s.playerB);

        Player pA = Bukkit.getPlayer(s.playerA);
        Player pB = Bukkit.getPlayer(s.playerB);
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (pA != null) {
            giveItems(pA, s.itemsA);
            pA.closeInventory();
            pA.sendMessage(ColorUtils.componentFor(pA, prefix + msg));
            plugin.getSoundManager().play(pA, "error");
        }
        if (pB != null) {
            giveItems(pB, s.itemsB);
            pB.closeInventory();
            pB.sendMessage(ColorUtils.componentFor(pB, prefix + msg));
            plugin.getSoundManager().play(pB, "error");
        }
    }

    private void giveItems(Player p, ItemStack[] items) {
        for (ItemStack it : items) {
            if (it != null && !it.getType().isAir()) {
                HashMap<Integer, ItemStack> left = p.getInventory().addItem(it);
                left.values().forEach(rem -> p.getWorld().dropItemNaturally(p.getLocation(), rem));
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player p)) return;
        TradeSession s = activeSessions.get(p.getUniqueId());
        if (s != null && !s.completed) {
            cancelSession(s, "&cتم إغلاق نافذة المقايضة وإرجاع الأغراض لأصحابها.");
        }
    }
}
