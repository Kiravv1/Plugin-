package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ColorUtils;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.ShulkerBox;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.BlockStateMeta;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class AutoRefillManager implements Listener {

    private final SurvivalPlus plugin;
    private final Set<UUID> disabledPlayers = new HashSet<>();

    public AutoRefillManager(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    public boolean toggleFor(Player p) {
        if (disabledPlayers.contains(p.getUniqueId())) {
            disabledPlayers.remove(p.getUniqueId());
            return true;
        } else {
            disabledPlayers.add(p.getUniqueId());
            return false;
        }
    }

    public boolean isEnabledFor(Player p) {
        return plugin.getConfig().getBoolean("auto-refill.enabled", true) && !disabledPlayers.contains(p.getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player p = event.getPlayer();
        if (p.getGameMode() == GameMode.CREATIVE || !isEnabledFor(p)) return;

        ItemStack placedStack = event.getItemInHand();
        if (placedStack.getAmount() > 1 || placedStack.hasItemMeta()) return;

        Material targetMat = placedStack.getType();
        EquipmentSlot hand = event.getHand();
        int heldSlot = p.getInventory().getHeldItemSlot();

        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            PlayerInventory inv = p.getInventory();
            ItemStack currentHand = (hand == EquipmentSlot.OFF_HAND) ? inv.getItemInOffHand() : inv.getItem(heldSlot);
            if (currentHand != null && !currentHand.getType().isAir()) return;

            for (int slot = 0; slot < 36; slot++) {
                if (hand == EquipmentSlot.HAND && slot == heldSlot) continue;
                ItemStack candidate = inv.getItem(slot);
                if (candidate != null && candidate.getType() == targetMat && !candidate.hasItemMeta()) {
                    ItemStack move = candidate.clone();
                    inv.setItem(slot, null);
                    placeInHand(inv, hand, heldSlot, move);
                    notifyRefill(p, move, "الحقيبة");
                    return;
                }
            }

            if (!plugin.getConfig().getBoolean("auto-refill.search-inside-shulker-boxes", true)) return;
            for (int slot = 0; slot < 36; slot++) {
                ItemStack shulkerItem = inv.getItem(slot);
                if (shulkerItem == null || !shulkerItem.getType().name().endsWith("SHULKER_BOX")) continue;
                if (!(shulkerItem.getItemMeta() instanceof BlockStateMeta bsm)) continue;
                if (!(bsm.getBlockState() instanceof ShulkerBox shulkerBox)) continue;

                Inventory shulkerInv = shulkerBox.getInventory();
                for (int sSlot = 0; sSlot < shulkerInv.getSize(); sSlot++) {
                    ItemStack inside = shulkerInv.getItem(sSlot);
                    if (inside != null && inside.getType() == targetMat && !inside.hasItemMeta()) {
                        ItemStack move = inside.clone();
                        shulkerInv.setItem(sSlot, null);
                        bsm.setBlockState(shulkerBox);
                        shulkerItem.setItemMeta(bsm);
                        inv.setItem(slot, shulkerItem);

                        placeInHand(inv, hand, heldSlot, move);
                        notifyRefill(p, move, "صندوق شالكر");
                        return;
                    }
                }
            }
        });
    }

    private void placeInHand(PlayerInventory inv, EquipmentSlot hand, int heldSlot, ItemStack stack) {
        if (hand == EquipmentSlot.OFF_HAND) inv.setItemInOffHand(stack);
        else inv.setItem(heldSlot, stack);
    }

    private void notifyRefill(Player p, ItemStack stack, String source) {
        plugin.getSoundManager().play(p, "refill");
        if (plugin.getConfig().getBoolean("auto-refill.show-actionbar", true)) {
            String msg = plugin.getConfig().getString("auto-refill.actionbar-message", "")
                    .replace("%amount%", String.valueOf(stack.getAmount()))
                    .replace("%item%", stack.getType().name())
                    .replace("%source%", source);
            p.sendActionBar(ColorUtils.componentFor(p, msg));
        }
    }
}
