package com.strawberry.survivalplus.utils;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.UUID;

public class ClaimTrustHelper {

    public static boolean canAccessContainer(Player player, Location location, boolean mustBeInsideClaim) {
        if (player == null || location == null) return false;
        if (player.hasPermission("survivalplus.admin")) return true;

        Plugin gp = Bukkit.getPluginManager().getPlugin("GriefPrevention");
        if (gp == null || !gp.isEnabled()) {
            return !mustBeInsideClaim;
        }

        try {
            Object dataStore = gp.getClass().getField("dataStore").get(gp);
            Class<?> claimClass = Class.forName("me.ryanhamshire.GriefPrevention.Claim");
            Method getClaimAt = dataStore.getClass().getMethod("getClaimAt", Location.class, boolean.class, claimClass);
            Object claim = getClaimAt.invoke(dataStore, location, false, null);

            if (claim == null) {
                return !mustBeInsideClaim;
            }

            Object ownerId = claim.getClass().getMethod("getOwnerID").invoke(claim);
            if (ownerId instanceof UUID uuid && uuid.equals(player.getUniqueId())) {
                return true;
            }

            Method allowContainers = claim.getClass().getMethod("allowContainers", Player.class);
            Object denialReason = allowContainers.invoke(claim, player);
            return denialReason == null;
        } catch (Exception e) {
            return !mustBeInsideClaim;
        }
    }
}
