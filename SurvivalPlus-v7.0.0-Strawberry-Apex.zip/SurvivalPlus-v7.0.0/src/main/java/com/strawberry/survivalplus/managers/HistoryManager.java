package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.GuiBuilder;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class HistoryManager {

    public enum EntryType {
        ALL("الكل", Material.BOOK, "&#FFF0F3"),
        SHOP("المتاجر", Material.EMERALD, "&#06D6A0"),
        TRADE("المقايضات", Material.GOLD_INGOT, "&#FFD166"),
        MAIL("البريد والتحويلات", Material.PAPER, "&#FF758F"),
        GRAVE("القبور", Material.TOTEM_OF_UNDYING, "&#C77DFF");

        public final String arabicLabel;
        public final Material icon;
        public final String colorHex;

        EntryType(String arabicLabel, Material icon, String colorHex) {
            this.arabicLabel = arabicLabel;
            this.icon = icon;
            this.colorHex = colorHex;
        }
    }

    public static class HistoryEntry {
        public final EntryType type;
        public final String timestamp;
        public final String title;
        public final String details;
        public final double amountDelta;

        public HistoryEntry(EntryType type, String timestamp, String title, String details, double amountDelta) {
            this.type = type;
            this.timestamp = timestamp;
            this.title = title;
            this.details = details;
            this.amountDelta = amountDelta;
        }
    }

    private final SurvivalPlus plugin;
    private final File historyDir;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm");
    private static final int[] CONTENT_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };

    public HistoryManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.historyDir = new File(plugin.getDataFolder(), "history");
        if (!historyDir.exists()) historyDir.mkdirs();
    }

    public void log(UUID playerId, EntryType type, String title, String details, double amountDelta) {
        if (!plugin.getConfig().getBoolean("history.enabled", true)) return;
        List<HistoryEntry> entries = loadEntries(playerId);
        entries.add(0, new HistoryEntry(type, LocalDateTime.now().format(FMT), title, details, amountDelta));

        int max = plugin.getConfig().getInt("history.max-entries-per-player", 200);
        while (entries.size() > max) {
            entries.remove(entries.size() - 1);
        }
        saveEntries(playerId, entries);
    }

    private List<HistoryEntry> loadEntries(UUID playerId) {
        File f = new File(historyDir, playerId.toString() + ".yml");
        List<HistoryEntry> list = new ArrayList<>();
        if (!f.exists()) return list;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection sec = cfg.getConfigurationSection("entries");
        if (sec == null) return list;

        List<String> keys = new ArrayList<>(sec.getKeys(false));
        keys.sort(Comparator.comparingInt(k -> {
            try { return Integer.parseInt(k); } catch (Exception e) { return 0; }
        }));

        for (String key : keys) {
            try {
                EntryType t = EntryType.valueOf(sec.getString(key + ".type", "SHOP"));
                String ts = sec.getString(key + ".time", "");
                String title = sec.getString(key + ".title", "");
                String details = sec.getString(key + ".details", "");
                double delta = sec.getDouble(key + ".delta", 0.0);
                list.add(new HistoryEntry(t, ts, title, details, delta));
            } catch (Exception ignored) {}
        }
        return list;
    }

    private void saveEntries(UUID playerId, List<HistoryEntry> entries) {
        if (!historyDir.exists()) historyDir.mkdirs();
        YamlConfiguration cfg = new YamlConfiguration();
        for (int i = 0; i < entries.size(); i++) {
            HistoryEntry e = entries.get(i);
            String p = "entries." + i;
            cfg.set(p + ".type", e.type.name());
            cfg.set(p + ".time", e.timestamp);
            cfg.set(p + ".title", e.title);
            cfg.set(p + ".details", e.details);
            cfg.set(p + ".delta", e.amountDelta);
        }
        try {
            cfg.save(new File(historyDir, playerId.toString() + ".yml"));
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save history for " + playerId + ": " + e.getMessage());
        }
    }

    public void openHistoryGui(Player player, EntryType filter, int page) {
        String title = plugin.getConfig().getString("history.gui-title", "سجل النشاط")
                + " &8[" + filter.colorHex + "&l" + filter.arabicLabel + "&8]";
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.HISTORY_LEDGER)
                .with("filter", filter.name())
                .with("page", page);
        Inventory inv = GuiBuilder.create(player, holder, 54, title);

        List<HistoryEntry> all = loadEntries(player.getUniqueId());
        List<HistoryEntry> filtered = new ArrayList<>();
        for (HistoryEntry e : all) {
            if (filter == EntryType.ALL || e.type == filter) filtered.add(e);
        }

        int perPage = CONTENT_SLOTS.length;
        int start = page * perPage;
        for (int i = 0; i < perPage && (start + i) < filtered.size(); i++) {
            HistoryEntry e = filtered.get(start + i);
            String deltaStr = e.amountDelta > 0
                    ? "&#06D6A0&l+" + round2(e.amountDelta) + "$"
                    : (e.amountDelta < 0 ? "&#FF4D6D&l" + round2(e.amountDelta) + "$" : "&7بدون تغيير مالي");

            inv.setItem(CONTENT_SLOTS[i], GuiBuilder.makeItem(player, e.type.icon,
                    e.type.colorHex + "&l✦ " + e.title,
                    Arrays.asList(
                            "&#FFB3C1&l━━━━━━━━━━━━━━━━━━",
                            "&7التصنيف: " + e.type.colorHex + "&l" + e.type.arabicLabel,
                            "&7التاريخ والوقت: &#FFD166&l" + e.timestamp,
                            "&7التفاصيل: &f" + e.details,
                            "&7الأثر المالي: " + deltaStr,
                            "&#FFB3C1&l━━━━━━━━━━━━━━━━━━"
                    )));
        }

        if (filtered.isEmpty()) {
            inv.setItem(22, GuiBuilder.makeItem(player, Material.PAPER, "&#FFB3C1&lلا توجد سجلات في هذا التصنيف حالياً",
                    Collections.singletonList("&7ستظهر هنا كل معاملاتك الموثقة تلقائياً.")));
        }

        inv.setItem(45, GuiBuilder.backButton(player));
        inv.setItem(47, filterBtn(player, EntryType.ALL, filter == EntryType.ALL));
        inv.setItem(48, filterBtn(player, EntryType.SHOP, filter == EntryType.SHOP));
        inv.setItem(49, filterBtn(player, EntryType.TRADE, filter == EntryType.TRADE));
        inv.setItem(50, filterBtn(player, EntryType.MAIL, filter == EntryType.MAIL));
        inv.setItem(51, filterBtn(player, EntryType.GRAVE, filter == EntryType.GRAVE));

        if (page > 0) inv.setItem(46, GuiBuilder.makeItem(player, Material.SPECTRAL_ARROW, "&#FFD166&l« السابق", null));
        if ((page + 1) * perPage < filtered.size()) inv.setItem(52, GuiBuilder.makeItem(player, Material.SPECTRAL_ARROW, "&#FFD166&lالتالي »", null));

        player.openInventory(inv);
        plugin.getSoundManager().play(player, "open-gui");
    }

    private ItemStack filterBtn(Player p, EntryType t, boolean active) {
        return GuiBuilder.makeItem(p, active ? Material.LIME_DYE : t.icon,
                (active ? "&#06D6A0&l✔ تصفية: " : t.colorHex + "&l✦ تصفية: ") + t.arabicLabel,
                Collections.singletonList(active ? "&aهذا الفلتر مفعّل حالياً." : "&7اضغط لعرض سجلات " + t.arabicLabel + " فقط."));
    }

    public void handleClick(Player p, StrawberryGuiHolder holder, int slot) {
        EntryType current = EntryType.valueOf(holder.getString("filter", "ALL"));
        int page = holder.getInt("page", 0);

        if (slot == 45) {
            String cmd = plugin.getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                    .replace("%player%", p.getName());
            p.closeInventory();
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            return;
        }
        if (slot == 46 && page > 0) { openHistoryGui(p, current, page - 1); return; }
        if (slot == 52) { openHistoryGui(p, current, page + 1); return; }

        switch (slot) {
            case 47 -> openHistoryGui(p, EntryType.ALL, 0);
            case 48 -> openHistoryGui(p, EntryType.SHOP, 0);
            case 49 -> openHistoryGui(p, EntryType.TRADE, 0);
            case 50 -> openHistoryGui(p, EntryType.MAIL, 0);
            case 51 -> openHistoryGui(p, EntryType.GRAVE, 0);
        }
    }

    private double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
