package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ColorUtils;
import com.strawberry.survivalplus.utils.GuiBuilder;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class PlayerShopManager {

    public static class ShopProduct {
        public ItemStack item;
        public double unitPrice;
        public boolean bulkEnabled;
        public int soldUnits;
        public double revenueGenerated;

        public ShopProduct(ItemStack item, double unitPrice, boolean bulkEnabled) {
            this.item = item.clone();
            this.item.setAmount(1);
            this.unitPrice = unitPrice;
            this.bulkEnabled = bulkEnabled;
        }
    }

    public static class PlayerShop {
        public UUID ownerId;
        public String ownerName;
        public int tier = 1;
        public double totalRevenue = 0.0;
        public double totalTaxPaid = 0.0;
        public int totalTransactions = 0;
        public int totalUnitsSold = 0;
        public int totalVisits = 0;
        public boolean globalBulkMode = false;
        public long flashSaleEndsAt = 0L;
        public long flashSaleCooldownEndsAt = 0L;
        public final Map<UUID, Integer> ratings = new HashMap<>();
        public final Set<UUID> followers = new HashSet<>();
        public final List<ShopProduct> products = new ArrayList<>();
        public final List<String> recentSalesLog = new ArrayList<>();

        public boolean isAllProductsBulkEligible() {
            if (products.isEmpty() || !globalBulkMode) return false;
            for (ShopProduct p : products) {
                if (!p.bulkEnabled) return false;
            }
            return true;
        }

        public boolean isFlashSaleActive() {
            return flashSaleEndsAt > System.currentTimeMillis();
        }

        public double getAverageRating() {
            if (ratings.isEmpty()) return 5.0;
            double sum = 0.0;
            for (int r : ratings.values()) sum += r;
            return Math.round((sum / ratings.size()) * 10.0) / 10.0;
        }

        public ShopProduct getTopSellingProduct() {
            ShopProduct best = null;
            for (ShopProduct p : products) {
                if (best == null || p.soldUnits > best.soldUnits) best = p;
            }
            return best;
        }
    }

    private final SurvivalPlus plugin;
    private final Map<UUID, PlayerShop> shops = new LinkedHashMap<>();
    private final Set<UUID> bedrockBulkBuyMode = new HashSet<>();
    private final Set<UUID> favoritesOnlyFilter = new HashSet<>();
    private final File dataFile;

    private static final int[] DIRECTORY_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };

    private static final int[] PRODUCT_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42
    };

    public PlayerShopManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        this.dataFile = new File(plugin.getDataFolder(), "shops.yml");
        loadAll();
    }

    public void reload() {}

    public void loadAll() {
        shops.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection root = cfg.getConfigurationSection("shops");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            try {
                UUID ownerId = UUID.fromString(key);
                ConfigurationSection s = root.getConfigurationSection(key);
                if (s == null) continue;
                PlayerShop shop = new PlayerShop();
                shop.ownerId = ownerId;
                shop.ownerName = s.getString("owner-name", "Player");
                shop.tier = s.getInt("tier", 1);
                shop.totalRevenue = s.getDouble("revenue", 0.0);
                shop.totalTaxPaid = s.getDouble("tax-paid", 0.0);
                shop.totalTransactions = s.getInt("transactions", 0);
                shop.totalUnitsSold = s.getInt("units-sold", 0);
                shop.totalVisits = s.getInt("visits", 0);
                shop.globalBulkMode = s.getBoolean("global-bulk-mode", false);
                shop.flashSaleEndsAt = s.getLong("flash-end", 0L);
                shop.flashSaleCooldownEndsAt = s.getLong("flash-cd", 0L);
                shop.recentSalesLog.addAll(s.getStringList("recent-sales"));

                for (String fId : s.getStringList("followers")) {
                    try { shop.followers.add(UUID.fromString(fId)); } catch (Exception ignored) {}
                }
                ConfigurationSection rSec = s.getConfigurationSection("ratings");
                if (rSec != null) {
                    for (String rKey : rSec.getKeys(false)) {
                        shop.ratings.put(UUID.fromString(rKey), rSec.getInt(rKey));
                    }
                }
                ConfigurationSection pSec = s.getConfigurationSection("products");
                if (pSec != null) {
                    for (String pKey : pSec.getKeys(false)) {
                        ItemStack item = pSec.getItemStack(pKey + ".item");
                        double price = pSec.getDouble(pKey + ".price", 10.0);
                        boolean bulk = pSec.getBoolean(pKey + ".bulk", false);
                        if (item != null && !item.getType().isAir()) {
                            ShopProduct prod = new ShopProduct(item, price, bulk);
                            prod.soldUnits = pSec.getInt(pKey + ".sold-units", 0);
                            prod.revenueGenerated = pSec.getDouble(pKey + ".rev-gen", 0.0);
                            shop.products.add(prod);
                        }
                    }
                }
                shops.put(ownerId, shop);
            } catch (Exception ignored) {}
        }
    }

    public void saveAll() {
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        YamlConfiguration cfg = new YamlConfiguration();
        for (PlayerShop shop : shops.values()) {
            String path = "shops." + shop.ownerId;
            cfg.set(path + ".owner-name", shop.ownerName);
            cfg.set(path + ".tier", shop.tier);
            cfg.set(path + ".revenue", shop.totalRevenue);
            cfg.set(path + ".tax-paid", shop.totalTaxPaid);
            cfg.set(path + ".transactions", shop.totalTransactions);
            cfg.set(path + ".units-sold", shop.totalUnitsSold);
            cfg.set(path + ".visits", shop.totalVisits);
            cfg.set(path + ".global-bulk-mode", shop.globalBulkMode);
            cfg.set(path + ".flash-end", shop.flashSaleEndsAt);
            cfg.set(path + ".flash-cd", shop.flashSaleCooldownEndsAt);
            cfg.set(path + ".recent-sales", shop.recentSalesLog);

            List<String> fIds = new ArrayList<>();
            shop.followers.forEach(u -> fIds.add(u.toString()));
            cfg.set(path + ".followers", fIds);

            for (Map.Entry<UUID, Integer> e : shop.ratings.entrySet()) {
                cfg.set(path + ".ratings." + e.getKey(), e.getValue());
            }
            for (int i = 0; i < shop.products.size(); i++) {
                ShopProduct p = shop.products.get(i);
                cfg.set(path + ".products." + i + ".item", p.item);
                cfg.set(path + ".products." + i + ".price", p.unitPrice);
                cfg.set(path + ".products." + i + ".bulk", p.bulkEnabled);
                cfg.set(path + ".products." + i + ".sold-units", p.soldUnits);
                cfg.set(path + ".products." + i + ".rev-gen", p.revenueGenerated);
            }
        }
        try {
            cfg.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save shops.yml: " + e.getMessage());
        }
    }

    public PlayerShop getOrCreateShop(Player owner) {
        PlayerShop existing = shops.get(owner.getUniqueId());
        if (existing != null) {
            existing.ownerName = owner.getName();
            return existing;
        }
        String prefix = plugin.getConfig().getString("general.prefix", "");
        double createCost = plugin.getConfig().getDouble("player-shops.creation-cost", 300.0);
        if (plugin.getEconomy() != null && createCost > 0) {
            if (!plugin.getEconomy().has(owner, createCost)) {
                owner.sendMessage(ColorUtils.componentFor(owner, prefix + "&cتحتاج إلى &#FFD166&l" + createCost + "$ &cلفتح متجرك التجاري لأول مرة!"));
                plugin.getSoundManager().play(owner, "error");
                return null;
            }
            plugin.getEconomy().withdrawPlayer(owner, createCost);
            owner.sendMessage(ColorUtils.componentFor(owner, prefix + "&#06D6A0&l✔ مبروك! تم افتتاح متجرك بنجاح برتبة &7&lتاجر مبتدئ."));
            plugin.getSoundManager().play(owner, "purchase");
        }
        PlayerShop created = new PlayerShop();
        created.ownerId = owner.getUniqueId();
        created.ownerName = owner.getName();
        shops.put(owner.getUniqueId(), created);
        saveAll();
        return created;
    }

    public void addHandItemToShop(Player owner, double price, boolean bulk) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (price <= 0) {
            owner.sendMessage(ColorUtils.componentFor(owner, prefix + "&cيجب أن يكون السعر أكبر من صفر!"));
            return;
        }
        ItemStack hand = owner.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            owner.sendMessage(ColorUtils.componentFor(owner, prefix + "&cامسك الغرض الذي تريد عرضه في يدك أولاً!"));
            return;
        }
        PlayerShop shop = getOrCreateShop(owner);
        if (shop == null) return;

        int maxSlots = getTierSlots(shop.tier);
        if (shop.products.size() >= maxSlots) {
            owner.sendMessage(ColorUtils.componentFor(owner, prefix + "&cوصل متجرك للحد الأقصى (&e" + maxSlots + " منتج&c)! ارتقِ لرتبة تجارية أعلى لإضافة المزيد."));
            plugin.getSoundManager().play(owner, "error");
            return;
        }

        boolean effectiveBulk = bulk || shop.globalBulkMode;
        shop.products.add(new ShopProduct(hand, price, effectiveBulk));
        saveAll();
        owner.sendMessage(ColorUtils.componentFor(owner, prefix + "&#06D6A0&l✔ تمت إضافة &f&l" + hand.getType().name()
                + " &#06D6A0&lلمتجرك بسعر &#FFD166&l" + price + "$ "
                + (effectiveBulk ? "&#06D6A0(جملة مفعّلة)" : "&7(بيع فردي)")));
        plugin.getSoundManager().play(owner, "restock");
    }

    public void openDirectoryGui(Player viewer, int page) {
        String title = plugin.getConfig().getString("player-shops.gui.directory-title", "سوق اللاعبين");
        boolean favOnly = favoritesOnlyFilter.contains(viewer.getUniqueId());
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.SHOP_DIRECTORY)
                .with("page", page);
        Inventory inv = GuiBuilder.create(viewer, holder, 54, title);

        boolean strictAllBulk = plugin.getConfig().getBoolean("player-shops.bulk-discount.only-show-badge-when-all-items-enabled", true);
        int discountPct = plugin.getConfig().getInt("player-shops.bulk-discount.default-discount-percent", 15);
        int flashPct = plugin.getConfig().getInt("player-shops.flash-sale.extra-discount-percent", 20);

        List<PlayerShop> sorted = new ArrayList<>();
        for (PlayerShop s : shops.values()) {
            if (favOnly && !s.followers.contains(viewer.getUniqueId())) continue;
            sorted.add(s);
        }

        sorted.sort((a, b) -> {
            int flashCmp = Boolean.compare(b.isFlashSaleActive(), a.isFlashSaleActive());
            if (flashCmp != 0) return flashCmp;
            int tierCmp = Integer.compare(b.tier, a.tier);
            if (tierCmp != 0) return tierCmp;
            return Double.compare(b.getAverageRating(), a.getAverageRating());
        });

        int perPage = DIRECTORY_SLOTS.length;
        int start = page * perPage;
        for (int i = 0; i < perPage && (start + i) < sorted.size(); i++) {
            PlayerShop shop = sorted.get(start + i);
            boolean showBulkBadge = strictAllBulk ? shop.isAllProductsBulkEligible() : shop.globalBulkMode;
            String bulkLine = showBulkBadge
                    ? plugin.getConfig().getString("player-shops.gui.bulk-active-line", "").replace("%discount%", String.valueOf(discountPct))
                    : "";

            String flashLine = shop.isFlashSaleActive()
                    ? plugin.getConfig().getString("player-shops.gui.flash-sale-line", "")
                        .replace("%flash%", String.valueOf(flashPct))
                        .replace("%flash_time%", formatMinutes(shop.flashSaleEndsAt - System.currentTimeMillis()))
                    : "";

            String tierBadge = plugin.getConfig().getString("player-shops.tiers." + shop.tier + ".badge", "&7[مبتدئ]");
            List<String> rawLore = plugin.getConfig().getStringList("player-shops.gui.shop-icon-lore");
            List<String> finalLore = new ArrayList<>();
            for (String line : rawLore) {
                String parsed = line
                        .replace("%owner%", shop.ownerName)
                        .replace("%tier_badge%", tierBadge)
                        .replace("%rating%", String.valueOf(shop.getAverageRating()))
                        .replace("%votes%", String.valueOf(shop.ratings.size()))
                        .replace("%items_count%", String.valueOf(shop.products.size()))
                        .replace("%flash_sale_line%", flashLine)
                        .replace("%bulk_status_line%", bulkLine);
                if (!parsed.trim().isEmpty()) finalLore.add(parsed);
            }

            Material icon = shop.isFlashSaleActive()
                    ? Material.BLAZE_POWDER
                    : GuiBuilder.parseMaterial(plugin.getConfig().getString("player-shops.tiers." + shop.tier + ".icon"), Material.BARREL);
            int slot = DIRECTORY_SLOTS[i];
            holder.with("slot_" + slot, shop.ownerId.toString());
            inv.setItem(slot, GuiBuilder.makeItem(viewer, icon, "&#FF4D6D&l✦ &f&lمتجر &#FFD166&l" + shop.ownerName, finalLore));
        }

        if (sorted.isEmpty()) {
            inv.setItem(22, GuiBuilder.makeItem(viewer, Material.BARRIER,
                    favOnly ? "&#FF758F&lلا توجد متاجر في مفضلتك بعد" : "&#FF4D6D&lلا توجد متاجر حالياً",
                    Arrays.asList("&7افتح متجرك التجاري الآن وابدأ رحلتك نحو رتبة", "&#FF4D6D&lإمبراطور ستروبيري التجاري!")));
        }

        inv.setItem(45, GuiBuilder.backButton(viewer));
        inv.setItem(47, GuiBuilder.makeItem(viewer, favOnly ? Material.PINK_DYE : Material.GRAY_DYE,
                favOnly ? "&#FF758F&l♥ عرض: متاجري المفضلة فقط" : "&7&l♥ عرض: جميع المتاجر",
                Collections.singletonList("&7اضغط للتبديل بين جميع المتاجر ومتاجرك المفضلة.")));

        inv.setItem(49, GuiBuilder.makeItem(viewer, Material.EMERALD, "&#06D6A0&l✦ إدارة متجرك وإحصائياتك",
                Arrays.asList(
                        "&7لوحة الإدارة + إحصائياتك الخاصة السرية",
                        "&7+ مسار ترقية الرتب الـ 7 + العروض الخاطفة.",
                        "",
                        "&#FF758F&l» &f&lاضغط للفتح"
                )));

        if (page > 0) inv.setItem(48, GuiBuilder.makeItem(viewer, Material.SPECTRAL_ARROW, "&#FFD166&l« السابق", null));
        if ((page + 1) * perPage < sorted.size()) inv.setItem(50, GuiBuilder.makeItem(viewer, Material.SPECTRAL_ARROW, "&#FFD166&lالتالي »", null));

        viewer.openInventory(inv);
        plugin.getSoundManager().play(viewer, "open-gui");
    }

    public void openShopView(Player viewer, UUID ownerId, int page) {
        PlayerShop shop = shops.get(ownerId);
        if (shop == null) return;
        if (!viewer.getUniqueId().equals(ownerId) && page == 0) {
            shop.totalVisits++;
        }

        boolean bulkBuyMode = bedrockBulkBuyMode.contains(viewer.getUniqueId());
        boolean isFollowing = shop.followers.contains(viewer.getUniqueId());
        int bulkQty = plugin.getConfig().getInt("player-shops.bulk-discount.min-quantity-for-bulk", 16);
        int discountPct = plugin.getConfig().getInt("player-shops.bulk-discount.default-discount-percent", 15);
        int flashPct = shop.isFlashSaleActive() ? plugin.getConfig().getInt("player-shops.flash-sale.extra-discount-percent", 20) : 0;

        String title = plugin.getConfig().getString("player-shops.gui.shop-view-title", "متجر %owner%")
                .replace("%owner%", shop.ownerName);

        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.SHOP_VIEW)
                .with("owner", ownerId.toString())
                .with("page", page);
        Inventory inv = GuiBuilder.create(viewer, holder, 54, title);

        int perPage = PRODUCT_SLOTS.length;
        int start = page * perPage;
        for (int i = 0; i < perPage && (start + i) < shop.products.size(); i++) {
            int prodIndex = start + i;
            ShopProduct prod = shop.products.get(prodIndex);
            double effectiveUnit = round2(prod.unitPrice * (1.0 - (flashPct / 100.0)));

            ItemStack display = prod.item.clone();
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                List<String> lore = new ArrayList<>();
                lore.add("&#FFB3C1&l━━━━━━━━━━━━━━━━━━");
                if (flashPct > 0) {
                    lore.add("&7السعر الأصلي: &c&m" + prod.unitPrice + "$");
                    lore.add("&#FF4D6D&l🔥 سعر العرض الخاطف: &#FFD166&l" + effectiveUnit + "$ &a(-" + flashPct + "%)");
                } else {
                    lore.add("&7سعر الحبة: &#FFD166&l" + effectiveUnit + "$");
                }
                if (prod.bulkEnabled) {
                    double bulkTotal = round2(effectiveUnit * bulkQty * (1.0 - (discountPct / 100.0)));
                    lore.add("&#06D6A0&l✔ خصم الجملة (" + bulkQty + "x): &#FFD166&l" + bulkTotal + "$ &a(-" + discountPct + "%)");
                    lore.add("&7كليك يسار: &fشراء 1 حبة");
                    lore.add("&7كليك يمين / وضع الجملة: &aشراء " + bulkQty + " حبة بالخصم");
                } else {
                    lore.add("&7اضغط للشراء: &f1 حبة بسعر &#FFD166&l" + effectiveUnit + "$");
                }
                lore.add("&#FFB3C1&l━━━━━━━━━━━━━━━━━━");
                meta.lore(ColorUtils.loreFor(viewer, lore));
                display.setItemMeta(meta);
            }
            int slot = PRODUCT_SLOTS[i];
            holder.with("prod_" + slot, prodIndex);
            inv.setItem(slot, display);
        }

        inv.setItem(45, GuiBuilder.makeItem(viewer, Material.ARROW, "&#FF4D6D&l« العودة لسوق اللاعبين", null));
        inv.setItem(47, GuiBuilder.makeItem(viewer, isFollowing ? Material.ROSE_BUSH : Material.DEAD_BUSH,
                isFollowing ? "&#FF758F&l♥ متابَع (في مفضلتك)" : "&7&l♡ متابعة المتجر",
                Collections.singletonList("&7يصلك إشعار فوري عند تفعيل التاجر لعرض خاطف!")));
        inv.setItem(48, GuiBuilder.makeItem(viewer,
                bulkBuyMode ? Material.LIME_DYE : Material.GRAY_DYE,
                bulkBuyMode ? "&#06D6A0&l✦ وضع الشراء: جملة (" + bulkQty + "x)" : "&7&l✦ وضع الشراء: فردي (1x)",
                Arrays.asList("&7مخصص للمس السريع على Bedrock!", "&7اضغط للتبديل بين الفردي والجملة.")));
        inv.setItem(50, GuiBuilder.makeItem(viewer, Material.NETHER_STAR, "&#FFD166&l★ تقييم المتجر (" + shop.getAverageRating() + "/5)",
                Collections.singletonList("&7اضغط لفتح نافذة التقييم من 1 إلى 5 نجوم.")));

        if (page > 0) inv.setItem(46, GuiBuilder.makeItem(viewer, Material.SPECTRAL_ARROW, "&#FFD166&l« صفحة سابقة", null));
        if ((page + 1) * perPage < shop.products.size()) inv.setItem(52, GuiBuilder.makeItem(viewer, Material.SPECTRAL_ARROW, "&#FFD166&lصفحة تالية »", null));

        viewer.openInventory(inv);
        plugin.getSoundManager().play(viewer, "open-gui");
    }

    public void openManageGui(Player owner, int page) {
        PlayerShop shop = getOrCreateShop(owner);
        if (shop == null) return;

        String tierName = plugin.getConfig().getString("player-shops.tiers." + shop.tier + ".name", "تاجر مبتدئ");
        String title = plugin.getConfig().getString("player-shops.gui.manage-title", "إدارة متجرك")
                .replace("%tier%", tierName);

        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.SHOP_MANAGE)
                .with("page", page);
        Inventory inv = GuiBuilder.create(owner, holder, 54, title);

        int perPage = PRODUCT_SLOTS.length;
        int start = page * perPage;
        for (int i = 0; i < perPage && (start + i) < shop.products.size(); i++) {
            int prodIdx = start + i;
            ShopProduct prod = shop.products.get(prodIdx);
            ItemStack display = prod.item.clone();
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                List<String> lore = Arrays.asList(
                        "&#FFB3C1&l━━━━━━━━━━━━━━━━━━",
                        "&7السعر: &#FFD166&l" + prod.unitPrice + "$",
                        "&7المبيعات (سري لك): &#06D6A0&l" + prod.soldUnits + " وحدة (" + round2(prod.revenueGenerated) + "$)",
                        "&7خصم الجملة: " + (prod.bulkEnabled ? "&#06D6A0&lمفعل ✔" : "&c&lمعطل ✖"),
                        "",
                        "&eكليك يسار: &fتبديل خصم الجملة للمنتج",
                        "&cكليك يمين / Shift: &fحذف المنتج",
                        "&#FFB3C1&l━━━━━━━━━━━━━━━━━━"
                );
                meta.lore(ColorUtils.loreFor(owner, lore));
                display.setItemMeta(meta);
            }
            int slot = PRODUCT_SLOTS[i];
            holder.with("manage_prod_" + slot, prodIdx);
            inv.setItem(slot, display);
        }

        boolean allEligible = shop.isAllProductsBulkEligible();
        inv.setItem(45, GuiBuilder.makeItem(owner, Material.ARROW, "&#FF4D6D&l« العودة لسوق اللاعبين", null));
        inv.setItem(47, GuiBuilder.makeItem(owner,
                allEligible ? Material.LIME_CONCRETE : Material.RED_CONCRETE,
                allEligible ? "&#06D6A0&l✔ خصم الجملة الشامل: مفعل لكل المنتجات" : "&#FF4D6D&l✖ خصم الجملة الشامل: غير مفعل بالكامل",
                Arrays.asList(
                        "&7عند التفعيل يُطبّق على &f&lكل منتجاتك",
                        "&7وتظهر شارة الجملة الرسمية على متجرك في الدليل.",
                        "",
                        "&#FFD166&l» اضغط للتفعيل / الإيقاف الشامل"
                )));
        inv.setItem(48, GuiBuilder.makeItem(owner, Material.SPYGLASS, "&#06D6A0&l✦ لوحة الإحصائيات والتحليلات (سري)",
                Arrays.asList(
                        "&7الأرباح، المبيعات، الضرائب، معدل التحويل،",
                        "&7أكثر منتج مبيعاً، وآخر صفقات متجرك.",
                        "&8(مخفية تماماً عن باقي اللاعبين!)"
                )));

        int minFlashTier = plugin.getConfig().getInt("player-shops.flash-sale.min-tier-required", 3);
        inv.setItem(49, GuiBuilder.makeItem(owner, shop.isFlashSaleActive() ? Material.BLAZE_POWDER : Material.FIRE_CHARGE,
                shop.isFlashSaleActive() ? "&#FF4D6D&l🔥 عرض خاطف نشط الآن!" : "&#FFD166&l✦ إطلاق عرض خاطف (Flash Sale)",
                Arrays.asList(
                        "&7خصم إضافي &e-" + plugin.getConfig().getInt("player-shops.flash-sale.extra-discount-percent", 20) + "% &7لمدة 15 دقيقة",
                        "&7مع إعلان فوري لمتابعي متجرك وتصدر الدليل!",
                        shop.tier < minFlashTier ? "&cيتطلب رتبة تاجر فضي (المستوى " + minFlashTier + ") فأعلى." : "&#06D6A0&l» اضغط للتشغيل"
                )));
        inv.setItem(50, GuiBuilder.makeItem(owner, Material.NETHER_STAR, "&#C77DFF&l✦ مسار ترقية الرتب التجارية (7 رتب)",
                Arrays.asList(
                        "&7رتبتك الحالية: " + tierName + " &7(" + shop.tier + "/7)",
                        "&7المنتجات: &f" + shop.products.size() + "/" + getTierSlots(shop.tier),
                        "",
                        "&#FFD166&l» اضغط لاستعراض الشروط والترقية"
                )));

        if (page > 0) inv.setItem(46, GuiBuilder.makeItem(owner, Material.SPECTRAL_ARROW, "&#FFD166&l« السابق", null));
        if ((page + 1) * perPage < shop.products.size()) inv.setItem(52, GuiBuilder.makeItem(owner, Material.SPECTRAL_ARROW, "&#FFD166&lالتالي »", null));

        owner.openInventory(inv);
        plugin.getSoundManager().play(owner, "open-gui");
    }

    public void openAnalyticsGui(Player owner) {
        PlayerShop shop = getOrCreateShop(owner);
        if (shop == null) return;

        String title = plugin.getConfig().getString("player-shops.gui.analytics-title", "لوحة إحصائيات متجرك");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.SHOP_ANALYTICS);
        Inventory inv = GuiBuilder.create(owner, holder, 45, title);

        double convRate = shop.totalVisits == 0 ? 0.0 : round2((shop.totalTransactions * 100.0) / shop.totalVisits);
        double taxPct = plugin.getConfig().getDouble("player-shops.tiers." + shop.tier + ".tax-percent", 6.0);

        inv.setItem(10, GuiBuilder.makeItem(owner, Material.EMERALD_BLOCK, "&#06D6A0&l✦ صافي الأرباح والإيرادات",
                Arrays.asList(
                        "&#FFB3C1&l━━━━━━━━━━━━━━━━━━",
                        "&7صافي أرباحك: &#06D6A0&l" + round2(shop.totalRevenue) + "$",
                        "&7الضرائب المدفوعة: &#FF4D6D&l" + round2(shop.totalTaxPaid) + "$",
                        "&7نسبة ضريبتك الحالية: &#FFD166&l" + taxPct + "%",
                        "&#FFB3C1&l━━━━━━━━━━━━━━━━━━"
                )));
        inv.setItem(12, GuiBuilder.makeItem(owner, Material.GOLD_INGOT, "&#FFD166&l✦ حجم المبيعات والزوار",
                Arrays.asList(
                        "&#FFB3C1&l━━━━━━━━━━━━━━━━━━",
                        "&7عدد الصفقات المكتملة: &#FFD166&l" + shop.totalTransactions + " صفقة",
                        "&7إجمالي الوحدات المباعة: &#06D6A0&l" + shop.totalUnitsSold + " وحدة",
                        "&7زيارات العملاء: &#FF8FA3&l" + shop.totalVisits + " زيارة",
                        "&7معدل التحويل للشراء: &#48CAE4&l" + convRate + "%",
                        "&7المتابعون: &#FF758F&l" + shop.followers.size() + " متابع",
                        "&#FFB3C1&l━━━━━━━━━━━━━━━━━━"
                )));

        ShopProduct top = shop.getTopSellingProduct();
        inv.setItem(14, GuiBuilder.makeItem(owner, top != null ? top.item.getType() : Material.BARRIER,
                "&#FF758F&l✦ المنتج الأكثر مبيعاً (Top Seller)",
                top != null ? Arrays.asList(
                        "&#FFB3C1&l━━━━━━━━━━━━━━━━━━",
                        "&7المنتج: &f&l" + top.item.getType().name(),
                        "&7الوحدات المباعة: &#06D6A0&l" + top.soldUnits,
                        "&7أرباح هذا المنتج: &#FFD166&l" + round2(top.revenueGenerated) + "$",
                        "&#FFB3C1&l━━━━━━━━━━━━━━━━━━"
                ) : Collections.singletonList("&7لا توجد مبيعات مسجلة بعد.")));

        int[] starCounts = new int[6];
        for (int r : shop.ratings.values()) {
            if (r >= 1 && r <= 5) starCounts[r]++;
        }
        inv.setItem(16, GuiBuilder.makeItem(owner, Material.NETHER_STAR, "&#FFD166&l★ تحليل تقييمات العملاء",
                Arrays.asList(
                        "&7المتوسط العام: &#FFD166&l" + shop.getAverageRating() + " / 5.0 &7(" + shop.ratings.size() + " تقييم)",
                        "&a5 نجوم: &f" + starCounts[5] + " &8| &24 نجوم: &f" + starCounts[4],
                        "&e3 نجوم: &f" + starCounts[3] + " &8| &62 نجمتان: &f" + starCounts[2] + " &8| &c1 نجمة: &f" + starCounts[1]
                )));

        List<String> recentLore = new ArrayList<>();
        recentLore.add("&#FFB3C1&l━━━━━━━━━━━━━━━━━━");
        if (shop.recentSalesLog.isEmpty()) {
            recentLore.add("&7لا توجد صفقات حديثة بعد.");
        } else {
            int limit = Math.min(8, shop.recentSalesLog.size());
            for (int i = 0; i < limit; i++) {
                recentLore.add("&f" + (i + 1) + ". " + shop.recentSalesLog.get(i));
            }
        }
        recentLore.add("&#FFB3C1&l━━━━━━━━━━━━━━━━━━");
        inv.setItem(22, GuiBuilder.makeItem(owner, Material.WRITABLE_BOOK, "&#48CAE4&l✦ آخر 8 عمليات بيع في متجرك", recentLore));

        inv.setItem(36, GuiBuilder.makeItem(owner, Material.ARROW, "&#FF4D6D&l« العودة لإدارة المتجر", null));
        owner.openInventory(inv);
        plugin.getSoundManager().play(owner, "open-gui");
    }

    public void openUpgradePathGui(Player owner) {
        PlayerShop shop = getOrCreateShop(owner);
        if (shop == null) return;

        String title = plugin.getConfig().getString("player-shops.gui.upgrade-title", "مسار ترقية الرتب");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.SHOP_UPGRADES);
        Inventory inv = GuiBuilder.create(owner, holder, 36, title);

        int[] tierSlots = {10, 11, 12, 13, 14, 15, 16};
        for (int t = 1; t <= 7; t++) {
            ConfigurationSection sec = plugin.getConfig().getConfigurationSection("player-shops.tiers." + t);
            if (sec == null) continue;

            String name = sec.getString("name", "رتبة " + t);
            int slots = sec.getInt("slots", 9);
            double tax = sec.getDouble("tax-percent", 5.0);
            int maxBulk = sec.getInt("max-bulk-discount", 15);
            double cost = sec.getDouble("requirements.upgrade-cost", 0.0);
            int reqSales = sec.getInt("requirements.min-sales-count", 0);
            double reqRev = sec.getDouble("requirements.min-revenue", 0.0);
            double reqRating = sec.getDouble("requirements.min-rating", 0.0);

            boolean unlocked = shop.tier >= t;
            boolean isNext = shop.tier + 1 == t;
            boolean meetsSales = shop.totalTransactions >= reqSales;
            boolean meetsRev = shop.totalRevenue >= reqRev;
            boolean meetsRating = shop.getAverageRating() >= reqRating;
            boolean meetsMoney = plugin.getEconomy() == null || plugin.getEconomy().has(owner, cost);

            List<String> lore = new ArrayList<>();
            lore.add("&#FFB3C1&l━━━━━━━━━━━━━━━━━━");
            lore.add("&7الخانات: &#06D6A0&l" + slots + " منتج &8| &7الضريبة: &#FFD166&l" + tax + "%");
            lore.add("&7أقصى خصم جملة: &#48CAE4&l" + maxBulk + "%");
            if (t >= 3) lore.add("&#FF758F&l✔ يدعم العروض الخاطفة (Flash Sales)");
            lore.add("&#FFB3C1&l━━━━━━━━━━━━━━━━━━");

            if (unlocked) {
                lore.add("&#06D6A0&l✔ تم فتح هذه الرتبة بنجاح!");
            } else {
                lore.add("&f&lمتطلبات الترقية:");
                lore.add((meetsSales ? "&#06D6A0✔ " : "&c✖ ") + "&7الصفقات: &f" + shop.totalTransactions + "/" + reqSales);
                lore.add((meetsRev ? "&#06D6A0✔ " : "&c✖ ") + "&7الأرباح: &f" + round2(shop.totalRevenue) + "$/" + reqRev + "$");
                lore.add((meetsRating ? "&#06D6A0✔ " : "&c✖ ") + "&7التقييم: &f" + shop.getAverageRating() + "/" + reqRating);
                lore.add((meetsMoney ? "&#06D6A0✔ " : "&c✖ ") + "&7رسم الترقية: &#FFD166&l" + cost + "$");
                lore.add("");
                if (isNext && meetsSales && meetsRev && meetsRating && meetsMoney) {
                    lore.add("&#06D6A0&l» اضغط الآن للترقية الفورية!");
                } else if (isNext) {
                    lore.add("&cأكمل جميع الشروط أولاً للترقية.");
                } else {
                    lore.add("&8افتح الرتبة السابقة أولاً.");
                }
            }

            Material icon = unlocked
                    ? GuiBuilder.parseMaterial(sec.getString("icon"), Material.EMERALD)
                    : (isNext ? Material.NETHER_STAR : Material.GRAY_STAINED_GLASS_PANE);
            holder.with("tier_" + tierSlots[t - 1], t);
            inv.setItem(tierSlots[t - 1], GuiBuilder.makeItem(owner, icon, name + " &8(#" + t + ")", lore));
        }

        inv.setItem(27, GuiBuilder.makeItem(owner, Material.ARROW, "&#FF4D6D&l« العودة لإدارة المتجر", null));
        owner.openInventory(inv);
        plugin.getSoundManager().play(owner, "open-gui");
    }

    public void openRatingGui(Player viewer, UUID ownerId) {
        PlayerShop shop = shops.get(ownerId);
        if (shop == null) return;
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.SHOP_RATE)
                .with("owner", ownerId.toString());
        Inventory inv = GuiBuilder.create(viewer, holder, 27, "&#FFD166&l★ تقييم متجر &f&l" + shop.ownerName);

        Material[] mats = {Material.RED_WOOL, Material.ORANGE_WOOL, Material.YELLOW_WOOL, Material.LIME_WOOL, Material.NETHER_STAR};
        String[] labels = {"&c★ 1 نجمة (ضعيف)", "&#FF758F★★ 2 نجمتان (مقبول)", "&#FFD166★★★ 3 نجوم (جيد)", "&#06D6A0★★★★ 4 نجوم (ممتاز)", "&#FFD166&l★★★★★ 5 نجوم (أسطوري!)"};
        for (int s = 1; s <= 5; s++) {
            int slot = 10 + s;
            holder.with("stars_" + slot, s);
            inv.setItem(slot, GuiBuilder.makeItem(viewer, mats[s - 1], labels[s - 1],
                    Collections.singletonList("&7اضغط لاعتماد تقييمك لهذا المتجر.")));
        }
        inv.setItem(18, GuiBuilder.makeItem(viewer, Material.ARROW, "&#FF4D6D&l« رجوع للمتجر", null));
        viewer.openInventory(inv);
        plugin.getSoundManager().play(viewer, "click");
    }

    public void handleDirectoryClick(Player p, StrawberryGuiHolder holder, int slot) {
        int page = holder.getInt("page", 0);
        if (slot == 45) { dispatchBackToMenu(p); return; }
        if (slot == 47) {
            if (favoritesOnlyFilter.contains(p.getUniqueId())) favoritesOnlyFilter.remove(p.getUniqueId());
            else favoritesOnlyFilter.add(p.getUniqueId());
            plugin.getSoundManager().play(p, "click");
            openDirectoryGui(p, 0);
            return;
        }
        if (slot == 49) { openManageGui(p, 0); return; }
        if (slot == 48 && page > 0) { openDirectoryGui(p, page - 1); return; }
        if (slot == 50) { openDirectoryGui(p, page + 1); return; }

        Object ownerRaw = holder.get("slot_" + slot);
        if (ownerRaw != null) openShopView(p, UUID.fromString(ownerRaw.toString()), 0);
    }

    public void handleShopViewClick(Player buyer, StrawberryGuiHolder holder, int slot, ClickType clickType) {
        UUID ownerId = UUID.fromString(holder.getString("owner", ""));
        int page = holder.getInt("page", 0);
        PlayerShop shop = shops.get(ownerId);
        if (shop == null) return;
        String prefix = plugin.getConfig().getString("general.prefix", "");

        if (slot == 45) { openDirectoryGui(buyer, 0); return; }
        if (slot == 46 && page > 0) { openShopView(buyer, ownerId, page - 1); return; }
        if (slot == 52) { openShopView(buyer, ownerId, page + 1); return; }
        if (slot == 47) {
            if (shop.followers.contains(buyer.getUniqueId())) shop.followers.remove(buyer.getUniqueId());
            else shop.followers.add(buyer.getUniqueId());
            saveAll();
            plugin.getSoundManager().play(buyer, "click");
            openShopView(buyer, ownerId, page);
            return;
        }
        if (slot == 48) {
            if (bedrockBulkBuyMode.contains(buyer.getUniqueId())) bedrockBulkBuyMode.remove(buyer.getUniqueId());
            else bedrockBulkBuyMode.add(buyer.getUniqueId());
            plugin.getSoundManager().play(buyer, "click");
            openShopView(buyer, ownerId, page);
            return;
        }
        if (slot == 50) {
            if (buyer.getUniqueId().equals(ownerId)) {
                buyer.sendMessage(ColorUtils.componentFor(buyer, prefix + "&cلا يمكنك تقييم متجرك الشخصي!"));
                plugin.getSoundManager().play(buyer, "error");
                return;
            }
            openRatingGui(buyer, ownerId);
            return;
        }

        Object prodIdxObj = holder.get("prod_" + slot);
        if (!(prodIdxObj instanceof Integer idx) || idx >= shop.products.size()) return;

        ShopProduct prod = shop.products.get(idx);
        boolean wantBulk = prod.bulkEnabled && (clickType.isRightClick() || bedrockBulkBuyMode.contains(buyer.getUniqueId()));
        int qty = wantBulk ? plugin.getConfig().getInt("player-shops.bulk-discount.min-quantity-for-bulk", 16) : 1;
        int bulkPct = wantBulk ? plugin.getConfig().getInt("player-shops.bulk-discount.default-discount-percent", 15) : 0;
        int flashPct = shop.isFlashSaleActive() ? plugin.getConfig().getInt("player-shops.flash-sale.extra-discount-percent", 20) : 0;

        double afterFlash = prod.unitPrice * (1.0 - (flashPct / 100.0));
        double totalPrice = round2(afterFlash * qty * (1.0 - (bulkPct / 100.0)));

        if (plugin.getEconomy() != null) {
            if (!plugin.getEconomy().has(buyer, totalPrice)) {
                buyer.sendMessage(ColorUtils.componentFor(buyer, prefix + "&cرصيدك غير كافٍ! السعر: &#FFD166&l" + totalPrice + "$"));
                plugin.getSoundManager().play(buyer, "error");
                return;
            }
            double taxPct = plugin.getConfig().getDouble("player-shops.tiers." + shop.tier + ".tax-percent", 6.0);
            double taxAmt = round2(totalPrice * (taxPct / 100.0));
            double ownerShare = round2(totalPrice - taxAmt);

            plugin.getEconomy().withdrawPlayer(buyer, totalPrice);
            OfflinePlayer offlineOwner = Bukkit.getOfflinePlayer(ownerId);
            plugin.getEconomy().depositPlayer(offlineOwner, ownerShare);

            shop.totalRevenue += ownerShare;
            shop.totalTaxPaid += taxAmt;
            shop.totalTransactions++;
            shop.totalUnitsSold += qty;
            prod.soldUnits += qty;
            prod.revenueGenerated += ownerShare;
            shop.recentSalesLog.add(0, "&#FFD166" + buyer.getName() + " &7اشترى &f" + qty + "x " + prod.item.getType().name() + " &#06D6A0(+" + ownerShare + "$)");
            while (shop.recentSalesLog.size() > 15) shop.recentSalesLog.remove(shop.recentSalesLog.size() - 1);
            saveAll();

            plugin.getHistoryManager().log(buyer.getUniqueId(), HistoryManager.EntryType.SHOP,
                    "شراء من متجر " + shop.ownerName, qty + "x " + prod.item.getType().name(), -totalPrice);
            plugin.getHistoryManager().log(ownerId, HistoryManager.EntryType.SHOP,
                    "بيع في متجرك لـ " + buyer.getName(), qty + "x " + prod.item.getType().name() + " (ضريبة " + taxAmt + "$)", ownerShare);

            Player onlineOwner = Bukkit.getPlayer(ownerId);
            if (onlineOwner != null && onlineOwner.isOnline()) {
                onlineOwner.sendMessage(ColorUtils.componentFor(onlineOwner,
                        prefix + "&#06D6A0&l✔ باع متجرك &f&l" + qty + "x " + prod.item.getType().name()
                                + " &7إلى &#FFD166&l" + buyer.getName() + " &7وصافيك &#06D6A0&l+" + ownerShare + "$"));
                plugin.getSoundManager().play(onlineOwner, "success");
            }
        }

        ItemStack give = prod.item.clone();
        give.setAmount(qty);
        HashMap<Integer, ItemStack> left = buyer.getInventory().addItem(give);
        left.values().forEach(rem -> buyer.getWorld().dropItemNaturally(buyer.getLocation(), rem));

        buyer.sendMessage(ColorUtils.componentFor(buyer,
                prefix + "&#06D6A0&l✔ اشتريت &f&l" + qty + "x " + prod.item.getType().name() + " &7مقابل &#FFD166&l" + totalPrice + "$"));
        plugin.getSoundManager().play(buyer, "purchase");
    }

    public void handleManageClick(Player owner, StrawberryGuiHolder holder, int slot, ClickType clickType) {
        PlayerShop shop = shops.get(owner.getUniqueId());
        if (shop == null) return;
        int page = holder.getInt("page", 0);
        String prefix = plugin.getConfig().getString("general.prefix", "");

        if (slot == 45) { openDirectoryGui(owner, 0); return; }
        if (slot == 46 && page > 0) { openManageGui(owner, page - 1); return; }
        if (slot == 52) { openManageGui(owner, page + 1); return; }
        if (slot == 48) { openAnalyticsGui(owner); return; }
        if (slot == 50) { openUpgradePathGui(owner); return; }

        if (slot == 47) {
            boolean newState = !shop.isAllProductsBulkEligible();
            shop.globalBulkMode = newState;
            for (ShopProduct p : shop.products) p.bulkEnabled = newState;
            saveAll();
            owner.sendMessage(ColorUtils.componentFor(owner, prefix + (newState
                    ? "&#06D6A0&l✔ تم تفعيل خصم الجملة الشامل لجميع منتجات متجرك!"
                    : "&eتم إيقاف خصم الجملة الشامل وإخفاء شارة الجملة عن المتجر.")));
            plugin.getSoundManager().play(owner, "success");
            openManageGui(owner, page);
            return;
        }

        if (slot == 49) {
            int minTier = plugin.getConfig().getInt("player-shops.flash-sale.min-tier-required", 3);
            if (shop.tier < minTier) {
                owner.sendMessage(ColorUtils.componentFor(owner, prefix + "&cالعروض الخاطفة تفتح من رتبة التاجر الفضي (المستوى " + minTier + ")!"));
                plugin.getSoundManager().play(owner, "error");
                return;
            }
            long now = System.currentTimeMillis();
            if (shop.flashSaleCooldownEndsAt > now) {
                owner.sendMessage(ColorUtils.componentFor(owner, prefix + "&cيمكنك إطلاق عرض خاطف جديد بعد &#FFD166&l" + formatMinutes(shop.flashSaleCooldownEndsAt - now)));
                plugin.getSoundManager().play(owner, "error");
                return;
            }
            long durMs = plugin.getConfig().getLong("player-shops.flash-sale.duration-minutes", 15) * 60_000L;
            long cdMs = plugin.getConfig().getLong("player-shops.flash-sale.cooldown-minutes", 120) * 60_000L;
            int flashPct = plugin.getConfig().getInt("player-shops.flash-sale.extra-discount-percent", 20);
            shop.flashSaleEndsAt = now + durMs;
            shop.flashSaleCooldownEndsAt = now + cdMs;
            saveAll();

            String broadcast = prefix + "&#FF4D6D&l🔥 عرض خاطف! &fأطلق متجر &#FFD166&l" + owner.getName()
                    + " &fخصماً إضافياً &#06D6A0&l-" + flashPct + "% &fلمدة 15 دقيقة! استخدم &#FF758F&l/shop";
            Bukkit.getOnlinePlayers().forEach(pl -> {
                pl.sendMessage(ColorUtils.componentFor(pl, broadcast));
                if (shop.followers.contains(pl.getUniqueId())) plugin.getSoundManager().play(pl, "boost");
            });
            plugin.getSoundManager().play(owner, "boost");
            openManageGui(owner, page);
            return;
        }

        Object prodIdxObj = holder.get("manage_prod_" + slot);
        if (!(prodIdxObj instanceof Integer idx) || idx >= shop.products.size()) return;

        if (clickType.isRightClick() || clickType.isShiftClick()) {
            shop.products.remove((int) idx);
            saveAll();
            owner.sendMessage(ColorUtils.componentFor(owner, prefix + "&cتم حذف المنتج من متجرك."));
        } else {
            ShopProduct prod = shop.products.get(idx);
            prod.bulkEnabled = !prod.bulkEnabled;
            if (!prod.bulkEnabled) shop.globalBulkMode = false;
            saveAll();
        }
        plugin.getSoundManager().play(owner, "click");
        openManageGui(owner, page);
    }

    public void handleAnalyticsClick(Player owner, int slot) {
        if (slot == 36) openManageGui(owner, 0);
    }

    public void handleUpgradesClick(Player owner, StrawberryGuiHolder holder, int slot) {
        if (slot == 27) { openManageGui(owner, 0); return; }
        Object tObj = holder.get("tier_" + slot);
        if (!(tObj instanceof Integer targetTier)) return;

        PlayerShop shop = shops.get(owner.getUniqueId());
        if (shop == null || targetTier != shop.tier + 1) return;

        String prefix = plugin.getConfig().getString("general.prefix", "");
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("player-shops.tiers." + targetTier);
        if (sec == null) return;

        double cost = sec.getDouble("requirements.upgrade-cost", 0.0);
        int reqSales = sec.getInt("requirements.min-sales-count", 0);
        double reqRev = sec.getDouble("requirements.min-revenue", 0.0);
        double reqRating = sec.getDouble("requirements.min-rating", 0.0);

        if (shop.totalTransactions < reqSales || shop.totalRevenue < reqRev || shop.getAverageRating() < reqRating) {
            owner.sendMessage(ColorUtils.componentFor(owner, prefix + "&cلم تكمل متطلبات المبيعات أو الأرباح أو التقييم لهذه الرتبة بعد!"));
            plugin.getSoundManager().play(owner, "error");
            return;
        }
        if (plugin.getEconomy() != null && !plugin.getEconomy().has(owner, cost)) {
            owner.sendMessage(ColorUtils.componentFor(owner, prefix + "&cرصيدك غير كافٍ لدفع رسم الترقية (&#FFD166&l" + cost + "$&c)!"));
            plugin.getSoundManager().play(owner, "error");
            return;
        }
        if (plugin.getEconomy() != null && cost > 0) plugin.getEconomy().withdrawPlayer(owner, cost);

        shop.tier = targetTier;
        saveAll();
        String newName = sec.getString("name", "رتبة " + targetTier);
        Bukkit.getOnlinePlayers().forEach(pl -> pl.sendMessage(ColorUtils.componentFor(pl,
                prefix + "&#FFD166&l★ تهانينا! &fارتقى التاجر &#FF758F&l" + owner.getName() + " &fإلى رتبة " + newName + "!")));
        plugin.getSoundManager().play(owner, "boost");
        openUpgradePathGui(owner);
    }

    public void handleRateClick(Player viewer, StrawberryGuiHolder holder, int slot) {
        UUID ownerId = UUID.fromString(holder.getString("owner", ""));
        if (slot == 18) { openShopView(viewer, ownerId, 0); return; }
        Object sObj = holder.get("stars_" + slot);
        if (!(sObj instanceof Integer stars)) return;

        PlayerShop shop = shops.get(ownerId);
        if (shop == null) return;
        shop.ratings.put(viewer.getUniqueId(), stars);
        saveAll();
        String prefix = plugin.getConfig().getString("general.prefix", "");
        viewer.sendMessage(ColorUtils.componentFor(viewer, prefix + "&#FFD166&l★ تم تسجيل تقييمك (" + stars + "/5) لمتجر " + shop.ownerName + "!"));
        plugin.getSoundManager().play(viewer, "success");
        openShopView(viewer, ownerId, 0);
    }

    private int getTierSlots(int tier) {
        return plugin.getConfig().getInt("player-shops.tiers." + tier + ".slots", 9);
    }

    private String formatMinutes(long ms) {
        long mins = Math.max(1, ms / 60_000L);
        return mins + " د";
    }

    private double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    private void dispatchBackToMenu(Player p) {
        String cmd = plugin.getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                .replace("%player%", p.getName());
        p.closeInventory();
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
    }
}
