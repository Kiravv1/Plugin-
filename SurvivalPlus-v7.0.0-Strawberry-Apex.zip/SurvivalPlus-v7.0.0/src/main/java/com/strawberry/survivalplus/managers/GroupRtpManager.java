package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ColorUtils;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;
import java.util.*;

public class GroupRtpManager {

    private final SurvivalPlus plugin;
    private final Random random = new Random();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, Location> pos1Selection = new HashMap<>();
    private final Map<UUID, Location> pos2Selection = new HashMap<>();
    private final Set<UUID> lastZonePlayers = new HashSet<>();

    private BossBar bossBar;
    private UUID holoLine1Id;
    private UUID holoLine2Id;
    private int countdown = -1;
    private double particleAngle = 0.0;
    private BukkitRunnable task;

    public GroupRtpManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        if (bossBar != null) bossBar.removeAll();
        removeZoneHologram();

        String colorName = plugin.getConfig().getString("group-rtp.visuals-and-audio.bossbar-color", "PINK");
        BarColor color;
        try {
            color = BarColor.valueOf(colorName.toUpperCase());
        } catch (Exception e) {
            color = BarColor.PINK;
        }
        bossBar = Bukkit.createBossBar("", color, BarStyle.SEGMENTED_10);
        bossBar.setVisible(false);
        countdown = -1;

        if (plugin.getConfig().getBoolean("group-rtp.enabled", true)
                && plugin.getConfig().getBoolean("group-rtp.zone.configured", false)
                && plugin.getConfig().getBoolean("group-rtp.zone.hologram-enabled", true)) {
            spawnZoneHologram(0);
        }
    }

    public void setPos1(Player p) {
        pos1Selection.put(p.getUniqueId(), p.getLocation().getBlock().getLocation());
        checkAndSaveBounds(p);
    }

    public void setPos2(Player p) {
        pos2Selection.put(p.getUniqueId(), p.getLocation().getBlock().getLocation());
        checkAndSaveBounds(p);
    }

    private void checkAndSaveBounds(Player p) {
        Location l1 = pos1Selection.get(p.getUniqueId());
        Location l2 = pos2Selection.get(p.getUniqueId());
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (l1 != null && l2 != null && l1.getWorld() != null && l1.getWorld().equals(l2.getWorld())) {
            saveZone(l1.getWorld().getName(),
                    Math.min(l1.getBlockX(), l2.getBlockX()), Math.min(l1.getBlockY(), l2.getBlockY()), Math.min(l1.getBlockZ(), l2.getBlockZ()),
                    Math.max(l1.getBlockX(), l2.getBlockX()), Math.max(l1.getBlockY(), l2.getBlockY()) + 3, Math.max(l1.getBlockZ(), l2.getBlockZ()));
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ تم حفظ بوابة الانتقال الجماعي بنجاح وتفعيل الهولوجرام!"));
            plugin.getSoundManager().play(p, "success");
        } else {
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&#FFD166&l✦ تم تحديد النقطة بنجاح! حدد النقطة الأخرى لإكمال البوابة."));
            plugin.getSoundManager().play(p, "click");
        }
    }

    public void saveQuickZone(Player p) {
        Location l = p.getLocation();
        saveZone(l.getWorld().getName(),
                l.getBlockX() - 3, l.getBlockY() - 1, l.getBlockZ() - 3,
                l.getBlockX() + 3, l.getBlockY() + 3, l.getBlockZ() + 3);
    }

    private void saveZone(String world, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        plugin.getConfig().set("group-rtp.zone.configured", true);
        plugin.getConfig().set("group-rtp.zone.world", world);
        plugin.getConfig().set("group-rtp.zone.min-x", minX);
        plugin.getConfig().set("group-rtp.zone.min-y", minY);
        plugin.getConfig().set("group-rtp.zone.min-z", minZ);
        plugin.getConfig().set("group-rtp.zone.max-x", maxX);
        plugin.getConfig().set("group-rtp.zone.max-y", maxY);
        plugin.getConfig().set("group-rtp.zone.max-z", maxZ);
        plugin.saveConfig();
        reload();
    }

    public void startZoneTask() {
        if (task != null) task.cancel();
        task = new BukkitRunnable() {
            int tickCounter = 0;

            @Override
            public void run() {
                if (!plugin.getConfig().getBoolean("group-rtp.enabled", true)) return;
                if (!plugin.getConfig().getBoolean("group-rtp.zone.configured", false)) return;

                World world = Bukkit.getWorld(plugin.getConfig().getString("group-rtp.zone.world", "world"));
                if (world == null) return;

                spawnZoneRing(world, countdown >= 0);

                tickCounter++;
                if (tickCounter % 4 != 0) return;

                List<Player> playersInZone = getEligiblePlayersInZone(world);
                updateZoneHologramCount(playersInZone.size());

                Set<UUID> currentIds = new HashSet<>();
                String joinSound = plugin.getConfig().getString("group-rtp.visuals-and-audio.sound-join-zone", "block.amethyst_block.resonate");

                for (Player p : playersInZone) {
                    currentIds.add(p.getUniqueId());
                    if (!lastZonePlayers.contains(p.getUniqueId())) {
                        plugin.getSoundManager().playRaw(p, joinSound, 0.8f, 1.2f);
                    }
                }
                lastZonePlayers.clear();
                lastZonePlayers.addAll(currentIds);

                int minPlayers = plugin.getConfig().getInt("group-rtp.requirements.min-players", 2);
                int maxPlayers = plugin.getConfig().getInt("group-rtp.requirements.max-players", 10);
                int maxCountdown = plugin.getConfig().getInt("group-rtp.requirements.countdown-seconds", 8);

                if (playersInZone.isEmpty()) {
                    if (bossBar.isVisible()) {
                        bossBar.setVisible(false);
                        bossBar.removeAll();
                    }
                    countdown = -1;
                    return;
                }

                if (playersInZone.size() > maxPlayers) {
                    playersInZone = playersInZone.subList(0, maxPlayers);
                }

                if (plugin.getConfig().getBoolean("group-rtp.visuals-and-audio.bossbar-enabled", true)) {
                    bossBar.removeAll();
                    playersInZone.forEach(bossBar::addPlayer);
                    bossBar.setVisible(true);
                }

                if (playersInZone.size() < minPlayers) {
                    if (countdown >= 0 && plugin.getConfig().getBoolean("group-rtp.requirements.cancel-if-below-min", true)) {
                        String cancelSound = plugin.getConfig().getString("group-rtp.visuals-and-audio.sound-cancel", "entity.villager.no");
                        playersInZone.forEach(p -> plugin.getSoundManager().playRaw(p, cancelSound, 0.8f, 0.9f));
                    }
                    countdown = -1;
                    String waitTitle = plugin.getConfig().getString("group-rtp.visuals-and-audio.bossbar-waiting-title", "")
                            .replace("%players%", String.valueOf(playersInZone.size()))
                            .replace("%min%", String.valueOf(minPlayers));
                    bossBar.setTitle(ColorUtils.translateLegacy(waitTitle));
                    bossBar.setProgress(Math.min(1.0, (double) playersInZone.size() / Math.max(1, minPlayers)));

                    String actionWait = plugin.getConfig().getString("group-rtp.visuals-and-audio.actionbar-waiting", "")
                            .replace("%players%", String.valueOf(playersInZone.size()))
                            .replace("%min%", String.valueOf(minPlayers));
                    playersInZone.forEach(p -> p.sendActionBar(ColorUtils.componentFor(p, actionWait)));
                    return;
                }

                if (countdown < 0) countdown = maxCountdown;

                String activeBar = plugin.getConfig().getString("group-rtp.visuals-and-audio.bossbar-title", "")
                        .replace("%players%", String.valueOf(playersInZone.size()))
                        .replace("%min%", String.valueOf(minPlayers))
                        .replace("%time%", String.valueOf(countdown));
                bossBar.setTitle(ColorUtils.translateLegacy(activeBar));
                bossBar.setProgress(Math.max(0.0, Math.min(1.0, (double) countdown / Math.max(1, maxCountdown))));

                String actionCount = plugin.getConfig().getString("group-rtp.visuals-and-audio.actionbar-countdown", "")
                        .replace("%time%", String.valueOf(countdown));
                String soundName = countdown <= 3
                        ? plugin.getConfig().getString("group-rtp.visuals-and-audio.sound-countdown-final", "block.note_block.pling")
                        : plugin.getConfig().getString("group-rtp.visuals-and-audio.sound-tick", "block.note_block.chime");
                float pitch = countdown <= 3 ? 1.55f - (countdown * 0.1f) : 1.0f;

                for (Player p : playersInZone) {
                    p.sendActionBar(ColorUtils.componentFor(p, actionCount));
                    plugin.getSoundManager().playRaw(p, soundName, 0.9f, pitch);
                }

                if (countdown == 0) {
                    executeGroupTeleport(playersInZone);
                    countdown = -1;
                    bossBar.setVisible(false);
                    bossBar.removeAll();
                } else {
                    countdown--;
                }
            }
        };
        task.runTaskTimer(plugin, 20L, 5L);
    }

    private void executeGroupTeleport(List<Player> players) {
        String targetWorldName = plugin.getConfig().getString("group-rtp.destination.target-world", "world");
        World targetWorld = Bukkit.getWorld(targetWorldName);
        if (targetWorld == null) return;

        Location baseLoc = findSafeLocation(targetWorld);
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (baseLoc == null) {
            players.forEach(p -> p.sendMessage(ColorUtils.componentFor(p, prefix + "&cلم نتمكن من إيجاد موقع آمن هذه المرة، حاول مجدداً!")));
            return;
        }

        double cost = plugin.getConfig().getDouble("group-rtp.requirements.cost-per-player", 50.0);
        int cdSeconds = plugin.getConfig().getInt("group-rtp.requirements.cooldown-seconds", 120);
        int spread = plugin.getConfig().getInt("group-rtp.destination.team-spread-radius", 4);
        String arriveSound = plugin.getConfig().getString("group-rtp.visuals-and-audio.sound-success", "entity.enderman.teleport");
        Particle arriveParticle = parseParticle(plugin.getConfig().getString("group-rtp.visuals-and-audio.arrive-particle"), Particle.HEART);

        List<Player> ready = new ArrayList<>();
        for (Player p : players) {
            if (plugin.getEconomy() != null && cost > 0 && !plugin.getEconomy().has(p, cost)) {
                p.sendMessage(ColorUtils.componentFor(p, prefix + "&cرصيدك غير كافٍ للانطلاق الجماعي! المطلوب: &#FFD166&l" + cost + "$"));
                plugin.getSoundManager().play(p, "error");
                continue;
            }
            ready.add(p);
        }

        if (ready.size() < plugin.getConfig().getInt("group-rtp.requirements.min-players", 2)) {
            ready.forEach(p -> p.sendMessage(ColorUtils.componentFor(p, prefix + "&cتم إلغاء الانطلاق لعدم توفر الرصيد الكافي لعدد اللاعبين المطلوب.")));
            return;
        }

        String rawTitle = plugin.getConfig().getString("group-rtp.visuals-and-audio.arrive-title", "");
        String rawSub = plugin.getConfig().getString("group-rtp.visuals-and-audio.arrive-subtitle", "")
                .replace("%count%", String.valueOf(ready.size()));

        long expireAt = System.currentTimeMillis() + (cdSeconds * 1000L);
        for (int i = 0; i < ready.size(); i++) {
            Player p = ready.get(i);
            if (plugin.getEconomy() != null && cost > 0) plugin.getEconomy().withdrawPlayer(p, cost);
            cooldowns.put(p.getUniqueId(), expireAt);

            double angle = (2.0 * Math.PI * i) / ready.size();
            double ox = Math.cos(angle) * Math.min(spread, 4);
            double oz = Math.sin(angle) * Math.min(spread, 4);
            Location memberLoc = baseLoc.clone().add(ox, 0, oz);
            int highestY = targetWorld.getHighestBlockYAt(memberLoc);
            memberLoc.setY(highestY + 1.0);

            p.teleport(memberLoc);
            plugin.getSoundManager().playRaw(p, arriveSound, 1.0f, 1.1f);
            p.showTitle(Title.title(
                    ColorUtils.componentFor(p, rawTitle),
                    ColorUtils.componentFor(p, rawSub),
                    Title.Times.times(Duration.ofMillis(400), Duration.ofSeconds(3), Duration.ofMillis(600))
            ));
            targetWorld.spawnParticle(arriveParticle, memberLoc.clone().add(0, 1.2, 0), 18, 0.6, 0.5, 0.6, 0.02);

            if (plugin.getConfig().getBoolean("group-rtp.buffs-on-arrive.enabled", true)) {
                int res = plugin.getConfig().getInt("group-rtp.buffs-on-arrive.resistance-seconds", 12) * 20;
                int reg = plugin.getConfig().getInt("group-rtp.buffs-on-arrive.regeneration-seconds", 8) * 20;
                int nv = plugin.getConfig().getInt("group-rtp.buffs-on-arrive.night-vision-seconds", 30) * 20;
                if (res > 0) p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, res, 1));
                if (reg > 0) p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, reg, 1));
                if (nv > 0) p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, nv, 0));
            }
        }
    }

    private Location findSafeLocation(World world) {
        int minR = plugin.getConfig().getInt("group-rtp.destination.min-radius", 500);
        int maxR = plugin.getConfig().getInt("group-rtp.destination.max-radius", 14000);
        int cx = plugin.getConfig().getInt("group-rtp.destination.center-x", 0);
        int cz = plugin.getConfig().getInt("group-rtp.destination.center-z", 0);
        int attempts = plugin.getConfig().getInt("group-rtp.destination.max-attempts", 45);
        boolean respectBorder = plugin.getConfig().getBoolean("group-rtp.safety.respect-world-border", true);
        double borderPad = plugin.getConfig().getDouble("group-rtp.safety.border-padding", 60);
        Set<String> blacklist = new HashSet<>(plugin.getConfig().getStringList("group-rtp.safety.blacklisted-blocks"));

        WorldBorder wb = world.getWorldBorder();
        double halfBorder = (wb.getSize() / 2.0) - borderPad;

        for (int i = 0; i < attempts; i++) {
            double angle = random.nextDouble() * 2.0 * Math.PI;
            double dist = minR + random.nextDouble() * Math.max(1, maxR - minR);
            int x = cx + (int) Math.round(Math.cos(angle) * dist);
            int z = cz + (int) Math.round(Math.sin(angle) * dist);

            if (respectBorder) {
                double dx = Math.abs(x - wb.getCenter().getX());
                double dz = Math.abs(z - wb.getCenter().getZ());
                if (dx > halfBorder || dz > halfBorder) continue;
            }

            int y = world.getHighestBlockYAt(x, z);
            Block ground = world.getBlockAt(x, y, z);
            Block feet = world.getBlockAt(x, y + 1, z);
            Block head = world.getBlockAt(x, y + 2, z);

            if (ground.getType().isSolid()
                    && !blacklist.contains(ground.getType().name())
                    && feet.getType().isAir()
                    && head.getType().isAir()) {
                return new Location(world, x + 0.5, y + 1.0, z + 0.5);
            }
        }
        return null;
    }

    private List<Player> getEligiblePlayersInZone(World world) {
        double minX = Math.min(plugin.getConfig().getDouble("group-rtp.zone.min-x"), plugin.getConfig().getDouble("group-rtp.zone.max-x"));
        double maxX = Math.max(plugin.getConfig().getDouble("group-rtp.zone.min-x"), plugin.getConfig().getDouble("group-rtp.zone.max-x")) + 1.0;
        double minY = Math.min(plugin.getConfig().getDouble("group-rtp.zone.min-y"), plugin.getConfig().getDouble("group-rtp.zone.max-y"));
        double maxY = Math.max(plugin.getConfig().getDouble("group-rtp.zone.min-y"), plugin.getConfig().getDouble("group-rtp.zone.max-y")) + 1.0;
        double minZ = Math.min(plugin.getConfig().getDouble("group-rtp.zone.min-z"), plugin.getConfig().getDouble("group-rtp.zone.max-z"));
        double maxZ = Math.max(plugin.getConfig().getDouble("group-rtp.zone.min-z"), plugin.getConfig().getDouble("group-rtp.zone.max-z")) + 1.0;

        long now = System.currentTimeMillis();
        List<Player> list = new ArrayList<>();
        for (Player p : world.getPlayers()) {
            Location l = p.getLocation();
            if (l.getX() >= minX && l.getX() <= maxX && l.getY() >= minY && l.getY() <= maxY && l.getZ() >= minZ && l.getZ() <= maxZ) {
                long cdEnd = cooldowns.getOrDefault(p.getUniqueId(), 0L);
                if (cdEnd > now) {
                    long rem = (cdEnd - now) / 1000L;
                    p.sendActionBar(ColorUtils.componentFor(p, "&cعليك الانتظار &#FFD166&l" + rem + "ث &cقبل الانطلاق الجماعي مجدداً!"));
                    continue;
                }
                list.add(p);
            }
        }
        return list;
    }

    private void spawnZoneRing(World world, boolean activeCountdown) {
        double minX = Math.min(plugin.getConfig().getDouble("group-rtp.zone.min-x"), plugin.getConfig().getDouble("group-rtp.zone.max-x"));
        double maxX = Math.max(plugin.getConfig().getDouble("group-rtp.zone.min-x"), plugin.getConfig().getDouble("group-rtp.zone.max-x")) + 1.0;
        double minZ = Math.min(plugin.getConfig().getDouble("group-rtp.zone.min-z"), plugin.getConfig().getDouble("group-rtp.zone.max-z"));
        double maxZ = Math.max(plugin.getConfig().getDouble("group-rtp.zone.min-z"), plugin.getConfig().getDouble("group-rtp.zone.max-z")) + 1.0;
        double y = Math.min(plugin.getConfig().getDouble("group-rtp.zone.min-y"), plugin.getConfig().getDouble("group-rtp.zone.max-y")) + 0.35;

        double cx = (minX + maxX) / 2.0;
        double cz = (minZ + maxZ) / 2.0;
        double radius = Math.max(1.5, Math.min(maxX - minX, maxZ - minZ) / 2.0);

        Particle ringP = parseParticle(plugin.getConfig().getString("group-rtp.visuals-and-audio.ring-particle"), Particle.CHERRY_LEAVES);
        Particle vortexP = parseParticle(plugin.getConfig().getString("group-rtp.visuals-and-audio.vortex-particle"), Particle.END_ROD);

        particleAngle += activeCountdown ? 0.55 : 0.3;
        for (int i = 0; i < 4; i++) {
            double a = particleAngle + (i * (Math.PI / 2.0));
            double px = cx + Math.cos(a) * radius;
            double pz = cz + Math.sin(a) * radius;
            world.spawnParticle(ringP, px, y, pz, 1, 0, 0.05, 0, 0.01);
            if (activeCountdown) {
                world.spawnParticle(vortexP, px, y + 0.9, pz, 1, 0, 0.14, 0, 0.01);
            }
        }
    }

    private void spawnZoneHologram(int currentPlayers) {
        World w = Bukkit.getWorld(plugin.getConfig().getString("group-rtp.zone.world", "world"));
        if (w == null) return;
        double cx = (plugin.getConfig().getDouble("group-rtp.zone.min-x") + plugin.getConfig().getDouble("group-rtp.zone.max-x") + 1.0) / 2.0;
        double cz = (plugin.getConfig().getDouble("group-rtp.zone.min-z") + plugin.getConfig().getDouble("group-rtp.zone.max-z") + 1.0) / 2.0;
        double baseY = Math.min(plugin.getConfig().getDouble("group-rtp.zone.min-y"), plugin.getConfig().getDouble("group-rtp.zone.max-y")) + 2.6;

        int minP = plugin.getConfig().getInt("group-rtp.requirements.min-players", 2);
        String l1 = plugin.getConfig().getString("group-rtp.zone.hologram-line1", "بوابة الاستكشاف الجماعي");
        String l2 = plugin.getConfig().getString("group-rtp.zone.hologram-line2", "")
                .replace("%players%", String.valueOf(currentPlayers))
                .replace("%min%", String.valueOf(minP));

        ArmorStand s1 = w.spawn(new Location(w, cx, baseY + 0.3, cz), ArmorStand.class, as -> {
            as.setInvisible(true);
            as.setGravity(false);
            as.setMarker(true);
            as.setInvulnerable(true);
            as.setSilent(true);
            as.setCustomNameVisible(true);
            as.customName(ColorUtils.component(l1));
        });
        ArmorStand s2 = w.spawn(new Location(w, cx, baseY, cz), ArmorStand.class, as -> {
            as.setInvisible(true);
            as.setGravity(false);
            as.setMarker(true);
            as.setInvulnerable(true);
            as.setSilent(true);
            as.setCustomNameVisible(true);
            as.customName(ColorUtils.component(l2));
        });
        holoLine1Id = s1.getUniqueId();
        holoLine2Id = s2.getUniqueId();
    }

    private void updateZoneHologramCount(int currentPlayers) {
        if (holoLine2Id == null) return;
        Entity e = Bukkit.getEntity(holoLine2Id);
        if (e != null) {
            int minP = plugin.getConfig().getInt("group-rtp.requirements.min-players", 2);
            String l2 = plugin.getConfig().getString("group-rtp.zone.hologram-line2", "")
                    .replace("%players%", String.valueOf(currentPlayers))
                    .replace("%min%", String.valueOf(minP));
            e.customName(ColorUtils.component(l2));
        }
    }

    private void removeZoneHologram() {
        if (holoLine1Id != null) {
            Entity e = Bukkit.getEntity(holoLine1Id);
            if (e != null) e.remove();
            holoLine1Id = null;
        }
        if (holoLine2Id != null) {
            Entity e = Bukkit.getEntity(holoLine2Id);
            if (e != null) e.remove();
            holoLine2Id = null;
        }
    }

    private Particle parseParticle(String name, Particle def) {
        if (name == null) return def;
        try { return Particle.valueOf(name.toUpperCase()); } catch (Exception e) { return def; }
    }

    public void shutdown() {
        if (task != null) task.cancel();
        if (bossBar != null) bossBar.removeAll();
        removeZoneHologram();
    }
}
