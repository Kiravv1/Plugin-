package com.strawberry.survivalplus.utils;

import com.strawberry.survivalplus.SurvivalPlus;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ColorUtils {

    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private static final LegacyComponentSerializer SERIALIZER = LegacyComponentSerializer.builder()
            .character('§')
            .hexColors()
            .useUnusualXRepeatedCharacterHexFormat()
            .build();

    public static String translateLegacy(String text) {
        if (text == null) return "";
        Matcher matcher = HEX_PATTERN.matcher(text);
        StringBuilder sb = new StringBuilder();
        while (matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder replacement = new StringBuilder("§x");
            for (char c : hex.toCharArray()) {
                replacement.append('§').append(c);
            }
            matcher.appendReplacement(sb, replacement.toString());
        }
        matcher.appendTail(sb);
        return sb.toString().replace('&', '§');
    }

    public static String adaptForBedrock(Player player, String raw) {
        if (raw == null) return "";
        boolean enabled = SurvivalPlus.getInstance().getConfig().getBoolean("general.bedrock-compatibility.enabled", true);
        boolean replaceSymbols = SurvivalPlus.getInstance().getConfig().getBoolean("general.bedrock-compatibility.replace-heavy-symbols", true);
        if (enabled && replaceSymbols && isBedrockPlayer(player)) {
            return raw.replace("✦", "★")
                      .replace("━", "-")
                      .replace("»", ">")
                      .replace("«", "<")
                      .replace("✔", "✓")
                      .replace("✖", "x")
                      .replace("🔥", "")
                      .replace("🚀", "")
                      .replace("⏳", "")
                      .replace("☀", "")
                      .replace("🔒", "")
                      .replace("✉", "")
                      .replace("✎", "")
                      .replace("↺", "");
        }
        return raw;
    }

    public static Component component(String text) {
        return SERIALIZER.deserialize(translateLegacy(text))
                .decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    public static Component componentFor(Player player, String text) {
        return component(adaptForBedrock(player, text));
    }

    public static List<Component> loreFor(Player player, List<String> lines) {
        List<Component> result = new ArrayList<>();
        if (lines == null) return result;
        for (String line : lines) {
            result.add(componentFor(player, line));
        }
        return result;
    }

    public static boolean isBedrockPlayer(Player player) {
        if (player == null) return false;
        if (player.getUniqueId().toString().startsWith("00000000-0000-0000")) return true;
        return Bukkit.getPluginManager().isPluginEnabled("floodgate") && player.getName().startsWith(".");
    }
}
