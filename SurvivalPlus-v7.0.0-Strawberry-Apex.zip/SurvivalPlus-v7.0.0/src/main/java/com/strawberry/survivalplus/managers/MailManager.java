package com.strawberry.survivalplus.managers;

import com.strawberry.survivalplus.SurvivalPlus;
import com.strawberry.survivalplus.utils.ColorUtils;
import com.strawberry.survivalplus.utils.GuiBuilder;
import com.strawberry.survivalplus.utils.StrawberryGuiHolder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MailManager implements Listener {

    public static class Parcel {
        public final String id;
        public final UUID senderId;
        public final String senderName;
        public final ItemStack item;
        public final double attachedMoney;
        public final double codPrice;
        public final String sentAt;

        public Parcel(String id, UUID senderId, String senderName, ItemStack item, double attachedMoney, double codPrice, String sentAt) {
            this.id = id;
            this.senderId = senderId;
            this.senderName = senderName;
            this.item = item;
            this.attachedMoney = attachedMoney;
            this.codPrice = codPrice;
            this.sentAt = sentAt;
        }
    }

    private final SurvivalPlus plugin;
    private final File mailFile;
    private final Map<UUID, List<Parcel>> inboxes = new HashMap<>();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("MM/dd HH:mm");
    private static final int[] INBOX_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };

    public MailManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        this.mailFile = new File(plugin.getDataFolder(), "mail.yml");
        loadAll();
    }

    public void loadAll() {
        inboxes.clear();
        if (!mailFile.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(mailFile);
        ConfigurationSection root = cfg.getConfigurationSection("inboxes");
        if (root == null) return;

        for (String uKey : root.getKeys(false)) {
            try {
                UUID targetId = UUID.fromString(uKey);
                ConfigurationSection pSec = root.getConfigurationSection(uKey);
                if (pSec == null) continue;
                List<Parcel> list = new ArrayList<>();
                for (String id : pSec.getKeys(false)) {
                    UUID senderId = UUID.fromString(pSec.getString(id + ".sender-id", targetId.toString()));
                    String senderName = pSec.getString(id + ".sender-name", "Server");
                    ItemStack item = pSec.getItemStack(id + ".item");
                    double money = pSec.getDouble(id + ".money", 0.0);
                    double cod = pSec.getDouble(id + ".cod", 0.0);
                    String sentAt = pSec.getString(id + ".sent-at", "");
                    list.add(new Parcel(id, senderId, senderName, item, money, cod, sentAt));
                }
                inboxes.put(targetId, list);
            } catch (Exception ignored) {}
        }
    }

    public void saveAll() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Map.Entry<UUID, List<Parcel>> entry : inboxes.entrySet()) {
            for (Parcel p : entry.getValue()) {
                String path = "inboxes." + entry.getKey() + "." + p.id;
                cfg.set(path + ".sender-id", p.senderId.toString());
                cfg.set(path + ".sender-name", p.senderName);
                cfg.set(path + ".item", p.item);
                cfg.set(path + ".money", p.attachedMoney);
                cfg.set(path + ".cod", p.codPrice);
                cfg.set(path + ".sent-at", p.sentAt);
            }
        }
        try {
            cfg.save(mailFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save mail.yml: " + e.getMessage());
        }
    }

    public void sendHandParcel(Player sender, OfflinePlayer target, double codPrice) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        ItemStack hand = sender.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            sender.sendMessage(ColorUtils.componentFor(sender, prefix + "&cامسك الغرض الذي تريد إرساله بالبريد في يدك!"));
            return;
        }
        double fee = plugin.getConfig().getDouble("mail.send-fee", 25.0);
        if (plugin.getEconomy() != null && fee > 0) {
            if (!plugin.getEconomy().has(sender, fee)) {
                sender.sendMessage(ColorUtils.componentFor(sender, prefix + "&cتحتاج إلى &#FFD166&l" + fee + "$ &cكرسوم شحن بريدي."));
                plugin.getSoundManager().play(sender, "error");
                return;
            }
            plugin.getEconomy().withdrawPlayer(sender, fee);
        }

        ItemStack copy = hand.clone();
        sender.getInventory().setItemInMainHand(null);

        String targetName = target.getName() != null ? target.getName() : "Player";
        Parcel parcel = new Parcel(UUID.randomUUID().toString().substring(0, 8), sender.getUniqueId(), sender.getName(),
                copy, 0.0, Math.max(0.0, codPrice), LocalDateTime.now().format(FMT));
        inboxes.computeIfAbsent(target.getUniqueId(), k -> new ArrayList<>()).add(parcel);
        saveAll();

        plugin.getHistoryManager().log(sender.getUniqueId(), HistoryManager.EntryType.MAIL,
                "إرسال طرد إلى " + targetName,
                copy.getAmount() + "x " + copy.getType().name() + (codPrice > 0 ? " (دفع عند الاستلام: " + codPrice + "$)" : ""), -fee);

        sender.sendMessage(ColorUtils.componentFor(sender, prefix + "&#06D6A0&l✔ تم شحن الطرد إلى &#FFD166&l" + targetName + " &#06D6A0&lبنجاح!"));
        plugin.getSoundManager().play(sender, "success");

        if (target.isOnline() && target.getPlayer() != null) {
            Player tp = target.getPlayer();
            tp.sendMessage(ColorUtils.componentFor(tp, prefix + "&#FFD166&l✉ وصلك طرد بريدي جديد من &f&l" + sender.getName() + " &7— افتح &#FF758F&l/mail"));
            plugin.getSoundManager().play(tp, "mail-notify");
        }
    }

    public void sendMoneyParcel(Player sender, OfflinePlayer target, double amount) {
        String prefix = plugin.getConfig().getString("general.prefix", "");
        if (amount <= 0 || plugin.getEconomy() == null) return;
        double fee = plugin.getConfig().getDouble("mail.send-fee", 25.0);
        if (!plugin.getEconomy().has(sender, amount + fee)) {
            sender.sendMessage(ColorUtils.componentFor(sender, prefix + "&cرصيدك غير كافٍ للتحويل + رسوم البريد (" + (amount + fee) + "$)!"));
            plugin.getSoundManager().play(sender, "error");
            return;
        }
        plugin.getEconomy().withdrawPlayer(sender, amount + fee);

        String targetName = target.getName() != null ? target.getName() : "Player";
        Parcel parcel = new Parcel(UUID.randomUUID().toString().substring(0, 8), sender.getUniqueId(), sender.getName(),
                null, amount, 0.0, LocalDateTime.now().format(FMT));
        inboxes.computeIfAbsent(target.getUniqueId(), k -> new ArrayList<>()).add(parcel);
        saveAll();

        plugin.getHistoryManager().log(sender.getUniqueId(), HistoryManager.EntryType.MAIL,
                "حوالة بريدية إلى " + targetName, "مبلغ " + amount + "$", -(amount + fee));

        sender.sendMessage(ColorUtils.componentFor(sender, prefix + "&#06D6A0&l✔ تم إرسال حوالة بقيمة &#FFD166&l" + amount + "$ &aإلى " + targetName));
        plugin.getSoundManager().play(sender, "success");

        if (target.isOnline() && target.getPlayer() != null) {
            Player tp = target.getPlayer();
            tp.sendMessage(ColorUtils.componentFor(tp, prefix + "&#FFD166&l✉ وصلتك حوالة مالية بريدية من &f&l" + sender.getName() + " &7— افتح &#FF758F&l/mail"));
            plugin.getSoundManager().play(tp, "mail-notify");
        }
    }

    public void openInboxGui(Player player) {
        String title = plugin.getConfig().getString("mail.gui-title", "صندوق البريد");
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.MAIL_INBOX);
        Inventory inv = GuiBuilder.create(player, holder, 54, title);

        List<Parcel> list = inboxes.getOrDefault(player.getUniqueId(), Collections.emptyList());
        for (int i = 0; i < list.size() && i < INBOX_SLOTS.length; i++) {
            Parcel p = list.get(i);
            Material mat = p.item != null ? p.item.getType() : Material.GOLD_INGOT;
            List<String> lore = new ArrayList<>();
            lore.add("&#FFB3C1&l━━━━━━━━━━━━━━━━━━");
            lore.add("&7المُرسل: &#FFD166&l" + p.senderName);
            lore.add("&7تاريخ الإرسال: &f" + p.sentAt);
            if (p.item != null) lore.add("&7المحتوى: &#06D6A0&l" + p.item.getAmount() + "x " + p.item.getType().name());
            if (p.attachedMoney > 0) lore.add("&7حوالة مالية: &#FFD166&l+" + p.attachedMoney + "$");
            if (p.codPrice > 0) {
                lore.add("&#FF4D6D&l⚠ طرد دفع عند الاستلام (C.O.D)");
                lore.add("&7السعر المطلوب للاستلام: &#FFD166&l" + p.codPrice + "$");
                lore.add("&#06D6A0&l» اضغط لفتح نافذة القبول أو الإرجاع");
            } else {
                lore.add("&#06D6A0&l» اضغط لاستلام الطرد فوراً");
            }
            lore.add("&#FFB3C1&l━━━━━━━━━━━━━━━━━━");

            int slot = INBOX_SLOTS[i];
            holder.with("parcel_" + slot, p.id);
            inv.setItem(slot, GuiBuilder.makeItem(player, mat, "&#FFD166&l✉ طرد من " + p.senderName, lore));
        }

        if (list.isEmpty()) {
            inv.setItem(22, GuiBuilder.makeItem(player, Material.CHEST_MINECART, "&#FFB3C1&lصندوق بريدك فارغ حالياً",
                    Arrays.asList("&7لإرسال طرد: &e/mail send <اللاعب> [سعر_COD]", "&7لإرسال مبلغ: &e/mail pay <اللاعب> <المبلغ>")));
        }

        inv.setItem(45, GuiBuilder.backButton(player));
        player.openInventory(inv);
        plugin.getSoundManager().play(player, "open-gui");
    }

    public void openCodConfirmGui(Player player, Parcel parcel) {
        StrawberryGuiHolder holder = new StrawberryGuiHolder(StrawberryGuiHolder.GuiType.MAIL_CONFIRM_COD)
                .with("parcel_id", parcel.id);
        Inventory inv = GuiBuilder.create(player, holder, 27, "&#FFD166&l✦ تأكيد الدفع عند الاستلام");

        inv.setItem(11, GuiBuilder.makeItem(player, Material.LIME_CONCRETE, "&#06D6A0&l✔ قبول ودفع " + parcel.codPrice + "$",
                Collections.singletonList("&7سيُخصم المبلغ ويُحوّل للمُرسل وتستلم الغرض فوراً.")));
        inv.setItem(13, parcel.item != null ? parcel.item.clone() : new ItemStack(Material.PAPER));
        inv.setItem(15, GuiBuilder.makeItem(player, Material.RED_CONCRETE, "&c&l✖ رفض وإرجاع الطرد للمُرسل",
                Collections.singletonList("&7يُعاد الغرض مجاناً إلى بريد " + parcel.senderName)));

        player.openInventory(inv);
        plugin.getSoundManager().play(player, "click");
    }

    public void handleInboxClick(Player p, StrawberryGuiHolder holder, int slot) {
        if (slot == 45) {
            String cmd = plugin.getConfig().getString("menu-bridge.global-back-command", "dm open strawberry_menu %player%")
                    .replace("%player%", p.getName());
            p.closeInventory();
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            return;
        }
        Object idObj = holder.get("parcel_" + slot);
        if (idObj == null) return;
        Parcel parcel = findParcel(p.getUniqueId(), idObj.toString());
        if (parcel == null) return;

        if (parcel.codPrice > 0) {
            openCodConfirmGui(p, parcel);
        } else {
            claimParcel(p, parcel);
            openInboxGui(p);
        }
    }

    public void handleCodClick(Player p, StrawberryGuiHolder holder, int slot) {
        String id = holder.getString("parcel_id", "");
        Parcel parcel = findParcel(p.getUniqueId(), id);
        if (parcel == null) { openInboxGui(p); return; }
        String prefix = plugin.getConfig().getString("general.prefix", "");

        if (slot == 11) {
            if (plugin.getEconomy() != null) {
                if (!plugin.getEconomy().has(p, parcel.codPrice)) {
                    p.sendMessage(ColorUtils.componentFor(p, prefix + "&cرصيدك غير كافٍ لدفع مبلغ الاستلام (" + parcel.codPrice + "$)!"));
                    plugin.getSoundManager().play(p, "error");
                    return;
                }
                plugin.getEconomy().withdrawPlayer(p, parcel.codPrice);
                plugin.getEconomy().depositPlayer(Bukkit.getOfflinePlayer(parcel.senderId), parcel.codPrice);
                String desc = parcel.item != null ? parcel.item.getAmount() + "x " + parcel.item.getType().name() : "طرد";
                plugin.getHistoryManager().log(p.getUniqueId(), HistoryManager.EntryType.MAIL,
                        "استلام طرد C.O.D من " + parcel.senderName, desc, -parcel.codPrice);
                plugin.getHistoryManager().log(parcel.senderId, HistoryManager.EntryType.MAIL,
                        "تحصيل طرد C.O.D من " + p.getName(), desc, parcel.codPrice);
            }
            claimParcel(p, parcel);
            openInboxGui(p);
        } else if (slot == 15) {
            inboxes.getOrDefault(p.getUniqueId(), new ArrayList<>()).remove(parcel);
            Parcel returned = new Parcel(UUID.randomUUID().toString().substring(0, 8), p.getUniqueId(),
                    p.getName() + " (مُرتجع)", parcel.item, 0.0, 0.0, LocalDateTime.now().format(FMT));
            inboxes.computeIfAbsent(parcel.senderId, k -> new ArrayList<>()).add(returned);
            saveAll();
            p.sendMessage(ColorUtils.componentFor(p, prefix + "&eتم رفض الطرد وإرجاعه إلى بريد &#FFD166&l" + parcel.senderName));
            plugin.getSoundManager().play(p, "click");
            openInboxGui(p);
        }
    }

    private void claimParcel(Player p, Parcel parcel) {
        inboxes.getOrDefault(p.getUniqueId(), new ArrayList<>()).remove(parcel);
        saveAll();

        if (parcel.item != null) {
            HashMap<Integer, ItemStack> left = p.getInventory().addItem(parcel.item.clone());
            left.values().forEach(rem -> p.getWorld().dropItemNaturally(p.getLocation(), rem));
        }
        if (parcel.attachedMoney > 0 && plugin.getEconomy() != null) {
            plugin.getEconomy().depositPlayer(p, parcel.attachedMoney);
            plugin.getHistoryManager().log(p.getUniqueId(), HistoryManager.EntryType.MAIL,
                    "استلام حوالة من " + parcel.senderName, "حوالة بريدية", parcel.attachedMoney);
        }
        String prefix = plugin.getConfig().getString("general.prefix", "");
        p.sendMessage(ColorUtils.componentFor(p, prefix + "&#06D6A0&l✔ تم استلام الطرد بنجاح!"));
        plugin.getSoundManager().play(p, "purchase");
    }

    private Parcel findParcel(UUID owner, String id) {
        for (Parcel p : inboxes.getOrDefault(owner, Collections.emptyList())) {
            if (p.id.equals(id)) return p;
        }
        return null;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        List<Parcel> list = inboxes.get(p.getUniqueId());
        if (list != null && !list.isEmpty()) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!p.isOnline()) return;
                String prefix = plugin.getConfig().getString("general.prefix", "");
                p.sendMessage(ColorUtils.componentFor(p, prefix + "&#FFD166&l✉ لديك " + list.size()
                        + " طرد بريدي بانتظارك! افتح &#FF758F&l/mail &fلاستلامها."));
                plugin.getSoundManager().play(p, "mail-notify");
            }, 60L);
        }
    }
}
