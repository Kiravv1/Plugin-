package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class NotificationManager {
    private final SurvivalPlus plugin;
    private final File dataFile;
    private final Map<UUID, Map<String, Boolean>> playerPrefs = new HashMap<>();

    public NotificationManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "notifications-data.yml");
    }

    public void loadData() {
        playerPrefs.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection sec = yml.getConfigurationSection("players");
        if (sec == null) return;
        for (String uuidStr : sec.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidStr);
                ConfigurationSection ps = sec.getConfigurationSection(uuidStr);
                if (ps == null) continue;
                Map<String, Boolean> map = new HashMap<>();
                for (String key : ps.getKeys(false)) map.put(key, ps.getBoolean(key));
                playerPrefs.put(uuid, map);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public void saveData() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, Boolean>> entry : playerPrefs.entrySet()) {
            for (Map.Entry<String, Boolean> pref : entry.getValue().entrySet()) {
                yml.set("players." + entry.getKey() + "." + pref.getKey(), pref.getValue());
            }
        }
        try { yml.save(dataFile); } catch (IOException ignored) {}
    }

    public boolean isGloballyEnabled(String typeKey) {
        return plugin.getConfigManager().getNotifications().getBoolean("types." + typeKey + ".enabled", true);
    }

    public boolean isEnabledFor(UUID playerId, String typeKey) {
        if (!isGloballyEnabled(typeKey)) return false;
        Map<String, Boolean> map = playerPrefs.get(playerId);
        if (map != null && map.containsKey(typeKey)) return map.get(typeKey);
        return plugin.getConfigManager().getNotifications().getBoolean("types." + typeKey + ".default-player-state", true);
    }

    public void toggle(Player player, String typeKey) {
        if (!isGloballyEnabled(typeKey)) {
            plugin.getConfigManager().send(player, "notifications.disabled-by-server");
            TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.error"));
            return;
        }
        boolean next = !isEnabledFor(player.getUniqueId(), typeKey);
        playerPrefs.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>()).put(typeKey, next);
        saveData();
        String name = plugin.getConfigManager().getNotifications().getString("types." + typeKey + ".name", typeKey);
        plugin.getConfigManager().send(player, next ? "notifications.toggled-on" : "notifications.toggled-off", "%name%", name);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString(next ? "sounds.success" : "sounds.click"), next ? 1.3f : 0.9f);
    }

    public void setAll(Player player, boolean state) {
        ConfigurationSection types = plugin.getConfigManager().getNotifications().getConfigurationSection("types");
        if (types == null) return;
        Map<String, Boolean> map = playerPrefs.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>());
        for (String key : types.getKeys(false)) if (isGloballyEnabled(key)) map.put(key, state);
        saveData();
        plugin.getConfigManager().send(player, state ? "notifications.enabled-all" : "notifications.disabled-all");
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString(state ? "sounds.success" : "sounds.click"));
    }

    public void notify(Player player, String typeKey, String messagePath, String... placeholders) {
        if (player == null || !player.isOnline()) return;
        if (!isEnabledFor(player.getUniqueId(), typeKey)) return;
        plugin.getConfigManager().send(player, messagePath, placeholders);
        ConfigurationSection sec = plugin.getConfigManager().getNotifications().getConfigurationSection("types." + typeKey);
        if (sec != null) {
            if (sec.getBoolean("send-actionbar", false)) player.sendActionBar(plugin.getConfigManager().rawMessage(messagePath, placeholders));
            String snd = sec.getString("sound", "");
            if (!snd.isBlank()) TextUtil.playSound(player, snd, 1.2f);
        }
    }

    public void broadcast(String typeKey, Component component) {
        if (!isGloballyEnabled(typeKey)) return;
        String sound = plugin.getConfigManager().getNotifications().getString("types." + typeKey + ".sound", "");
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (isEnabledFor(p.getUniqueId(), typeKey)) {
                p.sendMessage(component);
                if (!sound.isBlank()) TextUtil.playSound(p, sound, 1.1f);
            }
        }
    }

    public void openGui(Player player) {
        ConfigurationSection cfg = plugin.getConfigManager().getNotifications();
        ConfigurationSection gui = cfg.getConfigurationSection("gui");
        int size = gui.getInt("size", 36);
        GuiHolder holder = new GuiHolder("NOTIFICATIONS_GUI");
        Inventory inv = Bukkit.createInventory(holder, size, TextUtil.color(gui.getString("title", "الإشعارات")));
        holder.setInventory(inv);
        TextUtil.applySleekFrame(inv);

        ConfigurationSection types = cfg.getConfigurationSection("types");
        if (types != null) {
            for (String key : types.getKeys(false)) {
                ConfigurationSection t = types.getConfigurationSection(key);
                if (t == null) continue;
                boolean globalOn = t.getBoolean("enabled", true);
                boolean playerOn = isEnabledFor(player.getUniqueId(), key);
                String status = !globalOn ? "&8معطّل من السيرفر" : (playerOn ? "&#06D6A0✔ مفعّل" : "&#EF476F✘ مغلق");
                inv.setItem(t.getInt("slot", 10), TextUtil.makeItem(
                        TextUtil.parseMaterial(t.getString("material"), Material.BELL),
                        t.getString("name", key),
                        List.of("", "  &7" + t.getString("description", ""), "", "  &#FF8FA3▪ &fالحالة: " + status, "  &#06D6A0» &fاضغط للتبديل"),
                        globalOn && playerOn));
            }
        }

        inv.setItem(gui.getInt("enable-all-slot", 29), TextUtil.makeItem(Material.LIME_DYE, "&#06D6A0✔ تفعيل الكل", List.of(), false));
        inv.setItem(gui.getInt("back-slot", 31), TextUtil.makeItem(Material.SPECTRAL_ARROW, "&#FFB703« العودة للقائمة الرئيسية", List.of(), false));
        inv.setItem(gui.getInt("disable-all-slot", 33), TextUtil.makeItem(Material.RED_DYE, "&#EF476F✘ كتم الكل", List.of(), false));
        player.openInventory(inv);
        TextUtil.playSound(player, plugin.getConfigManager().getConfig().getString("sounds.open-gui"));
    }
}
