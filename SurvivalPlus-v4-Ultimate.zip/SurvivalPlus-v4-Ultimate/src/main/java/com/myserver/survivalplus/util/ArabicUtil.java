package com.myserver.survivalplus.util;

public final class ArabicUtil {
    private ArabicUtil() {}

    /**
     * يوحّد الحروف العربية المتشابهة (ة -> ه ، أ/إ/آ -> ا ، ى -> ي) ويزيل التشكيل
     * حتى تعمل الأوامر العربية دائماً مهما اختلف إملاء اللاعب
     */
    public static String normalize(String input) {
        if (input == null) return "";
        String s = input.trim().toLowerCase();
        // إزالة التشكيل والمدّة
        s = s.replaceAll("[\u064B-\u065F\u0670\u0640]", "");
        s = s.replace('أ', 'ا')
             .replace('إ', 'ا')
             .replace('آ', 'ا')
             .replace('ة', 'ه')
             .replace('ى', 'ي');
        return s;
    }

    public static boolean matches(String input, String... candidates) {
        String normInput = normalize(input);
        for (String c : candidates) {
            if (normInput.equals(normalize(c))) return true;
        }
        return false;
    }
}
