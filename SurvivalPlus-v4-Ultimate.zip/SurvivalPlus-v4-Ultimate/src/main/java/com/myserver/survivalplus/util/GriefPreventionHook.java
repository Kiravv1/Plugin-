package com.myserver.survivalplus.util;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

/**
 * جسر ربط آمن ومباشر مع بلقن GriefPrevention
 * يقرأ الأراضي، رصيد النقاط، ويحمي الـ RTP والحصاد التلقائي بدون أخطاء اعتمادية
 */
public class GriefPreventionHook {
    public record GPClaimInfo(int index, String worldName, int minX, int minZ, int maxX, int maxZ, Location teleportTarget) {
        public int width() { return (maxX - minX) + 1; }
        public int length() { return (maxZ - minZ) + 1; }
        public int area() { return width() * length(); }
        public int centerX() { return (minX + maxX) / 2; }
        public int centerZ() { return (minZ + maxZ) / 2; }
    }

    private boolean hooked = false;
    private Object dataStore;
    private Method mGetPlayerData;
    private Method mGetClaimAt;
    private Method mGetAccrued;
    private Method mGetBonus;
    private Method mSetBonus;
    private Method mGetRemaining;
    private Method mGetClaims;
    private Method mAllowBuild;
    private Field fLesser;
    private Field fGreater;

    public boolean setup() {
        Plugin gp = Bukkit.getPluginManager().getPlugin("GriefPrevention");
        if (gp == null || !gp.isEnabled()) return false;

        try {
            Class<?> gpClass = Class.forName("me.ryanhamshire.GriefPrevention.GriefPrevention");
            Object instance = gpClass.getField("instance").get(null);
            this.dataStore = gpClass.getField("dataStore").get(instance);

            Class<?> dsClass = dataStore.getClass();
            this.mGetPlayerData = dsClass.getMethod("getPlayerData", UUID.class);

            Class<?> claimClass = Class.forName("me.ryanhamshire.GriefPrevention.Claim");
            this.mGetClaimAt = dsClass.getMethod("getClaimAt", Location.class, boolean.class, claimClass);
            this.mAllowBuild = claimClass.getMethod("allowBuild", Player.class, org.bukkit.Material.class);
            this.fLesser = claimClass.getField("lesserBoundaryCorner");
            this.fGreater = claimClass.getField("greaterBoundaryCorner");

            Class<?> pdClass = Class.forName("me.ryanhamshire.GriefPrevention.PlayerData");
            this.mGetAccrued = pdClass.getMethod("getAccruedClaimBlocks");
            this.mGetBonus = pdClass.getMethod("getBonusClaimBlocks");
            this.mSetBonus = pdClass.getMethod("setBonusClaimBlocks", int.class);
            this.mGetRemaining = pdClass.getMethod("getRemainingClaimBlocks");
            this.mGetClaims = pdClass.getMethod("getClaims");

            this.hooked = true;
            return true;
        } catch (Exception e) {
            this.hooked = false;
            return false;
        }
    }

    public boolean isHooked() { return hooked; }

    public boolean isClaimedAt(Location loc) {
        if (!hooked || loc == null) return false;
        try {
            Object claim = mGetClaimAt.invoke(dataStore, loc, true, null);
            return claim != null;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean canBuildAt(Player player, Location loc, org.bukkit.Material mat) {
        if (!hooked || loc == null) return true;
        try {
            Object claim = mGetClaimAt.invoke(dataStore, loc, true, null);
            if (claim == null) return true;
            Object denialReason = mAllowBuild.invoke(claim, player, mat);
            return denialReason == null;
        } catch (Exception e) {
            return true;
        }
    }

    public int getAccruedBlocks(UUID uuid) {
        if (!hooked) return 0;
        try {
            Object pd = mGetPlayerData.invoke(dataStore, uuid);
            return (int) mGetAccrued.invoke(pd);
        } catch (Exception e) {
            return 0;
        }
    }

    public int getBonusBlocks(UUID uuid) {
        if (!hooked) return 0;
        try {
            Object pd = mGetPlayerData.invoke(dataStore, uuid);
            return (int) mGetBonus.invoke(pd);
        } catch (Exception e) {
            return 0;
        }
    }

    public int getRemainingBlocks(UUID uuid) {
        if (!hooked) return 0;
        try {
            Object pd = mGetPlayerData.invoke(dataStore, uuid);
            return (int) mGetRemaining.invoke(pd);
        } catch (Exception e) {
            return 0;
        }
    }

    public boolean addBonusBlocks(UUID uuid, int delta) {
        if (!hooked) return false;
        try {
            Object pd = mGetPlayerData.invoke(dataStore, uuid);
            int current = (int) mGetBonus.invoke(pd);
            int next = current + delta;
            if (next < 0) return false;
            mSetBonus.invoke(pd, next);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public List<GPClaimInfo> getPlayerClaims(UUID uuid) {
        List<GPClaimInfo> result = new ArrayList<>();
        if (!hooked) return result;
        try {
            Object pd = mGetPlayerData.invoke(dataStore, uuid);
            Collection<?> claims = (Collection<?>) mGetClaims.invoke(pd);
            int idx = 1;
            for (Object c : claims) {
                Location lesser = (Location) fLesser.get(c);
                Location greater = (Location) fGreater.get(c);
                if (lesser == null || greater == null || lesser.getWorld() == null) continue;
                int minX = Math.min(lesser.getBlockX(), greater.getBlockX());
                int maxX = Math.max(lesser.getBlockX(), greater.getBlockX());
                int minZ = Math.min(lesser.getBlockZ(), greater.getBlockZ());
                int maxZ = Math.max(lesser.getBlockZ(), greater.getBlockZ());
                int cx = (minX + maxX) / 2;
                int cz = (minZ + maxZ) / 2;
                int y = lesser.getWorld().getHighestBlockYAt(cx, cz) + 1;
                Location tp = new Location(lesser.getWorld(), cx + 0.5, y, cz + 0.5);
                result.add(new GPClaimInfo(idx++, lesser.getWorld().getName(), minX, minZ, maxX, maxZ, tp));
            }
        } catch (Exception ignored) {}
        return result;
    }
}
