package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.util.PermissionUtil;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.CompletableFuture;

public class RtpManager {
    private final SurvivalPlus plugin;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> searching = new HashSet<>();
    private final Random random = new Random();

    // منطقة الانتقال الجماعي في السباون
    private Location groupPos1;
    private Location groupPos2;
    private int groupCountdown = -1;

    public RtpManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        loadGroupRegion();
        startGroupZoneTask();
    }

    public void loadGroupRegion() {
        this.groupPos1 = parseLoc(plugin.getConfig().getString("group-rtp.pos1", ""));
        this.groupPos2 = parseLoc(plugin.getConfig().getString("group-rtp.pos2", ""));
    }

    private Location parseLoc(String str) {
        if (str == null || str.isEmpty()) return null;
        try {
            String[] p = str.split(":");
            World w = Bukkit.getWorld(p[0]);
            if (w == null) return null;
            return new Location(w, Double.parseDouble(p[1]), Double.parseDouble(p[2]), Double.parseDouble(p[3]));
        } catch (Exception e) {
            return null;
        }
    }

    private String serializeLoc(Location loc) {
        return loc.getWorld().getName() + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
    }

    public void setGroupPos(int num, Location loc) {
        if (num == 1) {
            this.groupPos1 = loc.clone();
            plugin.getConfig().set("group-rtp.pos1", serializeLoc(loc));
        } else {
            this.groupPos2 = loc.clone();
            plugin.getConfig().set("group-rtp.pos2", serializeLoc(loc));
        }
        if (this.groupPos1 != null && this.groupPos2 != null) {
            plugin.getConfig().set("group-rtp.enabled", true);
        }
        plugin.saveConfig();
    }

    public boolean isDimensionEnabled(String dimKey) {
        return plugin.getConfig().getBoolean("rtp.worlds." + dimKey + ".enabled", true);
    }

    public boolean toggleDimension(String dimKey) {
        boolean next = !isDimensionEnabled(dimKey);
        plugin.getConfig().set("rtp.worlds." + dimKey + ".enabled", next);
        plugin.saveConfig();
        return next;
    }

    public void startDimensionRtp(Player player, String dimKey) {
        if (!isDimensionEnabled(dimKey)) {
            player.sendMessage(plugin.msg("rtp.world-disabled"));
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        if (searching.contains(player.getUniqueId())) return;

        if (!player.hasPermission("survivalplus.rtp.bypass")) {
            int defaultCd = plugin.getConfig().getInt("rtp.default-cooldown-seconds", 300);
            int cd = PermissionUtil.getMinNumericPermission(player, "survivalplus.rtp.cooldown.", defaultCd, 0);
            long last = cooldowns.getOrDefault(player.getUniqueId(), 0L);
            long elapsedSec = (System.currentTimeMillis() - last) / 1000L;
            if (elapsedSec < cd) {
                long left = cd - elapsedSec;
                player.sendMessage(plugin.msg("rtp.cooldown", "{time}", TextUtil.formatDuration(left)));
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }
        }

        String worldName = plugin.getConfig().getString("rtp.worlds." + dimKey + ".world-name", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            // البحث التلقائي حسب البيئة لو اختلف اسم العالم في الاستضافة
            World.Environment targetEnv = switch (dimKey) {
                case "nether" -> World.Environment.NETHER;
                case "end" -> World.Environment.THE_END;
                default -> World.Environment.NORMAL;
            };
            for (World w : Bukkit.getWorlds()) {
                if (w.getEnvironment() == targetEnv) {
                    world = w;
                    break;
                }
            }
        }
        if (world == null) {
            player.sendMessage(plugin.msg("rtp.world-disabled"));
            return;
        }

        int minR = plugin.getConfig().getInt("rtp.worlds." + dimKey + ".min-radius", 250);
        int maxR = plugin.getConfig().getInt("rtp.worlds." + dimKey + ".max-radius", 3500);
        String displayName = plugin.getConfig().getString("rtp.worlds." + dimKey + ".display-name", world.getName());

        searching.add(player.getUniqueId());
        player.sendMessage(plugin.msg("rtp.searching", "{world}", displayName));

        int attempts = plugin.getConfig().getInt("rtp.max-attempts", 20);
        World finalWorld = world;
        findSafeLocationAsync(world, minR, maxR, attempts).thenAccept(safeLoc -> {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) {
                    searching.remove(player.getUniqueId());
                    return;
                }
                if (safeLoc == null) {
                    searching.remove(player.getUniqueId());
                    player.sendMessage(TextUtil.color("&cتعذر العثور على مكان آمن حالياً، حاول مرة أخرى."));
                    return;
                }
                beginWarmup(player, safeLoc, displayName);
            });
        });
    }

    public CompletableFuture<Location> findSafeLocationAsync(World world, int minR, int maxR, int attemptsLeft) {
        if (attemptsLeft <= 0) {
            return CompletableFuture.completedFuture(null);
        }

        double angle = random.nextDouble() * Math.PI * 2;
        double dist = minR + random.nextDouble() * Math.max(100, maxR - minR);
        int x = (int) Math.round(Math.cos(angle) * dist);
        int z = (int) Math.round(Math.sin(angle) * dist);

        return world.getChunkAtAsync(x >> 4, z >> 4).thenCompose(chunk -> {
            Location candidate = evaluateColumn(world, x, z);
            if (candidate != null && !plugin.getGpHook().isClaimedAt(candidate)) {
                return CompletableFuture.completedFuture(candidate);
            }
            return findSafeLocationAsync(world, minR, maxR, attemptsLeft - 1);
        });
    }

    private Location evaluateColumn(World world, int x, int z) {
        World.Environment env = world.getEnvironment();
        if (env == World.Environment.NETHER) {
            // البحث بين Y=34 و Y=115 لتجنب بحار اللافا وسقف النذر (Y=128)
            for (int y = 112; y >= 34; y--) {
                Block floor = world.getBlockAt(x, y, z);
                Block b1 = world.getBlockAt(x, y + 1, z);
                Block b2 = world.getBlockAt(x, y + 2, z);
                if (isSafeGround(floor.getType()) && b1.isPassable() && !b1.isLiquid() && b2.isPassable() && !b2.isLiquid()) {
                    return floor.getLocation().add(0.5, 1.0, 0.5);
                }
            }
            return null;
        }

        Block highest = world.getHighestBlockAt(x, z);
        if (env == World.Environment.THE_END && highest.getY() < 40) {
            return null; // تجنب السقوط في فراغ الإند
        }
        Block above1 = highest.getRelative(0, 1, 0);
        Block above2 = highest.getRelative(0, 2, 0);
        if (isSafeGround(highest.getType()) && above1.isPassable() && !above1.isLiquid() && above2.isPassable() && !above2.isLiquid()) {
            return highest.getLocation().add(0.5, 1.0, 0.5);
        }
        return null;
    }

    private boolean isSafeGround(Material mat) {
        if (!mat.isSolid()) return false;
        return switch (mat) {
            case LAVA, WATER, MAGMA_BLOCK, CACTUS, CAMPFIRE, SOUL_CAMPFIRE,
                 FIRE, SOUL_FIRE, POWDER_SNOW, SWEET_BERRY_BUSH, POINTED_DRIPSTONE, BEDROCK -> false;
            default -> true;
        };
    }

    private void beginWarmup(Player player, Location target, String displayName) {
        int warmup = player.hasPermission("survivalplus.rtp.bypass") ? 0 : plugin.getConfig().getInt("rtp.warmup-seconds", 3);
        if (warmup <= 0) {
            completeTeleport(player, target, displayName);
            return;
        }

        Location startLoc = player.getLocation().clone();
        player.sendMessage(plugin.msg("rtp.warmup", "{seconds}", String.valueOf(warmup)));

        new BukkitRunnable() {
            int remaining = warmup;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    searching.remove(player.getUniqueId());
                    cancel();
                    return;
                }
                if (plugin.getCombatManager().isInCombat(player)) {
                    searching.remove(player.getUniqueId());
                    player.sendMessage(plugin.msg("rtp.cancelled-combat"));
                    cancel();
                    return;
                }
                if (player.getLocation().getWorld() != startLoc.getWorld()
                        || player.getLocation().distanceSquared(startLoc) > 1.2) {
                    searching.remove(player.getUniqueId());
                    player.sendMessage(plugin.msg("rtp.cancelled-move"));
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                    cancel();
                    return;
                }
                if (remaining <= 0) {
                    completeTeleport(player, target, displayName);
                    cancel();
                    return;
                }
                player.sendActionBar(plugin.getMessages().getNoPrefix("rtp.warmup-actionbar", "{seconds}", String.valueOf(remaining)));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.6f, 1.2f);
                remaining--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void completeTeleport(Player player, Location target, String displayName) {
        searching.remove(player.getUniqueId());
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis());
        player.teleport(target);
        player.playSound(target, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
        player.spawnParticle(Particle.PORTAL, target.clone().add(0, 1, 0), 40, 0.5, 1, 0.5, 0.1);
        player.sendMessage(plugin.msg("rtp.success",
                "{world}", displayName,
                "{x}", String.valueOf(target.getBlockX()),
                "{y}", String.valueOf(target.getBlockY()),
                "{z}", String.valueOf(target.getBlockZ())));
    }

    // ==================== منطقة الانتقال الجماعي في السباون ====================
    private boolean isInsideGroupZone(Location loc) {
        if (groupPos1 == null || groupPos2 == null || loc.getWorld() == null) return false;
        if (!loc.getWorld().equals(groupPos1.getWorld())) return false;
        int minX = Math.min(groupPos1.getBlockX(), groupPos2.getBlockX());
        int maxX = Math.max(groupPos1.getBlockX(), groupPos2.getBlockX());
        int minY = Math.min(groupPos1.getBlockY(), groupPos2.getBlockY()) - 1;
        int maxY = Math.max(groupPos1.getBlockY(), groupPos2.getBlockY()) + 3;
        int minZ = Math.min(groupPos1.getBlockZ(), groupPos2.getBlockZ());
        int maxZ = Math.max(groupPos1.getBlockZ(), groupPos2.getBlockZ());
        int x = loc.getBlockX(), y = loc.getBlockY(), z = loc.getBlockZ();
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    private void startGroupZoneTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!plugin.getConfig().getBoolean("group-rtp.enabled", false)) return;
                if (groupPos1 == null || groupPos2 == null || groupPos1.getWorld() == null) return;

                List<Player> inside = new ArrayList<>();
                for (Player p : groupPos1.getWorld().getPlayers()) {
                    if (isInsideGroupZone(p.getLocation())) {
                        inside.add(p);
                    }
                }

                int minPlayers = plugin.getConfig().getInt("group-rtp.min-players", 1);
                if (inside.size() < minPlayers) {
                    groupCountdown = -1;
                    return;
                }

                if (groupCountdown < 0) {
                    groupCountdown = plugin.getConfig().getInt("group-rtp.countdown-seconds", 10);
                }

                // تأثير بصري خفيف حول المنطقة
                Location center = groupPos1.clone().add(groupPos2).multiply(0.5);
                groupPos1.getWorld().spawnParticle(Particle.END_ROD, center.add(0, 1, 0), 12, 1.5, 0.5, 1.5, 0.02);

                if (groupCountdown > 0) {
                    for (Player p : inside) {
                        p.sendActionBar(plugin.getMessages().getNoPrefix("group-rtp.actionbar-countdown",
                                "{seconds}", String.valueOf(groupCountdown),
                                "{count}", String.valueOf(inside.size())));
                        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.6f, 1.0f + ((10 - Math.min(10, groupCountdown)) * 0.08f));
                    }
                    groupCountdown--;
                    return;
                }

                // وصل العد للصفر -> نقل جماعي إلى نفس الإحداثيات!
                groupCountdown = -1;
                String targetWorldName = plugin.getConfig().getString("group-rtp.target-world", "world");
                World targetWorld = Bukkit.getWorld(targetWorldName);
                if (targetWorld == null) targetWorld = Bukkit.getWorlds().get(0);

                int minR = plugin.getConfig().getInt("group-rtp.min-radius", 300);
                int maxR = plugin.getConfig().getInt("group-rtp.max-radius", 3500);
                List<Player> snapshot = new ArrayList<>(inside);

                findSafeLocationAsync(targetWorld, minR, maxR, 25).thenAccept(sharedLoc -> {
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        if (sharedLoc == null) return;
                        int count = 0;
                        for (Player p : snapshot) {
                            if (p.isOnline() && isInsideGroupZone(p.getLocation())) {
                                p.teleport(sharedLoc);
                                p.playSound(sharedLoc, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
                                p.spawnParticle(Particle.PORTAL, sharedLoc.clone().add(0, 1, 0), 30, 0.5, 1, 0.5, 0.1);
                                count++;
                            }
                        }
                        if (count > 0) {
                            for (Player p : snapshot) {
                                if (p.isOnline()) {
                                    p.sendMessage(plugin.msg("group-rtp.teleported",
                                            "{count}", String.valueOf(count),
                                            "{x}", String.valueOf(sharedLoc.getBlockX()),
                                            "{y}", String.valueOf(sharedLoc.getBlockY()),
                                            "{z}", String.valueOf(sharedLoc.getBlockZ())));
                                }
                            }
                        }
                    });
                });
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    public void cleanupPlayer(UUID uuid) {
        searching.remove(uuid);
    }
}
