package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.models.GraveData;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Skull;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class GraveManager {
    private final SurvivalPlus plugin;
    private final File file;
    private FileConfiguration config;
    private final Map<String, GraveData> graves = new LinkedHashMap<>();

    public GraveManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "graves.yml");
        load();
        startTickTask();
    }

    public String locKey(Location loc) {
        return loc.getWorld().getName() + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
    }

    public void load() {
        graves.clear();
        if (!file.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = config.getConfigurationSection("graves");
        if (root == null) return;

        for (String id : root.getKeys(false)) {
            try {
                ConfigurationSection sec = root.getConfigurationSection(id);
                if (sec == null) continue;
                UUID ownerUuid = UUID.fromString(sec.getString("ownerUuid"));
                String ownerName = sec.getString("ownerName", "لاعب");
                Location loc = sec.getLocation("location");
                int exp = sec.getInt("exp", 0);
                long created = sec.getLong("createdAt", System.currentTimeMillis());
                long expires = sec.getLong("expiresAt", System.currentTimeMillis() + 60000L);
                String holoStr = sec.getString("hologramUuid");

                List<ItemStack> items = new ArrayList<>();
                ConfigurationSection itemsSec = sec.getConfigurationSection("items");
                if (itemsSec != null) {
                    for (String k : itemsSec.getKeys(false)) {
                        ItemStack item = itemsSec.getItemStack(k);
                        if (item != null && item.getType() != Material.AIR) items.add(item);
                    }
                }
                if (loc != null && loc.getWorld() != null && !items.isEmpty()) {
                    GraveData gd = new GraveData(id, ownerUuid, ownerName, loc, items, exp, created, expires);
                    if (holoStr != null && !holoStr.isEmpty()) {
                        gd.setHologramEntityUuid(UUID.fromString(holoStr));
                    }
                    graves.put(id, gd);
                }
            } catch (Exception ignored) {}
        }
    }

    public void save() {
        config = new YamlConfiguration();
        for (GraveData gd : graves.values()) {
            if (gd.isClaimed()) continue;
            String base = "graves." + gd.getId();
            config.set(base + ".ownerUuid", gd.getOwnerUuid().toString());
            config.set(base + ".ownerName", gd.getOwnerName());
            config.set(base + ".location", gd.getLocation());
            config.set(base + ".exp", gd.getStoredExp());
            config.set(base + ".createdAt", gd.getCreatedAt());
            config.set(base + ".expiresAt", gd.getExpiresAt());
            config.set(base + ".hologramUuid", gd.getHologramEntityUuid() != null ? gd.getHologramEntityUuid().toString() : null);

            int idx = 0;
            for (ItemStack item : gd.getItems()) {
                config.set(base + ".items." + (idx++), item);
            }
        }
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public GraveData createGrave(Player player, Location deathLoc, List<ItemStack> drops, int exp) {
        if (!plugin.getConfig().getBoolean("graves.enabled", true)) return null;
        List<ItemStack> cleanDrops = new ArrayList<>();
        for (ItemStack item : drops) {
            if (item != null && item.getType() != Material.AIR && item.getAmount() > 0) {
                cleanDrops.add(item.clone());
            }
        }
        if (cleanDrops.isEmpty()) return null;

        Location safeLoc = findSafeGraveLocation(deathLoc);
        Block block = safeLoc.getBlock();
        block.setType(Material.PLAYER_HEAD);
        if (block.getState() instanceof Skull skull) {
            skull.setOwningPlayer(player);
            skull.update(true, false);
        }

        int minutes = plugin.getConfig().getInt("graves.expire-minutes", 15);
        long now = System.currentTimeMillis();
        long expires = now + (minutes * 60L * 1000L);
        String id = UUID.randomUUID().toString().substring(0, 8);

        GraveData grave = new GraveData(id, player.getUniqueId(), player.getName(), block.getLocation(), cleanDrops, exp, now, expires);
        spawnHologram(grave);
        graves.put(id, grave);
        save();

        player.sendMessage(plugin.msg("graves.created",
                "{x}", String.valueOf(block.getX()),
                "{y}", String.valueOf(block.getY()),
                "{z}", String.valueOf(block.getZ()),
                "{minutes}", String.valueOf(minutes)));
        return grave;
    }

    private Location findSafeGraveLocation(Location raw) {
        World world = raw.getWorld();
        int x = raw.getBlockX();
        int z = raw.getBlockZ();
        int minY = world.getMinHeight() + 1;
        int maxY = world.getMaxHeight() - 2;
        int y = Math.max(minY, Math.min(maxY, raw.getBlockY()));

        // إذا مات في اللافا، اصعد للأعلى حتى تجد هواء
        for (int scanY = y; scanY <= Math.min(maxY, y + 30); scanY++) {
            Block b = world.getBlockAt(x, scanY, z);
            if (b.getType() == Material.AIR || b.getType() == Material.CAVE_AIR) {
                return b.getLocation();
            }
        }
        // إذا سقط في الـ Void (مثل الإند)، ابحث عن أقرب أرض صلبة قريبة أو السباون
        for (int r = 1; r <= 24; r += 2) {
            for (int dx = -r; dx <= r; dx += 2) {
                for (int dz = -r; dz <= r; dz += 2) {
                    Block top = world.getHighestBlockAt(x + dx, z + dz);
                    if (top.getType().isSolid() && top.getY() >= minY) {
                        return top.getRelative(0, 1, 0).getLocation();
                    }
                }
            }
        }
        return world.getSpawnLocation();
    }

    private void spawnHologram(GraveData grave) {
        Location holoLoc = grave.getLocation().clone().add(0.5, 1.15, 0.5);
        TextDisplay display = holoLoc.getWorld().spawn(holoLoc, TextDisplay.class, td -> {
            td.setBillboard(Display.Billboard.CENTER);
            td.setSeeThrough(false);
            td.setShadowed(true);
            td.text(buildHologramText(grave));
        });
        grave.setHologramEntityUuid(display.getUniqueId());
    }

    private net.kyori.adventure.text.Component buildHologramText(GraveData grave) {
        return TextUtil.color("&6&l⚰ قبر " + grave.getOwnerName() + "
"
                + "&7الأغراض: &e" + grave.getItems().size() + " &8| &7المتبقي: &c" + TextUtil.formatMMSS(grave.getRemainingSeconds()));
    }

    public GraveData getGraveAtBlock(Block block) {
        if (block == null) return null;
        String target = locKey(block.getLocation());
        for (GraveData g : graves.values()) {
            if (!g.isClaimed() && locKey(g.getLocation()).equals(target)) {
                return g;
            }
        }
        return null;
    }

    public GraveData getGraveById(String id) {
        return graves.get(id);
    }

    public List<GraveData> getPlayerGraves(UUID ownerUuid) {
        List<GraveData> list = new ArrayList<>();
        for (GraveData g : graves.values()) {
            if (!g.isClaimed() && !g.isExpired() && g.getOwnerUuid().equals(ownerUuid)) {
                list.add(g);
            }
        }
        return list;
    }

    /**
     * استلام القبر مع قفل فوري Anti-Dupe لمنع التكرار عند الضغط السريع
     */
    public boolean claimGrave(Player player, GraveData grave) {
        if (grave == null || grave.isClaimed()) return false;
        if (!grave.getOwnerUuid().equals(player.getUniqueId()) && !player.hasPermission("survivalplus.admin")) {
            player.sendMessage(plugin.msg("graves.not-owner"));
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return false;
        }

        // قفل وحذف فوري قبل تسليم الأغراض
        grave.setClaimed(true);
        graves.remove(grave.getId());
        removeGraveVisuals(grave);
        save();

        for (ItemStack item : grave.getItems()) {
            plugin.getShopManager().giveItemSafely(player, item);
        }
        if (grave.getStoredExp() > 0 && plugin.getConfig().getBoolean("graves.keep-xp", true)) {
            player.giveExp(grave.getStoredExp());
        }

        player.sendMessage(plugin.msg("graves.claimed"));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.9f, 1.3f);
        return true;
    }

    private void removeGraveVisuals(GraveData grave) {
        Location loc = grave.getLocation();
        if (loc != null && loc.getWorld() != null) {
            Block b = loc.getBlock();
            if (b.getType() == Material.PLAYER_HEAD || b.getType() == Material.PLAYER_WALL_HEAD) {
                b.setType(Material.AIR);
            }
        }
        if (grave.getHologramEntityUuid() != null) {
            Entity ent = Bukkit.getEntity(grave.getHologramEntityUuid());
            if (ent != null) ent.remove();
        }
    }

    private void startTickTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (graves.isEmpty()) return;
                boolean changed = false;
                Iterator<Map.Entry<String, GraveData>> it = graves.entrySet().iterator();
                while (it.hasNext()) {
                    GraveData gd = it.next().getValue();
                    if (gd.isClaimed()) {
                        it.remove();
                        changed = true;
                        continue;
                    }
                    if (gd.isExpired()) {
                        gd.setClaimed(true);
                        removeGraveVisuals(gd);
                        it.remove();
                        changed = true;
                        Player owner = Bukkit.getPlayer(gd.getOwnerUuid());
                        if (owner != null && owner.isOnline()) {
                            owner.sendMessage(plugin.msg("graves.expired"));
                        }
                        continue;
                    }
                    if (gd.getHologramEntityUuid() != null) {
                        Entity ent = Bukkit.getEntity(gd.getHologramEntityUuid());
                        if (ent instanceof TextDisplay td) {
                            td.text(buildHologramText(gd));
                        }
                    }
                }
                if (changed) save();
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    public void cleanupAllVisuals() {
        save();
    }
}
