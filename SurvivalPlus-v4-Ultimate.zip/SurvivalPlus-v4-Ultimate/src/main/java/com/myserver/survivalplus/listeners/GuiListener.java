package com.myserver.survivalplus.listeners;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.gui.GuiHolder;
import com.myserver.survivalplus.managers.ChatPromptManager;
import com.myserver.survivalplus.managers.CustomMenuManager;
import com.myserver.survivalplus.managers.ShopManager;
import com.myserver.survivalplus.models.GraveData;
import com.myserver.survivalplus.models.PlayerShop;
import com.myserver.survivalplus.models.ShopListing;
import com.myserver.survivalplus.util.GriefPreventionHook;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class GuiListener implements Listener {
    private final SurvivalPlus plugin;
    private final Map<UUID, Long> toolCooldowns = new HashMap<>();

    public GuiListener(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof GuiHolder
                || event.getView().getTopInventory().getHolder() instanceof CustomMenuManager.CustomMenuHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (event.getInventory().getHolder() instanceof com.myserver.survivalplus.managers.VaultManager.VaultInventoryHolder vh) {
            plugin.getVaultManager().saveAndCloseVault(vh.getOwnerUuid(), vh.getVaultNumber(), event.getInventory());
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        // 1. القائمة الرئيسية المخصصة (/القائمة)
        if (event.getView().getTopInventory().getHolder() instanceof CustomMenuManager.CustomMenuHolder) {
            event.setCancelled(true);
            if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) return;
            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;
            String cmd = clicked.getItemMeta().getPersistentDataContainer()
                    .get(plugin.getCustomMenuManager().keyCommand, PersistentDataType.STRING);
            if (cmd != null && !cmd.isEmpty()) {
                player.closeInventory();
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.2f);
                Bukkit.dispatchCommand(player, cmd);
            }
            return;
        }

        // 2. قوائم البلقن الداخلية
        if (!(event.getView().getTopInventory().getHolder() instanceof GuiHolder holder)) return;
        event.setCancelled(true);

        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        int slot = event.getSlot();

        switch (holder.getType()) {
            case CLAIMS_DASHBOARD -> handleClaimsDashboard(player, slot);
            case CLAIMS_LIST -> handleClaimsList(player, slot, clicked);
            case RTP_WORLD_SELECTOR -> handleRtpSelector(player, clicked);
            case VAULTS_LIST -> handleVaultsList(player, slot, clicked, event.isShiftClick());
            case GRAVES_LIST -> handleGravesList(player, slot, clicked, event.getClick());
            case GRAVE_PREVIEW -> {
                if (slot == 49) {
                    clickSound(player);
                    plugin.getGuiManager().openGravesList(player);
                }
            }
            case HOMES_LIST -> handleHomesList(player, slot, clicked);
            case SHOP_DIRECTORY -> handleShopDirectory(player, holder, slot, clicked);
            case PLAYER_SHOP -> handlePlayerShop(player, holder, slot, clicked, event.getClick());
            case SHOP_CONFIRM -> handleShopConfirm(player, holder, slot);
            case OWNER_DASHBOARD -> handleOwnerDashboard(player, slot);
            case OWNER_LISTINGS -> handleOwnerListings(player, slot, clicked, event.getClick());
            case OWNER_SALES_LOG -> {
                if (slot == 49) {
                    clickSound(player);
                    plugin.getGuiManager().openShopOwnerDashboard(player);
                }
            }
            case OWNER_ICON_PICKER -> handleIconPicker(player, holder, slot, clicked);
        }
    }

    // --- 1. إدارة الأراضي ومتجر النقاط ---
    private void handleClaimsDashboard(Player player, int slot) {
        if (slot == 36) {
            player.closeInventory();
            return;
        }
        if (slot == 29) {
            clickSound(player);
            plugin.getGuiManager().openClaimsList(player);
            return;
        }
        if (slot == 11 || slot == 20) {
            int cd = plugin.getConfig().getInt("claims-gui.tool-cooldown-seconds", 30);
            long last = toolCooldowns.getOrDefault(player.getUniqueId(), 0L);
            long elapsed = (System.currentTimeMillis() - last) / 1000L;
            if (elapsed < cd && !player.hasPermission("survivalplus.admin")) {
                player.sendMessage(plugin.msg("claims-gui.tool-cooldown", "{seconds}", String.valueOf(cd - elapsed)));
                return;
            }
            toolCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
            if (slot == 11) {
                plugin.getShopManager().giveItemSafely(player, new ItemStack(Material.GOLDEN_SHOVEL));
                player.sendMessage(plugin.msg("claims-gui.tool-given", "{tool}", "مجرفة الذهب"));
            } else {
                plugin.getShopManager().giveItemSafely(player, new ItemStack(Material.STICK));
                player.sendMessage(plugin.msg("claims-gui.tool-given", "{tool}", "عصا الفحص"));
            }
            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 1.2f);
            return;
        }

        if (slot == 13 || slot == 22 || slot == 31) {
            String key = (slot == 13) ? "pack-small" : (slot == 22 ? "pack-medium" : "pack-large");
            int blocks = plugin.getConfig().getInt("claims-gui." + key + ".blocks", 100);
            double price = plugin.getConfig().getDouble("claims-gui." + key + ".price", 500.0);
            String sym = plugin.getCurrencySymbol();

            if (!plugin.getEconomy().isReady()) {
                player.sendMessage(plugin.msg("general.vault-missing"));
                return;
            }
            if (!plugin.getEconomy().has(player, price)) {
                player.sendMessage(plugin.msg("shop.not-enough-money", "{price}", TextUtil.formatMoney(price, sym)));
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }
            if (plugin.getEconomy().withdraw(player, price) && plugin.getGpHook().addBonusBlocks(player.getUniqueId(), blocks)) {
                player.sendMessage(plugin.msg("claims-gui.bought",
                        "{blocks}", String.valueOf(blocks),
                        "{price}", TextUtil.formatMoney(price, sym)));
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.4f);
                plugin.getGuiManager().openClaimsDashboard(player);
            }
            return;
        }

        if (slot == 24) {
            int blocks = plugin.getConfig().getInt("claims-gui.sell-pack.blocks", 100);
            double payout = plugin.getConfig().getDouble("claims-gui.sell-pack.payout", 250.0);
            String sym = plugin.getCurrencySymbol();

            int bonus = plugin.getGpHook().getBonusBlocks(player.getUniqueId());
            int rem = plugin.getGpHook().getRemainingBlocks(player.getUniqueId());
            if (bonus < blocks || rem < blocks) {
                player.sendMessage(plugin.msg("claims-gui.not-enough-sell", "{blocks}", String.valueOf(blocks)));
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }
            if (plugin.getGpHook().addBonusBlocks(player.getUniqueId(), -blocks)) {
                plugin.getEconomy().deposit(player, payout);
                player.sendMessage(plugin.msg("claims-gui.sold",
                        "{blocks}", String.valueOf(blocks),
                        "{payout}", TextUtil.formatMoney(payout, sym)));
                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
                plugin.getGuiManager().openClaimsDashboard(player);
            }
        }
    }

    private void handleClaimsList(Player player, int slot, ItemStack clicked) {
        if (slot == 49) {
            clickSound(player);
            plugin.getGuiManager().openClaimsDashboard(player);
            return;
        }
        if (slot < 45 && clicked.hasItemMeta()) {
            Integer idx = clicked.getItemMeta().getPersistentDataContainer().get(plugin.getGuiManager().keyIntData, PersistentDataType.INTEGER);
            if (idx == null) return;
            List<GriefPreventionHook.GPClaimInfo> claims = plugin.getGpHook().getPlayerClaims(player.getUniqueId());
            if (idx < 0 || idx >= claims.size()) return;

            GriefPreventionHook.GPClaimInfo target = claims.get(idx);
            player.closeInventory();
            int warmup = plugin.getConfig().getInt("claims-gui.teleport-warmup-seconds", 3);
            player.sendMessage(plugin.msg("claims-gui.teleporting"));
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (!player.isOnline()) return;
                    if (plugin.getCombatManager().isInCombat(player)) {
                        player.sendMessage(plugin.msg("rtp.cancelled-combat"));
                        return;
                    }
                    player.teleport(target.teleportTarget());
                    player.playSound(target.teleportTarget(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
                }
            }.runTaskLater(plugin, warmup * 20L);
        }
    }

    // --- 2. اختيار عالم RTP ---
    private void handleRtpSelector(Player player, ItemStack clicked) {
        if (!clicked.hasItemMeta()) return;
        String dimKey = clicked.getItemMeta().getPersistentDataContainer().get(plugin.getGuiManager().keyData, PersistentDataType.STRING);
        if (dimKey != null) {
            player.closeInventory();
            plugin.getRtpManager().startDimensionRtp(player, dimKey);
        }
    }

    // --- 3. الخزائن الشخصية ---
    private void handleVaultsList(Player player, int slot, ItemStack clicked, boolean shift) {
        if (slot == eventLastRowCenter(clicked)) {
            player.closeInventory();
            return;
        }
        if (clicked.getType() == Material.BARRIER) {
            player.closeInventory();
            return;
        }
        if (!clicked.hasItemMeta()) return;
        Integer vaultNum = clicked.getItemMeta().getPersistentDataContainer().get(plugin.getGuiManager().keyIntData, PersistentDataType.INTEGER);
        if (vaultNum == null) return;

        int allowed = plugin.getVaultManager().getAllowedVaults(player);
        if (vaultNum > allowed) {
            player.sendMessage(plugin.msg("vaults.no-access"));
            return;
        }

        if (shift) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand.getType() == Material.AIR) {
                player.sendMessage(plugin.msg("vaults.hold-item"));
                return;
            }
            plugin.getVaultManager().setVaultIcon(player.getUniqueId(), vaultNum, hand.getType());
            player.sendMessage(plugin.msg("vaults.icon-updated", "{num}", String.valueOf(vaultNum)));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
            plugin.getGuiManager().openVaultsList(player);
        } else {
            player.playSound(player.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.8f, 1.1f);
            plugin.getVaultManager().openVault(player, player.getUniqueId(), vaultNum);
        }
    }

    private int eventLastRowCenter(ItemStack item) { return -1; }

    // --- 4. القبور النشطة ---
    private void handleGravesList(Player player, int slot, ItemStack clicked, ClickType clickType) {
        if (slot == 40) {
            player.closeInventory();
            return;
        }
        if (slot < 36 && clicked.hasItemMeta()) {
            String graveId = clicked.getItemMeta().getPersistentDataContainer().get(plugin.getGuiManager().keyData, PersistentDataType.STRING);
            if (graveId == null) return;
            GraveData grave = plugin.getGraveManager().getGraveById(graveId);
            if (grave == null || grave.isClaimed() || grave.isExpired()) {
                plugin.getGuiManager().openGravesList(player);
                return;
            }

            if (clickType.isRightClick()) {
                clickSound(player);
                plugin.getGuiManager().openGravePreview(player, grave);
                return;
            }

            // كليك يسار -> الانتقال للقبر
            if (!plugin.getConfig().getBoolean("graves.allow-teleport", true)) return;
            double cost = plugin.getConfig().getDouble("graves.teleport-cost", 100.0);
            boolean free = cost <= 0 || player.hasPermission("survivalplus.graves.free");
            if (!free) {
                if (!plugin.getEconomy().isReady()) {
                    player.sendMessage(plugin.msg("general.vault-missing"));
                    return;
                }
                if (!plugin.getEconomy().has(player, cost)) {
                    player.sendMessage(plugin.msg("shop.not-enough-money", "{price}", TextUtil.formatMoney(cost, plugin.getCurrencySymbol())));
                    return;
                }
                if (!plugin.getEconomy().withdraw(player, cost)) return;
            }

            player.closeInventory();
            player.teleport(grave.getLocation().clone().add(0.5, 0.2, 0.5));
            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
            player.sendMessage(plugin.msg("graves.teleported"));
        }
    }

    // --- 5. منازل EssentialsX ---
    private void handleHomesList(Player player, int slot, ItemStack clicked) {
        if (slot == 40) {
            player.closeInventory();
            return;
        }
        if (slot < 36 && clicked.hasItemMeta()) {
            String homeName = clicked.getItemMeta().getPersistentDataContainer().get(plugin.getGuiManager().keyData, PersistentDataType.STRING);
            if (homeName != null) {
                player.closeInventory();
                Bukkit.dispatchCommand(player, "home " + homeName);
            }
        }
    }

    // --- 6. متاجر اللاعبين ---
    private void handleShopDirectory(Player player, GuiHolder holder, int slot, ItemStack clicked) {
        if (slot == 45 && clicked.getType() == Material.ARROW) {
            clickSound(player);
            plugin.getGuiManager().openShopDirectory(player, holder.getPage() - 1, holder.getSortMode());
            return;
        }
        if (slot == 53 && clicked.getType() == Material.ARROW) {
            clickSound(player);
            plugin.getGuiManager().openShopDirectory(player, holder.getPage() + 1, holder.getSortMode());
            return;
        }
        if (slot == 47) {
            clickSound(player);
            plugin.getGuiManager().openShopDirectory(player, 0, holder.getSortMode().next());
            return;
        }
        if (slot == 49) {
            clickSound(player);
            plugin.getGuiManager().openShopOwnerDashboard(player);
            return;
        }
        if (slot < 45 && clicked.hasItemMeta()) {
            String ownerStr = clicked.getItemMeta().getPersistentDataContainer().get(plugin.getGuiManager().keyData, PersistentDataType.STRING);
            if (ownerStr != null) {
                player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 0.7f, 1.2f);
                plugin.getGuiManager().openPlayerShop(player, UUID.fromString(ownerStr), true);
            }
        }
    }

    private void handlePlayerShop(Player player, GuiHolder holder, int slot, ItemStack clicked, ClickType clickType) {
        UUID ownerUuid = holder.getTargetUuid();
        PlayerShop shop = plugin.getShopManager().getShop(ownerUuid);
        if (shop == null) {
            player.closeInventory();
            return;
        }
        if (slot == 45) {
            clickSound(player);
            plugin.getGuiManager().openShopDirectory(player, 0, holder.getSortMode());
            return;
        }
        if (slot == 48 && !player.getUniqueId().equals(ownerUuid)) {
            boolean liked = shop.toggleLike(player.getUniqueId());
            plugin.getShopManager().save();
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, liked ? 1.5f : 0.8f);
            plugin.getGuiManager().openPlayerShop(player, ownerUuid, false);
            return;
        }
        if (slot == 50 && player.getUniqueId().equals(ownerUuid)) {
            clickSound(player);
            plugin.getGuiManager().openShopOwnerDashboard(player);
            return;
        }
        if (slot < 45 && clicked.hasItemMeta()) {
            String listingId = clicked.getItemMeta().getPersistentDataContainer().get(plugin.getGuiManager().keyData, PersistentDataType.STRING);
            if (listingId == null) return;
            ShopListing listing = shop.getListings().get(listingId);
            if (listing == null || listing.isSold()) {
                plugin.getGuiManager().openPlayerShop(player, ownerUuid, false);
                return;
            }
            if (player.getUniqueId().equals(ownerUuid)) {
                if (clickType.isRightClick()) {
                    plugin.getShopManager().withdrawListing(player, listingId);
                    plugin.getGuiManager().openPlayerShop(player, ownerUuid, false);
                } else {
                    plugin.getChatPromptManager().startPrompt(player, ChatPromptManager.PromptType.EDIT_PRICE,
                            listingId, "اكتب السعر الجديد للسلعة في الشات:");
                }
            } else {
                clickSound(player);
                plugin.getGuiManager().openShopConfirm(player, shop, listing);
            }
        }
    }

    private void handleShopConfirm(Player player, GuiHolder holder, int slot) {
        if (slot == 15) {
            clickSound(player);
            plugin.getGuiManager().openPlayerShop(player, holder.getTargetUuid(), false);
            return;
        }
        if (slot == 11) {
            plugin.getShopManager().purchaseListing(player, holder.getTargetUuid(), holder.getExtraId(), holder.getExpectedPrice());
            player.closeInventory();
        }
    }

    private void handleOwnerDashboard(Player player, int slot) {
        PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
        switch (slot) {
            case 11 -> { clickSound(player); plugin.getGuiManager().openShopOwnerListings(player); }
            case 13 -> { clickSound(player); plugin.getGuiManager().openShopSalesLog(player); }
            case 15 -> {
                if (!player.hasPermission("survivalplus.shop.icon")) {
                    player.sendMessage(plugin.msg("general.no-permission"));
                    return;
                }
                clickSound(player);
                plugin.getGuiManager().openShopIconPicker(player, 0);
            }
            case 20 -> { plugin.getShopManager().boostShop(player); plugin.getGuiManager().openShopOwnerDashboard(player); }
            case 22 -> plugin.getChatPromptManager().startPrompt(player, ChatPromptManager.PromptType.SHOP_NAME, null, "اكتب الاسم الجديد لمتجرك في الشات:");
            case 24 -> plugin.getChatPromptManager().startPrompt(player, ChatPromptManager.PromptType.SHOP_DESC, null, "اكتب الوصف الجديد لمتجرك في الشات:");
            case 30 -> {
                shop.setOpen(!shop.isOpen());
                plugin.getShopManager().save();
                clickSound(player);
                plugin.getGuiManager().openShopOwnerDashboard(player);
            }
            case 32 -> { clickSound(player); plugin.getGuiManager().openPlayerShop(player, player.getUniqueId(), false); }
            case 36 -> { clickSound(player); plugin.getGuiManager().openShopDirectory(player, 0, ShopManager.SortMode.TOP_SALES); }
        }
    }

    private void handleOwnerListings(Player player, int slot, ItemStack clicked, ClickType clickType) {
        if (slot == 49) {
            clickSound(player);
            plugin.getGuiManager().openShopOwnerDashboard(player);
            return;
        }
        if (slot < 45 && clicked.hasItemMeta()) {
            String listingId = clicked.getItemMeta().getPersistentDataContainer().get(plugin.getGuiManager().keyData, PersistentDataType.STRING);
            if (listingId == null) return;
            if (clickType.isRightClick()) {
                plugin.getShopManager().withdrawListing(player, listingId);
                plugin.getGuiManager().openShopOwnerListings(player);
            } else {
                plugin.getChatPromptManager().startPrompt(player, ChatPromptManager.PromptType.EDIT_PRICE, listingId, "اكتب السعر الجديد للسلعة في الشات:");
            }
        }
    }

    private void handleIconPicker(Player player, GuiHolder holder, int slot, ItemStack clicked) {
        PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
        if (slot == 45 && clicked.getType() == Material.ARROW) {
            clickSound(player);
            plugin.getGuiManager().openShopIconPicker(player, holder.getPage() - 1);
            return;
        }
        if (slot == 53 && clicked.getType() == Material.ARROW) {
            clickSound(player);
            plugin.getGuiManager().openShopIconPicker(player, holder.getPage() + 1);
            return;
        }
        if (slot == 49) {
            clickSound(player);
            plugin.getGuiManager().openShopOwnerDashboard(player);
            return;
        }
        if (slot == 2) {
            shop.setIconMaterial(null);
            plugin.getShopManager().save();
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
            plugin.getGuiManager().openShopOwnerDashboard(player);
            return;
        }
        if (slot == 6) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand.getType() == Material.AIR) {
                player.sendMessage(plugin.msg("shop.hold-item"));
                return;
            }
            shop.setIconMaterial(hand.getType());
            plugin.getShopManager().save();
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
            plugin.getGuiManager().openShopOwnerDashboard(player);
            return;
        }
        if (clicked.hasItemMeta()) {
            String matName = clicked.getItemMeta().getPersistentDataContainer().get(plugin.getGuiManager().keyData, PersistentDataType.STRING);
            if (matName != null) {
                Material mat = Material.matchMaterial(matName);
                if (mat != null) {
                    shop.setIconMaterial(mat);
                    plugin.getShopManager().save();
                    player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
                    plugin.getGuiManager().openShopOwnerDashboard(player);
                }
            }
        }
    }

    private void clickSound(Player player) {
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1.2f);
    }
}
