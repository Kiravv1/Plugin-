package com.myserver.survivalplus.managers;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class CustomMenuManager {
    private final SurvivalPlus plugin;
    private final File file;
    private FileConfiguration config;
    public final NamespacedKey keyCommand;

    public static class CustomMenuHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() { return null; }
    }

    public CustomMenuManager(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "menus.yml");
        this.keyCommand = new NamespacedKey(plugin, "splus_menu_cmd");
        reload();
    }

    public void reload() {
        if (!file.exists()) {
            plugin.saveResource("menus.yml", false);
        }
        config = YamlConfiguration.loadConfiguration(file);
    }

    public void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void openMainMenu(Player player) {
        String title = config.getString("title", "&8❖ &3قائمة السيرفر الرئيسية &8❖");
        int size = config.getInt("size", 45);
        if (size < 9 || size > 54 || size % 9 != 0) size = 45;

        Inventory inv = Bukkit.createInventory(new CustomMenuHolder(), size, TextUtil.color(title));

        if (config.getBoolean("fill-empty", true)) {
            Material fillerMat = Material.matchMaterial(config.getString("filler-material", "BLACK_STAINED_GLASS_PANE"));
            if (fillerMat == null) fillerMat = Material.BLACK_STAINED_GLASS_PANE;
            ItemStack filler = new ItemStack(fillerMat);
            ItemMeta fm = filler.getItemMeta();
            fm.displayName(TextUtil.color(" "));
            filler.setItemMeta(fm);
            for (int i = 0; i < size; i++) inv.setItem(i, filler);
        }

        ConfigurationSection itemsSec = config.getConfigurationSection("items");
        if (itemsSec != null) {
            for (String key : itemsSec.getKeys(false)) {
                ConfigurationSection sec = itemsSec.getConfigurationSection(key);
                if (sec == null) continue;
                int slot = sec.getInt("slot", -1);
                if (slot < 0 || slot >= size) continue;

                Material mat = Material.matchMaterial(sec.getString("material", "PAPER"));
                if (mat == null || !mat.isItem()) mat = Material.PAPER;

                ItemStack item = new ItemStack(mat);
                if (mat == Material.PLAYER_HEAD && item.getItemMeta() instanceof SkullMeta sm) {
                    sm.setOwningPlayer(player);
                    item.setItemMeta(sm);
                }

                ItemMeta meta = item.getItemMeta();
                meta.displayName(TextUtil.color(sec.getString("name", "&eعنصر")));
                List<String> lore = sec.getStringList("lore");
                if (!lore.isEmpty()) {
                    meta.lore(TextUtil.colorList(lore));
                }
                if (sec.getBoolean("glow", false)) {
                    meta.setEnchantmentGlintOverride(true);
                }
                String cmd = sec.getString("command", "");
                if (!cmd.isEmpty()) {
                    meta.getPersistentDataContainer().set(keyCommand, PersistentDataType.STRING, cmd);
                }
                item.setItemMeta(meta);
                inv.setItem(slot, item);
            }
        }

        player.openInventory(inv);
    }

    public void addItemFromHand(Player admin, int slot, ItemStack hand, String command) {
        String key = "custom_" + slot;
        config.set("items." + key + ".slot", slot);
        config.set("items." + key + ".material", hand.getType().name());

        String name = TextUtil.getItemFriendlyName(hand);
        if (hand.hasItemMeta() && hand.getItemMeta().hasDisplayName()) {
            name = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand()
                    .serialize(hand.getItemMeta().displayName());
        } else {
            name = "&b&l❖ " + name;
        }
        config.set("items." + key + ".name", name);

        List<String> lore = new ArrayList<>();
        if (hand.hasItemMeta() && hand.getItemMeta().hasLore() && hand.getItemMeta().lore() != null) {
            for (var c : hand.getItemMeta().lore()) {
                lore.add(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand().serialize(c));
            }
        } else {
            lore.add("&7اضغط لتنفيذ الأمر");
        }
        config.set("items." + key + ".lore", lore);
        config.set("items." + key + ".glow", hand.hasItemMeta() && hand.getItemMeta().hasEnchants());
        config.set("items." + key + ".command", command.startsWith("/") ? command.substring(1) : command);
        save();
    }

    public boolean removeSlot(int slot) {
        ConfigurationSection itemsSec = config.getConfigurationSection("items");
        if (itemsSec == null) return false;
        boolean found = false;
        for (String key : new ArrayList<>(itemsSec.getKeys(false))) {
            if (itemsSec.getInt(key + ".slot", -1) == slot) {
                config.set("items." + key, null);
                found = true;
            }
        }
        if (found) save();
        return found;
    }

    public void setTitle(String newTitle) {
        config.set("title", newTitle);
        save();
    }
}
