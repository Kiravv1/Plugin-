package com.myserver.survivalplus.commands;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.managers.ShopManager;
import com.myserver.survivalplus.models.PlayerShop;
import com.myserver.survivalplus.util.ArabicUtil;
import com.myserver.survivalplus.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class CoreCommandExecutor implements CommandExecutor, TabCompleter {
    private final SurvivalPlus plugin;

    public CoreCommandExecutor(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase();

        // أوامر الإدارة العامة /splus
        if (cmd.equals("splus")) {
            if (!sender.hasPermission("survivalplus.admin")) {
                sender.sendMessage(plugin.msg("general.no-permission"));
                return true;
            }
            if (args.length > 0 && ArabicUtil.matches(args[0], "reload", "تحديث", "اعادة")) {
                plugin.reloadConfig();
                plugin.getMessages().reload();
                plugin.getCustomMenuManager().reload();
                plugin.getRtpManager().loadGroupRegion();
                sender.sendMessage(plugin.msg("general.reloaded"));
                return true;
            }
            sender.sendMessage(TextUtil.color("&8&m----------&r &b✦ SurvivalPlus v4.0.0 ✦ &8&m----------"));
            sender.sendMessage(TextUtil.color("&e/splus reload &7- تحديث config.yml و messages.yml و menus.yml"));
            sender.sendMessage(TextUtil.color("&e/rtp toggle <world|nether|end> &7- تفعيل/إيقاف عالم في الـ RTP"));
            sender.sendMessage(TextUtil.color("&e/grouprtp <pos1|pos2> &7- تحديد منطقة الانتقال الجماعي في السباون"));
            sender.sendMessage(TextUtil.color("&e/menu add <الخانة> <الأمر> &7- إضافة الغرض بيدك للقائمة الرئيسية"));
            sender.sendMessage(TextUtil.color("&7حالة Vault: " + (plugin.getEconomy().isReady() ? "&aمتصل ✔" : "&cغير متصل ✘")
                    + " &8| &7حالة GriefPrevention: " + (plugin.getGpHook().isHooked() ? "&aمتصل ✔" : "&cغير متصل ✘")));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("general.players-only"));
            return true;
        }

        switch (cmd) {
            case "menu" -> handleMenuCommand(player, args);
            case "shop" -> handleShopCommand(player, args);
            case "claimmenu" -> plugin.getGuiManager().openClaimsDashboard(player);
            case "rtp" -> handleRtpCommand(player, args);
            case "grouprtp" -> handleGroupRtpCommand(player, args);
            case "vault" -> handleVaultCommand(player, args);
            case "graves" -> plugin.getGuiManager().openGravesList(player);
            case "homes" -> plugin.getGuiManager().openEssentialsHomes(player);
            case "trash" -> player.openInventory(Bukkit.createInventory(null, 36, TextUtil.color("&8❖ &7سلة المهملات &8❖")));
        }
        return true;
    }

    private void handleMenuCommand(Player player, String[] args) {
        if (args.length == 0) {
            plugin.getCustomMenuManager().openMainMenu(player);
            return;
        }
        if (!player.hasPermission("survivalplus.admin")) {
            plugin.getCustomMenuManager().openMainMenu(player);
            return;
        }
        if (ArabicUtil.matches(args[0], "add", "اضافة", "اضف")) {
            if (args.length < 3) {
                player.sendMessage(TextUtil.color("&cالاستخدام: &e/menu add <رقم_الخانة_0_44> <الأمر_بدون_سلاش>"));
                return;
            }
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand.getType() == Material.AIR) {
                player.sendMessage(plugin.msg("shop.hold-item"));
                return;
            }
            int slot;
            try {
                slot = Integer.parseInt(args[1]);
                if (slot < 0 || slot >= 45) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                player.sendMessage(TextUtil.color("&cرقم الخانة يجب أن يكون بين 0 و 44."));
                return;
            }
            String cmdToRun = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
            plugin.getCustomMenuManager().addItemFromHand(player, slot, hand, cmdToRun);
            player.sendMessage(TextUtil.color("&a✔ تمت إضافة الزر في الخانة &e" + slot + " &aلتنفيذ أمر: &b/" + cmdToRun));
        } else if (ArabicUtil.matches(args[0], "remove", "حذف", "ازالة")) {
            if (args.length < 2) return;
            try {
                int slot = Integer.parseInt(args[1]);
                if (plugin.getCustomMenuManager().removeSlot(slot)) {
                    player.sendMessage(TextUtil.color("&eتم حذف الزر من الخانة &c" + slot));
                }
            } catch (NumberFormatException ignored) {}
        } else if (ArabicUtil.matches(args[0], "title", "عنوان")) {
            if (args.length < 2) return;
            String title = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
            plugin.getCustomMenuManager().setTitle(title);
            player.sendMessage(TextUtil.color("&a✔ تم تحديث عنوان القائمة الرئيسية!"));
        } else {
            plugin.getCustomMenuManager().openMainMenu(player);
        }
    }

    private void handleShopCommand(Player player, String[] args) {
        if (args.length == 0) {
            plugin.getGuiManager().openShopDirectory(player, 0, ShopManager.SortMode.TOP_SALES);
            return;
        }
        String sub = args[0];

        if (ArabicUtil.matches(sub, "sell", "بيع")) {
            if (args.length < 2) {
                player.sendMessage(TextUtil.color("&cالاستخدام: &e/متجر بيع <السعر> &7أو &e/shop sell <السعر>"));
                return;
            }
            double price;
            try {
                price = Double.parseDouble(args[1]);
            } catch (NumberFormatException e) {
                player.sendMessage(TextUtil.color("&cيرجى إدخال رقم صحيح للسعر!"));
                return;
            }
            plugin.getShopManager().addListing(player, player.getInventory().getItemInMainHand(), price);
        } else if (ArabicUtil.matches(sub, "manage", "ادارة", "متجري", "لوحة")) {
            plugin.getGuiManager().openShopOwnerDashboard(player);
        } else if (ArabicUtil.matches(sub, "icon", "ايقونة", "شكل")) {
            if (!player.hasPermission("survivalplus.shop.icon")) {
                player.sendMessage(plugin.msg("general.no-permission"));
                return;
            }
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand.getType() == Material.AIR) {
                plugin.getGuiManager().openShopIconPicker(player, 0);
            } else {
                PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
                shop.setIconMaterial(hand.getType());
                plugin.getShopManager().save();
                player.sendMessage(TextUtil.color("&a✔ تم تعيين أيقونة متجرك للغرض الممسوك في يدك!"));
            }
        } else if (ArabicUtil.matches(sub, "name", "اسم")) {
            if (args.length < 2) {
                player.sendMessage(TextUtil.color("&cالاستخدام: &e/متجر اسم <الاسم_الجديد>"));
                return;
            }
            String raw = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
            boolean allowColor = player.hasPermission("survivalplus.shop.color");
            String clean = allowColor ? raw : TextUtil.stripColor(raw);
            if (TextUtil.stripColor(clean).length() > 32) {
                player.sendMessage(TextUtil.color("&cالاسم طويل جداً! الحد الأقصى 32 حرفاً."));
                return;
            }
            PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
            shop.setCustomName(allowColor ? clean : "&b" + clean);
            plugin.getShopManager().save();
            player.sendMessage(TextUtil.color("&a✔ تم تحديث اسم متجرك إلى: " + shop.getCustomName()));
        } else if (ArabicUtil.matches(sub, "desc", "وصف")) {
            if (args.length < 2) {
                player.sendMessage(TextUtil.color("&cالاستخدام: &e/متجر وصف <الوصف_الجديد>"));
                return;
            }
            String raw = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
            boolean allowColor = player.hasPermission("survivalplus.shop.color");
            String clean = allowColor ? raw : TextUtil.stripColor(raw);
            if (TextUtil.stripColor(clean).length() > 80) {
                player.sendMessage(TextUtil.color("&cالوصف طويل جداً! الحد الأقصى 80 حرفاً."));
                return;
            }
            PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
            shop.setDescription(allowColor ? clean : "&7" + clean);
            plugin.getShopManager().save();
            player.sendMessage(TextUtil.color("&a✔ تم تحديث وصف متجرك بنجاح!"));
        } else if (ArabicUtil.matches(sub, "boost", "ترويج")) {
            plugin.getShopManager().boostShop(player);
        } else if (ArabicUtil.matches(sub, "toggle", "اغلاق", "فتح")) {
            PlayerShop shop = plugin.getShopManager().getOrCreateShop(player);
            shop.setOpen(!shop.isOpen());
            plugin.getShopManager().save();
            player.sendMessage(TextUtil.color(shop.isOpen() ? "&a✔ تم فتح متجرك للزوار!" : "&eتم إغلاق متجرك مؤقتاً."));
        } else {
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
            PlayerShop shop = plugin.getShopManager().getShop(target.getUniqueId());
            if (shop != null) {
                plugin.getGuiManager().openPlayerShop(player, target.getUniqueId(), true);
            } else {
                player.sendMessage(TextUtil.color("&cلم يتم العثور على متجر بهذا الاسم. اكتب &e/متجر &cلفتح السوق."));
            }
        }
    }

    private void handleRtpCommand(Player player, String[] args) {
        if (args.length >= 2 && ArabicUtil.matches(args[0], "toggle", "تحكم", "تبديل")) {
            if (!player.hasPermission("survivalplus.admin")) {
                player.sendMessage(plugin.msg("general.no-permission"));
                return;
            }
            String dim = null;
            if (ArabicUtil.matches(args[1], "world", "overworld", "عادي")) dim = "overworld";
            else if (ArabicUtil.matches(args[1], "nether", "نذر")) dim = "nether";
            else if (ArabicUtil.matches(args[1], "end", "اند")) dim = "end";

            if (dim == null) {
                player.sendMessage(TextUtil.color("&cالاستخدام: &e/rtp toggle <world|nether|end>"));
                return;
            }
            boolean nowEnabled = plugin.getRtpManager().toggleDimension(dim);
            String disp = plugin.getConfig().getString("rtp.worlds." + dim + ".display-name", dim);
            player.sendMessage(plugin.msg("rtp.admin-toggled",
                    "{world}", disp,
                    "{state}", nowEnabled ? "&aمفعل ✔" : "&cمغلق ✘"));
            return;
        }
        plugin.getGuiManager().openRtpSelector(player);
    }

    private void handleGroupRtpCommand(Player player, String[] args) {
        if (!player.hasPermission("survivalplus.admin")) {
            player.sendMessage(plugin.msg("general.no-permission"));
            return;
        }
        if (args.length == 0) {
            player.sendMessage(TextUtil.color("&cالاستخدام: &e/grouprtp pos1 &7ثم &e/grouprtp pos2 &7لتحديد منطقة الانتقال الجماعي في السباون."));
            return;
        }
        if (ArabicUtil.matches(args[0], "pos1", "1", "زاوية1")) {
            plugin.getRtpManager().setGroupPos(1, player.getLocation());
            player.sendMessage(plugin.msg("group-rtp.pos-set", "{num}", "1"));
        } else if (ArabicUtil.matches(args[0], "pos2", "2", "زاوية2")) {
            plugin.getRtpManager().setGroupPos(2, player.getLocation());
            player.sendMessage(plugin.msg("group-rtp.pos-set", "{num}", "2"));
        }
    }

    private void handleVaultCommand(Player player, String[] args) {
        if (args.length > 0) {
            try {
                int num = Integer.parseInt(args[0]);
                int allowed = plugin.getVaultManager().getAllowedVaults(player);
                if (num < 1 || num > allowed) {
                    player.sendMessage(plugin.msg("vaults.no-access"));
                    return;
                }
                plugin.getVaultManager().openVault(player, player.getUniqueId(), num);
                return;
            } catch (NumberFormatException ignored) {}
        }
        plugin.getGuiManager().openVaultsList(player);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String cmd = command.getName().toLowerCase();
        if (cmd.equals("shop") && args.length == 1) {
            return Arrays.asList("sell", "بيع", "manage", "ادارة", "icon", "ايقونة", "name", "اسم", "desc", "وصف", "boost", "ترويج", "toggle");
        }
        if (cmd.equals("rtp") && args.length == 1 && sender.hasPermission("survivalplus.admin")) {
            return Arrays.asList("toggle", "تحكم");
        }
        if (cmd.equals("rtp") && args.length == 2 && sender.hasPermission("survivalplus.admin")) {
            return Arrays.asList("world", "nether", "end");
        }
        if (cmd.equals("grouprtp") && args.length == 1 && sender.hasPermission("survivalplus.admin")) {
            return Arrays.asList("pos1", "pos2");
        }
        if (cmd.equals("menu") && args.length == 1 && sender.hasPermission("survivalplus.admin")) {
            return Arrays.asList("add", "remove", "title");
        }
        if (cmd.equals("splus") && args.length == 1 && sender.hasPermission("survivalplus.admin")) {
            return Collections.singletonList("reload");
        }
        return Collections.emptyList();
    }
}
