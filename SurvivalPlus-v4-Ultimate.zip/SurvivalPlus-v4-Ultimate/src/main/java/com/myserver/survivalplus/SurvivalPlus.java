package com.myserver.survivalplus;

import com.myserver.survivalplus.commands.CoreCommandExecutor;
import com.myserver.survivalplus.gui.GuiManager;
import com.myserver.survivalplus.listeners.GameplayListener;
import com.myserver.survivalplus.listeners.GuiListener;
import com.myserver.survivalplus.managers.*;
import com.myserver.survivalplus.util.DynamicCommand;
import com.myserver.survivalplus.util.EconomyProvider;
import com.myserver.survivalplus.util.GriefPreventionHook;
import com.myserver.survivalplus.util.VaultEconomyProvider;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;
import java.util.List;

public class SurvivalPlus extends JavaPlugin {
    private EconomyProvider economy = EconomyProvider.NONE;
    private GriefPreventionHook gpHook;
    private MessageManager messageManager;
    private ShopManager shopManager;
    private RtpManager rtpManager;
    private VaultManager vaultManager;
    private GraveManager graveManager;
    private CombatManager combatManager;
    private ChatPromptManager chatPromptManager;
    private CustomMenuManager customMenuManager;
    private GuiManager guiManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.messageManager = new MessageManager(this);

        // ربط اقتصاد Vault (EssentialsX)
        if (getServer().getPluginManager().getPlugin("Vault") != null) {
            VaultEconomyProvider vault = new VaultEconomyProvider();
            if (vault.setup()) {
                this.economy = vault;
                getLogger().info("تم ربط SurvivalPlus بنظام اقتصاد Vault (EssentialsX) بنجاح!");
            }
        }

        // ربط GriefPrevention
        this.gpHook = new GriefPreventionHook();
        if (gpHook.setup()) {
            getLogger().info("تم ربط SurvivalPlus ببلقن GriefPrevention بنجاح!");
        } else {
            getLogger().warning("ملاحظة: بلقن GriefPrevention غير مفعل بعد.");
        }

        this.shopManager = new ShopManager(this);
        this.rtpManager = new RtpManager(this);
        this.vaultManager = new VaultManager(this);
        this.graveManager = new GraveManager(this);
        this.combatManager = new CombatManager(this);
        this.chatPromptManager = new ChatPromptManager(this);
        this.customMenuManager = new CustomMenuManager(this);
        this.guiManager = new GuiManager(this);

        getServer().getPluginManager().registerEvents(new GuiListener(this), this);
        getServer().getPluginManager().registerEvents(new GameplayListener(this), this);

        CoreCommandExecutor executor = new CoreCommandExecutor(this);
        List<String> cmds = Arrays.asList("menu", "shop", "claimmenu", "rtp", "grouprtp", "vault", "graves", "homes", "trash", "splus");
        for (String c : cmds) {
            List<String> aliases = getConfig().getStringList("commands." + c + ".aliases");
            DynamicCommand dyn = new DynamicCommand(c, "أوامر SurvivalPlus", aliases, executor, executor);
            Bukkit.getCommandMap().register("survivalplus", dyn);
        }

        getLogger().info("تم تشغيل بلقن SurvivalPlus v4.0.0 بجميع أنظمته المتكاملة!");
    }

    @Override
    public void onDisable() {
        if (shopManager != null) shopManager.save();
        if (graveManager != null) graveManager.cleanupAllVisuals();
    }

    public Component msg(String path, String... placeholders) {
        return messageManager.get(path, placeholders);
    }

    public String getCurrencySymbol() {
        return getConfig().getString("shop.currency-symbol", "$");
    }

    public EconomyProvider getEconomy() { return economy; }
    public GriefPreventionHook getGpHook() { return gpHook; }
    public MessageManager getMessages() { return messageManager; }
    public ShopManager getShopManager() { return shopManager; }
    public RtpManager getRtpManager() { return rtpManager; }
    public VaultManager getVaultManager() { return vaultManager; }
    public GraveManager getGraveManager() { return graveManager; }
    public CombatManager getCombatManager() { return combatManager; }
    public ChatPromptManager getChatPromptManager() { return chatPromptManager; }
    public CustomMenuManager getCustomMenuManager() { return customMenuManager; }
    public GuiManager getGuiManager() { return guiManager; }
}
