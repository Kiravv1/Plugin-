package com.myserver.survivalplus.listeners;

import com.myserver.survivalplus.SurvivalPlus;
import com.myserver.survivalplus.models.GraveData;
import com.myserver.survivalplus.util.TextUtil;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;

import java.util.Collection;
import java.util.Random;

public class GameplayListener implements Listener {
    private final SurvivalPlus plugin;
    private final Random random = new Random();

    public GameplayListener(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    // ==================== 1. القبور عند الموت والتفاعل معها وحمايتها ====================
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        plugin.getCombatManager().untag(player.getUniqueId());

        if (event.getKeepInventory()) return;
        if (event.getDrops().isEmpty()) return;

        int exp = event.getKeepLevel() ? 0 : calculateTotalExp(player);
        GraveData grave = plugin.getGraveManager().createGrave(player, player.getLocation(), event.getDrops(), exp);
        if (grave != null) {
            event.getDrops().clear();
            if (!event.getKeepLevel()) {
                event.setDroppedExp(0);
            }
        }
    }

    private int calculateTotalExp(Player player) {
        int level = player.getLevel();
        int exp = Math.round(player.getExp() * player.getExpToLevel());
        if (level <= 16) return exp + (level * level + 6 * level);
        if (level <= 31) return exp + (int) (2.5 * level * level - 40.5 * level + 360);
        return exp + (int) (4.5 * level * level - 162.5 * level + 2220);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onGraveInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) return;

        GraveData grave = plugin.getGraveManager().getGraveAtBlock(event.getClickedBlock());
        if (grave != null) {
            event.setCancelled(true);
            plugin.getGraveManager().claimGrave(event.getPlayer(), grave);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGraveBreak(BlockBreakEvent event) {
        if (plugin.getGraveManager().getGraveAtBlock(event.getBlock()) != null) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGraveExplode1(EntityExplodeEvent event) {
        event.blockList().removeIf(b -> plugin.getGraveManager().getGraveAtBlock(b) != null);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGraveExplode2(BlockExplodeEvent event) {
        event.blockList().removeIf(b -> plugin.getGraveManager().getGraveAtBlock(b) != null);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGraveFluid(BlockFromToEvent event) {
        if (plugin.getGraveManager().getGraveAtBlock(event.getToBlock()) != null) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGravePiston1(BlockPistonExtendEvent event) {
        for (Block b : event.getBlocks()) {
            if (plugin.getGraveManager().getGraveAtBlock(b) != null) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGravePiston2(BlockPistonRetractEvent event) {
        for (Block b : event.getBlocks()) {
            if (plugin.getGraveManager().getGraveAtBlock(b) != null) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGraveHopper(InventoryMoveItemEvent event) {
        if (event.getSource().getLocation() != null
                && plugin.getGraveManager().getGraveAtBlock(event.getSource().getLocation().getBlock()) != null) {
            event.setCancelled(true);
        }
    }

    // ==================== 2. الحصاد التلقائي بالمحراث (Auto-Replant with Hoe) ====================
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCropHarvestWithHoe(PlayerInteractEvent event) {
        if (!plugin.getConfig().getBoolean("auto-replant.enabled", true)) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) return;

        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (plugin.getConfig().getBoolean("auto-replant.require-hoe", true) && !isHoe(tool.getType())) {
            return;
        }

        Block block = event.getClickedBlock();
        Material cropType = block.getType();
        if (!isReplantableCrop(cropType)) return;
        if (!(block.getBlockData() instanceof Ageable ageable)) return;
        if (ageable.getAge() < ageable.getMaximumAge()) return;

        // التحقق من صلاحية البناء في GriefPrevention لمنع سرقة مزارع الآخرين!
        if (!plugin.getGpHook().canBuildAt(player, block.getLocation(), cropType)) {
            return;
        }

        event.setCancelled(true);

        Material seedMat = getSeedMaterial(cropType);
        Collection<ItemStack> drops = block.getDrops(tool, player);
        boolean replanted = false;

        for (ItemStack drop : drops) {
            if (!replanted && drop.getType() == seedMat && drop.getAmount() > 0) {
                drop.setAmount(drop.getAmount() - 1);
                replanted = true;
            }
            if (drop.getAmount() > 0) {
                block.getWorld().dropItemNaturally(block.getLocation().add(0.5, 0.3, 0.5), drop);
            }
        }

        if (!replanted) {
            // محاولة سحب بذرة من حقيبة اللاعب
            if (player.getInventory().contains(seedMat)) {
                player.getInventory().removeItem(new ItemStack(seedMat, 1));
                replanted = true;
            }
        }

        if (replanted) {
            ageable.setAge(0);
            block.setBlockData(ageable);
        } else {
            block.setType(Material.AIR);
        }

        block.getWorld().playSound(block.getLocation(), Sound.ITEM_CROP_PLANT, 0.9f, 1.1f);
        block.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, block.getLocation().add(0.5, 0.5, 0.5), 6, 0.25, 0.25, 0.25, 0);

        // استهلاك 1 من تحمل المحراث بشكل طبيعي مع احترام تطويرة Unbreaking
        if (plugin.getConfig().getBoolean("auto-replant.consume-durability", true) && isHoe(tool.getType())) {
            applyNaturalDurability(player, tool);
        }
    }

    private boolean isHoe(Material mat) {
        return mat == Material.WOODEN_HOE || mat == Material.STONE_HOE || mat == Material.IRON_HOE
                || mat == Material.GOLDEN_HOE || mat == Material.DIAMOND_HOE || mat == Material.NETHERITE_HOE;
    }

    private boolean isReplantableCrop(Material mat) {
        return mat == Material.WHEAT || mat == Material.CARROTS || mat == Material.POTATOES
                || mat == Material.BEETROOTS || mat == Material.NETHER_WART;
    }

    private Material getSeedMaterial(Material crop) {
        return switch (crop) {
            case WHEAT -> Material.WHEAT_SEEDS;
            case CARROTS -> Material.CARROT;
            case POTATOES -> Material.POTATO;
            case BEETROOTS -> Material.BEETROOT_SEEDS;
            case NETHER_WART -> Material.NETHER_WART;
            default -> Material.AIR;
        };
    }

    private void applyNaturalDurability(Player player, ItemStack tool) {
        if (player.getGameMode() == GameMode.CREATIVE) return;
        if (!(tool.getItemMeta() instanceof Damageable dmg)) return;
        if (dmg.isUnbreakable()) return;

        int unbreakingLevel = tool.getEnchantmentLevel(Enchantment.UNBREAKING);
        if (unbreakingLevel > 0 && random.nextInt(unbreakingLevel + 1) != 0) {
            return; // لم ينقص التحمل بفضل Unbreaking
        }

        int nextDamage = dmg.getDamage() + 1;
        if (nextDamage >= tool.getType().getMaxDurability()) {
            player.getInventory().setItemInMainHand(null);
            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
        } else {
            dmg.setDamage(nextDamage);
            tool.setItemMeta(dmg);
        }
    }

    // ==================== 3. حماية القتال (Combat Tag) ====================
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPvP(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        Player attacker = null;
        if (event.getDamager() instanceof Player p) {
            attacker = p;
        } else if (event.getDamager() instanceof Projectile proj && proj.getShooter() instanceof Player shooter) {
            attacker = shooter;
        }
        if (attacker == null || attacker.equals(victim)) return;

        plugin.getCombatManager().tag(victim);
        plugin.getCombatManager().tag(attacker);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCombatCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getCombatManager().isInCombat(player)) return;
        if (plugin.getCombatManager().isCommandBlocked(event.getMessage())) {
            event.setCancelled(true);
            long rem = plugin.getCombatManager().getRemainingSeconds(player);
            player.sendMessage(plugin.msg("combat.blocked-command", "{seconds}", String.valueOf(rem)));
        }
    }

    // ==================== 4. جلسات اللاعبين والشات ====================
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        var shop = plugin.getShopManager().getShop(player.getUniqueId());
        if (shop != null) {
            shop.setOwnerName(player.getName());
            if (shop.getPendingOfflineSalesCount() > 0) {
                int count = shop.getPendingOfflineSalesCount();
                double earnings = shop.getPendingOfflineEarnings();
                shop.setPendingOfflineSalesCount(0);
                shop.setPendingOfflineEarnings(0.0);
                plugin.getShopManager().save();

                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (!player.isOnline()) return;
                    player.sendMessage(plugin.msg("shop.offline-earnings",
                            "{count}", String.valueOf(count),
                            "{earnings}", TextUtil.formatMoney(earnings, plugin.getCurrencySymbol())));
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.3f);
                }, 40L);
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getChatPromptManager().hasActivePrompt(player.getUniqueId())) return;
        event.setCancelled(true);
        plugin.getChatPromptManager().handleInput(player, TextUtil.toPlain(event.message()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (plugin.getCombatManager().isInCombat(player)) {
            plugin.getCombatManager().untag(player.getUniqueId());
            if (plugin.getConfig().getBoolean("combat.kill-on-logout", true)) {
                player.setHealth(0.0);
                Bukkit.broadcast(plugin.msg("combat.logout-broadcast", "{player}", player.getName()));
            }
        }
        plugin.getChatPromptManager().cleanupPlayer(player.getUniqueId());
        plugin.getRtpManager().cleanupPlayer(player.getUniqueId());
    }
}
